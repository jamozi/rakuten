# RAOS-CONTENT-001 v0.1 図集

## 1. 記事企画から公開まで

```mermaid
flowchart LR
    Plan[Article Plan] --> Type[Article Type Version]
    Plan --> Intent[Primary Intent / Decision]
    Type --> Packet[Approved Source Packet]
    Packet --> Method[Methodology Version]
    Method --> Draft[Content AST Draft]
    Draft --> Claims[Claim Extraction]
    Claims --> Evidence[Claim-Evidence Validation]
    Evidence --> Reco[Recommendation Validation]
    Reco --> Quality[Quality & Policy Gates]
    Quality --> Review[Human Review]
    Review --> SEO[SEO / Accessibility Validation]
    SEO --> Snapshot[Immutable Publication Snapshot]
    Snapshot --> Renderer[Deterministic Renderer]
    Renderer --> Public[Public Read Model / CDN]
```

## 2. Content ASTの所有境界

```mermaid
flowchart TB
    Editor[Editor / AI Draft] --> Editable[Editorial Blocks]
    Editable --> AST[Versioned Content AST]
    Catalog[Catalog / Offer Projection] --> ProductCard[Renderer-owned Product Card]
    Policy[Policy Bundle] --> Disclosure[Renderer-owned Disclosure]
    Method[Comparison / Recommendation Facts] --> Tables[Renderer-owned Tables]
    AST --> Renderer[Safe Renderer]
    ProductCard --> Renderer
    Disclosure --> Renderer
    Tables --> Renderer
    Renderer --> HTML[Escaped HTML]
    HTML --> JSONLD[Deterministic JSON-LD]
```

## 3. Claimから原本への逆引き

```mermaid
flowchart RL
    Public[公開文] --> Block[Article Block]
    Block --> Claim[Claim]
    Claim --> Link[Claim-Evidence Link]
    Link --> Fact[Fact / Derived Fact]
    Fact --> Snapshot[Source Snapshot]
    Snapshot --> Artifact[Immutable Raw Artifact]
```

## 4. 推薦計算

```mermaid
flowchart TD
    C[Candidate Universe Freeze] --> I[Identity & Evidence Check]
    I --> H{Hard Constraints}
    H -- Fail --> X[Ineligible + reason]
    H -- Pass --> N[Dimension Normalization]
    N --> V[Weighted Evidence Coverage]
    V --> S[Base Suitability Score]
    S --> P[Uncertainty / Conflict / Stale Penalty]
    P --> T{Tie Rule}
    T --> G[Contextual Recommendation Group]
    G --> R[Human Review / Override Audit]
```

## 5. 鮮度とSafe Degradation

```mermaid
stateDiagram-v2
    [*] --> Fresh
    Fresh --> NearExpiry: warning threshold
    NearExpiry --> Fresh: verified refresh
    NearExpiry --> Stale: blocking threshold
    Stale --> Degraded: hide field / CTA
    Degraded --> Fresh: refreshed and validated
    Stale --> Paused: decision basis invalid
    Paused --> Fresh: re-review + publish new snapshot
```

## 6. DisclosureとAffiliate Link

```mermaid
sequenceDiagram
    participant S as Publication Snapshot
    participant P as Policy Bundle
    participant R as Public Renderer
    participant L as Affiliate Link Resource
    participant U as User
    S->>R: approved content + refs
    P->>R: disclosure text + placement
    L->>R: verified direct Rakuten URL
    R-->>U: disclosure at top
    R-->>U: CTA says Rakuten destination
    U->>L: direct navigation
    R-->>R: send non-blocking click beacon
```

## 7. SEO・Structured Data

```mermaid
flowchart LR
    Snapshot[Visible Snapshot] --> Meta[Title/H1/Meta/Canonical]
    Snapshot --> Article[Article/BlogPosting JSON-LD]
    Snapshot --> Bread[BreadcrumbList JSON-LD]
    Snapshot -. prohibited .-> Product[Product/Offer on multi-product page]
    Snapshot -. prohibited .-> FAQ[FAQPage]
    Snapshot -. prohibited .-> Rating[Review/AggregateRating from Rakuten aggregate]
    Meta --> Validate[Contract + visible-content validation]
    Article --> Validate
    Bread --> Validate
```

## 8. 更新・統合・撤退

```mermaid
flowchart TD
    Change[Fact / Policy / Intent change] --> Impact[Impact analysis]
    Impact --> U{Same decision still valid?}
    U -- Yes --> Update[Create new Article Version]
    U -- No --> D{Equivalent canonical exists?}
    D -- Yes --> Merge[Human-approved merge + 301]
    D -- No --> V{Temporary evidence gap?}
    V -- Yes --> Hold[noindex / paused hold]
    V -- No --> Retire[410 or archived route]
```

## 9. 人間レビュー

```mermaid
flowchart LR
    Draft --> Fact[Fact / Identity Review]
    Fact --> Editorial[Editorial Review]
    Editorial --> Compliance[Compliance Review]
    Compliance --> Final[Final Approval]
    Final --> Publish
    Fact --> Changes[Request Changes]
    Editorial --> Changes
    Compliance --> Pause[Pause / Incident]
    Changes --> Draft
```

## 10. Version結合

```mermaid
flowchart TB
    AV[Article Version] --> CSV[Content Schema Version]
    AV --> ATV[Article Type Version]
    AV --> SPV[Source Packet Version]
    AV --> MV[Methodology Version]
    AV --> PB[Policy Bundle Version]
    AV --> SEO[SEO Metadata Version]
    AV --> QR[Quality Result]
    AV --> AP[Approval]
    CSV --> PM[Publication Content Manifest]
    ATV --> PM
    SPV --> PM
    MV --> PM
    PB --> PM
    SEO --> PM
    QR --> PM
    AP --> PM
    PM --> PS[Publication Snapshot]
```
