#!/usr/bin/env python3
"""Reference validator for RAOS-CONTENT-001 contracts.

This script validates syntax, schema registry integrity, fixture behavior,
article-template policy rules, and key invariant separation. It is a reference
implementation for Codex to port into the repository's standard test stack.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def add(result: list[dict[str, Any]], code: str, passed: bool, detail: str) -> None:
    result.append({"code": code, "status": "PASS" if passed else "ERROR", "detail": detail})


def policy_findings(article: dict[str, Any], article_types: dict[str, dict[str, Any]]) -> list[str]:
    findings: list[str] = []
    blocks = article.get("blocks", [])
    types = [b.get("type") for b in blocks]
    block_ids = [b.get("block_id") for b in blocks]

    if not blocks or types[0] != "disclosure_slot":
        findings.append("POL-CONT-008")
    if "source_summary" not in types:
        findings.append("POL-CONT-001")
    if "methodology" not in types:
        findings.append("POL-CONT-019")
    if len(block_ids) != len(set(block_ids)):
        findings.append("POL-CONT-036")

    article_type = article.get("article_type")
    definition = article_types.get(article_type)
    if definition:
        missing = [x for x in definition.get("required_blocks", []) if x not in types]
        # disclosure_slot is renderer-owned and intentionally not repeated in the article-type catalog.
        if missing:
            findings.append("POL-CONT-020")
    else:
        findings.append("POL-CONT-020")
    if any(code in findings for code in {"POL-CONT-001", "POL-CONT-019", "POL-CONT-020", "POL-CONT-036"}):
        findings.append("QG-CONT-003")
    return sorted(set(findings))


def main() -> int:
    results: list[dict[str, Any]] = []

    yaml_files = sorted(ROOT.rglob("*.yaml"))
    json_files = sorted(ROOT.rglob("*.json"))
    for path in yaml_files:
        try:
            load_yaml(path)
        except Exception as exc:  # pragma: no cover - surfaced in report
            add(results, "YAML_PARSE", False, f"{path.relative_to(ROOT)}: {exc}")
    add(results, "YAML_PARSE", not any(x["code"] == "YAML_PARSE" and x["status"] == "ERROR" for x in results), f"{len(yaml_files)} YAML files")

    json_errors = []
    for path in json_files:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            json_errors.append(f"{path.relative_to(ROOT)}: {exc}")
    add(results, "JSON_PARSE", not json_errors, f"{len(json_files)} JSON files" if not json_errors else "; ".join(json_errors))

    registry = load_yaml(ROOT / "RAOS_06_schema_registry_v0.1.yaml")
    ids: set[str] = set()
    reg_errors: list[str] = []
    for entry in registry["schemas"]:
        path = ROOT / entry["path"]
        if not path.exists():
            reg_errors.append(f"missing {entry['path']}")
            continue
        doc = json.loads(path.read_text(encoding="utf-8"))
        try:
            Draft202012Validator.check_schema(doc)
        except Exception as exc:
            reg_errors.append(f"invalid schema {entry['path']}: {exc}")
        if doc.get("$id") != entry["schema_id"]:
            reg_errors.append(f"$id mismatch {entry['path']}")
        if entry["schema_id"] in ids:
            reg_errors.append(f"duplicate $id {entry['schema_id']}")
        ids.add(entry["schema_id"])
        if digest(path) != entry["sha256"]:
            reg_errors.append(f"sha256 mismatch {entry['path']}")
    add(results, "SCHEMA_REGISTRY", not reg_errors, f"{len(registry['schemas'])} schemas" if not reg_errors else "; ".join(reg_errors))

    content_schema = json.loads((ROOT / "schemas/content-ast.schema.json").read_text(encoding="utf-8"))
    content_validator = Draft202012Validator(content_schema)

    valid_errors: list[str] = []
    for path in sorted((ROOT / "fixtures/valid").glob("*.json")):
        article = json.loads(path.read_text(encoding="utf-8"))
        errors = sorted(content_validator.iter_errors(article), key=lambda e: list(e.path))
        if errors:
            valid_errors.append(f"{path.name}: {errors[0].message}")
    add(results, "VALID_FIXTURES", not valid_errors, "5 valid fixtures" if not valid_errors else "; ".join(valid_errors))

    expected = load_yaml(ROOT / "fixtures/invalid/expected_results.yaml")
    schema_fixture_errors: list[str] = []
    policy_fixture_errors: list[str] = []
    article_type_doc = load_yaml(ROOT / "RAOS_06_article_type_catalog_v0.1.yaml")
    article_types = {x["code"]: x for x in article_type_doc["article_types"]}
    for item in expected["fixtures"]:
        path = ROOT / item["path"]
        article = json.loads(path.read_text(encoding="utf-8"))
        errors = list(content_validator.iter_errors(article))
        if item["category"] == "schema":
            if not errors:
                schema_fixture_errors.append(f"{item['code']} unexpectedly passed schema")
        else:
            if errors:
                policy_fixture_errors.append(f"{item['code']} failed schema before policy: {errors[0].message}")
                continue
            findings = policy_findings(article, article_types)
            if item["expected"] not in findings:
                policy_fixture_errors.append(f"{item['code']} expected {item['expected']}, got {findings}")
    add(results, "INVALID_SCHEMA_FIXTURES", not schema_fixture_errors, "10 negative schema fixtures" if not schema_fixture_errors else "; ".join(schema_fixture_errors))
    add(results, "INVALID_POLICY_FIXTURES", not policy_fixture_errors, "5 negative policy fixtures" if not policy_fixture_errors else "; ".join(policy_fixture_errors))

    block_catalog = load_yaml(ROOT / "RAOS_06_content_block_catalog_v0.1.yaml")
    known_blocks = {x["code"] for x in block_catalog["blocks"]}
    template_errors: list[str] = []
    for definition in article_type_doc["article_types"]:
        template_path = ROOT / definition["template"]
        if not template_path.exists():
            template_errors.append(f"missing {definition['template']}")
            continue
        template = load_yaml(template_path)
        if template.get("article_type") != definition["code"]:
            template_errors.append(f"article_type mismatch {definition['template']}")
        required = set(definition["required_blocks"])
        unknown = required - known_blocks
        if unknown:
            template_errors.append(f"unknown required block {definition['code']}: {sorted(unknown)}")
        template_required = set(template.get("required_sequence", [])) - {"disclosure_slot"}
        if required != template_required:
            template_errors.append(f"required block drift {definition['code']}")
    add(results, "ARTICLE_TEMPLATES", not template_errors, "5 templates" if not template_errors else "; ".join(template_errors))

    recommendation = load_yaml(ROOT / "RAOS_06_recommendation_methodology_v0.1.yaml")
    rec_text = json.dumps(recommendation, ensure_ascii=False).lower()
    prohibited_terms = ["affiliate_rate", "commission", "revenue", "contribution_profit", "epc", "rpm"]
    # Terms must appear in an explicit deny/prohibited context, not in formula inputs.
    formula_text = json.dumps(recommendation.get("formula", {}), ensure_ascii=False).lower()
    leaked = [t for t in prohibited_terms if t in formula_text]
    add(results, "RECOMMENDATION_FINANCE_ISOLATION", not leaked, "finance inputs excluded" if not leaked else f"found in formula: {leaked}")

    schema_text = (ROOT / "schemas/content-ast.schema.json").read_text(encoding="utf-8").lower()
    prohibited_fields = ["raw_html", "affiliate_url", "review_body", "review_text", "commission", "affiliate_rate"]
    field_leaks = [x for x in prohibited_fields if f'\"{x}\"' in schema_text]
    add(results, "CONTENT_AST_PROHIBITED_FIELDS", not field_leaks, "no forbidden fields" if not field_leaks else f"found: {field_leaks}")

    test_path = ROOT / "RAOS_06_content_test_matrix_v0.1.csv"
    trace_path = ROOT / "RAOS_06_traceability_matrix_v0.1.csv"
    with test_path.open(encoding="utf-8-sig", newline="") as f:
        tests = list(csv.DictReader(f))
    with trace_path.open(encoding="utf-8-sig", newline="") as f:
        traces = list(csv.DictReader(f))
    add(results, "TEST_MATRIX", len(tests) >= 1000 and len({x["test_id"] for x in tests}) == len(tests), f"{len(tests)} unique tests")
    add(results, "TRACEABILITY", len(traces) >= 100 and all(x.get("requirement_id") and x.get("artifact") for x in traces), f"{len(traces)} rows")

    errors = [x for x in results if x["status"] == "ERROR"]
    payload = {
        "document": "RAOS-CONTENT-VALIDATION-RESULT",
        "root": str(ROOT),
        "summary": {"pass": len(results) - len(errors), "error": len(errors)},
        "checks": results,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
