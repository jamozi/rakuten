# RAOS-CONTENT-001 v0.1

## 目的

本Packageは、RAOSの公開記事を「文章ファイル」ではなく、検索意図、商品候補集合、比較方法、Claim、Evidence、広告表示、CTA、鮮度、SEO、Human Approvalを束ねた**監査可能なContent Product**として実装するための契約正本です。

## 最初に読む順序

1. `RAOS_06_README_v0.1.md`
2. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
3. `upstream/RAOS_02_system_architecture_v0.1.md`
4. `upstream/RAOS_03_data_model_database_design_v0.1.md`
5. `upstream/RAOS_04_api_event_job_contract_design_v0.1.md`
6. `upstream/RAOS_05_ai_agent_prompt_routing_evaluation_design_v0.1.md`
7. `RAOS_06_content_editorial_evidence_design_v0.1.md`
8. `RAOS_06_article_type_catalog_v0.1.yaml`
9. `RAOS_06_content_block_catalog_v0.1.yaml`
10. `RAOS_06_claim_evidence_policy_v0.1.yaml`
11. `RAOS_06_recommendation_methodology_v0.1.yaml`
12. `RAOS_06_editorial_policy_catalog_v0.1.yaml`
13. `schemas/**`, `templates/**`, `fixtures/**`
14. `RAOS_06_implementation_slices_v0.1.yaml`
15. `RAOS_06_CODEX_KICKOFF_v0.1.md`

## 正本順位

1. 法令、楽天規約・ガイドライン
2. `RAOS-REQ-001`
3. `RAOS-ARCH-001`
4. `RAOS-DATA-001`
5. `RAOS-API-001`
6. `RAOS-AI-001`
7. 本PackageのMarkdown設計書
8. 本Packageの機械可読Catalog／JSON Schema
9. Template／Fixture／参考実装

矛盾を検出した場合、下位成果物を黙って変更せず、Decision Record候補とAlignment Patchを提出してください。

## Package構成

```text
.
├── RAOS_06_content_editorial_evidence_design_v0.1.md
├── RAOS_06_*_catalog_v0.1.yaml
├── RAOS_06_*_policy_v0.1.yaml
├── RAOS_06_content_test_matrix_v0.1.csv
├── RAOS_06_traceability_matrix_v0.1.csv
├── schemas/
├── templates/
├── fixtures/
├── reference/
├── proposals/
└── upstream/
```

## 不変条件

- Contentの正本をRaw HTML、任意Markdown、LLM出力文字列へ簡略化しない。
- Content ASTにRaw HTML escape hatchを追加しない。
- Affiliate URLはLLM入力・出力や編集本文へ入れず、Rendererが承認済みOfferから解決する。
- Disclosure SlotはRenderer所有であり、編集者やAIが削除・移動できない。
- 楽天レビュー本文を取得、保存、要約、言い換え、引用しない。
- 実機Evidenceがない記事を「レビュー」「使ってみた」「検証済み」と表示しない。
- 推薦Scoreへ料率、報酬、EPC、RPM、利益を入力しない。
- UnknownまたはStaleなFactを推測で埋めない。
- AIに承認、公開、Policy解除、Kill Switch解除を許可しない。
- Proposal SQL／YAMLを本番へ直接適用しない。

## ローカル検証

```bash
python reference/validate_content_contracts.py
```

このValidatorは参考実装です。CodexはRepository標準のLint、JSON Schema、Python、TypeScript、Contract Testへ同等以上の検査を移植してください。

## Proposalの扱い

- `RAOS_06_001_data_alignment_patch_v0.1.sql`
- `RAOS_06_002_api_alignment_patch_v0.1.yaml`
- `RAOS_06_003_ai_alignment_patch_v0.1.yaml`

上記は`PROPOSAL_ONLY`です。Migration／OpenAPI／AsyncAPI／AI Contract正本へ直接適用せず、上位設計との互換性確認、Integration Test、Reviewを経て別Versionとして採用してください。
