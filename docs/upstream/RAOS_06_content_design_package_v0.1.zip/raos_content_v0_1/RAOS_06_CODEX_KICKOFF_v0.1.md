# RAOS-CONTENT-001 Codex Kickoff

## 今回の実装範囲

`CONT-SLICE-001: Content contract repository bootstrap`だけを実装してください。

## コード変更前に提示するもの

1. 読み込んだ上位・Content契約ファイル一覧
2. 発見した矛盾、曖昧点、Schema Drift
3. 変更予定ファイル
4. Test計画
5. 今回の対象外

## 実装対象

- `contracts/content/catalogs/**`
- `contracts/content/schemas/**`
- `contracts/content/templates/**`
- `contracts/content/fixtures/**`
- YAML／JSON／CSV構文検査
- JSON Schema Draft 2020-12 Meta Validation
- Schema RegistryのPath／`$id`／SHA-256検査
- 5正常Fixtureと15異常Fixtureの検査
- Article Type、Block、TemplateのCross-reference検査
- Python／TypeScript型生成の再現可能な設定
- Generated Artifact Drift検査
- Secret、楽天レビュー本文、Raw HTML、手書きAffiliate URLの禁止Scan
- CI Workflow
- CODEOWNERS、PR Template、Contract Change Checklist

## 最初のPRで実装しないもの

- 記事生成Business Logic
- OpenAIへの実通信
- Renderer／公開Web UI
- Recommendation Scoreの本番計算
- DB Migrationの適用
- OpenAPI／AsyncAPI正本変更
- WordPress連携
- 楽天API Live Call
- Search Console／GA4連携
- 自動公開
- Production Deployment

## 必須Test

- 全SchemaのDraft 2020-12 Validation
- `$id`一意性
- Relative `$ref`解決
- Registry Hash一致
- 全正常FixtureがSchema合格
- Schema異常Fixtureが期待どおり失敗
- Policy異常Fixtureが期待Policy Codeで失敗
- Unknown Field fail-closed
- Raw HTML禁止
- Manual Affiliate URL禁止
- Disclosure Slot固定
- Finance fieldがRecommendation／Content Schemaへ混入しない
- 生成物の二回生成でGit差分なし

## Definition of Done

- CIがClean Checkoutから再現可能
- Contract生成物に未コミット差分なし
- P0 Testが全件合格
- Proposal Patchを本番正本へ適用していない
- 上位Requirement IDとDesign IDがTestへ紐付いている
- PR本文に不変条件、残課題、次Sliceへの依存を記載

## 禁止事項

- 仕様を「記事Markdownテンプレート」だけへ縮退しない。
- Schemaで表現しにくいPolicyを削除せず、Policy Validatorとして実装する。
- FixtureをTestが通るように書き換えて不具合を隠さない。
- Affiliate URL、料率、報酬、レビュー本文をPromptやContent ASTへ追加しない。
- Human Approvalを省略しない。
