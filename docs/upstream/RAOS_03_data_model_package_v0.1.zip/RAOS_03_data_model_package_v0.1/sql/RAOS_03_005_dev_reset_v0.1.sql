-- DEVELOPMENT/EPHEMERAL ENVIRONMENTS ONLY. Never grant this to application roles.
DO $$
BEGIN
  IF current_setting('raos.allow_destructive_reset', true) IS DISTINCT FROM 'on' THEN
    RAISE EXCEPTION 'set raos.allow_destructive_reset=on explicitly in an ephemeral database';
  END IF;
  IF current_database() !~ '(dev|test|ci|ephemeral)' THEN
    RAISE EXCEPTION 'database name does not look ephemeral: %', current_database();
  END IF;
END $$;

DROP SCHEMA IF EXISTS readmodel CASCADE;
DROP SCHEMA IF EXISTS finance CASCADE;
DROP SCHEMA IF EXISTS analytics CASCADE;
DROP SCHEMA IF EXISTS freshness CASCADE;
DROP SCHEMA IF EXISTS publishing CASCADE;
DROP SCHEMA IF EXISTS policy CASCADE;
DROP SCHEMA IF EXISTS ai CASCADE;
DROP SCHEMA IF EXISTS editorial CASCADE;
DROP SCHEMA IF EXISTS evidence CASCADE;
DROP SCHEMA IF EXISTS catalog CASCADE;
DROP SCHEMA IF EXISTS portfolio CASCADE;
DROP SCHEMA IF EXISTS iam CASCADE;
DROP SCHEMA IF EXISTS ops CASCADE;
