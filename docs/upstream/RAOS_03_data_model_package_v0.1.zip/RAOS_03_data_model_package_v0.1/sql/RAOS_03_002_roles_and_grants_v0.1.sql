-- RAOS-DATA-001 database roles and grants
-- Run as the database owner after the baseline DDL. No LOGIN roles or credentials are created here.
BEGIN;
SET LOCAL lock_timeout = '5s';

DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_migrator') THEN CREATE ROLE raos_migrator NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_api_rw') THEN CREATE ROLE raos_api_rw NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_worker_rw') THEN CREATE ROLE raos_worker_rw NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_dispatcher_rw') THEN CREATE ROLE raos_dispatcher_rw NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_projection_rw') THEN CREATE ROLE raos_projection_rw NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_public_ro') THEN CREATE ROLE raos_public_ro NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_reporting_ro') THEN CREATE ROLE raos_reporting_ro NOLOGIN; END IF; END $$;
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='raos_auditor_ro') THEN CREATE ROLE raos_auditor_ro NOLOGIN; END IF; END $$;

REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;

REVOKE ALL ON SCHEMA ops FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA ops FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA ops FROM PUBLIC;
REVOKE ALL ON SCHEMA iam FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA iam FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA iam FROM PUBLIC;
REVOKE ALL ON SCHEMA portfolio FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA portfolio FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA portfolio FROM PUBLIC;
REVOKE ALL ON SCHEMA catalog FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA catalog FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA catalog FROM PUBLIC;
REVOKE ALL ON SCHEMA evidence FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA evidence FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA evidence FROM PUBLIC;
REVOKE ALL ON SCHEMA editorial FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA editorial FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA editorial FROM PUBLIC;
REVOKE ALL ON SCHEMA ai FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA ai FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA ai FROM PUBLIC;
REVOKE ALL ON SCHEMA policy FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA policy FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA policy FROM PUBLIC;
REVOKE ALL ON SCHEMA publishing FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA publishing FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA publishing FROM PUBLIC;
REVOKE ALL ON SCHEMA freshness FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA freshness FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA freshness FROM PUBLIC;
REVOKE ALL ON SCHEMA analytics FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA analytics FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA analytics FROM PUBLIC;
REVOKE ALL ON SCHEMA finance FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA finance FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA finance FROM PUBLIC;
REVOKE ALL ON SCHEMA readmodel FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA readmodel FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA readmodel FROM PUBLIC;

-- Application/API role. It never reads public-only projection through a broader owner connection.
GRANT USAGE ON SCHEMA iam, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance, ops TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA ops TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA iam TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA portfolio TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA catalog TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA evidence TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA editorial TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA ai TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA policy TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA publishing TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA freshness TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA analytics TO raos_api_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA finance TO raos_api_rw;
REVOKE DELETE ON ALL TABLES IN SCHEMA ops, iam, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance FROM raos_api_rw;
GRANT EXECUTE ON FUNCTION ai.guard_approved_source_packet(), publishing.guard_final_approval(), publishing.guard_publication_candidate(), publishing.guard_publication_transition() TO raos_api_rw;

-- Worker role for deterministic jobs and adapters.
GRANT USAGE ON SCHEMA ops, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA ops TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA portfolio TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA catalog TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA evidence TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA editorial TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA ai TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA policy TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA publishing TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA freshness TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA analytics TO raos_worker_rw;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA finance TO raos_worker_rw;
REVOKE DELETE ON ALL TABLES IN SCHEMA ops, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance FROM raos_worker_rw;

-- Outbox dispatcher has narrowly scoped queue permissions.
GRANT USAGE ON SCHEMA ops TO raos_dispatcher_rw;
GRANT SELECT, UPDATE ON ops.outbox_event, ops.job TO raos_dispatcher_rw;
GRANT SELECT, INSERT ON ops.inbox_receipt, ops.job_attempt, ops.audit_event TO raos_dispatcher_rw;

-- Projection writer may read systems of record and replace regenerable read models.
GRANT USAGE ON SCHEMA ops TO raos_projection_rw;
GRANT USAGE ON SCHEMA iam TO raos_projection_rw;
GRANT USAGE ON SCHEMA portfolio TO raos_projection_rw;
GRANT USAGE ON SCHEMA catalog TO raos_projection_rw;
GRANT USAGE ON SCHEMA evidence TO raos_projection_rw;
GRANT USAGE ON SCHEMA editorial TO raos_projection_rw;
GRANT USAGE ON SCHEMA ai TO raos_projection_rw;
GRANT USAGE ON SCHEMA policy TO raos_projection_rw;
GRANT USAGE ON SCHEMA publishing TO raos_projection_rw;
GRANT USAGE ON SCHEMA freshness TO raos_projection_rw;
GRANT USAGE ON SCHEMA analytics TO raos_projection_rw;
GRANT USAGE ON SCHEMA finance TO raos_projection_rw;
GRANT USAGE ON SCHEMA readmodel TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA ops TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA iam TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA portfolio TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA catalog TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA evidence TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA editorial TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA ai TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA policy TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA publishing TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA freshness TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics TO raos_projection_rw;
GRANT SELECT ON ALL TABLES IN SCHEMA finance TO raos_projection_rw;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA readmodel TO raos_projection_rw;

-- Public renderer is intentionally blind to editorial, evidence, AI, analytics and finance schemas.
GRANT USAGE ON SCHEMA readmodel TO raos_public_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA readmodel TO raos_public_ro;

-- Reporting and audit roles.
GRANT USAGE ON SCHEMA analytics, finance, readmodel, portfolio, editorial, publishing TO raos_reporting_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA analytics, finance, readmodel, portfolio, editorial, publishing TO raos_reporting_ro;
GRANT USAGE ON SCHEMA ops, iam, policy, publishing, evidence TO raos_auditor_ro;
GRANT SELECT ON ops.audit_event, ops.audit_export, ops.incident, ops.incident_event, ops.kill_switch_change, ops.release TO raos_auditor_ro;
GRANT SELECT ON iam.principal, iam.principal_role_assignment, iam.break_glass_record TO raos_auditor_ro;
GRANT SELECT ON policy.policy_bundle, policy.rule_version, policy.quality_check_run, policy.finding, policy.quality_score, policy.waiver, policy.gate_decision TO raos_auditor_ro;
GRANT SELECT ON publishing.review_assignment, publishing.review_decision, publishing.approval, publishing.publication_snapshot, publishing.publication_event, publishing.rollback_record TO raos_auditor_ro;
GRANT SELECT ON evidence.source_packet_version, evidence.claim, evidence.claim_evidence_link TO raos_auditor_ro;

-- Default privileges must be executed by the same owner that will create future objects.
ALTER DEFAULT PRIVILEGES IN SCHEMA ops GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA iam GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA portfolio GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA catalog GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA evidence GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA editorial GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA ai GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA policy GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA publishing GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA freshness GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA analytics GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA finance GRANT SELECT ON TABLES TO raos_projection_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA readmodel GRANT SELECT ON TABLES TO raos_public_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA readmodel GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO raos_projection_rw;

COMMIT;
