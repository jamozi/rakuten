-- RAOS-DATA-001 post-deploy validation queries
-- Execute in CI and capture the result as an artifact. Any exception is a failed deployment.
DO $$
DECLARE n bigint;
BEGIN
  SELECT count(*) INTO n FROM information_schema.tables
   WHERE table_schema IN ('ops', 'iam', 'portfolio', 'catalog', 'evidence', 'editorial', 'ai', 'policy', 'publishing', 'freshness', 'analytics', 'finance', 'readmodel') AND table_type='BASE TABLE';
  IF n <> 130 THEN RAISE EXCEPTION 'expected 130 RAOS tables, found %', n; END IF;

  SELECT count(*) INTO n FROM pg_constraint c JOIN pg_namespace nsp ON nsp.oid=c.connamespace
   WHERE nsp.nspname IN ('ops', 'iam', 'portfolio', 'catalog', 'evidence', 'editorial', 'ai', 'policy', 'publishing', 'freshness', 'analytics', 'finance', 'readmodel') AND c.contype='f';
  IF n <> 357 THEN RAISE EXCEPTION 'expected 357 foreign keys, found %', n; END IF;

  IF has_schema_privilege('raos_public_ro','editorial','USAGE')
     OR has_schema_privilege('raos_public_ro','finance','USAGE')
     OR has_schema_privilege('raos_public_ro','evidence','USAGE') THEN
     RAISE EXCEPTION 'public role has forbidden internal schema access';
  END IF;

  IF NOT has_schema_privilege('raos_public_ro','readmodel','USAGE') THEN
     RAISE EXCEPTION 'public role lacks readmodel access';
  END IF;
END $$;

-- The following SELECTs must return zero rows.
SELECT 'open publication without snapshot' AS violation, id
  FROM publishing.publication WHERE state='PUBLISHED' AND current_snapshot_id IS NULL;

SELECT 'public offer with enabled CTA but no affiliate URL' AS violation, id
  FROM readmodel.public_offer WHERE is_cta_enabled AND affiliate_url IS NULL;

SELECT 'passed quality score with invalid mandatory subscores' AS violation, id
  FROM policy.quality_score
 WHERE passed AND (total_score < pass_score OR factual_accuracy_score < 18 OR disclosure_policy_score <> 5);

SELECT 'unbalanced attribution commission' AS violation, commission_id
  FROM analytics.attribution_estimate WHERE status='APPROVED'
 GROUP BY commission_id HAVING abs(sum(allocation_ratio)-1) > 0.0000000001;

SELECT 'unbalanced cost allocation source' AS violation, source_type, source_id, period_month
  FROM finance.cost_allocation
 GROUP BY source_type, source_id, period_month HAVING sum(allocation_ratio) > 1.0000000001;
