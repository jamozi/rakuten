from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable
import csv
import datetime as dt
import hashlib
import json
import os
import re
import textwrap
import zipfile

import yaml

BASE = Path('/mnt/data')
OUT = BASE / 'raos_data_v0_1'
OUT.mkdir(parents=True, exist_ok=True)

DOC_DATE = '2026-07-30'
VERSION = '0.1'
PG_TARGET = '18.4'

SCHEMA_ORDER = [
    'ops', 'iam', 'portfolio', 'catalog', 'evidence', 'editorial',
    'ai', 'policy', 'publishing', 'freshness', 'analytics', 'finance', 'readmodel'
]

SCHEMA_META = {
    'ops': ('Operations', 'ジョブ、原本レジストリ、監査、障害、Kill Switch、実行時設定'),
    'iam': ('Identity and Access', 'OIDC主体、アプリケーションRole、権限、緊急アクセス'),
    'portfolio': ('Portfolio', 'サイト、カテゴリ、検索意図、キーワード、機会評価、優先アクション'),
    'catalog': ('Catalog', '楽天取得、商品同定、ショップ、Offer、外部事実Observation、Current Projection'),
    'evidence': ('Evidence', 'Source、Snapshot、Fact、Source Packet、Claim、根拠対応'),
    'editorial': ('Editorial', '記事企画、構造化記事版、比較、推薦、レビューコメント、内部リンク'),
    'ai': ('AI Orchestration', 'AI Task、Prompt、Schema、Model Route、Job、Attempt、Token・費用、評価'),
    'policy': ('Quality and Policy', 'Policy Bundle、Rule、品質検査、Finding、Score、Waiver、Gate'),
    'publishing': ('Publishing', '人間Review、Approval、Publication Snapshot、公開状態、Route、Rollback'),
    'freshness': ('Freshness', '鮮度SLA、Refresh、Staleness、Affiliate Link検査、影響分析'),
    'analytics': ('Analytics', '匿名行動、楽天クリック、GSC・GA4取込、帰属推定、日次指標'),
    'finance': ('Finance', '成果原本取込、発生・確定・取消、費用配賦、確定ユニットエコノミクス'),
    'readmodel': ('Public Read Model', '公開Rendererが読む安全な再生成可能Projection'),
}

COMMON_DESCRIPTIONS = {
    'id': '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。',
    'display_id': '人間が画面・ログ・問い合わせで使用する不変の表示ID。',
    'created_at': 'レコード作成時刻。UTCのtimestamptz。',
    'updated_at': '最終更新時刻。UTCのtimestamptz。',
    'lock_version': '楽観的排他制御用の単調増加Version。',
    'status': '業務状態を示す安定Enum文字列。',
    'metadata': '検索対象を限定した補助メタデータ。原本や秘密を格納しない。',
    'site_id': '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。',
    'category_id': '対象カテゴリ。',
    'article_id': '論理記事ID。',
    'article_version_id': '記事の特定Version。',
    'product_id': '正規化されたCanonical Product。',
    'offer_id': 'ショップ単位の販売Offer。',
    'job_id': '非同期Job。',
    'artifact_id': 'S3互換Object Storage上の不変Artifactレジストリ。',
    'created_by_principal_id': '作成操作を行ったIAM Principal。',
    'updated_by_principal_id': '最終更新操作を行ったIAM Principal。',
    'correlation_id': '要求・Job・Eventを横断して追跡するCorrelation ID。',
    'causation_id': 'この事実を直接発生させたCommand/Event/Job ID。',
    'version_no': 'Aggregate内で1から増加する不変Version番号。',
    'effective_from': '設定・関係が有効になる時刻。',
    'effective_to': '設定・関係の有効終了時刻。NULLは終了未定。',
}

@dataclass
class Column:
    name: str
    sql_type: str
    nullable: bool = True
    default: str | None = None
    description: str = ''
    classification: str = 'INTERNAL'
    pii: bool = False

    def desc(self) -> str:
        return self.description or COMMON_DESCRIPTIONS.get(self.name, self.name.replace('_', ' '))

@dataclass
class ForeignKey:
    columns: list[str]
    ref_schema: str
    ref_table: str
    ref_columns: list[str]
    on_delete: str = 'RESTRICT'
    deferrable: bool = False
    initially_deferred: bool = False
    name: str | None = None

@dataclass
class Index:
    name: str
    columns: list[str] = field(default_factory=list)
    expression: str | None = None
    unique: bool = False
    method: str = 'btree'
    where: str | None = None
    include: list[str] = field(default_factory=list)
    nulls_not_distinct: bool = False
    description: str = ''

@dataclass
class Table:
    schema: str
    name: str
    purpose: str
    columns: list[Column]
    pk: list[str] = field(default_factory=lambda: ['id'])
    uniques: list[tuple[str, list[str]]] = field(default_factory=list)
    checks: list[tuple[str, str]] = field(default_factory=list)
    fks: list[ForeignKey] = field(default_factory=list)
    indexes: list[Index] = field(default_factory=list)
    write_pattern: str = 'MUTABLE'  # MUTABLE | APPEND_ONLY | PROJECTION | REFERENCE
    classification: str = 'INTERNAL'
    retention_class: str = 'BUSINESS_CORE'
    requirements: list[str] = field(default_factory=list)
    architecture_refs: list[str] = field(default_factory=list)
    implementation_slice: str = ''
    owner_module: str = ''
    expected_gate1_rows: str = '<1k'
    expected_gate4_rows: str = '<100k'
    partitioning: str = 'NONE_MVP'
    notes: list[str] = field(default_factory=list)

    @property
    def fq(self) -> str:
        return f'{self.schema}.{self.name}'

TABLES: list[Table] = []


def c(name: str, sql_type: str, *, nullable: bool = True, default: str | None = None,
      description: str = '', classification: str = 'INTERNAL', pii: bool = False) -> Column:
    return Column(name, sql_type, nullable, default, description, classification, pii)


def id_col() -> Column:
    return c('id', 'uuid', nullable=False, default='uuidv7()')


def display_col(prefix: str) -> Column:
    return c('display_id', 'text', nullable=False,
             description=f'{prefix}-接頭辞を持つアプリケーション生成の不変表示ID。')


def created_col() -> Column:
    return c('created_at', 'timestamptz', nullable=False, default='CURRENT_TIMESTAMP')


def mutable_tail() -> list[Column]:
    return [
        created_col(),
        c('updated_at', 'timestamptz', nullable=False, default='CURRENT_TIMESTAMP'),
        c('lock_version', 'bigint', nullable=False, default='0'),
    ]


def immutable_tail() -> list[Column]:
    return [created_col()]


def json_obj(name: str, *, nullable: bool = False, default: str = "'{}'::jsonb",
             description: str = '', classification: str = 'INTERNAL') -> Column:
    return c(name, 'jsonb', nullable=nullable, default=default if not nullable else None,
             description=description, classification=classification)


def add(t: Table) -> None:
    if not t.owner_module:
        t.owner_module = t.schema
    TABLES.append(t)


def fk(cols: str | Iterable[str], ref: str, ref_cols: str | Iterable[str] = 'id',
       *, on_delete: str = 'RESTRICT', deferrable: bool = False,
       initially_deferred: bool = False, name: str | None = None) -> ForeignKey:
    cols_l = [cols] if isinstance(cols, str) else list(cols)
    ref_cols_l = [ref_cols] if isinstance(ref_cols, str) else list(ref_cols)
    rs, rt = ref.split('.', 1)
    return ForeignKey(cols_l, rs, rt, ref_cols_l, on_delete, deferrable, initially_deferred, name)


def idx(name: str, cols: Iterable[str] | None = None, *, expression: str | None = None,
        unique: bool = False, method: str = 'btree', where: str | None = None,
        include: Iterable[str] | None = None, nulls_not_distinct: bool = False,
        description: str = '') -> Index:
    return Index(name, list(cols or []), expression, unique, method, where,
                 list(include or []), nulls_not_distinct, description)


def enum_check(column: str, values: Iterable[str]) -> str:
    vals = ', '.join("'" + v.replace("'", "''") + "'" for v in values)
    return f"{column} IN ({vals})"


def score_check(column: str) -> str:
    return f'{column} >= 0 AND {column} <= 100'


def hash_check(column: str) -> str:
    return f"{column} ~ '^[0-9a-f]{{64}}$'"


def json_object_check(column: str) -> str:
    return f"jsonb_typeof({column}) = 'object'"


def json_array_check(column: str) -> str:
    return f"jsonb_typeof({column}) = 'array'"


def exactly_one(*columns: str) -> str:
    return 'num_nonnulls(' + ', '.join(columns) + ') = 1'


def at_most_one(*columns: str) -> str:
    return 'num_nonnulls(' + ', '.join(columns) + ') <= 1'


def ensure_fk_indexes() -> None:
    for t in TABLES:
        existing_prefixes = []
        if t.pk:
            existing_prefixes.append(tuple(t.pk))
        existing_prefixes.extend(tuple(cols) for _, cols in t.uniques)
        existing_prefixes.extend(tuple(i.columns) for i in t.indexes if i.columns)
        for f in t.fks:
            cols = tuple(f.columns)
            if not any(pref[:len(cols)] == cols for pref in existing_prefixes):
                name = f"ix_{t.schema}_{t.name}_{'_'.join(f.columns)}"
                t.indexes.append(idx(name, f.columns, description='Foreign key lookup and parent delete/update check.'))
                existing_prefixes.append(cols)

# ---------------------------------------------------------------------------
# OPS SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'ops', 'object_artifact',
    'S3互換Object Storage上の原本・入力・出力・公開Snapshotを登録する不変レジストリ。',
    [
        id_col(), display_col('OBJ'),
        c('artifact_kind', 'text', nullable=False, description='raw_provider_response、source_snapshot、source_packet、ai_input、ai_output、publication_snapshot、revenue_original、audit_export等。'),
        c('storage_provider', 'text', nullable=False, default="'s3'"),
        c('bucket_name', 'text', nullable=False),
        c('object_key', 'text', nullable=False),
        c('object_version', 'text', nullable=True, description='Object VersioningのVersion ID。ローカル環境ではNULL可。'),
        c('content_type', 'text', nullable=False),
        c('byte_size', 'bigint', nullable=False),
        c('sha256', 'text', nullable=False),
        c('encryption_state', 'text', nullable=False),
        c('retention_class', 'text', nullable=False),
        c('is_immutable', 'boolean', nullable=False, default='true'),
        c('source_system', 'text', nullable=False),
        c('acquired_at', 'timestamptz', nullable=True),
        c('created_by_principal_id', 'uuid', nullable=True, classification='CONFIDENTIAL'),
        json_obj('metadata', description='Objectタグ、parser、provider request ID等。秘密・原本文は含めない。'),
        created_col(),
    ],
    uniques=[('uq_ops_object_artifact_display_id', ['display_id'])],
    checks=[
        ('ck_ops_object_artifact_kind', enum_check('artifact_kind', [
            'raw_provider_response','raw_primary_source','source_snapshot','source_packet',
            'ai_input','ai_output','publication_snapshot','revenue_original','revenue_rejects',
            'audit_export','quality_report','diff','import_report','other'])),
        ('ck_ops_object_artifact_size', 'byte_size >= 0'),
        ('ck_ops_object_artifact_sha', hash_check('sha256')),
        ('ck_ops_object_artifact_enc', enum_check('encryption_state', ['SSE_KMS','SSE_S3','LOCAL_DEV'])),
        ('ck_ops_object_artifact_meta', json_object_check('metadata')),
    ],
    indexes=[
        idx('uq_ops_object_artifact_location', ['bucket_name','object_key','object_version'], unique=True, nulls_not_distinct=True),
        idx('ix_ops_object_artifact_sha', ['sha256']),
        idx('ix_ops_object_artifact_kind_created', ['artifact_kind','created_at']),
    ],
    write_pattern='APPEND_ONLY', classification='CONFIDENTIAL', retention_class='BY_ARTIFACT_KIND',
    requirements=['FR-002','FR-004','FR-018','FR-020','NFR-DATA-001','NFR-BACKUP-001'],
    implementation_slice='SLICE-007', expected_gate1_rows='<10k', expected_gate4_rows='<10m',
    notes=['DBには原本本文を保存せず、URI・Version・hash・metadataのみを保存する。']
))

add(Table(
    'ops', 'job', '非同期作業の業務上の正本。Scheduler、API、Eventから作成され、Attemptとは分離する。',
    [
        id_col(), display_col('JOB'),
        c('job_type', 'text', nullable=False), c('queue_name', 'text', nullable=False),
        c('status', 'text', nullable=False, default="'PENDING'"),
        c('priority', 'smallint', nullable=False, default='50'),
        c('idempotency_key', 'text', nullable=True),
        c('site_id', 'uuid', nullable=True),
        c('aggregate_type', 'text', nullable=True), c('aggregate_id', 'uuid', nullable=True),
        json_obj('payload', description='小さなCommand payload。大容量入力はpayload_artifact_idへ分離する。'),
        c('payload_artifact_id', 'uuid', nullable=True),
        c('scheduled_at', 'timestamptz', nullable=True),
        c('available_at', 'timestamptz', nullable=False, default='CURRENT_TIMESTAMP'),
        c('started_at', 'timestamptz', nullable=True), c('completed_at', 'timestamptz', nullable=True),
        c('max_attempts', 'smallint', nullable=False, default='5'),
        c('attempt_count', 'smallint', nullable=False, default='0'),
        c('lease_owner', 'text', nullable=True), c('lease_expires_at', 'timestamptz', nullable=True),
        c('correlation_id', 'uuid', nullable=False, default='uuidv7()'),
        c('causation_id', 'uuid', nullable=True), c('parent_job_id', 'uuid', nullable=True),
        c('budget_jpy', 'bigint', nullable=True),
        c('created_by_actor_type', 'text', nullable=False), c('created_by_actor_id', 'uuid', nullable=True),
        c('last_error_class', 'text', nullable=True), c('last_error_code', 'text', nullable=True),
        c('last_error_message', 'text', nullable=True, classification='CONFIDENTIAL'),
        *mutable_tail(),
    ],
    uniques=[('uq_ops_job_display_id', ['display_id'])],
    checks=[
        ('ck_ops_job_status', enum_check('status', ['PENDING','READY','RUNNING','SUCCEEDED','FAILED','CANCELLED','QUARANTINED'])),
        ('ck_ops_job_priority', 'priority BETWEEN 0 AND 100'),
        ('ck_ops_job_attempts', 'max_attempts BETWEEN 1 AND 50 AND attempt_count BETWEEN 0 AND max_attempts'),
        ('ck_ops_job_budget', 'budget_jpy IS NULL OR budget_jpy >= 0'),
        ('ck_ops_job_payload', json_object_check('payload')),
        ('ck_ops_job_lease_pair', '(lease_owner IS NULL) = (lease_expires_at IS NULL)'),
        ('ck_ops_job_completion', "status NOT IN ('SUCCEEDED','FAILED','CANCELLED','QUARANTINED') OR completed_at IS NOT NULL"),
        ('ck_ops_job_version', 'lock_version >= 0'),
    ],
    fks=[
        fk('payload_artifact_id','ops.object_artifact', on_delete='RESTRICT'),
        fk('parent_job_id','ops.job', on_delete='SET NULL'),
        fk('site_id','portfolio.site', on_delete='RESTRICT'),
    ],
    indexes=[
        idx('uq_ops_job_idempotency', ['job_type','idempotency_key'], unique=True, where='idempotency_key IS NOT NULL'),
        idx('ix_ops_job_ready', ['queue_name','priority','available_at'], where="status IN ('PENDING','READY')"),
        idx('ix_ops_job_lease', ['lease_expires_at'], where="status = 'RUNNING'"),
        idx('ix_ops_job_aggregate', ['aggregate_type','aggregate_id']),
        idx('ix_ops_job_correlation', ['correlation_id']),
    ],
    write_pattern='MUTABLE', classification='CONFIDENTIAL', retention_class='OPS_JOB_2Y',
    requirements=['NFR-REL-001','NFR-REL-002','FR-018','FR-020'],
    implementation_slice='SLICE-004', expected_gate1_rows='<50k', expected_gate4_rows='<50m',
    partitioning='CANDIDATE_BY_CREATED_AT_AFTER_10M'
))

add(Table(
    'ops', 'job_attempt', 'Jobの各実行Attemptを追記保存し、Retry、Provider call、入出力Artifact、失敗原因を再現可能にする。',
    [
        id_col(), c('job_id','uuid',nullable=False), c('attempt_no','smallint',nullable=False),
        c('status','text',nullable=False), c('worker_id','text',nullable=False),
        c('handler_version','text',nullable=False), c('started_at','timestamptz',nullable=False),
        c('completed_at','timestamptz',nullable=True), c('provider_request_id','text',nullable=True),
        c('input_artifact_id','uuid',nullable=True), c('output_artifact_id','uuid',nullable=True),
        c('error_class','text',nullable=True), c('error_code','text',nullable=True),
        c('error_message','text',nullable=True,classification='CONFIDENTIAL'),
        c('retry_after_at','timestamptz',nullable=True),
        json_obj('metrics', description='Duration、row count、provider quota等の低カーディナリティ指標。'),
        created_col(),
    ],
    uniques=[('uq_ops_job_attempt_no',['job_id','attempt_no'])],
    checks=[
        ('ck_ops_job_attempt_status', enum_check('status',['RUNNING','SUCCEEDED','FAILED','CANCELLED','TIMED_OUT'])),
        ('ck_ops_job_attempt_no','attempt_no >= 1'),
        ('ck_ops_job_attempt_metrics', json_object_check('metrics')),
        ('ck_ops_job_attempt_end', "status = 'RUNNING' OR completed_at IS NOT NULL"),
    ],
    fks=[fk('job_id','ops.job',on_delete='RESTRICT'),fk('input_artifact_id','ops.object_artifact'),fk('output_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_ops_job_attempt_started',['started_at']),idx('ix_ops_job_attempt_status',['status','started_at'])],
    write_pattern='APPEND_ONLY', classification='CONFIDENTIAL', retention_class='OPS_JOB_2Y',
    requirements=['NFR-REL-001','NFR-OBS-001','FR-018'], implementation_slice='SLICE-004',
    expected_gate1_rows='<100k', expected_gate4_rows='<100m', partitioning='CANDIDATE_BY_STARTED_AT_AFTER_20M'
))

add(Table(
    'ops','outbox_event','業務TransactionとEvent発行を原子的に接続するTransactional Outbox。',
    [
        id_col(), c('event_type','text',nullable=False), c('event_version','integer',nullable=False,default='1'),
        c('producer','text',nullable=False), c('aggregate_type','text',nullable=False), c('aggregate_id','uuid',nullable=False),
        c('aggregate_version','bigint',nullable=False), c('correlation_id','uuid',nullable=False), c('causation_id','uuid',nullable=True),
        c('actor_type','text',nullable=False), c('actor_id','uuid',nullable=True),
        json_obj('payload', description='Version付きEvent payload。秘密・大容量原本を含めない。'),
        c('payload_schema_hash','text',nullable=False), c('status','text',nullable=False,default="'PENDING'"),
        c('available_at','timestamptz',nullable=False,default='CURRENT_TIMESTAMP'), c('published_at','timestamptz',nullable=True),
        c('publish_attempts','smallint',nullable=False,default='0'), c('last_error','text',nullable=True,classification='CONFIDENTIAL'),
        created_col(),
    ],
    checks=[
        ('ck_ops_outbox_event_version','event_version >= 1 AND aggregate_version >= 0'),
        ('ck_ops_outbox_payload',json_object_check('payload')),('ck_ops_outbox_hash',hash_check('payload_schema_hash')),
        ('ck_ops_outbox_status',enum_check('status',['PENDING','DISPATCHING','PUBLISHED','FAILED','DEAD'])),
        ('ck_ops_outbox_attempts','publish_attempts >= 0'),
        ('ck_ops_outbox_published',"status <> 'PUBLISHED' OR published_at IS NOT NULL"),
    ],
    indexes=[
        idx('ix_ops_outbox_ready',['status','available_at'],where="status IN ('PENDING','FAILED')"),
        idx('ix_ops_outbox_aggregate',['aggregate_type','aggregate_id','aggregate_version']),
        idx('ix_ops_outbox_correlation',['correlation_id']),
        idx('ix_ops_outbox_created_brin',['created_at'],method='brin'),
    ],
    write_pattern='MUTABLE', classification='CONFIDENTIAL', retention_class='OUTBOX_180D',
    requirements=['NFR-REL-001','FR-020'],implementation_slice='SLICE-004',expected_gate1_rows='<100k',expected_gate4_rows='<100m',
    partitioning='CANDIDATE_MONTHLY_AFTER_20M'
))

add(Table(
    'ops','inbox_receipt','Consumer単位でEvent処理済みを記録し、at-least-once配送の重複を無害化する。',
    [
        id_col(), c('consumer_name','text',nullable=False), c('handler_version','text',nullable=False),
        c('event_id','uuid',nullable=False), c('status','text',nullable=False),
        c('received_at','timestamptz',nullable=False,default='CURRENT_TIMESTAMP'), c('processed_at','timestamptz',nullable=True),
        c('result_hash','text',nullable=True), c('error_code','text',nullable=True),
        created_col(),
    ],
    uniques=[('uq_ops_inbox_receipt',['consumer_name','handler_version','event_id'])],
    checks=[
        ('ck_ops_inbox_status',enum_check('status',['PROCESSING','PROCESSED','FAILED','IGNORED'])),
        ('ck_ops_inbox_hash',"result_hash IS NULL OR " + hash_check('result_hash')),
        ('ck_ops_inbox_processed',"status = 'PROCESSING' OR processed_at IS NOT NULL"),
    ],
    indexes=[idx('ix_ops_inbox_event',['event_id']),idx('ix_ops_inbox_received',['received_at'])],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='INBOX_400D',
    requirements=['NFR-REL-001'],implementation_slice='SLICE-004',expected_gate1_rows='<100k',expected_gate4_rows='<100m',
    partitioning='CANDIDATE_MONTHLY_AFTER_20M'
))

add(Table(
    'ops','idempotency_record','HTTP Command等の二重送信を検出し、同じKey＋同じpayloadへ同じ結果を返す。',
    [
        id_col(), c('actor_fingerprint','text',nullable=False,classification='CONFIDENTIAL'), c('route_key','text',nullable=False),
        c('idempotency_key','text',nullable=False), c('request_hash','text',nullable=False), c('status','text',nullable=False,default="'IN_PROGRESS'"),
        c('response_status','integer',nullable=True), json_obj('response_body',nullable=True,default="'{}'::jsonb",description='小さな再送応答。大きい応答はArtifactへ保存。'),
        c('response_artifact_id','uuid',nullable=True), c('resource_type','text',nullable=True), c('resource_id','uuid',nullable=True),
        c('expires_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_ops_idempotency',['actor_fingerprint','route_key','idempotency_key'])],
    checks=[
        ('ck_ops_idem_request_hash',hash_check('request_hash')),('ck_ops_idem_status',enum_check('status',['IN_PROGRESS','COMPLETED','FAILED'])),
        ('ck_ops_idem_response',"status = 'IN_PROGRESS' OR response_status IS NOT NULL"),
        ('ck_ops_idem_expiry','expires_at > created_at'),
        ('ck_ops_idem_response_body',"response_body IS NULL OR jsonb_typeof(response_body) = 'object'"),
    ],
    fks=[fk('response_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_ops_idempotency_expiry',['expires_at'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='IDEMPOTENCY_UNTIL_EXPIRY',
    requirements=['NFR-REL-001'],implementation_slice='SLICE-004',expected_gate1_rows='<50k',expected_gate4_rows='<10m'
))

add(Table(
    'ops','audit_event','管理操作・自動化操作・権限変更・公開・Kill Switch等を追記記録する監査正本。',
    [
        id_col(), c('occurred_at','timestamptz',nullable=False), c('actor_type','text',nullable=False),
        c('actor_id','uuid',nullable=True,classification='CONFIDENTIAL'), c('action','text',nullable=False),
        c('target_type','text',nullable=False), c('target_id','uuid',nullable=True), c('outcome','text',nullable=False),
        c('severity','text',nullable=False,default="'INFO'"), c('correlation_id','uuid',nullable=False),
        c('request_id','text',nullable=True), c('before_hash','text',nullable=True), c('after_hash','text',nullable=True),
        json_obj('details',description='差分要約、理由、Policy/Prompt版。秘密、原文、raw IPは含めない。',classification='CONFIDENTIAL'),
        created_col(),
    ],
    checks=[
        ('ck_ops_audit_actor',enum_check('actor_type',['USER','SERVICE','SCHEDULE','SYSTEM','ANONYMOUS'])),
        ('ck_ops_audit_outcome',enum_check('outcome',['SUCCESS','DENIED','FAILED','NOOP'])),
        ('ck_ops_audit_severity',enum_check('severity',['INFO','NOTICE','WARNING','CRITICAL'])),
        ('ck_ops_audit_before_hash',"before_hash IS NULL OR " + hash_check('before_hash')),
        ('ck_ops_audit_after_hash',"after_hash IS NULL OR " + hash_check('after_hash')),
        ('ck_ops_audit_details',json_object_check('details')),
    ],
    indexes=[
        idx('ix_ops_audit_occurred',['occurred_at']),idx('ix_ops_audit_actor',['actor_type','actor_id','occurred_at']),
        idx('ix_ops_audit_target',['target_type','target_id','occurred_at']),idx('ix_ops_audit_corr',['correlation_id']),
        idx('ix_ops_audit_occurred_brin',['occurred_at'],method='brin'),
    ],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',
    requirements=['FR-020','NFR-AUD-001'],implementation_slice='SLICE-004',expected_gate1_rows='<500k',expected_gate4_rows='<500m',
    partitioning='MONTHLY_AT_GATE3_OR_20M_ROWS',notes=['raw IPアドレス、完全なUser-Agent、Secretを保存しない。']
))

add(Table(
    'ops','audit_export','Audit Eventの定期不変Export、件数、範囲、manifest hashを登録する。',
    [
        id_col(), display_col('AEX'), c('period_start','timestamptz',nullable=False), c('period_end','timestamptz',nullable=False),
        c('artifact_id','uuid',nullable=False), c('event_count','bigint',nullable=False), c('first_event_id','uuid',nullable=True),
        c('last_event_id','uuid',nullable=True), c('manifest_sha256','text',nullable=False), c('status','text',nullable=False),
        c('completed_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_ops_audit_export_display',['display_id']),('uq_ops_audit_export_period',['period_start','period_end'])],
    checks=[
        ('ck_ops_audit_export_period','period_end > period_start'),('ck_ops_audit_export_count','event_count >= 0'),
        ('ck_ops_audit_export_hash',hash_check('manifest_sha256')),('ck_ops_audit_export_status',enum_check('status',['CREATING','COMPLETED','FAILED','VERIFIED'])),
    ],
    fks=[fk('artifact_id','ops.object_artifact')],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',
    requirements=['NFR-AUD-001','NFR-BACKUP-001'],implementation_slice='SLICE-023',expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'ops','alert','監視・契約変更・データ品質・鮮度・SecurityのAlertを重複集約する。',
    [
        id_col(), c('alert_key','text',nullable=False), c('severity','text',nullable=False), c('status','text',nullable=False,default="'OPEN'"),
        c('source','text',nullable=False), c('title','text',nullable=False), c('description','text',nullable=False,classification='CONFIDENTIAL'),
        c('first_seen_at','timestamptz',nullable=False), c('last_seen_at','timestamptz',nullable=False), c('occurrence_count','bigint',nullable=False,default='1'),
        c('incident_id','uuid',nullable=True), json_obj('metadata',classification='CONFIDENTIAL'),
        c('acknowledged_by_principal_id','uuid',nullable=True), c('acknowledged_at','timestamptz',nullable=True), c('resolved_at','timestamptz',nullable=True),
        *mutable_tail(),
    ],
    checks=[
        ('ck_ops_alert_severity',enum_check('severity',['P0','P1','P2','P3'])),('ck_ops_alert_status',enum_check('status',['OPEN','ACKNOWLEDGED','RESOLVED','SUPPRESSED'])),
        ('ck_ops_alert_count','occurrence_count >= 1'),('ck_ops_alert_times','last_seen_at >= first_seen_at'),('ck_ops_alert_meta',json_object_check('metadata')),
    ],
    fks=[fk('incident_id','ops.incident',on_delete='SET NULL'),fk('acknowledged_by_principal_id','iam.principal')],
    indexes=[idx('uq_ops_alert_open_key',['alert_key'],unique=True,where="status IN ('OPEN','ACKNOWLEDGED')"),idx('ix_ops_alert_status',['status','severity','last_seen_at'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='OPS_ALERT_2Y',requirements=['NFR-OBS-001','FR-019'],
    implementation_slice='SLICE-023',expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'ops','incident','重大障害・規約・誤送客・Security事象のライフサイクル正本。',
    [
        id_col(), display_col('INC'), c('severity','text',nullable=False), c('status','text',nullable=False),
        c('title','text',nullable=False), c('summary','text',nullable=False,classification='RESTRICTED'),
        c('declared_at','timestamptz',nullable=False), c('declared_by_principal_id','uuid',nullable=False),
        c('commander_principal_id','uuid',nullable=True), c('contained_at','timestamptz',nullable=True), c('recovered_at','timestamptz',nullable=True),
        c('closed_at','timestamptz',nullable=True), c('root_cause','text',nullable=True,classification='RESTRICTED'),
        json_obj('impact',description='影響ページ、期間、件数、金額、ユーザー影響の構造化要約。',classification='RESTRICTED'),
        *mutable_tail(),
    ],
    uniques=[('uq_ops_incident_display',['display_id'])],
    checks=[
        ('ck_ops_incident_severity',enum_check('severity',['P0','P1','P2','P3'])),
        ('ck_ops_incident_status',enum_check('status',['DECLARED','CONTAINING','CONTAINED','RECOVERING','MONITORING','CLOSED','REOPENED'])),
        ('ck_ops_incident_impact',json_object_check('impact')),('ck_ops_incident_version','lock_version >= 0'),
    ],
    fks=[fk('declared_by_principal_id','iam.principal'),fk('commander_principal_id','iam.principal')],
    indexes=[idx('ix_ops_incident_status',['status','severity','declared_at'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='INCIDENT_7Y_PROVISIONAL',requirements=['FR-019','FR-020'],
    implementation_slice='SLICE-022',expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'ops','incident_event','IncidentのContainment、判断、復旧、再発防止等の時系列イベント。',
    [
        id_col(), c('incident_id','uuid',nullable=False), c('event_type','text',nullable=False),
        c('note','text',nullable=False,classification='RESTRICTED'), c('actor_principal_id','uuid',nullable=False),
        json_obj('metadata',classification='RESTRICTED'), c('occurred_at','timestamptz',nullable=False), created_col(),
    ],
    checks=[('ck_ops_incident_event_type',enum_check('event_type',['NOTE','STATUS_CHANGE','CONTAINMENT','DECISION','RECOVERY','EVIDENCE','ACTION_ITEM'])),('ck_ops_incident_event_meta',json_object_check('metadata'))],
    fks=[fk('incident_id','ops.incident'),fk('actor_principal_id','iam.principal')],
    indexes=[idx('ix_ops_incident_event_timeline',['incident_id','occurred_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='INCIDENT_7Y_PROVISIONAL',requirements=['FR-019','FR-020'],
    implementation_slice='SLICE-022',expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'ops','kill_switch','Publication、Affiliate Link、Providerをglobal/site/category/article/provider scopeで緊急停止する現在状態。',
    [
        id_col(), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=True), c('switch_type','text',nullable=False),
        c('is_engaged','boolean',nullable=False,default='false'), c('generation','bigint',nullable=False,default='0'),
        c('reason','text',nullable=True,classification='RESTRICTED'), c('incident_id','uuid',nullable=True),
        c('changed_at','timestamptz',nullable=False,default='CURRENT_TIMESTAMP'), c('changed_by_principal_id','uuid',nullable=True),
        c('expires_at','timestamptz',nullable=True), *mutable_tail(),
    ],
    checks=[
        ('ck_ops_kill_scope',enum_check('scope_type',['GLOBAL','SITE','CATEGORY','ARTICLE','PROVIDER'])),
        ('ck_ops_kill_scope_id',"(scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)"),
        ('ck_ops_kill_type',enum_check('switch_type',['PUBLICATION','AFFILIATE_LINK','PROVIDER_CALL'])),
        ('ck_ops_kill_generation','generation >= 0'),('ck_ops_kill_version','lock_version >= 0'),
    ],
    fks=[fk('incident_id','ops.incident',on_delete='SET NULL'),fk('changed_by_principal_id','iam.principal')],
    indexes=[
        idx('uq_ops_kill_scope',['scope_type','scope_id','switch_type'],unique=True,nulls_not_distinct=True),
        idx('ix_ops_kill_engaged',['switch_type','is_engaged'],where='is_engaged = true'),
    ],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='BUSINESS_CORE',requirements=['FR-019'],
    implementation_slice='SLICE-022',expected_gate1_rows='<1k',expected_gate4_rows='<100k',
    notes=['PublicationとAffiliate Linkの停止は必ず別レコード・別switch_typeで管理する。']
))

add(Table(
    'ops','kill_switch_change','Kill Switch変更を追記保存し、誰が、なぜ、どのgenerationへ変更したかを残す。',
    [
        id_col(), c('kill_switch_id','uuid',nullable=False), c('previous_engaged','boolean',nullable=False), c('new_engaged','boolean',nullable=False),
        c('previous_generation','bigint',nullable=False), c('new_generation','bigint',nullable=False), c('reason','text',nullable=False,classification='RESTRICTED'),
        c('incident_id','uuid',nullable=True), c('actor_principal_id','uuid',nullable=False), c('occurred_at','timestamptz',nullable=False), created_col(),
    ],
    checks=[('ck_ops_kill_change_generation','new_generation = previous_generation + 1'),('ck_ops_kill_change_state','new_engaged <> previous_engaged')],
    fks=[fk('kill_switch_id','ops.kill_switch'),fk('incident_id','ops.incident',on_delete='SET NULL'),fk('actor_principal_id','iam.principal')],
    indexes=[idx('ix_ops_kill_change_timeline',['kill_switch_id','occurred_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-019','FR-020'],
    implementation_slice='SLICE-022',expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'ops','runtime_setting_version','Feature Flag、閾値、Provider version、SLA等の非秘密設定をVersion管理する。',
    [
        id_col(), c('setting_key','text',nullable=False), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=True),
        c('version_no','integer',nullable=False), c('setting_class','text',nullable=False), json_obj('value',classification='CONFIDENTIAL'),
        c('value_sha256','text',nullable=False), c('status','text',nullable=False), c('effective_from','timestamptz',nullable=True),
        c('effective_to','timestamptz',nullable=True), c('created_by_principal_id','uuid',nullable=False),
        c('approved_by_principal_id','uuid',nullable=True), c('approval_reason','text',nullable=True), created_col(),
    ],
    uniques=[('uq_ops_setting_version',['setting_key','scope_type','scope_id','version_no'])],
    checks=[
        ('ck_ops_setting_scope',enum_check('scope_type',['GLOBAL','SITE','CATEGORY','ARTICLE','PROVIDER','TASK'])),
        ('ck_ops_setting_scope_id',"(scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)"),
        ('ck_ops_setting_version','version_no >= 1'),('ck_ops_setting_class',enum_check('setting_class',['FEATURE_FLAG','THRESHOLD','PROVIDER','FRESHNESS','BUDGET','UI','OTHER'])),
        ('ck_ops_setting_no_secret',"setting_class <> 'SECRET'"),('ck_ops_setting_value',json_object_check('value')),('ck_ops_setting_hash',hash_check('value_sha256')),
        ('ck_ops_setting_status',enum_check('status',['DRAFT','ACTIVE','RETIRED','REJECTED'])),
        ('ck_ops_setting_window','effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from'),
    ],
    fks=[fk('created_by_principal_id','iam.principal'),fk('approved_by_principal_id','iam.principal')],
    indexes=[
        idx('uq_ops_setting_active',['setting_key','scope_type','scope_id'],unique=True,nulls_not_distinct=True,where="status = 'ACTIVE'"),
        idx('ix_ops_setting_lookup',['setting_key','status','effective_from']),
    ],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONFIG_7Y',requirements=['NFR-MAINT-001','FR-019','FR-020'],
    implementation_slice='SLICE-004',expected_gate1_rows='<10k',expected_gate4_rows='<1m',notes=['Secret値はSecrets Managerへ置き、本テーブルでのsetting_class=SECRETを禁止する。']
))

add(Table(
    'ops','retention_policy','Data Classごとの保持、匿名化、削除、Legal Hold可否をVersion付きで定義する。',
    [
        id_col(), c('retention_class','text',nullable=False), c('policy_version','integer',nullable=False),
        c('data_classification','text',nullable=False), c('duration_days','integer',nullable=True), c('delete_mode','text',nullable=False),
        c('legal_hold_supported','boolean',nullable=False,default='true'), c('status','text',nullable=False),
        c('notes','text',nullable=True,classification='CONFIDENTIAL'), c('effective_from','timestamptz',nullable=False),
        c('effective_to','timestamptz',nullable=True), c('approved_by_principal_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_ops_retention_version',['retention_class','policy_version'])],
    checks=[
        ('ck_ops_retention_version','policy_version >= 1'),('ck_ops_retention_duration','duration_days IS NULL OR duration_days >= 1'),
        ('ck_ops_retention_classification',enum_check('data_classification',['PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED'])),
        ('ck_ops_retention_mode',enum_check('delete_mode',['HARD_DELETE','ANONYMIZE','ARCHIVE_THEN_DELETE','RETAIN'])),
        ('ck_ops_retention_status',enum_check('status',['DRAFT','ACTIVE','RETIRED'])),('ck_ops_retention_window','effective_to IS NULL OR effective_to > effective_from'),
    ],
    fks=[fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('uq_ops_retention_active',['retention_class'],unique=True,where="status = 'ACTIVE'")],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONFIG_7Y',requirements=['NFR-DATA-001','NFR-BACKUP-001'],
    implementation_slice='SLICE-025',expected_gate1_rows='<1k',expected_gate4_rows='<10k',notes=['法務・税務確認前の年数はProvisionalとして扱い、コード固定しない。']
))

add(Table(
    'ops','release','Git SHA、Container image、DB revision、環境、Rollback関係を記録するRelease台帳。',
    [
        id_col(), display_col('REL'), c('release_version','text',nullable=False), c('git_sha','text',nullable=False),
        json_obj('image_digests',description='web/api/worker image digest。'), c('database_revision','text',nullable=False),
        c('environment','text',nullable=False), c('status','text',nullable=False), c('deployed_at','timestamptz',nullable=True),
        c('deployed_by_principal_id','uuid',nullable=True), c('rollback_of_release_id','uuid',nullable=True),
        c('manifest_artifact_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_ops_release_display',['display_id']),('uq_ops_release_env_version',['environment','release_version'])],
    checks=[
        ('ck_ops_release_git',"git_sha ~ '^[0-9a-f]{40,64}$'"),('ck_ops_release_images',json_object_check('image_digests')),
        ('ck_ops_release_env',enum_check('environment',['LOCAL','CI','STAGING','PRODUCTION'])),('ck_ops_release_status',enum_check('status',['BUILT','DEPLOYING','DEPLOYED','FAILED','ROLLED_BACK'])),
    ],
    fks=[fk('deployed_by_principal_id','iam.principal'),fk('rollback_of_release_id','ops.release',on_delete='SET NULL'),fk('manifest_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_ops_release_env_deployed',['environment','deployed_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='RELEASE_7Y',requirements=['NFR-MAINT-001','NFR-AUD-001'],
    implementation_slice='SLICE-024',expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

# ---------------------------------------------------------------------------
# IAM SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'iam','principal','管理ユーザーとService Principalを共通IDで表すIAM Root。PasswordやSecretは保持しない。',
    [
        id_col(), display_col('PRN'), c('principal_type','text',nullable=False), c('status','text',nullable=False,default="'ACTIVE'"),
        c('display_name','text',nullable=False), c('deactivated_at','timestamptz',nullable=True), c('deactivation_reason','text',nullable=True,classification='RESTRICTED'),
        *mutable_tail(),
    ],
    uniques=[('uq_iam_principal_display',['display_id'])],
    checks=[
        ('ck_iam_principal_type',enum_check('principal_type',['USER','SERVICE'])),
        ('ck_iam_principal_status',enum_check('status',['ACTIVE','SUSPENDED','DEACTIVATED'])),
        ('ck_iam_principal_deactivation',"status <> 'DEACTIVATED' OR deactivated_at IS NOT NULL"),
        ('ck_iam_principal_version','lock_version >= 0'),
    ],
    indexes=[idx('ix_iam_principal_status',['status','principal_type'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='IAM_LIFECYCLE',requirements=['NFR-SEC-002','FR-020'],
    implementation_slice='SLICE-005',expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

add(Table(
    'iam','user_account','OIDC UserのIssuer/Subject、表示用Email、MFA claim等をPrincipalへ紐付ける。',
    [
        c('principal_id','uuid',nullable=False), c('oidc_issuer','text',nullable=False,classification='RESTRICTED'),
        c('oidc_subject','text',nullable=False,classification='RESTRICTED'), c('email','text',nullable=True,classification='RESTRICTED',pii=True),
        c('email_verified','boolean',nullable=False,default='false'), c('mfa_required','boolean',nullable=False,default='true'),
        c('last_login_at','timestamptz',nullable=True), c('last_mfa_at','timestamptz',nullable=True), created_col(),
    ],
    pk=['principal_id'], uniques=[('uq_iam_user_oidc',['oidc_issuer','oidc_subject'])],
    checks=[('ck_iam_user_https_issuer',"oidc_issuer ~ '^https://'")],
    fks=[fk('principal_id','iam.principal',on_delete='RESTRICT')],
    indexes=[idx('ix_iam_user_email_lower',expression='lower(email)',where='email IS NOT NULL')],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='IAM_LIFECYCLE',requirements=['NFR-SEC-002'],
    implementation_slice='SLICE-005',expected_gate1_rows='<100',expected_gate4_rows='<10k',notes=['EmailはRecipient解決・表示の補助であり認証正本はIssuer+Subject。']
))

add(Table(
    'iam','service_principal','Worker、Dispatcher、CI等のWorkload IdentityをPrincipalへ紐付ける。Credential本体はSecrets Manager/OIDCに置く。',
    [
        c('principal_id','uuid',nullable=False), c('service_code','text',nullable=False), c('workload_identity','text',nullable=False,classification='RESTRICTED'),
        c('allowed_environment','text',nullable=False), c('credential_rotated_at','timestamptz',nullable=True),
        c('last_used_at','timestamptz',nullable=True), created_col(),
    ],
    pk=['principal_id'], uniques=[('uq_iam_service_code',['service_code']),('uq_iam_service_workload',['workload_identity','allowed_environment'])],
    checks=[('ck_iam_service_env',enum_check('allowed_environment',['LOCAL','CI','STAGING','PRODUCTION']))],
    fks=[fk('principal_id','iam.principal')],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='IAM_LIFECYCLE',requirements=['NFR-SEC-001','NFR-SEC-002'],
    implementation_slice='SLICE-005',expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

add(Table(
    'iam','role','RAOSアプリケーション内Roleの定義。DB Roleとは分離する。',
    [id_col(), c('role_code','text',nullable=False), c('name','text',nullable=False), c('description','text',nullable=False),
     c('is_system_role','boolean',nullable=False,default='true'), c('status','text',nullable=False,default="'ACTIVE'"), created_col()],
    uniques=[('uq_iam_role_code',['role_code'])], checks=[('ck_iam_role_status',enum_check('status',['ACTIVE','RETIRED']))],
    write_pattern='REFERENCE',classification='INTERNAL',retention_class='CONFIG_7Y',requirements=['NFR-SEC-002'],implementation_slice='SLICE-005',
    expected_gate1_rows='<100',expected_gate4_rows='<1k'
))

add(Table(
    'iam','permission','API/Command単位の安定Permission code。',
    [id_col(), c('permission_code','text',nullable=False), c('description','text',nullable=False), c('risk_level','text',nullable=False),
     c('status','text',nullable=False,default="'ACTIVE'"), created_col()],
    uniques=[('uq_iam_permission_code',['permission_code'])],
    checks=[('ck_iam_permission_risk',enum_check('risk_level',['LOW','MEDIUM','HIGH','CRITICAL'])),('ck_iam_permission_status',enum_check('status',['ACTIVE','RETIRED']))],
    write_pattern='REFERENCE',classification='INTERNAL',retention_class='CONFIG_7Y',requirements=['NFR-SEC-002'],implementation_slice='SLICE-005',
    expected_gate1_rows='<500',expected_gate4_rows='<5k'
))

add(Table(
    'iam','role_permission','RoleとPermissionの多対多対応。',
    [c('role_id','uuid',nullable=False),c('permission_id','uuid',nullable=False),created_col()],
    pk=['role_id','permission_id'],fks=[fk('role_id','iam.role'),fk('permission_id','iam.permission')],
    write_pattern='REFERENCE',classification='INTERNAL',retention_class='CONFIG_7Y',requirements=['NFR-SEC-002'],implementation_slice='SLICE-005',
    expected_gate1_rows='<5k',expected_gate4_rows='<50k'
))

add(Table(
    'iam','principal_role_assignment','Principalへglobal/site/category/article scopeのRoleを期限付き付与する。',
    [
        id_col(), c('principal_id','uuid',nullable=False), c('role_id','uuid',nullable=False), c('scope_type','text',nullable=False),
        c('scope_id','uuid',nullable=True), c('valid_from','timestamptz',nullable=False,default='CURRENT_TIMESTAMP'), c('valid_to','timestamptz',nullable=True),
        c('assigned_by_principal_id','uuid',nullable=False), c('assignment_reason','text',nullable=False,classification='RESTRICTED'),
        c('revoked_at','timestamptz',nullable=True), c('revoked_by_principal_id','uuid',nullable=True), c('revocation_reason','text',nullable=True,classification='RESTRICTED'),
        created_col(),
    ],
    checks=[
        ('ck_iam_assignment_scope',enum_check('scope_type',['GLOBAL','SITE','CATEGORY','ARTICLE'])),
        ('ck_iam_assignment_scope_id',"(scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)"),
        ('ck_iam_assignment_window','valid_to IS NULL OR valid_to > valid_from'),
        ('ck_iam_assignment_revoke_pair','(revoked_at IS NULL) = (revoked_by_principal_id IS NULL)'),
    ],
    fks=[fk('principal_id','iam.principal'),fk('role_id','iam.role'),fk('assigned_by_principal_id','iam.principal'),fk('revoked_by_principal_id','iam.principal')],
    indexes=[
        idx('uq_iam_assignment_active',['principal_id','role_id','scope_type','scope_id'],unique=True,nulls_not_distinct=True,where='revoked_at IS NULL'),
        idx('ix_iam_assignment_lookup',['principal_id','scope_type','scope_id','valid_from']),
    ],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['NFR-SEC-002','FR-020'],
    implementation_slice='SLICE-005',expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'iam','session_revocation','PrincipalまたはOIDC Subjectのrevoke-beforeを保持し、既存Sessionを無効化する。',
    [
        id_col(), c('principal_id','uuid',nullable=False), c('oidc_issuer','text',nullable=False,classification='RESTRICTED'),
        c('oidc_subject','text',nullable=False,classification='RESTRICTED'), c('revoke_before','timestamptz',nullable=False),
        c('reason','text',nullable=False,classification='RESTRICTED'), c('created_by_principal_id','uuid',nullable=False), c('expires_at','timestamptz',nullable=True), created_col(),
    ],
    checks=[('ck_iam_session_issuer',"oidc_issuer ~ '^https://'"),('ck_iam_session_expiry','expires_at IS NULL OR expires_at > revoke_before')],
    fks=[fk('principal_id','iam.principal'),fk('created_by_principal_id','iam.principal')],
    indexes=[idx('ix_iam_session_revocation_lookup',['oidc_issuer','oidc_subject','revoke_before'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='IAM_SESSION_2Y',requirements=['NFR-SEC-002'],implementation_slice='SLICE-005',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'iam','break_glass_record','緊急権限の理由、Incident、承認、権限集合、有効期間、終了を記録する。',
    [
        id_col(), display_col('BGA'), c('principal_id','uuid',nullable=False), c('incident_id','uuid',nullable=False),
        c('reason','text',nullable=False,classification='RESTRICTED'), c('approved_by_principal_id','uuid',nullable=False),
        json_obj('permissions',description='緊急時に一時付与したPermission code集合。',classification='RESTRICTED'),
        c('started_at','timestamptz',nullable=False), c('expires_at','timestamptz',nullable=False), c('ended_at','timestamptz',nullable=True),
        c('end_reason','text',nullable=True,classification='RESTRICTED'), created_col(),
    ],
    uniques=[('uq_iam_break_glass_display',['display_id'])],
    checks=[('ck_iam_break_glass_window','expires_at > started_at AND (ended_at IS NULL OR ended_at >= started_at)'),('ck_iam_break_glass_permissions',json_object_check('permissions'))],
    fks=[fk('principal_id','iam.principal'),fk('incident_id','ops.incident'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('ix_iam_break_glass_active',['expires_at'],where='ended_at IS NULL')],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['NFR-SEC-002','FR-020'],
    implementation_slice='SLICE-005',expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

# ---------------------------------------------------------------------------
# PORTFOLIO SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'portfolio','site','RAOSが運営するMedia SiteのRoot。MVPは1件だがCategory、Article、Analytics、Financeのscope基準となる。',
    [
        id_col(), display_col('SITE'), c('site_code','text',nullable=False), c('name','text',nullable=False),
        c('primary_domain','text',nullable=False), c('brand_name','text',nullable=False), c('locale','text',nullable=False,default="'ja-JP'"),
        c('timezone','text',nullable=False,default="'Asia/Tokyo'"), c('currency','text',nullable=False,default="'JPY'"),
        c('status','text',nullable=False,default="'PLANNING'"), json_obj('public_settings',description='公開表示に安全なSite設定。秘密や内部KPIを含めない。'),
        *mutable_tail(),
    ],
    uniques=[('uq_portfolio_site_display',['display_id']),('uq_portfolio_site_code',['site_code']),('uq_portfolio_site_domain',['primary_domain'])],
    checks=[
        ('ck_portfolio_site_domain',"primary_domain ~ '^[a-z0-9.-]+$'"),('ck_portfolio_site_currency',"currency ~ '^[A-Z]{3}$'"),
        ('ck_portfolio_site_status',enum_check('status',['PLANNING','ACTIVE','PAUSED','RETIRED'])),('ck_portfolio_site_settings',json_object_check('public_settings')),
        ('ck_portfolio_site_version','lock_version >= 0'),
    ],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-001'],implementation_slice='SLICE-006',
    expected_gate1_rows='1',expected_gate4_rows='<100'
))

add(Table(
    'portfolio','category','運営上のCategory階層、Risk、Gate stage、公開上限、承認を管理する。',
    [
        id_col(), display_col('CAT'), c('site_id','uuid',nullable=False), c('parent_category_id','uuid',nullable=True),
        c('category_code','text',nullable=False), c('name','text',nullable=False), c('description','text',nullable=True),
        c('risk_class','text',nullable=False), c('stage','text',nullable=False,default="'CANDIDATE'"), c('article_limit','integer',nullable=True),
        c('approved_at','timestamptz',nullable=True), c('approved_by_principal_id','uuid',nullable=True),
        json_obj('entry_criteria',description='当該Categoryへ参入するための定量・定性基準。'), *mutable_tail(),
    ],
    uniques=[('uq_portfolio_category_display',['display_id']),('uq_portfolio_category_code',['site_id','category_code'])],
    checks=[
        ('ck_portfolio_category_risk',enum_check('risk_class',['LOW','MEDIUM','HIGH','PROHIBITED'])),
        ('ck_portfolio_category_stage',enum_check('stage',['CANDIDATE','RESEARCH','APPROVED','ACTIVE','PAUSED','RETIRED','REJECTED'])),
        ('ck_portfolio_category_limit','article_limit IS NULL OR article_limit >= 0'),('ck_portfolio_category_entry',json_object_check('entry_criteria')),
        ('ck_portfolio_category_approval',"stage NOT IN ('APPROVED','ACTIVE') OR (approved_at IS NOT NULL AND approved_by_principal_id IS NOT NULL)"),
        ('ck_portfolio_category_parent','parent_category_id IS NULL OR parent_category_id <> id'),('ck_portfolio_category_version','lock_version >= 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('parent_category_id','portfolio.category'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('ix_portfolio_category_tree',['site_id','parent_category_id']),idx('ix_portfolio_category_stage',['site_id','stage'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-001','FR-016'],implementation_slice='SLICE-006',
    expected_gate1_rows='<20',expected_gate4_rows='<10k'
))

add(Table(
    'portfolio','intent_cluster','Category内の検索意図Cluster。Article PlanとKeywordを結び、同一意図の重複記事を防ぐ。',
    [
        id_col(), display_col('INT'), c('category_id','uuid',nullable=False), c('cluster_code','text',nullable=False),
        c('name','text',nullable=False), c('description','text',nullable=False), c('intent_type','text',nullable=False),
        c('status','text',nullable=False,default="'ACTIVE'"), json_obj('decision_requirements',description='ユーザーが当該意図で判断するために必要な比較軸・疑問・不安。'),
        *mutable_tail(),
    ],
    uniques=[('uq_portfolio_intent_display',['display_id']),('uq_portfolio_intent_code',['category_id','cluster_code'])],
    checks=[
        ('ck_portfolio_intent_type',enum_check('intent_type',['SELECTION_GUIDE','USE_CASE','COMPARISON','MODEL_DIFFERENCE','CONDITION_FILTER','INFORMATIONAL_SUPPORT'])),
        ('ck_portfolio_intent_status',enum_check('status',['ACTIVE','PAUSED','RETIRED'])),('ck_portfolio_intent_requirements',json_object_check('decision_requirements')),
        ('ck_portfolio_intent_version','lock_version >= 0'),
    ],
    fks=[fk('category_id','portfolio.category')],
    indexes=[idx('ix_portfolio_intent_category',['category_id','status'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-001'],implementation_slice='SLICE-006',
    expected_gate1_rows='<20',expected_gate4_rows='<100k'
))

add(Table(
    'portfolio','keyword','検索Queryを表示形と正規化形に分け、文字列変更に依存しないStable IDを付与する。',
    [
        id_col(), display_col('KW'), c('site_id','uuid',nullable=False), c('display_text','text',nullable=False), c('normalized_text','text',nullable=False),
        c('locale','text',nullable=False,default="'ja-JP'"), c('status','text',nullable=False,default="'ACTIVE'"),
        c('sensitive_query','boolean',nullable=False,default='false'), *mutable_tail(),
    ],
    uniques=[('uq_portfolio_keyword_display',['display_id']),('uq_portfolio_keyword_normalized',['site_id','locale','normalized_text'])],
    checks=[('ck_portfolio_keyword_status',enum_check('status',['ACTIVE','PAUSED','RETIRED','BLOCKED'])),('ck_portfolio_keyword_version','lock_version >= 0')],
    fks=[fk('site_id','portfolio.site')],
    indexes=[idx('ix_portfolio_keyword_text',expression='lower(display_text)')],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='BUSINESS_CORE',requirements=['FR-001'],implementation_slice='SLICE-006',
    expected_gate1_rows='<5k',expected_gate4_rows='<10m'
))

add(Table(
    'portfolio','intent_cluster_keyword','Intent Cluster内でKeywordをprimary、secondary、question、exclusionに分類する。',
    [c('intent_cluster_id','uuid',nullable=False),c('keyword_id','uuid',nullable=False),c('keyword_role','text',nullable=False),c('priority','smallint',nullable=False,default='50'),created_col()],
    pk=['intent_cluster_id','keyword_id'],
    checks=[('ck_portfolio_cluster_keyword_role',enum_check('keyword_role',['PRIMARY','SECONDARY','QUESTION','EXCLUSION'])),('ck_portfolio_cluster_keyword_priority','priority BETWEEN 0 AND 100')],
    fks=[fk('intent_cluster_id','portfolio.intent_cluster'),fk('keyword_id','portfolio.keyword')],
    indexes=[idx('ix_portfolio_cluster_keyword_role',['intent_cluster_id','keyword_role','priority'])],
    write_pattern='REFERENCE',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-001'],implementation_slice='SLICE-006',
    expected_gate1_rows='<10k',expected_gate4_rows='<20m'
))

add(Table(
    'portfolio','keyword_metric_observation','許諾済みProviderまたはCSVから得た検索需要、競争、順位、Trend等の時点Observation。',
    [
        id_col(), c('keyword_id','uuid',nullable=False), c('provider_code','text',nullable=False), c('metric_type','text',nullable=False),
        c('metric_value','numeric(24,8)',nullable=False), c('unit','text',nullable=False), c('country_code','text',nullable=False,default="'JP'"),
        c('device','text',nullable=False,default="'ALL'"), c('observed_date','date',nullable=False), c('confidence','numeric(5,4)',nullable=True),
        c('raw_artifact_id','uuid',nullable=True), c('ingested_at','timestamptz',nullable=False), created_col(),
    ],
    checks=[
        ('ck_portfolio_kw_metric_type',enum_check('metric_type',['SEARCH_VOLUME','COMPETITION','RANK','CPC','TREND_INDEX','RESULT_COUNT_ESTIMATE'])),
        ('ck_portfolio_kw_metric_device',enum_check('device',['ALL','DESKTOP','MOBILE','TABLET'])),('ck_portfolio_kw_metric_conf','confidence IS NULL OR confidence BETWEEN 0 AND 1'),
    ],
    fks=[fk('keyword_id','portfolio.keyword'),fk('raw_artifact_id','ops.object_artifact')],
    indexes=[
        idx('uq_portfolio_kw_metric_observation',['keyword_id','provider_code','metric_type','country_code','device','observed_date'],unique=True),
        idx('ix_portfolio_kw_metric_latest',['keyword_id','metric_type','observed_date']),
    ],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='ANALYTICS_25M',requirements=['FR-001','FR-016'],implementation_slice='SLICE-006',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m',partitioning='CANDIDATE_BY_OBSERVED_DATE_AFTER_20M'
))

add(Table(
    'portfolio','opportunity_assessment','Editorial feasibility、Business opportunity、Compliance riskを混合せず別Column・別根拠で評価する版付き判断。',
    [
        id_col(), display_col('OPA'), c('category_id','uuid',nullable=False), c('intent_cluster_id','uuid',nullable=True), c('keyword_id','uuid',nullable=True),
        c('assessment_type','text',nullable=False), c('formula_version','text',nullable=False),
        c('editorial_feasibility_score','numeric(5,2)',nullable=False), c('business_opportunity_score','numeric(5,2)',nullable=False),
        c('compliance_risk_score','numeric(5,2)',nullable=False), c('overall_priority_score','numeric(5,2)',nullable=False),
        c('decision','text',nullable=False), json_obj('editorial_components',description='Editorialに必要な一次情報、独自価値、比較可能性等。'),
        json_obj('business_components',description='需要、競争、商品数、想定EPC等。推薦順位には渡さない。',classification='CONFIDENTIAL'),
        json_obj('compliance_components',description='Category、表示、著作権、規約、YMYL等のRisk。',classification='RESTRICTED'),
        c('assessed_at','timestamptz',nullable=False), c('assessed_by_actor_type','text',nullable=False), c('assessed_by_actor_id','uuid',nullable=True),
        c('expires_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_portfolio_opp_display',['display_id'])],
    checks=[
        ('ck_portfolio_opp_type',enum_check('assessment_type',['CATEGORY','CLUSTER','KEYWORD','ARTICLE_PLAN'])),
        ('ck_portfolio_opp_editorial',score_check('editorial_feasibility_score')),('ck_portfolio_opp_business',score_check('business_opportunity_score')),
        ('ck_portfolio_opp_compliance',score_check('compliance_risk_score')),('ck_portfolio_opp_priority',score_check('overall_priority_score')),
        ('ck_portfolio_opp_decision',enum_check('decision',['PURSUE','RESEARCH','HOLD','REJECT','EXIT'])),
        ('ck_portfolio_opp_editorial_json',json_object_check('editorial_components')),('ck_portfolio_opp_business_json',json_object_check('business_components')),
        ('ck_portfolio_opp_compliance_json',json_object_check('compliance_components')),('ck_portfolio_opp_expiry','expires_at IS NULL OR expires_at > assessed_at'),
    ],
    fks=[fk('category_id','portfolio.category'),fk('intent_cluster_id','portfolio.intent_cluster'),fk('keyword_id','portfolio.keyword')],
    indexes=[idx('ix_portfolio_opp_scope',['category_id','intent_cluster_id','keyword_id','assessed_at']),idx('ix_portfolio_opp_priority',['decision','overall_priority_score'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='BUSINESS_CORE',requirements=['FR-005','FR-016'],implementation_slice='SLICE-006',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m',notes=['business_componentsおよびbusiness_opportunity_scoreをEditorial Recommendation QueryへJoinしないことをArchitecture Testで検査する。']
))

add(Table(
    'portfolio','action_candidate','新規作成・更新・統合・削除・保留の候補を、期待増分利益・緊急度・信頼度とともに管理する。',
    [
        id_col(), display_col('ACT'), c('site_id','uuid',nullable=False), c('category_id','uuid',nullable=True),
        c('action_type','text',nullable=False), c('target_entity_type','text',nullable=False), c('target_entity_id','uuid',nullable=True),
        c('secondary_entity_id','uuid',nullable=True), c('source_signal','text',nullable=False), c('expected_incremental_profit_jpy','bigint',nullable=True),
        c('urgency_score','numeric(5,2)',nullable=False), c('confidence','numeric(5,4)',nullable=False), c('priority_score','numeric(8,3)',nullable=False),
        c('status','text',nullable=False,default="'PROPOSED'"), json_obj('rationale',classification='CONFIDENTIAL'),
        c('generated_at','timestamptz',nullable=False), c('expires_at','timestamptz',nullable=True),
        c('decided_by_principal_id','uuid',nullable=True), c('decided_at','timestamptz',nullable=True), c('decision_note','text',nullable=True),
        *mutable_tail(),
    ],
    uniques=[('uq_portfolio_action_display',['display_id'])],
    checks=[
        ('ck_portfolio_action_type',enum_check('action_type',['CREATE','UPDATE','MERGE','DELETE','ARCHIVE','PAUSE','HOLD','INVESTIGATE'])),
        ('ck_portfolio_action_target',enum_check('target_entity_type',['CATEGORY','CLUSTER','KEYWORD','ARTICLE_PLAN','ARTICLE','PRODUCT','OFFER'])),
        ('ck_portfolio_action_urgency',score_check('urgency_score')),('ck_portfolio_action_conf','confidence BETWEEN 0 AND 1'),
        ('ck_portfolio_action_status',enum_check('status',['PROPOSED','ACCEPTED','REJECTED','IN_PROGRESS','COMPLETED','EXPIRED'])),
        ('ck_portfolio_action_rationale',json_object_check('rationale')),('ck_portfolio_action_expiry','expires_at IS NULL OR expires_at > generated_at'),
        ('ck_portfolio_action_decision_pair','(decided_by_principal_id IS NULL) = (decided_at IS NULL)'),('ck_portfolio_action_version','lock_version >= 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('category_id','portfolio.category'),fk('decided_by_principal_id','iam.principal')],
    indexes=[idx('ix_portfolio_action_queue',['site_id','status','priority_score','generated_at']),idx('ix_portfolio_action_target',['target_entity_type','target_entity_id'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='BUSINESS_CORE',requirements=['FR-016'],implementation_slice='SLICE-021',
    expected_gate1_rows='<50k',expected_gate4_rows='<50m'
))

# ---------------------------------------------------------------------------
# CATALOG SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'catalog','provider_endpoint','楽天等のCommerce ProviderとAPI Contract versionを一つのVersion行として管理する。Secretは含めない。',
    [
        id_col(), c('provider_code','text',nullable=False), c('provider_name','text',nullable=False), c('api_name','text',nullable=False),
        c('api_version','text',nullable=False), c('base_host','text',nullable=False), c('status','text',nullable=False),
        c('contract_sha256','text',nullable=False), c('documentation_url','text',nullable=True),
        json_obj('non_secret_config',description='Timeout、page size、field mapping等。Application ID、Access Key、Affiliate IDは含めない。',classification='CONFIDENTIAL'),
        c('effective_from','timestamptz',nullable=False), c('effective_to','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_catalog_provider_api_version',['provider_code','api_name','api_version'])],
    checks=[
        ('ck_catalog_provider_host',"base_host ~ '^[a-z0-9.-]+$'"),('ck_catalog_provider_status',enum_check('status',['DRAFT','ACTIVE','DEPRECATED','RETIRED','BLOCKED'])),
        ('ck_catalog_provider_contract_hash',hash_check('contract_sha256')),('ck_catalog_provider_config',json_object_check('non_secret_config')),
        ('ck_catalog_provider_window','effective_to IS NULL OR effective_to > effective_from'),
    ],
    indexes=[idx('uq_catalog_provider_active',['provider_code','api_name'],unique=True,where="status = 'ACTIVE'")],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONFIG_7Y',requirements=['FR-002','NFR-MAINT-001'],
    implementation_slice='SLICE-008',expected_gate1_rows='<100',expected_gate4_rows='<10k',notes=['楽天商品検索API 2026-07-01等をversion rowとして登録する。']
))

add(Table(
    'catalog','ingestion_request','外部API Request/Responseの契約、raw Artifact、件数、Rate Limit、失敗分類を記録する。',
    [
        id_col(), display_col('ING'), c('provider_endpoint_id','uuid',nullable=False), c('job_id','uuid',nullable=False),
        c('request_fingerprint','text',nullable=False), json_obj('request_parameters',description='Secretを除外したCanonical request parameters。',classification='CONFIDENTIAL'),
        c('requested_at','timestamptz',nullable=False), c('responded_at','timestamptz',nullable=True), c('http_status','integer',nullable=True),
        c('status','text',nullable=False), c('raw_response_artifact_id','uuid',nullable=True), c('item_count','integer',nullable=True),
        json_obj('rate_limit_observation',description='Remaining、reset時刻等。'), c('error_class','text',nullable=True), c('error_code','text',nullable=True),
        c('error_message','text',nullable=True,classification='CONFIDENTIAL'), created_col(),
    ],
    uniques=[('uq_catalog_ingestion_display',['display_id']),('uq_catalog_ingestion_job',['job_id'])],
    checks=[
        ('ck_catalog_ingestion_fingerprint',hash_check('request_fingerprint')),('ck_catalog_ingestion_status',enum_check('status',['REQUESTED','SUCCEEDED','FAILED','QUARANTINED'])),
        ('ck_catalog_ingestion_http','http_status IS NULL OR http_status BETWEEN 100 AND 599'),('ck_catalog_ingestion_count','item_count IS NULL OR item_count >= 0'),
        ('ck_catalog_ingestion_params',json_object_check('request_parameters')),('ck_catalog_ingestion_rate',json_object_check('rate_limit_observation')),
        ('ck_catalog_ingestion_response',"status <> 'SUCCEEDED' OR (responded_at IS NOT NULL AND raw_response_artifact_id IS NOT NULL)"),
    ],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('job_id','ops.job'),fk('raw_response_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_catalog_ingestion_provider_time',['provider_endpoint_id','requested_at']),idx('ix_catalog_ingestion_status',['status','requested_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='RAW_PROVIDER_2Y',requirements=['FR-002','FR-004','NFR-REL-002'],
    implementation_slice='SLICE-008',expected_gate1_rows='<100k',expected_gate4_rows='<100m',partitioning='CANDIDATE_BY_REQUESTED_AT_AFTER_20M'
))

add(Table(
    'catalog','rakuten_genre','楽天ジャンルID階層のVersioned current registry。',
    [
        id_col(), c('provider_endpoint_id','uuid',nullable=False), c('external_genre_id','bigint',nullable=False), c('parent_external_genre_id','bigint',nullable=True),
        c('genre_name','text',nullable=False), c('genre_level','smallint',nullable=False), c('is_leaf','boolean',nullable=False),
        c('is_active','boolean',nullable=False,default='true'), c('source_snapshot_id','uuid',nullable=False), c('observed_at','timestamptz',nullable=False),
        *mutable_tail(),
    ],
    uniques=[('uq_catalog_rakuten_genre',['provider_endpoint_id','external_genre_id'])],
    checks=[('ck_catalog_rakuten_genre_id','external_genre_id > 0'),('ck_catalog_rakuten_genre_level','genre_level >= 0'),('ck_catalog_rakuten_genre_parent','parent_external_genre_id IS NULL OR parent_external_genre_id <> external_genre_id'),('ck_catalog_rakuten_genre_version','lock_version >= 0')],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_rakuten_genre_parent',['provider_endpoint_id','parent_external_genre_id'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CATALOG_CURRENT',requirements=['FR-002','FR-004'],implementation_slice='SLICE-009',
    expected_gate1_rows='<100k',expected_gate4_rows='<1m'
))

add(Table(
    'catalog','shop','Provider内ShopをStable IDへ正規化する。',
    [
        id_col(), display_col('SHP'), c('provider_endpoint_id','uuid',nullable=False), c('external_shop_code','text',nullable=False),
        c('shop_name','text',nullable=False), c('shop_url','text',nullable=True), c('affiliate_capable','boolean',nullable=False,default='true'),
        c('status','text',nullable=False), c('first_observed_at','timestamptz',nullable=False), c('last_observed_at','timestamptz',nullable=False),
        c('source_snapshot_id','uuid',nullable=False), *mutable_tail(),
    ],
    uniques=[('uq_catalog_shop_display',['display_id']),('uq_catalog_shop_external',['provider_endpoint_id','external_shop_code'])],
    checks=[('ck_catalog_shop_status',enum_check('status',['ACTIVE','INACTIVE','BLOCKED','UNKNOWN'])),('ck_catalog_shop_url',"shop_url IS NULL OR shop_url ~ '^https://'"),('ck_catalog_shop_observed','last_observed_at >= first_observed_at'),('ck_catalog_shop_version','lock_version >= 0')],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_shop_status',['provider_endpoint_id','status'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003','FR-004'],implementation_slice='SLICE-009',
    expected_gate1_rows='<100k',expected_gate4_rows='<10m'
))

add(Table(
    'catalog','canonical_product','複数Shop Listingを束ねる商品概念。JAN、型番、Brand等は確信度付きIdentityとして扱う。',
    [
        id_col(), display_col('PRD'), c('category_id','uuid',nullable=False), c('canonical_name','text',nullable=False),
        c('brand_name','text',nullable=True), c('manufacturer_name','text',nullable=True), c('model_number','text',nullable=True),
        c('jan_code','text',nullable=True), c('product_type','text',nullable=False), c('lifecycle_status','text',nullable=False,default="'ACTIVE'"),
        c('identity_confidence','numeric(5,4)',nullable=False), json_obj('identity_attributes',description='同定に使用した正規化Attribute。'),
        c('merged_into_product_id','uuid',nullable=True), *mutable_tail(),
    ],
    uniques=[('uq_catalog_product_display',['display_id'])],
    checks=[
        ('ck_catalog_product_conf','identity_confidence BETWEEN 0 AND 1'),('ck_catalog_product_lifecycle',enum_check('lifecycle_status',['ACTIVE','DISCONTINUED','MERGED','SPLIT','UNKNOWN'])),
        ('ck_catalog_product_jan',"jan_code IS NULL OR jan_code ~ '^[0-9]{8,14}$'"),('ck_catalog_product_identity',json_object_check('identity_attributes')),
        ('ck_catalog_product_merge','merged_into_product_id IS NULL OR merged_into_product_id <> id'),('ck_catalog_product_version','lock_version >= 0'),
    ],
    fks=[fk('category_id','portfolio.category'),fk('merged_into_product_id','catalog.canonical_product',on_delete='RESTRICT')],
    indexes=[idx('ix_catalog_product_category',['category_id','lifecycle_status']),idx('ix_catalog_product_model',['category_id','model_number'],where='model_number IS NOT NULL'),idx('ix_catalog_product_jan',['jan_code'],where='jan_code IS NOT NULL')],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003','FR-004'],implementation_slice='SLICE-009',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'catalog','product_candidate','Provider Listingから抽出した商品候補。raw本文はArtifactへ置き、比較に必要な正規化項目と許可画像URLのみ保持する。',
    [
        id_col(), display_col('PCD'), c('provider_endpoint_id','uuid',nullable=False), c('external_item_code','text',nullable=False),
        c('shop_id','uuid',nullable=False), c('rakuten_genre_id','uuid',nullable=True), c('item_name','text',nullable=False),
        c('normalized_item_name','text',nullable=False), c('model_number_candidate','text',nullable=True), c('jan_code_candidate','text',nullable=True),
        json_obj('image_set',description='APIが返した許可画像URL、order、size。Overlay/Crop後画像は登録しない。'),
        c('listing_status','text',nullable=False), c('first_observed_at','timestamptz',nullable=False), c('last_observed_at','timestamptz',nullable=False),
        c('source_snapshot_id','uuid',nullable=False), *mutable_tail(),
    ],
    uniques=[('uq_catalog_candidate_display',['display_id']),('uq_catalog_candidate_external',['provider_endpoint_id','external_item_code'])],
    checks=[
        ('ck_catalog_candidate_status',enum_check('listing_status',['ACTIVE','MISSING','ENDED','BLOCKED','UNKNOWN'])),
        ('ck_catalog_candidate_jan',"jan_code_candidate IS NULL OR jan_code_candidate ~ '^[0-9]{8,14}$'"),('ck_catalog_candidate_images',json_object_check('image_set')),
        ('ck_catalog_candidate_observed','last_observed_at >= first_observed_at'),('ck_catalog_candidate_version','lock_version >= 0'),
    ],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('shop_id','catalog.shop'),fk('rakuten_genre_id','catalog.rakuten_genre'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_candidate_shop',['shop_id','listing_status']),idx('ix_catalog_candidate_genre',['rakuten_genre_id','listing_status']),idx('ix_catalog_candidate_model',['model_number_candidate'],where='model_number_candidate IS NOT NULL'),idx('ix_catalog_candidate_jan',['jan_code_candidate'],where='jan_code_candidate IS NOT NULL')],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-002','FR-003','FR-004','COMP-RAK-007'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<500m',partitioning='CANDIDATE_HASH_PROVIDER_AT_GATE4'
))

add(Table(
    'catalog','grouping_decision','Product CandidateをCanonical Productへ統合・分離・却下した判断とRule版・Score・理由を追記保存する。',
    [
        id_col(), c('product_candidate_id','uuid',nullable=False), c('proposed_product_id','uuid',nullable=True), c('decision_type','text',nullable=False),
        c('decision_score','numeric(5,4)',nullable=True), c('rule_version','text',nullable=False), json_obj('reasons',description='一致・不一致Attribute、閾値、Manual note。'),
        c('decided_by_actor_type','text',nullable=False), c('decided_by_actor_id','uuid',nullable=True), c('decided_at','timestamptz',nullable=False),
        c('supersedes_decision_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_catalog_group_decision_type',enum_check('decision_type',['AUTO_ACCEPT','HUMAN_ACCEPT','REJECT','SPLIT','UNDECIDED'])),
        ('ck_catalog_group_score','decision_score IS NULL OR decision_score BETWEEN 0 AND 1'),('ck_catalog_group_reasons',json_object_check('reasons')),
        ('ck_catalog_group_target',"decision_type IN ('REJECT','UNDECIDED') OR proposed_product_id IS NOT NULL"),
    ],
    fks=[fk('product_candidate_id','catalog.product_candidate'),fk('proposed_product_id','catalog.canonical_product'),fk('supersedes_decision_id','catalog.grouping_decision',on_delete='SET NULL')],
    indexes=[idx('ix_catalog_group_candidate',['product_candidate_id','decided_at']),idx('ix_catalog_group_product',['proposed_product_id','decided_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CATALOG_HISTORY',requirements=['FR-003'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='CANDIDATE_BY_DECIDED_AT_AFTER_50M'
))

add(Table(
    'catalog','product_group_membership','Product CandidateがどのCanonical Productへ属したかを有効期間付きで記録する。',
    [
        id_col(), c('product_id','uuid',nullable=False), c('product_candidate_id','uuid',nullable=False), c('grouping_decision_id','uuid',nullable=False),
        c('valid_from','timestamptz',nullable=False), c('valid_to','timestamptz',nullable=True), created_col(),
    ],
    checks=[('ck_catalog_membership_window','valid_to IS NULL OR valid_to > valid_from')],
    fks=[fk('product_id','catalog.canonical_product'),fk('product_candidate_id','catalog.product_candidate'),fk('grouping_decision_id','catalog.grouping_decision')],
    indexes=[
        idx('uq_catalog_membership_current',['product_candidate_id'],unique=True,where='valid_to IS NULL'),
        idx('ix_catalog_membership_product',['product_id','valid_from']),
    ],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b'
))

add(Table(
    'catalog','attribute_definition','カテゴリ別の比較可能Attribute定義、型、単位、正規化Ruleを管理する。',
    [
        id_col(), c('category_id','uuid',nullable=True), c('attribute_code','text',nullable=False), c('name','text',nullable=False),
        c('data_type','text',nullable=False), c('unit_family','text',nullable=True), c('is_comparable','boolean',nullable=False,default='true'),
        c('is_required','boolean',nullable=False,default='false'), c('normalization_rule_version','text',nullable=False),
        c('status','text',nullable=False,default="'ACTIVE'"), *mutable_tail(),
    ],
    checks=[
        ('ck_catalog_attribute_type',enum_check('data_type',['TEXT','NUMERIC','BOOLEAN','DATE','CODE'])),
        ('ck_catalog_attribute_status',enum_check('status',['ACTIVE','RETIRED'])),('ck_catalog_attribute_version','lock_version >= 0'),
    ],
    fks=[fk('category_id','portfolio.category')],
    indexes=[idx('uq_catalog_attribute_code',['category_id','attribute_code'],unique=True,nulls_not_distinct=True)],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CONFIG_7Y',requirements=['FR-003','FR-007'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'catalog','product_attribute_value','Canonical Productの型付きAttribute値と根拠Fact、有効期間、信頼度を保持する。',
    [
        id_col(), c('product_id','uuid',nullable=False), c('attribute_definition_id','uuid',nullable=False),
        c('value_text','text',nullable=True), c('value_numeric','numeric(30,10)',nullable=True), c('value_boolean','boolean',nullable=True),
        c('value_date','date',nullable=True), c('value_code','text',nullable=True), c('unit_code','text',nullable=True),
        c('source_fact_id','uuid',nullable=True), c('confidence','numeric(5,4)',nullable=False), c('valid_from','timestamptz',nullable=False),
        c('valid_to','timestamptz',nullable=True), created_col(),
    ],
    checks=[
        ('ck_catalog_product_attr_one_value',exactly_one('value_text','value_numeric','value_boolean','value_date','value_code')),
        ('ck_catalog_product_attr_conf','confidence BETWEEN 0 AND 1'),('ck_catalog_product_attr_window','valid_to IS NULL OR valid_to > valid_from'),
    ],
    fks=[fk('product_id','catalog.canonical_product'),fk('attribute_definition_id','catalog.attribute_definition'),fk('source_fact_id','evidence.fact')],
    indexes=[
        idx('uq_catalog_product_attr_current',['product_id','attribute_definition_id'],unique=True,where='valid_to IS NULL'),
        idx('ix_catalog_product_attr_numeric',['attribute_definition_id','value_numeric'],where='value_numeric IS NOT NULL'),
        idx('ix_catalog_product_attr_code',['attribute_definition_id','value_code'],where='value_code IS NOT NULL'),
    ],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003','FR-004','FR-007'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10m',expected_gate4_rows='<5b',partitioning='CANDIDATE_HASH_PRODUCT_AT_GATE4'
))

add(Table(
    'catalog','product_relation','後継、前世代、Variant、Bundle、Equivalent等の商品関係を根拠付きで管理する。',
    [
        id_col(), c('from_product_id','uuid',nullable=False), c('to_product_id','uuid',nullable=False), c('relation_type','text',nullable=False),
        c('confidence','numeric(5,4)',nullable=False), c('source_fact_id','uuid',nullable=True), c('valid_from','timestamptz',nullable=False),
        c('valid_to','timestamptz',nullable=True), created_col(),
    ],
    checks=[('ck_catalog_product_relation_type',enum_check('relation_type',['VARIANT','SUCCESSOR','PREDECESSOR','BUNDLE','COMPATIBLE','EQUIVALENT','ACCESSORY'])),('ck_catalog_product_relation_self','from_product_id <> to_product_id'),('ck_catalog_product_relation_conf','confidence BETWEEN 0 AND 1'),('ck_catalog_product_relation_window','valid_to IS NULL OR valid_to > valid_from')],
    fks=[fk('from_product_id','catalog.canonical_product'),fk('to_product_id','catalog.canonical_product'),fk('source_fact_id','evidence.fact')],
    indexes=[idx('uq_catalog_product_relation_current',['from_product_id','to_product_id','relation_type'],unique=True,where='valid_to IS NULL'),idx('ix_catalog_product_relation_reverse',['to_product_id','relation_type'])],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003','FR-007'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<500m'
))

add(Table(
    'catalog','offer','Shop単位の販売OfferをStable ID化し、Product Candidate・Shop・Canonical Productへ結び付ける。',
    [
        id_col(), display_col('OFF'), c('provider_endpoint_id','uuid',nullable=False), c('external_offer_id','text',nullable=False),
        c('product_candidate_id','uuid',nullable=False), c('product_id','uuid',nullable=True), c('shop_id','uuid',nullable=False),
        c('item_url','text',nullable=False), c('status','text',nullable=False), c('first_observed_at','timestamptz',nullable=False),
        c('last_observed_at','timestamptz',nullable=False), *mutable_tail(),
    ],
    uniques=[('uq_catalog_offer_display',['display_id']),('uq_catalog_offer_external',['provider_endpoint_id','external_offer_id'])],
    checks=[('ck_catalog_offer_url',"item_url ~ '^https://'"),('ck_catalog_offer_status',enum_check('status',['ACTIVE','OUT_OF_STOCK','ENDED','SUSPENDED','BLOCKED','UNKNOWN'])),('ck_catalog_offer_observed','last_observed_at >= first_observed_at'),('ck_catalog_offer_version','lock_version >= 0')],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('product_candidate_id','catalog.product_candidate'),fk('product_id','catalog.canonical_product'),fk('shop_id','catalog.shop')],
    indexes=[idx('ix_catalog_offer_product',['product_id','status']),idx('ix_catalog_offer_shop',['shop_id','status']),idx('ix_catalog_offer_candidate',['product_candidate_id'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CATALOG_HISTORY',requirements=['FR-003','FR-012'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='CANDIDATE_HASH_PROVIDER_AT_GATE4'
))

add(Table(
    'catalog','price_observation','価格・送料・Point等の時点事実を上書きせず追記する。',
    [
        id_col(), c('offer_id','uuid',nullable=False), c('price_jpy','bigint',nullable=False), c('tax_included','boolean',nullable=False,default='true'),
        c('shipping_fee_jpy','bigint',nullable=True), c('shipping_condition','text',nullable=False), c('points_rate','numeric(9,6)',nullable=True),
        c('observed_at','timestamptz',nullable=False), c('ingested_at','timestamptz',nullable=False), c('valid_until','timestamptz',nullable=True),
        c('source_snapshot_id','uuid',nullable=False), c('validation_status','text',nullable=False), c('confidence','numeric(5,4)',nullable=False), created_col(),
    ],
    checks=[
        ('ck_catalog_price_nonnegative','price_jpy >= 0 AND (shipping_fee_jpy IS NULL OR shipping_fee_jpy >= 0)'),
        ('ck_catalog_price_shipping',enum_check('shipping_condition',['FREE','PAID','CONDITIONAL','INCLUDED','UNKNOWN'])),
        ('ck_catalog_price_points','points_rate IS NULL OR points_rate BETWEEN 0 AND 100'),('ck_catalog_price_valid','valid_until IS NULL OR valid_until > observed_at'),
        ('ck_catalog_price_validation',enum_check('validation_status',['VALID','SUSPECT','INVALID','CONFLICT'])),('ck_catalog_price_conf','confidence BETWEEN 0 AND 1'),
    ],
    fks=[fk('offer_id','catalog.offer'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_price_offer_time',['offer_id','observed_at']),idx('ix_catalog_price_observed_brin',['observed_at'],method='brin')],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='OBSERVATION_3Y',requirements=['FR-004','FR-012'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY_AT_GATE3_OR_50M_ROWS'
))

add(Table(
    'catalog','availability_observation','在庫・販売終了・Backorder等の時点事実を追記する。',
    [
        id_col(), c('offer_id','uuid',nullable=False), c('availability','text',nullable=False), c('quantity','integer',nullable=True),
        c('lead_time_text','text',nullable=True), c('observed_at','timestamptz',nullable=False), c('ingested_at','timestamptz',nullable=False),
        c('valid_until','timestamptz',nullable=True), c('source_snapshot_id','uuid',nullable=False), c('validation_status','text',nullable=False),
        c('confidence','numeric(5,4)',nullable=False), created_col(),
    ],
    checks=[
        ('ck_catalog_avail_type',enum_check('availability',['IN_STOCK','OUT_OF_STOCK','BACKORDER','PREORDER','DISCONTINUED','UNKNOWN'])),
        ('ck_catalog_avail_qty','quantity IS NULL OR quantity >= 0'),('ck_catalog_avail_valid','valid_until IS NULL OR valid_until > observed_at'),
        ('ck_catalog_avail_validation',enum_check('validation_status',['VALID','SUSPECT','INVALID','CONFLICT'])),('ck_catalog_avail_conf','confidence BETWEEN 0 AND 1'),
    ],
    fks=[fk('offer_id','catalog.offer'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_avail_offer_time',['offer_id','observed_at']),idx('ix_catalog_avail_observed_brin',['observed_at'],method='brin')],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='OBSERVATION_3Y',requirements=['FR-004','FR-012'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY_AT_GATE3_OR_50M_ROWS'
))

add(Table(
    'catalog','review_aggregate_observation','楽天APIが返すReview件数・平均評価のみを保存する。Review本文を保存するColumnは設けない。',
    [
        id_col(), c('offer_id','uuid',nullable=False), c('review_count','integer',nullable=False), c('review_average','numeric(3,2)',nullable=True),
        c('observed_at','timestamptz',nullable=False), c('ingested_at','timestamptz',nullable=False), c('source_snapshot_id','uuid',nullable=False), created_col(),
    ],
    checks=[('ck_catalog_review_count','review_count >= 0'),('ck_catalog_review_average','review_average IS NULL OR review_average BETWEEN 0 AND 5')],
    fks=[fk('offer_id','catalog.offer'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_review_offer_time',['offer_id','observed_at'])],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='OBSERVATION_3Y',requirements=['FR-004','COMP-RAK-006'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY_AT_GATE3_OR_50M_ROWS',
    notes=['review_body、review_text、review_author等のColumn追加をSchema Lintで拒否する。']
))

add(Table(
    'catalog','affiliate_link_observation','公式/API返却Affiliate URL、Destination host、URL hash、料率Observationを追記し、URLを改変しない。',
    [
        id_col(), c('offer_id','uuid',nullable=False), c('affiliate_url','text',nullable=False,classification='CONFIDENTIAL'),
        c('url_sha256','text',nullable=False), c('destination_host','text',nullable=False), c('is_api_returned','boolean',nullable=False),
        c('affiliate_rate','numeric(9,6)',nullable=True,classification='CONFIDENTIAL'), c('observed_at','timestamptz',nullable=False),
        c('valid_until','timestamptz',nullable=True), c('source_snapshot_id','uuid',nullable=False), c('validation_status','text',nullable=False),
        c('link_contract_version','text',nullable=False), created_col(),
    ],
    checks=[
        ('ck_catalog_affiliate_url',"affiliate_url ~ '^https://'"),('ck_catalog_affiliate_hash',hash_check('url_sha256')),
        ('ck_catalog_affiliate_host',"destination_host ~ '^[a-z0-9.-]+$'"),('ck_catalog_affiliate_api','is_api_returned = true'),
        ('ck_catalog_affiliate_rate','affiliate_rate IS NULL OR affiliate_rate BETWEEN 0 AND 100'),('ck_catalog_affiliate_valid','valid_until IS NULL OR valid_until > observed_at'),
        ('ck_catalog_affiliate_validation',enum_check('validation_status',['VALID','UNVERIFIED','INVALID','EXPIRED','BLOCKED'])),
    ],
    fks=[fk('offer_id','catalog.offer'),fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[idx('ix_catalog_affiliate_offer_time',['offer_id','observed_at']),idx('ix_catalog_affiliate_hash',['url_sha256'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='OBSERVATION_3Y',requirements=['COMP-RAK-002','COMP-RAK-003','FR-011','FR-012'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY_AT_GATE3_OR_50M_ROWS',
    notes=['affiliate_rateはCatalog/Finance用途のみ。EditorialおよびReadmodelに同名・同義Columnを置かない。']
))

add(Table(
    'catalog','offer_current_projection','最新かつValidなObservationを選択した再生成可能Projection。公開候補はさらにFreshness/Policyを通す。',
    [
        c('offer_id','uuid',nullable=False), c('product_id','uuid',nullable=True), c('price_observation_id','uuid',nullable=True),
        c('availability_observation_id','uuid',nullable=True), c('review_observation_id','uuid',nullable=True), c('affiliate_link_observation_id','uuid',nullable=True),
        c('current_price_jpy','bigint',nullable=True), c('current_shipping_fee_jpy','bigint',nullable=True), c('current_availability','text',nullable=False,default="'UNKNOWN'"),
        c('review_count','integer',nullable=True), c('review_average','numeric(3,2)',nullable=True),
        c('affiliate_url','text',nullable=True,classification='CONFIDENTIAL'), c('destination_host','text',nullable=True),
        c('price_observed_at','timestamptz',nullable=True), c('availability_observed_at','timestamptz',nullable=True), c('link_observed_at','timestamptz',nullable=True),
        c('freshness_status','text',nullable=False), c('projection_version','bigint',nullable=False), c('updated_at','timestamptz',nullable=False),
    ],
    pk=['offer_id'],
    checks=[
        ('ck_catalog_offer_current_price','current_price_jpy IS NULL OR current_price_jpy >= 0'),
        ('ck_catalog_offer_current_ship','current_shipping_fee_jpy IS NULL OR current_shipping_fee_jpy >= 0'),
        ('ck_catalog_offer_current_avail',enum_check('current_availability',['IN_STOCK','OUT_OF_STOCK','BACKORDER','PREORDER','DISCONTINUED','UNKNOWN'])),
        ('ck_catalog_offer_current_review','(review_count IS NULL OR review_count >= 0) AND (review_average IS NULL OR review_average BETWEEN 0 AND 5)'),
        ('ck_catalog_offer_current_url',"affiliate_url IS NULL OR affiliate_url ~ '^https://'"),
        ('ck_catalog_offer_current_fresh',enum_check('freshness_status',['FRESH','WARNING','STALE','UNKNOWN','CONFLICT'])),('ck_catalog_offer_current_version','projection_version >= 1'),
    ],
    fks=[
        fk('offer_id','catalog.offer'),fk('product_id','catalog.canonical_product'),fk('price_observation_id','catalog.price_observation'),
        fk('availability_observation_id','catalog.availability_observation'),fk('review_observation_id','catalog.review_aggregate_observation'),
        fk('affiliate_link_observation_id','catalog.affiliate_link_observation'),
    ],
    indexes=[idx('ix_catalog_offer_current_product',['product_id','freshness_status']),idx('ix_catalog_offer_current_available',['current_availability','freshness_status'])],
    write_pattern='PROJECTION',classification='CONFIDENTIAL',retention_class='REBUILDABLE',requirements=['FR-011','FR-012'],implementation_slice='SLICE-009',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b'
))

add(Table(
    'catalog','category_genre_mapping','RAOS Categoryと楽天Genreのinclude/exclude/primary関係を有効期間付きで管理する。',
    [
        id_col(), c('category_id','uuid',nullable=False), c('rakuten_genre_id','uuid',nullable=False),
        c('mapping_role','text',nullable=False), c('valid_from','timestamptz',nullable=False), c('valid_to','timestamptz',nullable=True),
        c('decision_reason','text',nullable=False), c('decided_by_principal_id','uuid',nullable=False), created_col(),
    ],
    checks=[('ck_catalog_category_genre_role',enum_check('mapping_role',['PRIMARY','INCLUDE','EXCLUDE'])),('ck_catalog_category_genre_window','valid_to IS NULL OR valid_to > valid_from')],
    fks=[fk('category_id','portfolio.category'),fk('rakuten_genre_id','catalog.rakuten_genre'),fk('decided_by_principal_id','iam.principal')],
    indexes=[idx('uq_catalog_category_genre_current',['category_id','rakuten_genre_id','mapping_role'],unique=True,where='valid_to IS NULL'),idx('ix_catalog_genre_categories',['rakuten_genre_id','mapping_role'])],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-001','FR-002'],implementation_slice='SLICE-009',
    expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

# ---------------------------------------------------------------------------
# EVIDENCE SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'evidence','source','Provider API、Manufacturer、Manual entry等の根拠Sourceと利用条件・Authorityを管理する。',
    [
        id_col(), display_col('SRC'), c('source_type','text',nullable=False), c('provider_endpoint_id','uuid',nullable=True),
        c('name','text',nullable=False), c('base_url','text',nullable=True), c('authority_level','text',nullable=False),
        c('permitted_use','text',nullable=False), c('terms_checked_at','timestamptz',nullable=True), c('terms_checked_by_principal_id','uuid',nullable=True),
        c('status','text',nullable=False,default="'ACTIVE'"), json_obj('metadata',description='Contact、acquisition method、robots/terms note等。',classification='CONFIDENTIAL'),
        *mutable_tail(),
    ],
    uniques=[('uq_evidence_source_display',['display_id'])],
    checks=[
        ('ck_evidence_source_type',enum_check('source_type',['PROVIDER_API','MANUFACTURER','OFFICIAL_DOCUMENT','MANUAL_VERIFIED','INTERNAL_CALCULATION','ANALYTICS','OTHER'])),
        ('ck_evidence_source_authority',enum_check('authority_level',['PRIMARY','OFFICIAL','SECONDARY','INTERNAL_DERIVED','UNVERIFIED'])),
        ('ck_evidence_source_status',enum_check('status',['ACTIVE','PAUSED','BLOCKED','RETIRED'])),('ck_evidence_source_url',"base_url IS NULL OR base_url ~ '^https://'"),
        ('ck_evidence_source_meta',json_object_check('metadata')),('ck_evidence_source_version','lock_version >= 0'),
    ],
    fks=[fk('provider_endpoint_id','catalog.provider_endpoint'),fk('terms_checked_by_principal_id','iam.principal')],
    indexes=[idx('ix_evidence_source_type_status',['source_type','status'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONFIG_7Y',requirements=['FR-004','FR-006','FR-007'],implementation_slice='SLICE-010',
    expected_gate1_rows='<1k',expected_gate4_rows='<1m'
))

add(Table(
    'evidence','source_snapshot','Sourceの特定時点原本をObject Artifactと結び、取得・有効・失効・Parser・Validationを不変保存する。',
    [
        id_col(), display_col('SSN'), c('source_id','uuid',nullable=False), c('artifact_id','uuid',nullable=False),
        c('external_reference','text',nullable=True), c('acquired_at','timestamptz',nullable=False), c('effective_at','timestamptz',nullable=True),
        c('expires_at','timestamptz',nullable=True), c('content_sha256','text',nullable=False), c('parser_version','text',nullable=False),
        c('validation_status','text',nullable=False), c('validation_message','text',nullable=True,classification='CONFIDENTIAL'), created_col(),
    ],
    uniques=[('uq_evidence_snapshot_display',['display_id']),('uq_evidence_snapshot_artifact',['artifact_id'])],
    checks=[
        ('ck_evidence_snapshot_hash',hash_check('content_sha256')),('ck_evidence_snapshot_status',enum_check('validation_status',['VALID','SUSPECT','INVALID','QUARANTINED'])),
        ('ck_evidence_snapshot_expiry','expires_at IS NULL OR expires_at > COALESCE(effective_at, acquired_at)'),
    ],
    fks=[fk('source_id','evidence.source'),fk('artifact_id','ops.object_artifact')],
    indexes=[idx('ix_evidence_snapshot_source_time',['source_id','acquired_at']),idx('ix_evidence_snapshot_external',['source_id','external_reference'],where='external_reference IS NOT NULL')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='SOURCE_SNAPSHOT_7Y_PROVISIONAL',requirements=['FR-002','FR-004','NFR-DATA-001'],implementation_slice='SLICE-010',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='CANDIDATE_BY_ACQUIRED_AT_AFTER_50M'
))

add(Table(
    'evidence','fact','Source Snapshotから抽出・正規化した型付き事実。subject_type/id、predicate、locator、信頼度、有効期間を持つ。',
    [
        id_col(), display_col('FCT'), c('source_snapshot_id','uuid',nullable=False), c('subject_type','text',nullable=False),
        c('subject_id','uuid',nullable=False), c('predicate','text',nullable=False),
        c('value_text','text',nullable=True), c('value_numeric','numeric(30,10)',nullable=True), c('value_boolean','boolean',nullable=True),
        c('value_date','date',nullable=True), c('value_timestamp','timestamptz',nullable=True), c('value_json','jsonb',nullable=True),
        c('unit_code','text',nullable=True), c('locale','text',nullable=True), c('fact_kind','text',nullable=False,default="'ASSERTED'"),
        c('confidence','numeric(5,4)',nullable=False), c('valid_from','timestamptz',nullable=True), c('valid_to','timestamptz',nullable=True),
        json_obj('locator',description='JSON Pointer、page、section、table cell等の出典内位置。'), created_col(),
    ],
    uniques=[('uq_evidence_fact_display',['display_id'])],
    checks=[
        ('ck_evidence_fact_subject',enum_check('subject_type',['SITE','CATEGORY','PRODUCT','OFFER','SHOP','ARTICLE','KEYWORD','OTHER'])),
        ('ck_evidence_fact_one_value',exactly_one('value_text','value_numeric','value_boolean','value_date','value_timestamp','value_json')),
        ('ck_evidence_fact_kind',enum_check('fact_kind',['ASSERTED','DERIVED','MANUAL_VERIFIED'])),('ck_evidence_fact_conf','confidence BETWEEN 0 AND 1'),
        ('ck_evidence_fact_window','valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from'),('ck_evidence_fact_locator',json_object_check('locator')),
        ('ck_evidence_fact_value_json',"value_json IS NULL OR jsonb_typeof(value_json) IN ('object','array','string','number','boolean','null')"),
    ],
    fks=[fk('source_snapshot_id','evidence.source_snapshot')],
    indexes=[
        idx('ix_evidence_fact_subject',['subject_type','subject_id','predicate','created_at']),idx('ix_evidence_fact_snapshot',['source_snapshot_id']),
        idx('ix_evidence_fact_predicate_numeric',['predicate','value_numeric'],where='value_numeric IS NOT NULL'),
    ],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-004','FR-007','NFR-DATA-001'],implementation_slice='SLICE-010',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='CANDIDATE_HASH_SUBJECT_AT_GATE4'
))

add(Table(
    'evidence','fact_derivation','Derived Factと入力Factを多対多で結び、Algorithm/Formula versionを追跡する。',
    [
        c('derived_fact_id','uuid',nullable=False), c('input_fact_id','uuid',nullable=False), c('derivation_role','text',nullable=False),
        c('algorithm_version','text',nullable=False), c('formula_description','text',nullable=True), created_col(),
    ],
    pk=['derived_fact_id','input_fact_id','derivation_role'],
    checks=[('ck_evidence_derivation_role',enum_check('derivation_role',['INPUT','BASELINE','QUALIFIER','EXCLUSION'])),('ck_evidence_derivation_self','derived_fact_id <> input_fact_id')],
    fks=[fk('derived_fact_id','evidence.fact'),fk('input_fact_id','evidence.fact')],
    indexes=[idx('ix_evidence_derivation_input',['input_fact_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-004','FR-007'],implementation_slice='SLICE-010',
    expected_gate1_rows='<20m',expected_gate4_rows='<20b'
))

add(Table(
    'evidence','source_packet','Article Plan向けSource PacketのStable Aggregate。Version本文はsource_packet_versionへ置く。',
    [
        id_col(), display_col('SP'), c('article_plan_id','uuid',nullable=False), c('packet_type','text',nullable=False),
        c('status','text',nullable=False,default="'BUILDING'"), c('current_version_no','integer',nullable=False,default='0'),
        *mutable_tail(),
    ],
    uniques=[('uq_evidence_packet_display',['display_id']),('uq_evidence_packet_plan_type',['article_plan_id','packet_type'])],
    checks=[('ck_evidence_packet_type',enum_check('packet_type',['ARTICLE_DRAFT','ARTICLE_UPDATE','COMPARISON','QUALITY_REVIEW'])),('ck_evidence_packet_status',enum_check('status',['BUILDING','READY','IN_REVIEW','APPROVED','INVALID','SUPERSEDED'])),('ck_evidence_packet_version_no','current_version_no >= 0'),('ck_evidence_packet_lock','lock_version >= 0')],
    fks=[fk('article_plan_id','editorial.article_plan')],
    indexes=[idx('ix_evidence_packet_status',['status','updated_at'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-006','FR-007'],implementation_slice='SLICE-010',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'evidence','source_packet_version','AI/Editorへ渡す許可済み根拠集合の不変Version。Artifact hash、Schema、Review決定を保持する。',
    [
        id_col(), display_col('SPV'), c('source_packet_id','uuid',nullable=False), c('version_no','integer',nullable=False),
        c('artifact_id','uuid',nullable=False), c('content_sha256','text',nullable=False), c('schema_version','integer',nullable=False),
        c('status','text',nullable=False), c('built_by_job_id','uuid',nullable=True), c('reviewed_by_principal_id','uuid',nullable=True),
        c('reviewed_at','timestamptz',nullable=True), c('review_note','text',nullable=True,classification='CONFIDENTIAL'), created_col(),
    ],
    uniques=[('uq_evidence_packet_version_display',['display_id']),('uq_evidence_packet_version_no',['source_packet_id','version_no']),('uq_evidence_packet_version_artifact',['artifact_id'])],
    checks=[
        ('ck_evidence_packet_version_num','version_no >= 1 AND schema_version >= 1'),('ck_evidence_packet_version_hash',hash_check('content_sha256')),
        ('ck_evidence_packet_version_status',enum_check('status',['BUILDING','READY','IN_REVIEW','APPROVED','REJECTED','SUPERSEDED','INVALID'])),
        ('ck_evidence_packet_version_review',"status NOT IN ('APPROVED','REJECTED') OR (reviewed_by_principal_id IS NOT NULL AND reviewed_at IS NOT NULL)"),
    ],
    fks=[fk('source_packet_id','evidence.source_packet'),fk('artifact_id','ops.object_artifact'),fk('built_by_job_id','ops.job'),fk('reviewed_by_principal_id','iam.principal')],
    indexes=[idx('ix_evidence_packet_version_status',['source_packet_id','status','version_no'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-006','FR-007','NFR-DATA-001'],implementation_slice='SLICE-010',
    expected_gate1_rows='<50k',expected_gate4_rows='<50m'
))

add(Table(
    'evidence','source_packet_fact','Source Packet VersionへFactをrequired/supporting/exclusionとして収録する。',
    [
        c('source_packet_version_id','uuid',nullable=False), c('fact_id','uuid',nullable=False), c('usage_role','text',nullable=False),
        c('display_order','integer',nullable=False), c('is_required','boolean',nullable=False,default='false'), created_col(),
    ],
    pk=['source_packet_version_id','fact_id'],
    checks=[('ck_evidence_packet_fact_role',enum_check('usage_role',['REQUIRED','SUPPORTING','QUALIFIER','EXCLUSION','CONTRADICTING'])),('ck_evidence_packet_fact_order','display_order >= 0')],
    fks=[fk('source_packet_version_id','evidence.source_packet_version'),fk('fact_id','evidence.fact')],
    indexes=[idx('ix_evidence_packet_fact_order',['source_packet_version_id','display_order']),idx('ix_evidence_packet_fact_reverse',['fact_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-006','FR-007'],implementation_slice='SLICE-010',
    expected_gate1_rows='<5m',expected_gate4_rows='<5b'
))

add(Table(
    'evidence','source_packet_product','Source Packet Versionに含めるProduct/Offerとcandidate/recommended/compared/excluded roleを固定する。',
    [
        c('source_packet_version_id','uuid',nullable=False), c('product_id','uuid',nullable=False), c('offer_id','uuid',nullable=True),
        c('product_role','text',nullable=False), c('display_order','integer',nullable=False), created_col(),
    ],
    pk=['source_packet_version_id','product_id','product_role'],
    checks=[('ck_evidence_packet_product_role',enum_check('product_role',['CANDIDATE','RECOMMENDED','COMPARED','EXCLUDED','REFERENCE'])),('ck_evidence_packet_product_order','display_order >= 0')],
    fks=[fk('source_packet_version_id','evidence.source_packet_version'),fk('product_id','catalog.canonical_product'),fk('offer_id','catalog.offer')],
    indexes=[idx('ix_evidence_packet_product_order',['source_packet_version_id','display_order']),idx('ix_evidence_packet_product_reverse',['product_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='EVIDENCE_7Y_PROVISIONAL',requirements=['FR-006','FR-007'],implementation_slice='SLICE-010',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b'
))

add(Table(
    'evidence','claim','公開文中の主張単位。Article Version/Block、生成Attempt、Criticality、Support statusを追跡する。',
    [
        id_col(), display_col('CLM'), c('article_version_id','uuid',nullable=False), c('block_id','uuid',nullable=True),
        c('claim_key','text',nullable=False), c('claim_type','text',nullable=False), c('claim_text','text',nullable=False),
        c('criticality','text',nullable=False), c('support_status','text',nullable=False,default="'PENDING'"),
        c('generated_by_ai_attempt_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_evidence_claim_display',['display_id']),('uq_evidence_claim_key',['article_version_id','claim_key'])],
    checks=[
        ('ck_evidence_claim_type',enum_check('claim_type',['FACTUAL','COMPARATIVE','RECOMMENDATION','DISCLOSURE','EXPERIENCE','OPINION'])),
        ('ck_evidence_claim_criticality',enum_check('criticality',['LOW','MEDIUM','HIGH','CRITICAL'])),
        ('ck_evidence_claim_support',enum_check('support_status',['PENDING','SUPPORTED','PARTIAL','UNSUPPORTED','CONFLICT','NOT_REQUIRED'])),
    ],
    fks=[fk('article_version_id','editorial.article_version'),fk(['block_id','article_version_id'],'editorial.article_block',['id','article_version_id'],on_delete='RESTRICT'),fk('generated_by_ai_attempt_id','ai.ai_attempt')],
    indexes=[idx('ix_evidence_claim_version_status',['article_version_id','support_status','criticality']),idx('ix_evidence_claim_block',['block_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-007','FR-008','PRINCIPLE-03'],implementation_slice='SLICE-012',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',notes=['EXPERIENCE claimは実機・一次体験Evidenceがない限りBlocking Finding対象。']
))

add(Table(
    'evidence','claim_evidence_link','ClaimとFactをsupports/qualifies/contradictsとして結び、Support strengthと注記を保持する。',
    [
        c('claim_id','uuid',nullable=False), c('fact_id','uuid',nullable=False), c('support_type','text',nullable=False),
        c('support_strength','numeric(5,4)',nullable=False), c('note','text',nullable=True,classification='CONFIDENTIAL'), created_col(),
    ],
    pk=['claim_id','fact_id','support_type'],
    checks=[('ck_evidence_claim_link_type',enum_check('support_type',['SUPPORTS','QUALIFIES','CONTRADICTS'])),('ck_evidence_claim_link_strength','support_strength BETWEEN 0 AND 1')],
    fks=[fk('claim_id','evidence.claim'),fk('fact_id','evidence.fact')],
    indexes=[idx('ix_evidence_claim_link_fact',['fact_id','support_type'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-007','NFR-DATA-001'],implementation_slice='SLICE-012',
    expected_gate1_rows='<5m',expected_gate4_rows='<5b'
))

# ---------------------------------------------------------------------------
# EDITORIAL SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'editorial','article_plan','Category・Intent・Primary Keyword・Opportunityを結ぶ記事企画。公開記事より前の意思決定正本。',
    [
        id_col(), display_col('PLAN'), c('site_id','uuid',nullable=False), c('category_id','uuid',nullable=False),
        c('intent_cluster_id','uuid',nullable=False), c('primary_keyword_id','uuid',nullable=False), c('article_type','text',nullable=False),
        c('working_title','text',nullable=False), c('objective','text',nullable=False), c('status','text',nullable=False,default="'IDEA'"),
        c('priority','smallint',nullable=False,default='50'), c('opportunity_assessment_id','uuid',nullable=True),
        c('created_by_principal_id','uuid',nullable=False), c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True),
        json_obj('brief',description='Target user、decision questions、required sections、unique value hypothesis。'),
        *mutable_tail(),
    ],
    uniques=[('uq_editorial_plan_display',['display_id'])],
    checks=[
        ('ck_editorial_plan_type',enum_check('article_type',['SELECTION_GUIDE','USE_CASE_RECOMMENDATION','PRODUCT_COMPARISON','MODEL_DIFFERENCE','CONDITION_FILTER'])),
        ('ck_editorial_plan_status',enum_check('status',['IDEA','PLANNED','SOURCES_PENDING','PACKET_READY','GENERATING','DRAFT','IN_REVIEW','APPROVED','CANCELLED','ARCHIVED'])),
        ('ck_editorial_plan_priority','priority BETWEEN 0 AND 100'),('ck_editorial_plan_approval',"status <> 'APPROVED' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL)"),
        ('ck_editorial_plan_brief',json_object_check('brief')),('ck_editorial_plan_version','lock_version >= 0'),
    ],
    fks=[
        fk('site_id','portfolio.site'),fk('category_id','portfolio.category'),fk('intent_cluster_id','portfolio.intent_cluster'),
        fk('primary_keyword_id','portfolio.keyword'),fk('opportunity_assessment_id','portfolio.opportunity_assessment'),
        fk('created_by_principal_id','iam.principal'),fk('approved_by_principal_id','iam.principal'),
    ],
    indexes=[
        idx('ix_editorial_plan_queue',['site_id','status','priority','updated_at']),
        idx('ix_editorial_plan_keyword',['primary_keyword_id','status']),idx('ix_editorial_plan_cluster',['intent_cluster_id','status']),
    ],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-001','FR-005','FR-009'],implementation_slice='SLICE-006',
    expected_gate1_rows='<1k',expected_gate4_rows='<10m'
))

add(Table(
    'editorial','article','論理記事Aggregate。SlugやVersionを分離し、current/published Versionはdeferrable FKで指す。',
    [
        id_col(), display_col('ART'), c('site_id','uuid',nullable=False), c('article_plan_id','uuid',nullable=False),
        c('article_type','text',nullable=False), c('status','text',nullable=False,default="'IDEA'"),
        c('current_version_id','uuid',nullable=True), c('published_version_id','uuid',nullable=True),
        c('archived_at','timestamptz',nullable=True), c('archive_reason','text',nullable=True), *mutable_tail(),
    ],
    uniques=[('uq_editorial_article_display',['display_id']),('uq_editorial_article_plan',['article_plan_id'])],
    checks=[
        ('ck_editorial_article_type',enum_check('article_type',['SELECTION_GUIDE','USE_CASE_RECOMMENDATION','PRODUCT_COMPARISON','MODEL_DIFFERENCE','CONDITION_FILTER'])),
        ('ck_editorial_article_status',enum_check('status',['IDEA','PLANNED','SOURCES_PENDING','PACKET_READY','GENERATING','DRAFT','AUTO_REVIEW','HUMAN_REVIEW','APPROVED','SCHEDULED','PUBLISHED','UPDATE_PENDING','PAUSED','ARCHIVED'])),
        ('ck_editorial_article_archive',"status <> 'ARCHIVED' OR archived_at IS NOT NULL"),('ck_editorial_article_version','lock_version >= 0'),
    ],
    fks=[
        fk('site_id','portfolio.site'),fk('article_plan_id','editorial.article_plan'),
        fk('current_version_id','editorial.article_version',deferrable=True,initially_deferred=True),
        fk('published_version_id','editorial.article_version',deferrable=True,initially_deferred=True),
    ],
    indexes=[idx('ix_editorial_article_status',['site_id','status','updated_at']),idx('ix_editorial_article_current',['current_version_id']),idx('ix_editorial_article_published',['published_version_id'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-001','FR-009','FR-010'],implementation_slice='SLICE-012',
    expected_gate1_rows='<1k',expected_gate4_rows='<10m'
))

add(Table(
    'editorial','article_slug','Site内Pathの履歴。Slug変更時は既存行を上書きせずvalid_toを閉じ、新行を作る。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('article_id','uuid',nullable=False), c('slug','text',nullable=False),
        c('normalized_path','text',nullable=False), c('status','text',nullable=False), c('valid_from','timestamptz',nullable=False),
        c('valid_to','timestamptz',nullable=True), created_col(),
    ],
    checks=[
        ('ck_editorial_slug_path',"normalized_path ~ '^/[a-z0-9/_-]*$'"),('ck_editorial_slug_status',enum_check('status',['ACTIVE','REDIRECTED','RETIRED'])),
        ('ck_editorial_slug_window','valid_to IS NULL OR valid_to > valid_from'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article')],
    indexes=[
        idx('uq_editorial_slug_active_path',['site_id','normalized_path'],unique=True,where='valid_to IS NULL'),
        idx('uq_editorial_slug_active_article',['article_id'],unique=True,where="valid_to IS NULL AND status = 'ACTIVE'"),
        idx('ix_editorial_slug_article_history',['article_id','valid_from']),
    ],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-010'],implementation_slice='SLICE-012',
    expected_gate1_rows='<5k',expected_gate4_rows='<50m'
))

add(Table(
    'editorial','article_version','構造化記事のVersion。AI Draft、人間Edit、Review、Approvalを上書きせずVersionで管理する。',
    [
        id_col(), display_col('ARV'), c('article_id','uuid',nullable=False), c('version_no','integer',nullable=False),
        c('content_schema_version','integer',nullable=False), c('title','text',nullable=False), c('meta_title','text',nullable=True),
        c('meta_description','text',nullable=True), c('excerpt','text',nullable=True), c('body_sha256','text',nullable=False),
        c('status','text',nullable=False,default="'DRAFT'"), c('source_packet_version_id','uuid',nullable=False),
        c('based_on_version_id','uuid',nullable=True), c('ai_job_id','uuid',nullable=True), c('created_by_actor_type','text',nullable=False),
        c('created_by_actor_id','uuid',nullable=True), c('submitted_at','timestamptz',nullable=True), c('reviewed_at','timestamptz',nullable=True),
        *mutable_tail(),
    ],
    uniques=[('uq_editorial_article_version_display',['display_id']),('uq_editorial_article_version_no',['article_id','version_no'])],
    checks=[
        ('ck_editorial_article_version_num','version_no >= 1 AND content_schema_version >= 1'),('ck_editorial_article_version_hash',hash_check('body_sha256')),
        ('ck_editorial_article_version_status',enum_check('status',['DRAFT','AUTO_REVIEW','HUMAN_REVIEW','APPROVED','REJECTED','SUPERSEDED'])),
        ('ck_editorial_article_version_actor',enum_check('created_by_actor_type',['USER','SERVICE','SYSTEM'])),
        ('ck_editorial_article_version_review',"status NOT IN ('HUMAN_REVIEW','APPROVED','REJECTED') OR submitted_at IS NOT NULL"),
        ('ck_editorial_article_version_lock','lock_version >= 0'),
    ],
    fks=[
        fk('article_id','editorial.article',deferrable=True,initially_deferred=True),fk('source_packet_version_id','evidence.source_packet_version'),
        fk('based_on_version_id','editorial.article_version'),fk('ai_job_id','ai.ai_job'),
    ],
    indexes=[idx('ix_editorial_article_version_status',['article_id','status','version_no']),idx('ix_editorial_article_version_packet',['source_packet_version_id'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-006','FR-007','FR-009','FR-010'],implementation_slice='SLICE-012',
    expected_gate1_rows='<10k',expected_gate4_rows='<100m',notes=['APPROVED遷移はIntegrity GuardでFinal human approval、Quality pass、approved Source Packetを要求する。']
))

add(Table(
    'editorial','article_block','Article Version内の順序付き構造化Block。任意HTMLではなくBlock type＋Schema-valid JSONを保存する。',
    [
        id_col(), c('article_version_id','uuid',nullable=False), c('block_key','text',nullable=False), c('block_type','text',nullable=False),
        c('position','integer',nullable=False), c('heading_level','smallint',nullable=True), json_obj('content',description='Block type別JSON Schemaに適合した構造化本文。'),
        c('plain_text','text',nullable=False), c('content_sha256','text',nullable=False), created_col(),
    ],
    uniques=[('uq_editorial_block_key',['article_version_id','block_key']),('uq_editorial_block_position',['article_version_id','position']),('uq_editorial_block_id_version',['id','article_version_id'])],
    checks=[
        ('ck_editorial_block_type',enum_check('block_type',['INTRO','HEADING','PARAGRAPH','SELECTION_CRITERIA','COMPARISON_TABLE','PRODUCT_CARD','RECOMMENDATION','FIT_NONFIT','FAQ','DISCLOSURE','SUMMARY','CALLOUT','INTERNAL_LINKS'])),
        ('ck_editorial_block_position','position >= 0'),('ck_editorial_block_heading','heading_level IS NULL OR heading_level BETWEEN 2 AND 4'),
        ('ck_editorial_block_content',json_object_check('content')),('ck_editorial_block_hash',hash_check('content_sha256')),
    ],
    fks=[fk('article_version_id','editorial.article_version')],
    indexes=[idx('ix_editorial_block_order',['article_version_id','position'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-007','FR-008','FR-009'],implementation_slice='SLICE-012',
    expected_gate1_rows='<500k',expected_gate4_rows='<5b'
))

add(Table(
    'editorial','article_block_product','BlockへProduct/Offerをroleとposition付きで結ぶ。',
    [
        c('article_block_id','uuid',nullable=False), c('product_id','uuid',nullable=False), c('offer_id','uuid',nullable=True),
        c('placement_role','text',nullable=False), c('position','integer',nullable=False), c('placement_id','text',nullable=False), created_col(),
    ],
    pk=['article_block_id','product_id','placement_role'],
    uniques=[('uq_editorial_block_placement',['placement_id'])],
    checks=[('ck_editorial_block_product_role',enum_check('placement_role',['PRIMARY','ALTERNATIVE','COMPARED','MENTIONED','EXCLUDED'])),('ck_editorial_block_product_position','position >= 0')],
    fks=[fk('article_block_id','editorial.article_block'),fk('product_id','catalog.canonical_product'),fk('offer_id','catalog.offer')],
    indexes=[idx('ix_editorial_block_product_order',['article_block_id','position']),idx('ix_editorial_block_product_reverse',['product_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-007','FR-013'],implementation_slice='SLICE-012',
    expected_gate1_rows='<500k',expected_gate4_rows='<5b'
))

add(Table(
    'editorial','comparison_axis','Article Versionごとの比較軸定義。Product比較表の意味と型・単位・根拠要件を固定する。',
    [
        id_col(), c('article_version_id','uuid',nullable=False), c('axis_code','text',nullable=False), c('name','text',nullable=False),
        c('description','text',nullable=False), c('data_type','text',nullable=False), c('unit_code','text',nullable=True),
        c('position','integer',nullable=False), c('is_required','boolean',nullable=False,default='true'), created_col(),
    ],
    uniques=[('uq_editorial_axis_code',['article_version_id','axis_code']),('uq_editorial_axis_position',['article_version_id','position'])],
    checks=[('ck_editorial_axis_type',enum_check('data_type',['TEXT','NUMERIC','BOOLEAN','DATE','CODE'])),('ck_editorial_axis_position','position >= 0')],
    fks=[fk('article_version_id','editorial.article_version')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['OBJ-USER-001','OBJ-USER-002','FR-007'],implementation_slice='SLICE-012',
    expected_gate1_rows='<100k',expected_gate4_rows='<1b'
))

add(Table(
    'editorial','comparison_value','比較軸×Productの型付き値、表示値、根拠Fact、Validation状態。',
    [
        id_col(), c('comparison_axis_id','uuid',nullable=False), c('product_id','uuid',nullable=False),
        c('value_text','text',nullable=True), c('value_numeric','numeric(30,10)',nullable=True), c('value_boolean','boolean',nullable=True),
        c('value_date','date',nullable=True), c('value_code','text',nullable=True), c('display_value','text',nullable=False),
        c('source_fact_id','uuid',nullable=True), c('validation_status','text',nullable=False), created_col(),
    ],
    uniques=[('uq_editorial_comparison_value',['comparison_axis_id','product_id'])],
    checks=[
        ('ck_editorial_comparison_one_value',exactly_one('value_text','value_numeric','value_boolean','value_date','value_code')),
        ('ck_editorial_comparison_status',enum_check('validation_status',['VALID','MISSING','CONFLICT','UNSUPPORTED'])),
        ('ck_editorial_comparison_evidence',"validation_status <> 'VALID' OR source_fact_id IS NOT NULL"),
    ],
    fks=[fk('comparison_axis_id','editorial.comparison_axis'),fk('product_id','catalog.canonical_product'),fk('source_fact_id','evidence.fact')],
    indexes=[idx('ix_editorial_comparison_product',['product_id','comparison_axis_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['OBJ-USER-002','FR-007'],implementation_slice='SLICE-012',
    expected_gate1_rows='<1m',expected_gate4_rows='<10b'
))

add(Table(
    'editorial','recommendation_set','用途・条件別Recommendation groupとMethodologyをArticle Versionへ固定する。',
    [
        id_col(), c('article_version_id','uuid',nullable=False), c('set_code','text',nullable=False), c('name','text',nullable=False),
        c('target_segment','text',nullable=False), c('methodology','text',nullable=False), c('editorial_policy_version','text',nullable=False),
        c('position','integer',nullable=False), created_col(),
    ],
    uniques=[('uq_editorial_rec_set_code',['article_version_id','set_code']),('uq_editorial_rec_set_position',['article_version_id','position'])],
    checks=[('ck_editorial_rec_set_position','position >= 0')],
    fks=[fk('article_version_id','editorial.article_version')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['OBJ-USER-002','PRINCIPLE-04','FR-005'],implementation_slice='SLICE-012',
    expected_gate1_rows='<100k',expected_gate4_rows='<1b'
))

add(Table(
    'editorial','recommendation','Recommendation Set内の商品順位とEditorial Suitability Score。収益・Affiliate rate Columnを持たない。',
    [
        id_col(), c('recommendation_set_id','uuid',nullable=False), c('product_id','uuid',nullable=False), c('rank_position','integer',nullable=False),
        c('suitability_score','numeric(5,2)',nullable=False), c('status','text',nullable=False), created_col(),
    ],
    uniques=[('uq_editorial_rec_product',['recommendation_set_id','product_id']),('uq_editorial_rec_rank',['recommendation_set_id','rank_position'])],
    checks=[('ck_editorial_rec_rank','rank_position >= 1'),('ck_editorial_rec_score',score_check('suitability_score')),('ck_editorial_rec_status',enum_check('status',['RECOMMENDED','ALTERNATIVE','NOT_RECOMMENDED','EXCLUDED']))],
    fks=[fk('recommendation_set_id','editorial.recommendation_set'),fk('product_id','catalog.canonical_product')],
    indexes=[idx('ix_editorial_rec_product_reverse',['product_id'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['OBJ-USER-002','FR-005','PRINCIPLE-04'],implementation_slice='SLICE-012',
    expected_gate1_rows='<500k',expected_gate4_rows='<5b',notes=['Schema Lintでaffiliate_rate、commission、revenue、profit等のColumn追加を禁止する。']
))

add(Table(
    'editorial','recommendation_rationale','推薦のfit/non-fit/trade-off/qualifierをClaimまたはFactへ結び、説明可能性を担保する。',
    [
        id_col(), c('recommendation_id','uuid',nullable=False), c('rationale_type','text',nullable=False), c('rationale_text','text',nullable=False),
        c('claim_id','uuid',nullable=True), c('source_fact_id','uuid',nullable=True), c('position','integer',nullable=False), created_col(),
    ],
    checks=[
        ('ck_editorial_rationale_type',enum_check('rationale_type',['FIT','NON_FIT','TRADE_OFF','QUALIFIER','EVIDENCE'])),
        ('ck_editorial_rationale_source','claim_id IS NOT NULL OR source_fact_id IS NOT NULL'),('ck_editorial_rationale_position','position >= 0'),
    ],
    fks=[fk('recommendation_id','editorial.recommendation'),fk('claim_id','evidence.claim'),fk('source_fact_id','evidence.fact')],
    indexes=[idx('ix_editorial_rationale_order',['recommendation_id','position'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['OBJ-USER-002','FR-007'],implementation_slice='SLICE-012',
    expected_gate1_rows='<1m',expected_gate4_rows='<10b'
))

add(Table(
    'editorial','review_comment','Article Version、Block、Claimに対するReview thread。修正・解決履歴を上書きせずCommentとして残す。',
    [
        id_col(), c('article_version_id','uuid',nullable=False), c('article_block_id','uuid',nullable=True), c('claim_id','uuid',nullable=True),
        c('thread_id','uuid',nullable=False), c('parent_comment_id','uuid',nullable=True), c('author_principal_id','uuid',nullable=False),
        c('comment_text','text',nullable=False,classification='CONFIDENTIAL'), c('status','text',nullable=False,default="'OPEN'"),
        c('resolved_by_principal_id','uuid',nullable=True), c('resolved_at','timestamptz',nullable=True), created_col(),
    ],
    checks=[('ck_editorial_review_comment_status',enum_check('status',['OPEN','RESOLVED','WONT_FIX'])),('ck_editorial_review_comment_target','article_block_id IS NOT NULL OR claim_id IS NOT NULL'),('ck_editorial_review_comment_resolve_pair','(resolved_by_principal_id IS NULL) = (resolved_at IS NULL)')],
    fks=[fk('article_version_id','editorial.article_version'),fk('article_block_id','editorial.article_block'),fk('claim_id','evidence.claim'),fk('parent_comment_id','editorial.review_comment'),fk('author_principal_id','iam.principal'),fk('resolved_by_principal_id','iam.principal')],
    indexes=[idx('ix_editorial_review_thread',['thread_id','created_at']),idx('ix_editorial_review_open',['article_version_id','status'],where="status = 'OPEN'")],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-009','FR-020'],implementation_slice='SLICE-014',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'editorial','article_link','記事間のInternal/Related/Canonical link intentを管理し、公開時に安全なRouteへ解決する。',
    [
        id_col(), c('from_article_id','uuid',nullable=False), c('to_article_id','uuid',nullable=False), c('link_type','text',nullable=False),
        c('anchor_text','text',nullable=True), c('source_block_key','text',nullable=True), c('status','text',nullable=False,default="'ACTIVE'"),
        c('reason','text',nullable=True), *mutable_tail(),
    ],
    uniques=[('uq_editorial_article_link',['from_article_id','to_article_id','link_type'])],
    checks=[('ck_editorial_article_link_self','from_article_id <> to_article_id'),('ck_editorial_article_link_type',enum_check('link_type',['INTERNAL','RELATED','CANONICAL_REFERENCE'])),('ck_editorial_article_link_status',enum_check('status',['ACTIVE','PAUSED','REMOVED'])),('ck_editorial_article_link_version','lock_version >= 0')],
    fks=[fk('from_article_id','editorial.article'),fk('to_article_id','editorial.article')],
    indexes=[idx('ix_editorial_article_link_to',['to_article_id','status'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-016'],implementation_slice='SLICE-012',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

# ---------------------------------------------------------------------------
# AI SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'ai','task_definition','AI処理のTask type、Risk、Output Schema、予算、人間Review要否を定義する。',
    [
        id_col(), c('task_code','text',nullable=False), c('name','text',nullable=False), c('description','text',nullable=False),
        c('risk_level','text',nullable=False), c('output_schema_code','text',nullable=False), c('default_max_tokens','integer',nullable=False),
        c('default_max_cost_jpy','bigint',nullable=False), c('human_review_required','boolean',nullable=False,default='true'),
        c('status','text',nullable=False,default="'ACTIVE'"), created_col(),
    ],
    uniques=[('uq_ai_task_code',['task_code'])],
    checks=[
        ('ck_ai_task_risk',enum_check('risk_level',['LOW','MEDIUM','HIGH','CRITICAL'])),('ck_ai_task_tokens','default_max_tokens BETWEEN 1 AND 1000000'),
        ('ck_ai_task_cost','default_max_cost_jpy >= 0'),('ck_ai_task_status',enum_check('status',['ACTIVE','PAUSED','RETIRED'])),
    ],
    write_pattern='REFERENCE',classification='INTERNAL',retention_class='CONFIG_7Y',requirements=['FR-006','FR-008','FR-018'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

add(Table(
    'ai','prompt_version','Git管理Prompt templateの稼働Version、hash、承認、適用期間を登録する。Prompt本文はDBへ重複保存しない。',
    [
        id_col(), display_col('PRM'), c('task_definition_id','uuid',nullable=False), c('prompt_code','text',nullable=False), c('version_no','integer',nullable=False),
        c('git_path','text',nullable=False), c('git_commit_sha','text',nullable=False), c('template_sha256','text',nullable=False),
        c('status','text',nullable=False), c('effective_from','timestamptz',nullable=True), c('effective_to','timestamptz',nullable=True),
        c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_ai_prompt_display',['display_id']),('uq_ai_prompt_version',['prompt_code','version_no'])],
    checks=[
        ('ck_ai_prompt_version','version_no >= 1'),('ck_ai_prompt_git',"git_commit_sha ~ '^[0-9a-f]{40,64}$'"),('ck_ai_prompt_hash',hash_check('template_sha256')),
        ('ck_ai_prompt_status',enum_check('status',['DRAFT','ACTIVE','RETIRED','REJECTED'])),('ck_ai_prompt_window','effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from'),
        ('ck_ai_prompt_approval',"status <> 'ACTIVE' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL)"),
    ],
    fks=[fk('task_definition_id','ai.task_definition'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('uq_ai_prompt_active',['prompt_code'],unique=True,where="status = 'ACTIVE'"),idx('ix_ai_prompt_task',['task_definition_id','status'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='AI_CONFIG_7Y',requirements=['FR-018','NFR-MAINT-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'ai','output_schema_version','Structured OutputのJSON Schema version、Git commit、hash、稼働状態を登録する。',
    [
        id_col(), c('schema_code','text',nullable=False), c('version_no','integer',nullable=False), c('git_path','text',nullable=False),
        c('git_commit_sha','text',nullable=False), c('schema_sha256','text',nullable=False), c('status','text',nullable=False),
        c('effective_from','timestamptz',nullable=True), c('effective_to','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_ai_output_schema_version',['schema_code','version_no'])],
    checks=[('ck_ai_output_schema_version','version_no >= 1'),('ck_ai_output_schema_git',"git_commit_sha ~ '^[0-9a-f]{40,64}$'"),('ck_ai_output_schema_hash',hash_check('schema_sha256')),('ck_ai_output_schema_status',enum_check('status',['DRAFT','ACTIVE','RETIRED'])),('ck_ai_output_schema_window','effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from')],
    indexes=[idx('uq_ai_output_schema_active',['schema_code'],unique=True,where="status = 'ACTIVE'")],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='AI_CONFIG_7Y',requirements=['FR-018','NFR-MAINT-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'ai','model_definition','Provider model ID、Capability、Pricing observation、稼働状態を管理する。API Keyは保持しない。',
    [
        id_col(), c('provider_code','text',nullable=False), c('provider_model_id','text',nullable=False), c('display_name','text',nullable=False),
        json_obj('capabilities',description='Structured output、context、batch等のCapability snapshot。'),
        c('input_price_per_million','numeric(20,8)',nullable=True), c('cached_input_price_per_million','numeric(20,8)',nullable=True),
        c('output_price_per_million','numeric(20,8)',nullable=True), c('pricing_currency','text',nullable=True),
        c('pricing_observed_at','timestamptz',nullable=True), c('status','text',nullable=False), created_col(),
    ],
    uniques=[('uq_ai_model_provider_id',['provider_code','provider_model_id'])],
    checks=[
        ('ck_ai_model_capabilities',json_object_check('capabilities')),('ck_ai_model_prices','(input_price_per_million IS NULL OR input_price_per_million >= 0) AND (cached_input_price_per_million IS NULL OR cached_input_price_per_million >= 0) AND (output_price_per_million IS NULL OR output_price_per_million >= 0)'),
        ('ck_ai_model_currency',"pricing_currency IS NULL OR pricing_currency ~ '^[A-Z]{3}$'"),('ck_ai_model_status',enum_check('status',['ACTIVE','EVALUATION','PAUSED','RETIRED','BLOCKED'])),
    ],
    indexes=[idx('ix_ai_model_status',['provider_code','status'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='AI_CONFIG_7Y',requirements=['FR-018','NFR-COST-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

add(Table(
    'ai','model_route_version','TaskごとのPrimary/Fallback model、Timeout、Budget、Retry等の稼働Route version。',
    [
        id_col(), c('route_code','text',nullable=False), c('version_no','integer',nullable=False), c('task_definition_id','uuid',nullable=False),
        c('primary_model_id','uuid',nullable=False), c('fallback_model_id','uuid',nullable=True), json_obj('route_config',description='Timeout、retry、temperature、max tokens等。'),
        c('monthly_budget_jpy','bigint',nullable=True), c('per_job_budget_jpy','bigint',nullable=False), c('status','text',nullable=False),
        c('effective_from','timestamptz',nullable=True), c('effective_to','timestamptz',nullable=True), c('approved_by_principal_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_ai_route_version',['route_code','version_no'])],
    checks=[
        ('ck_ai_route_version','version_no >= 1'),('ck_ai_route_config',json_object_check('route_config')),('ck_ai_route_budget','(monthly_budget_jpy IS NULL OR monthly_budget_jpy >= 0) AND per_job_budget_jpy >= 0'),
        ('ck_ai_route_status',enum_check('status',['DRAFT','ACTIVE','PAUSED','RETIRED'])),('ck_ai_route_window','effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from'),
        ('ck_ai_route_models','fallback_model_id IS NULL OR fallback_model_id <> primary_model_id'),
    ],
    fks=[fk('task_definition_id','ai.task_definition'),fk('primary_model_id','ai.model_definition'),fk('fallback_model_id','ai.model_definition'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('uq_ai_route_active',['route_code'],unique=True,where="status = 'ACTIVE'"),idx('ix_ai_route_task',['task_definition_id','status'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='AI_CONFIG_7Y',requirements=['FR-018','NFR-COST-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'ai','ai_job','AI TaskのCanonical requestと各Version参照を固定し、Ops Jobと1対1で実行状態を管理する。',
    [
        id_col(), display_col('AIJ'), c('ops_job_id','uuid',nullable=False), c('task_definition_id','uuid',nullable=False),
        c('article_plan_id','uuid',nullable=True), c('article_version_id','uuid',nullable=True), c('source_packet_version_id','uuid',nullable=False),
        c('prompt_version_id','uuid',nullable=False), c('output_schema_version_id','uuid',nullable=False), c('model_route_version_id','uuid',nullable=False),
        c('status','text',nullable=False,default="'PENDING'"), c('max_cost_jpy','bigint',nullable=False), c('completed_at','timestamptz',nullable=True),
        created_col(),
    ],
    uniques=[('uq_ai_job_display',['display_id']),('uq_ai_job_ops',['ops_job_id'])],
    checks=[
        ('ck_ai_job_status',enum_check('status',['PENDING','RUNNING','SUCCEEDED','FAILED','BLOCKED','CANCELLED'])),('ck_ai_job_cost','max_cost_jpy >= 0'),
        ('ck_ai_job_target','article_plan_id IS NOT NULL OR article_version_id IS NOT NULL'),('ck_ai_job_complete',"status NOT IN ('SUCCEEDED','FAILED','BLOCKED','CANCELLED') OR completed_at IS NOT NULL"),
    ],
    fks=[
        fk('ops_job_id','ops.job'),fk('task_definition_id','ai.task_definition'),fk('article_plan_id','editorial.article_plan'),fk('article_version_id','editorial.article_version'),
        fk('source_packet_version_id','evidence.source_packet_version'),fk('prompt_version_id','ai.prompt_version'),fk('output_schema_version_id','ai.output_schema_version'),fk('model_route_version_id','ai.model_route_version'),
    ],
    indexes=[idx('ix_ai_job_status',['status','created_at']),idx('ix_ai_job_article',['article_plan_id','article_version_id'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='AI_RUN_3Y',requirements=['FR-006','FR-018'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m',notes=['INSERT/実行開始時にSource Packet Version=APPROVEDをDB Integrity Guardで確認する。']
))

add(Table(
    'ai','ai_attempt','Provider callごとの入力/出力Artifact、model、request ID、hash、Refusal、Latency、Errorを不変保存する。',
    [
        id_col(), c('ai_job_id','uuid',nullable=False), c('attempt_no','smallint',nullable=False), c('model_id','uuid',nullable=False),
        c('provider_request_id','text',nullable=True,classification='CONFIDENTIAL'), c('status','text',nullable=False), c('input_artifact_id','uuid',nullable=False),
        c('output_artifact_id','uuid',nullable=True), c('input_sha256','text',nullable=False), c('output_sha256','text',nullable=True),
        c('refusal_code','text',nullable=True), c('finish_reason','text',nullable=True), c('latency_ms','integer',nullable=True),
        c('error_class','text',nullable=True), c('error_code','text',nullable=True), c('error_message','text',nullable=True,classification='CONFIDENTIAL'),
        c('started_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_ai_attempt_no',['ai_job_id','attempt_no'])],
    checks=[
        ('ck_ai_attempt_no','attempt_no >= 1'),('ck_ai_attempt_status',enum_check('status',['RUNNING','SUCCEEDED','FAILED','REFUSED','TIMED_OUT','CANCELLED'])),
        ('ck_ai_attempt_input_hash',hash_check('input_sha256')),('ck_ai_attempt_output_hash',"output_sha256 IS NULL OR " + hash_check('output_sha256')),
        ('ck_ai_attempt_latency','latency_ms IS NULL OR latency_ms >= 0'),('ck_ai_attempt_complete',"status = 'RUNNING' OR completed_at IS NOT NULL"),
        ('ck_ai_attempt_output',"status <> 'SUCCEEDED' OR (output_artifact_id IS NOT NULL AND output_sha256 IS NOT NULL)"),
    ],
    fks=[fk('ai_job_id','ai.ai_job'),fk('model_id','ai.model_definition'),fk('input_artifact_id','ops.object_artifact'),fk('output_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_ai_attempt_model_time',['model_id','started_at']),idx('ix_ai_attempt_status',['status','started_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AI_RUN_3Y',requirements=['FR-018','NFR-AUD-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100k',expected_gate4_rows='<500m',partitioning='CANDIDATE_BY_STARTED_AT_AFTER_20M'
))

add(Table(
    'ai','usage_cost','AI AttemptのToken usage、Provider原通貨費用、換算Rate、JPY費用を不変記録する。',
    [
        id_col(), c('ai_attempt_id','uuid',nullable=False), c('input_tokens','bigint',nullable=False), c('cached_input_tokens','bigint',nullable=False,default='0'),
        c('output_tokens','bigint',nullable=False), c('total_tokens','bigint',nullable=False), c('provider_cost_amount','numeric(20,8)',nullable=False),
        c('provider_currency','text',nullable=False), c('fx_rate_to_jpy','numeric(20,8)',nullable=False), c('cost_jpy','bigint',nullable=False),
        c('pricing_version','text',nullable=False), c('observed_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_ai_usage_attempt',['ai_attempt_id'])],
    checks=[
        ('ck_ai_usage_tokens','input_tokens >= 0 AND cached_input_tokens >= 0 AND output_tokens >= 0 AND total_tokens = input_tokens + output_tokens'),
        ('ck_ai_usage_cost','provider_cost_amount >= 0 AND fx_rate_to_jpy > 0 AND cost_jpy >= 0'),('ck_ai_usage_currency',"provider_currency ~ '^[A-Z]{3}$'"),
    ],
    fks=[fk('ai_attempt_id','ai.ai_attempt')],
    indexes=[idx('ix_ai_usage_observed',['observed_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-018','NFR-COST-001'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100k',expected_gate4_rows='<500m'
))

add(Table(
    'ai','evaluation_result','Model RouteまたはPrompt候補を固定Evaluation suiteで比較したCase/Metric結果。詳細DatasetはArtifactへ置く。',
    [
        id_col(), c('suite_code','text',nullable=False), c('suite_version','integer',nullable=False), c('run_id','uuid',nullable=False),
        c('task_definition_id','uuid',nullable=False), c('model_route_version_id','uuid',nullable=False), c('prompt_version_id','uuid',nullable=False),
        c('case_key','text',nullable=False), c('metric_code','text',nullable=False), c('metric_value','numeric(20,8)',nullable=False),
        c('passed','boolean',nullable=False), json_obj('details',classification='CONFIDENTIAL'), c('result_artifact_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_ai_eval_case_metric',['run_id','case_key','metric_code'])],
    checks=[('ck_ai_eval_suite_version','suite_version >= 1'),('ck_ai_eval_details',json_object_check('details'))],
    fks=[fk('task_definition_id','ai.task_definition'),fk('model_route_version_id','ai.model_route_version'),fk('prompt_version_id','ai.prompt_version'),fk('result_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_ai_eval_route',['model_route_version_id','created_at']),idx('ix_ai_eval_run',['run_id','case_key'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='AI_EVAL_3Y',requirements=['NFR-TEST-001','FR-018'],implementation_slice='SLICE-011',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

# ---------------------------------------------------------------------------
# POLICY SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'policy','policy_bundle','規約・品質・鮮度・Security Rule集合をVersion、Git commit、hash、承認、有効期間で固定する。',
    [
        id_col(), display_col('POL'), c('bundle_code','text',nullable=False), c('version_no','integer',nullable=False), c('status','text',nullable=False),
        c('git_commit_sha','text',nullable=False), c('bundle_sha256','text',nullable=False), c('effective_from','timestamptz',nullable=True),
        c('effective_to','timestamptz',nullable=True), c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_policy_bundle_display',['display_id']),('uq_policy_bundle_version',['bundle_code','version_no'])],
    checks=[
        ('ck_policy_bundle_version','version_no >= 1'),('ck_policy_bundle_status',enum_check('status',['DRAFT','ACTIVE','RETIRED','REJECTED'])),
        ('ck_policy_bundle_git',"git_commit_sha ~ '^[0-9a-f]{40,64}$'"),('ck_policy_bundle_hash',hash_check('bundle_sha256')),
        ('ck_policy_bundle_window','effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from'),
        ('ck_policy_bundle_approval',"status <> 'ACTIVE' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL)"),
    ],
    fks=[fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('uq_policy_bundle_active',['bundle_code'],unique=True,where="status = 'ACTIVE'")],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='POLICY_7Y',requirements=['FR-008','FR-017','FR-019','NFR-MAINT-001'],implementation_slice='SLICE-013',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'policy','rule_version','個別RuleのCategory、Severity、Blocking、Implementation、定義、hashをVersion管理する。',
    [
        id_col(), c('rule_code','text',nullable=False), c('version_no','integer',nullable=False), c('rule_category','text',nullable=False),
        c('severity','text',nullable=False), c('is_blocking','boolean',nullable=False), c('implementation_type','text',nullable=False),
        json_obj('definition',description='Regex、threshold、field、manual checklist等のRule定義。'), c('definition_sha256','text',nullable=False),
        c('status','text',nullable=False), c('created_by_principal_id','uuid',nullable=False), c('approved_by_principal_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_policy_rule_version',['rule_code','version_no'])],
    checks=[
        ('ck_policy_rule_version','version_no >= 1'),('ck_policy_rule_category',enum_check('rule_category',['COMPLIANCE','FACTUAL','QUALITY','FRESHNESS','LINK','SECURITY','ACCESSIBILITY','SEO'])),
        ('ck_policy_rule_severity',enum_check('severity',['INFO','LOW','MEDIUM','HIGH','CRITICAL'])),('ck_policy_rule_impl',enum_check('implementation_type',['PYTHON','SQL','REGEX','JSON_SCHEMA','MANUAL'])),
        ('ck_policy_rule_definition',json_object_check('definition')),('ck_policy_rule_hash',hash_check('definition_sha256')),('ck_policy_rule_status',enum_check('status',['DRAFT','ACTIVE','RETIRED','REJECTED'])),
    ],
    fks=[fk('created_by_principal_id','iam.principal'),fk('approved_by_principal_id','iam.principal')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='POLICY_7Y',requirements=['FR-008','FR-017'],implementation_slice='SLICE-013',
    expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'policy','bundle_rule','Policy Bundle内のRule version、実行順、enforce/shadow/disabled modeを固定する。',
    [
        c('policy_bundle_id','uuid',nullable=False), c('rule_version_id','uuid',nullable=False), c('execution_order','integer',nullable=False),
        c('mode','text',nullable=False), created_col(),
    ],
    pk=['policy_bundle_id','rule_version_id'], uniques=[('uq_policy_bundle_rule_order',['policy_bundle_id','execution_order'])],
    checks=[('ck_policy_bundle_rule_order','execution_order >= 0'),('ck_policy_bundle_rule_mode',enum_check('mode',['ENFORCE','SHADOW','DISABLED']))],
    fks=[fk('policy_bundle_id','policy.policy_bundle'),fk('rule_version_id','policy.rule_version')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='POLICY_7Y',requirements=['FR-008','FR-017'],implementation_slice='SLICE-013',
    expected_gate1_rows='<50k',expected_gate4_rows='<10m'
))

add(Table(
    'policy','quality_check_run','Article Versionを特定Source Packet/Policy Bundleで検査したRunとReport Artifact。',
    [
        id_col(), display_col('QCR'), c('article_version_id','uuid',nullable=False), c('source_packet_version_id','uuid',nullable=False),
        c('policy_bundle_id','uuid',nullable=False), c('status','text',nullable=False), c('triggered_by_actor_type','text',nullable=False),
        c('triggered_by_actor_id','uuid',nullable=True), c('started_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True),
        c('total_score','numeric(5,2)',nullable=True), c('blocking_finding_count','integer',nullable=False,default='0'), c('report_artifact_id','uuid',nullable=True),
        created_col(),
    ],
    uniques=[('uq_policy_check_display',['display_id'])],
    checks=[
        ('ck_policy_check_status',enum_check('status',['RUNNING','PASSED','FAILED','ERROR','CANCELLED'])),('ck_policy_check_actor',enum_check('triggered_by_actor_type',['USER','SERVICE','SYSTEM'])),
        ('ck_policy_check_score','total_score IS NULL OR ' + score_check('total_score')),('ck_policy_check_blocking','blocking_finding_count >= 0'),
        ('ck_policy_check_complete',"status = 'RUNNING' OR completed_at IS NOT NULL"),
    ],
    fks=[fk('article_version_id','editorial.article_version'),fk('source_packet_version_id','evidence.source_packet_version'),fk('policy_bundle_id','policy.policy_bundle'),fk('report_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_policy_check_article',['article_version_id','started_at']),idx('ix_policy_check_status',['status','started_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-008','FR-017'],implementation_slice='SLICE-013',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'policy','finding','Quality Checkで検出したRule違反・不足・Conflictを対象Entityへ紐付け、解決・Waiver状態を管理する。',
    [
        id_col(), c('quality_check_run_id','uuid',nullable=False), c('rule_version_id','uuid',nullable=False), c('finding_code','text',nullable=False),
        c('severity','text',nullable=False), c('is_blocking','boolean',nullable=False), c('entity_type','text',nullable=False), c('entity_id','uuid',nullable=True),
        c('article_block_id','uuid',nullable=True), c('claim_id','uuid',nullable=True), c('message','text',nullable=False),
        json_obj('evidence',description='検出値、expected、locator、comparison等。',classification='CONFIDENTIAL'), c('status','text',nullable=False,default="'OPEN'"),
        c('resolved_at','timestamptz',nullable=True), c('resolved_by_principal_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_policy_finding_severity',enum_check('severity',['INFO','LOW','MEDIUM','HIGH','CRITICAL'])),('ck_policy_finding_entity',enum_check('entity_type',['ARTICLE_VERSION','BLOCK','CLAIM','PRODUCT','OFFER','LINK','SOURCE_PACKET'])),
        ('ck_policy_finding_status',enum_check('status',['OPEN','FIXED','WAIVED','FALSE_POSITIVE','ACCEPTED_RISK'])),('ck_policy_finding_evidence',json_object_check('evidence')),
        ('ck_policy_finding_resolve_pair','(resolved_at IS NULL) = (resolved_by_principal_id IS NULL)'),
    ],
    fks=[fk('quality_check_run_id','policy.quality_check_run'),fk('rule_version_id','policy.rule_version'),fk('article_block_id','editorial.article_block'),fk('claim_id','evidence.claim'),fk('resolved_by_principal_id','iam.principal')],
    indexes=[idx('ix_policy_finding_open',['quality_check_run_id','is_blocking','severity'],where="status = 'OPEN'"),idx('ix_policy_finding_entity',['entity_type','entity_id'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-008','FR-017'],implementation_slice='SLICE-013',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b'
))

add(Table(
    'policy','quality_score','Quality Runの100点評価、必須Subscore、Pass threshold、判定、内訳JSON。',
    [
        id_col(), c('quality_check_run_id','uuid',nullable=False), c('score_version','text',nullable=False), c('total_score','numeric(5,2)',nullable=False),
        c('pass_score','numeric(5,2)',nullable=False), c('factual_accuracy_score','numeric(5,2)',nullable=False), c('disclosure_policy_score','numeric(5,2)',nullable=False),
        c('passed','boolean',nullable=False), json_obj('components',description='8評価軸のearned/max/reason。'), created_col(),
    ],
    uniques=[('uq_policy_quality_score_run',['quality_check_run_id'])],
    checks=[
        ('ck_policy_score_total',score_check('total_score')),('ck_policy_score_pass',score_check('pass_score')),('ck_policy_score_factual','factual_accuracy_score BETWEEN 0 AND 20'),
        ('ck_policy_score_disclosure','disclosure_policy_score BETWEEN 0 AND 5'),('ck_policy_score_components',json_object_check('components')),
        ('ck_policy_score_pass_logic','passed = (total_score >= pass_score AND factual_accuracy_score >= 18 AND disclosure_policy_score = 5)'),
    ],
    fks=[fk('quality_check_run_id','policy.quality_check_run')],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-008','GATE-1'],implementation_slice='SLICE-013',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'policy','waiver','Findingの例外申請・承認・期限・Scopeを管理する。Critical zero-tolerance RuleはDB/Serviceで申請不可にする。',
    [
        id_col(), display_col('WVR'), c('finding_id','uuid',nullable=False), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=False),
        c('justification','text',nullable=False,classification='RESTRICTED'), c('status','text',nullable=False,default="'REQUESTED'"),
        c('requested_by_principal_id','uuid',nullable=False), c('requested_at','timestamptz',nullable=False), c('decided_by_principal_id','uuid',nullable=True),
        c('decided_at','timestamptz',nullable=True), c('decision_reason','text',nullable=True,classification='RESTRICTED'), c('expires_at','timestamptz',nullable=True),
        c('revoked_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_policy_waiver_display',['display_id'])],
    checks=[
        ('ck_policy_waiver_scope',enum_check('scope_type',['FINDING','ARTICLE_VERSION','ARTICLE','CATEGORY'])),
        ('ck_policy_waiver_status',enum_check('status',['REQUESTED','APPROVED','REJECTED','EXPIRED','REVOKED'])),
        ('ck_policy_waiver_decision_pair',"status = 'REQUESTED' OR (decided_by_principal_id IS NOT NULL AND decided_at IS NOT NULL)"),
        ('ck_policy_waiver_expiry','expires_at IS NULL OR expires_at > requested_at'),
    ],
    fks=[fk('finding_id','policy.finding'),fk('requested_by_principal_id','iam.principal'),fk('decided_by_principal_id','iam.principal')],
    indexes=[idx('ix_policy_waiver_active',['scope_type','scope_id','status','expires_at'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-008','FR-017','FR-020'],implementation_slice='SLICE-013',
    expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))

add(Table(
    'policy','gate_decision','GATE-0～4のscope別Pass/Fail/Conditional判定、根拠Artifact、条件、有効期限を追記する。',
    [
        id_col(), display_col('GTD'), c('gate_code','text',nullable=False), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=False),
        c('policy_bundle_id','uuid',nullable=False), c('result','text',nullable=False), json_obj('conditions',description='Conditional passの未達・期限・scale limit。',classification='CONFIDENTIAL'),
        c('evidence_artifact_id','uuid',nullable=False), c('decided_by_principal_id','uuid',nullable=False), c('decided_at','timestamptz',nullable=False),
        c('expires_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_policy_gate_display',['display_id'])],
    checks=[
        ('ck_policy_gate_code',enum_check('gate_code',['GATE-0','GATE-1','GATE-2','GATE-3','GATE-4'])),
        ('ck_policy_gate_scope',enum_check('scope_type',['SITE','CATEGORY','ARTICLE_TYPE','RELEASE'])),('ck_policy_gate_result',enum_check('result',['PASS','FAIL','CONDITIONAL'])),
        ('ck_policy_gate_conditions',json_object_check('conditions')),('ck_policy_gate_expiry','expires_at IS NULL OR expires_at > decided_at'),
    ],
    fks=[fk('policy_bundle_id','policy.policy_bundle'),fk('evidence_artifact_id','ops.object_artifact'),fk('decided_by_principal_id','iam.principal')],
    indexes=[idx('ix_policy_gate_scope',['gate_code','scope_type','scope_id','decided_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['GATE-0','GATE-1','FR-019'],implementation_slice='SLICE-025',
    expected_gate1_rows='<10k',expected_gate4_rows='<1m'
))


# ---------------------------------------------------------------------------
# PUBLISHING SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'publishing','review_assignment','記事Versionに対する編集・Fact・Compliance等のHuman Review担当、期限、進行状態を管理する。',
    [
        id_col(), display_col('RVA'), c('article_version_id','uuid',nullable=False), c('review_type','text',nullable=False),
        c('assigned_to_principal_id','uuid',nullable=False), c('assigned_by_principal_id','uuid',nullable=False),
        c('status','text',nullable=False,default="'ASSIGNED'"), c('priority','smallint',nullable=False,default='50'),
        c('due_at','timestamptz',nullable=True), c('started_at','timestamptz',nullable=True), c('completed_at','timestamptz',nullable=True),
        c('cancelled_at','timestamptz',nullable=True), c('instructions','text',nullable=True,classification='CONFIDENTIAL'),
        *mutable_tail(),
    ],
    uniques=[('uq_publishing_review_assignment_display',['display_id'])],
    checks=[
        ('ck_publishing_review_assignment_type',enum_check('review_type',['EDITORIAL','FACT','COMPLIANCE','UX','FINAL'])),
        ('ck_publishing_review_assignment_status',enum_check('status',['ASSIGNED','IN_PROGRESS','COMPLETED','CANCELLED'])),
        ('ck_publishing_review_assignment_priority','priority BETWEEN 0 AND 100'),
        ('ck_publishing_review_assignment_time','completed_at IS NULL OR started_at IS NULL OR completed_at >= started_at'),
    ],
    fks=[fk('article_version_id','editorial.article_version'),fk('assigned_to_principal_id','iam.principal'),fk('assigned_by_principal_id','iam.principal')],
    indexes=[idx('ix_publishing_review_assignment_queue',['assigned_to_principal_id','status','priority','due_at'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-008','FR-017'],implementation_slice='SLICE-014',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','review_decision','Human Reviewerが特定Assignment・記事Versionへ下したDecisionを追記し、後から上書きしない。',
    [
        id_col(), display_col('RVD'), c('review_assignment_id','uuid',nullable=False), c('article_version_id','uuid',nullable=False),
        c('decision','text',nullable=False), c('summary','text',nullable=False,classification='CONFIDENTIAL'),
        json_obj('checklist_results',description='Review checklist項目・結果・Evidence locator。',classification='CONFIDENTIAL'),
        c('decision_artifact_id','uuid',nullable=True), c('decided_by_principal_id','uuid',nullable=False), c('decided_at','timestamptz',nullable=False),
        c('supersedes_decision_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_publishing_review_decision_display',['display_id'])],
    checks=[
        ('ck_publishing_review_decision_value',enum_check('decision',['APPROVE','CHANGES_REQUESTED','REJECT'])),
        ('ck_publishing_review_decision_checklist',json_object_check('checklist_results')),
    ],
    fks=[fk('review_assignment_id','publishing.review_assignment'),fk('article_version_id','editorial.article_version'),fk('decision_artifact_id','ops.object_artifact'),fk('decided_by_principal_id','iam.principal'),fk('supersedes_decision_id','publishing.review_decision')],
    indexes=[idx('ix_publishing_review_decision_version',['article_version_id','decided_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-008','FR-017','FR-020'],implementation_slice='SLICE-014',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','approval','記事Versionに対するEditorial・Compliance・Final approval/revocationを独立した監査事実として追記する。',
    [
        id_col(), display_col('APR'), c('article_version_id','uuid',nullable=False), c('approval_type','text',nullable=False),
        c('decision','text',nullable=False), c('quality_check_run_id','uuid',nullable=True), c('policy_bundle_id','uuid',nullable=True),
        c('decision_reason','text',nullable=False,classification='RESTRICTED'), c('approved_by_principal_id','uuid',nullable=False),
        c('approved_at','timestamptz',nullable=False), c('valid_until','timestamptz',nullable=True), c('revoked_at','timestamptz',nullable=True),
        c('revoked_by_principal_id','uuid',nullable=True), c('revocation_reason','text',nullable=True,classification='RESTRICTED'),
        c('supersedes_approval_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_publishing_approval_display',['display_id'])],
    checks=[
        ('ck_publishing_approval_type',enum_check('approval_type',['EDITORIAL','FACT','COMPLIANCE','FINAL'])),
        ('ck_publishing_approval_decision',enum_check('decision',['APPROVED','REJECTED','REVOKED'])),
        ('ck_publishing_approval_valid','valid_until IS NULL OR valid_until > approved_at'),
        ('ck_publishing_approval_revoke_pair','(revoked_at IS NULL) = (revoked_by_principal_id IS NULL)'),
        ('ck_publishing_approval_revoke_event',"decision <> 'REVOKED' OR (supersedes_approval_id IS NOT NULL AND revoked_at IS NOT NULL AND revoked_by_principal_id IS NOT NULL)"),
    ],
    fks=[fk('article_version_id','editorial.article_version'),fk('quality_check_run_id','policy.quality_check_run'),fk('policy_bundle_id','policy.policy_bundle'),fk('approved_by_principal_id','iam.principal'),fk('revoked_by_principal_id','iam.principal'),fk('supersedes_approval_id','publishing.approval')],
    indexes=[
        idx('ix_publishing_approval_active_candidate',['article_version_id','approval_type','approved_at'],where="decision = 'APPROVED'"),
        idx('ix_publishing_approval_version',['article_version_id','approved_at']),
    ],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-008','FR-017','FR-020','GATE-1'],implementation_slice='SLICE-014',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','publication_candidate','公開要求の冪等受付、最終Approval、Quality Run、Snapshot build状態、Block理由を管理する。',
    [
        id_col(), display_col('PBC'), c('site_id','uuid',nullable=False), c('article_version_id','uuid',nullable=False),
        c('final_approval_id','uuid',nullable=False), c('quality_check_run_id','uuid',nullable=False), c('requested_by_principal_id','uuid',nullable=False),
        c('request_idempotency_key','text',nullable=False), c('status','text',nullable=False,default="'REQUESTED'"),
        c('snapshot_build_job_id','uuid',nullable=True), c('publication_snapshot_id','uuid',nullable=True),
        c('blocked_reason_code','text',nullable=True), c('blocked_detail','text',nullable=True,classification='RESTRICTED'),
        c('requested_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True), *mutable_tail(),
    ],
    uniques=[('uq_publishing_candidate_display',['display_id']),('uq_publishing_candidate_idempotency',['site_id','request_idempotency_key'])],
    checks=[
        ('ck_publishing_candidate_status',enum_check('status',['REQUESTED','VALIDATING','BLOCKED','SNAPSHOT_READY','PUBLISHED','FAILED','CANCELLED'])),
        ('ck_publishing_candidate_block',"status <> 'BLOCKED' OR blocked_reason_code IS NOT NULL"),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_version_id','editorial.article_version'),fk('final_approval_id','publishing.approval'),fk('quality_check_run_id','policy.quality_check_run'),fk('requested_by_principal_id','iam.principal'),fk('snapshot_build_job_id','ops.job'),fk('publication_snapshot_id','publishing.publication_snapshot',deferrable=True,initially_deferred=True)],
    indexes=[idx('ix_publishing_candidate_queue',['site_id','status','requested_at'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-009','FR-017','FR-020'],implementation_slice='SLICE-015',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','publication_snapshot','承認済みArticle Versionから生成した公開内容・Product Card・Structured Dataの不変Snapshot manifest。',
    [
        id_col(), display_col('PBS'), c('site_id','uuid',nullable=False), c('article_id','uuid',nullable=False), c('article_version_id','uuid',nullable=False),
        c('publication_candidate_id','uuid',nullable=False), c('artifact_id','uuid',nullable=False), c('schema_version','integer',nullable=False),
        c('content_sha256','text',nullable=False), c('source_packet_version_id','uuid',nullable=False), c('policy_bundle_id','uuid',nullable=False),
        c('quality_check_run_id','uuid',nullable=False), c('final_approval_id','uuid',nullable=False), c('canonical_path','text',nullable=False),
        c('title','text',nullable=False), c('meta_title','text',nullable=True), c('meta_description','text',nullable=True),
        c('disclosure_text','text',nullable=False), json_obj('manifest',description='公開Block、Product/Card refs、Structured Data、Asset hash、Freshness metadata。',classification='CONFIDENTIAL'),
        c('built_by_job_id','uuid',nullable=False), c('built_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_publishing_snapshot_display',['display_id']),('uq_publishing_snapshot_artifact',['artifact_id']),('uq_publishing_snapshot_hash',['site_id','content_sha256'])],
    checks=[
        ('ck_publishing_snapshot_schema','schema_version > 0'),('ck_publishing_snapshot_hash',hash_check('content_sha256')),
        ('ck_publishing_snapshot_manifest',json_object_check('manifest')),('ck_publishing_snapshot_path',"canonical_path ~ '^/' AND canonical_path !~ '[?#[:cntrl:]]'"),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('article_version_id','editorial.article_version'),fk('publication_candidate_id','publishing.publication_candidate',deferrable=True,initially_deferred=True),fk('artifact_id','ops.object_artifact'),fk('source_packet_version_id','evidence.source_packet_version'),fk('policy_bundle_id','policy.policy_bundle'),fk('quality_check_run_id','policy.quality_check_run'),fk('final_approval_id','publishing.approval'),fk('built_by_job_id','ops.job')],
    indexes=[idx('ix_publishing_snapshot_article',['article_id','built_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='PUBLICATION_PERMANENT',requirements=['FR-009','FR-010','FR-017'],implementation_slice='SLICE-015',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','publication','サイト・記事・Channel単位の現在公開状態とCurrent Snapshotを保持する制御Record。公開内容自体はSnapshotを正本とする。',
    [
        id_col(), display_col('PUB'), c('site_id','uuid',nullable=False), c('article_id','uuid',nullable=False), c('channel','text',nullable=False,default="'WEB'"),
        c('state','text',nullable=False,default="'UNPUBLISHED'"), c('current_snapshot_id','uuid',nullable=True), c('current_route_id','uuid',nullable=True),
        c('first_published_at','timestamptz',nullable=True), c('last_published_at','timestamptz',nullable=True), c('unpublished_at','timestamptz',nullable=True),
        c('etag','text',nullable=True), c('projection_generation','bigint',nullable=False,default='0'), *mutable_tail(),
    ],
    uniques=[('uq_publishing_publication_display',['display_id']),('uq_publishing_publication_article_channel',['site_id','article_id','channel'])],
    checks=[
        ('ck_publishing_publication_channel',enum_check('channel',['WEB','FEED','API'])),
        ('ck_publishing_publication_state',enum_check('state',['UNPUBLISHED','PUBLISHED','SUSPENDED','ARCHIVED'])),
        ('ck_publishing_publication_snapshot',"state <> 'PUBLISHED' OR current_snapshot_id IS NOT NULL"),
        ('ck_publishing_publication_generation','projection_generation >= 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('current_snapshot_id','publishing.publication_snapshot'),fk('current_route_id','publishing.public_route',deferrable=True,initially_deferred=True)],
    indexes=[idx('ix_publishing_publication_state',['site_id','state','last_published_at'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='PUBLICATION_PERMANENT',requirements=['FR-009','FR-010','FR-018'],implementation_slice='SLICE-015',
    expected_gate1_rows='<1k',expected_gate4_rows='<1m'
))

add(Table(
    'publishing','publication_event','Publish・Unpublish・Suspend・Resume・Rollback・Projection完了を時系列で追記する監査Event。',
    [
        id_col(), display_col('PUE'), c('publication_id','uuid',nullable=False), c('event_type','text',nullable=False),
        c('from_snapshot_id','uuid',nullable=True), c('to_snapshot_id','uuid',nullable=True), c('publication_candidate_id','uuid',nullable=True),
        c('release_id','uuid',nullable=True), c('actor_type','text',nullable=False), c('actor_id','uuid',nullable=True),
        c('reason_code','text',nullable=False), c('reason_detail','text',nullable=True,classification='RESTRICTED'),
        c('correlation_id','uuid',nullable=False), c('occurred_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_publishing_event_display',['display_id'])],
    checks=[
        ('ck_publishing_event_type',enum_check('event_type',['PUBLISHED','UNPUBLISHED','SUSPENDED','RESUMED','ROLLED_BACK','PROJECTION_REBUILT','FAILED'])),
        ('ck_publishing_event_actor',enum_check('actor_type',['HUMAN','SERVICE','SYSTEM'])),
    ],
    fks=[fk('publication_id','publishing.publication'),fk('from_snapshot_id','publishing.publication_snapshot'),fk('to_snapshot_id','publishing.publication_snapshot'),fk('publication_candidate_id','publishing.publication_candidate'),fk('release_id','ops.release')],
    indexes=[idx('ix_publishing_event_publication',['publication_id','occurred_at']),idx('ix_publishing_event_corr',['correlation_id'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-009','FR-010','FR-017','FR-020'],implementation_slice='SLICE-015',
    expected_gate1_rows='<10k',expected_gate4_rows='<100m'
))

add(Table(
    'publishing','public_route','Canonical path、Redirect、Noindex、Route ownerを管理し、同一Siteで同時に同じPathを所有させない。',
    [
        id_col(), display_col('RTE'), c('site_id','uuid',nullable=False), c('path','text',nullable=False), c('route_type','text',nullable=False),
        c('article_id','uuid',nullable=True), c('publication_id','uuid',nullable=True), c('redirect_target_route_id','uuid',nullable=True),
        c('http_status','smallint',nullable=False,default='200'), c('is_indexable','boolean',nullable=False,default='true'),
        c('status','text',nullable=False,default="'ACTIVE'"), c('activated_at','timestamptz',nullable=True), c('deactivated_at','timestamptz',nullable=True),
        *mutable_tail(),
    ],
    uniques=[('uq_publishing_route_display',['display_id'])],
    checks=[
        ('ck_publishing_route_type',enum_check('route_type',['ARTICLE','REDIRECT','GONE','STATIC'])),
        ('ck_publishing_route_status',enum_check('status',['DRAFT','ACTIVE','INACTIVE'])),
        ('ck_publishing_route_path',"path ~ '^/' AND path !~ '[?#[:cntrl:]]'"),
        ('ck_publishing_route_http','http_status BETWEEN 200 AND 599'),
        ('ck_publishing_route_target',"route_type <> 'REDIRECT' OR redirect_target_route_id IS NOT NULL"),
        ('ck_publishing_route_article',"route_type <> 'ARTICLE' OR article_id IS NOT NULL"),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('publication_id','publishing.publication',deferrable=True,initially_deferred=True),fk('redirect_target_route_id','publishing.public_route')],
    indexes=[idx('ux_publishing_route_active_path',['site_id','path'],unique=True,where="status = 'ACTIVE'"),idx('ix_publishing_route_article',['article_id','status'])],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='PUBLICATION_PERMANENT',requirements=['FR-009','FR-010'],implementation_slice='SLICE-015',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'publishing','rollback_record','誤公開・不具合時に、対象Publicationを以前の不変Snapshotへ戻した事実、検証、承認を保存する。',
    [
        id_col(), display_col('RBK'), c('publication_id','uuid',nullable=False), c('from_snapshot_id','uuid',nullable=False), c('to_snapshot_id','uuid',nullable=False),
        c('incident_id','uuid',nullable=True), c('requested_by_principal_id','uuid',nullable=False), c('approved_by_principal_id','uuid',nullable=True),
        c('executed_by_principal_id','uuid',nullable=True), c('status','text',nullable=False,default="'REQUESTED'"),
        c('reason','text',nullable=False,classification='RESTRICTED'), c('verification_result','text',nullable=True,classification='CONFIDENTIAL'),
        c('requested_at','timestamptz',nullable=False), c('executed_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_publishing_rollback_display',['display_id'])],
    checks=[
        ('ck_publishing_rollback_status',enum_check('status',['REQUESTED','APPROVED','EXECUTED','FAILED','CANCELLED'])),
        ('ck_publishing_rollback_diff','from_snapshot_id <> to_snapshot_id'),
    ],
    fks=[fk('publication_id','publishing.publication'),fk('from_snapshot_id','publishing.publication_snapshot'),fk('to_snapshot_id','publishing.publication_snapshot'),fk('incident_id','ops.incident'),fk('requested_by_principal_id','iam.principal'),fk('approved_by_principal_id','iam.principal'),fk('executed_by_principal_id','iam.principal')],
    indexes=[idx('ix_publishing_rollback_publication',['publication_id','requested_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='AUDIT_7Y_PROVISIONAL',requirements=['FR-010','FR-017','FR-020'],implementation_slice='SLICE-015',
    expected_gate1_rows='<1k',expected_gate4_rows='<1m'
))

# ---------------------------------------------------------------------------
# FRESHNESS SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'freshness','freshness_policy','カテゴリ・記事種別・Fact種別ごとの最大Age、Warning、Critical、再取得CadenceをVersion管理する。',
    [
        id_col(), display_col('FPL'), c('site_id','uuid',nullable=False), c('category_id','uuid',nullable=True), c('article_type','text',nullable=True),
        c('fact_type','text',nullable=False), c('version_no','integer',nullable=False), c('warning_after','interval',nullable=False),
        c('critical_after','interval',nullable=False), c('refresh_interval','interval',nullable=False), c('on_critical_action','text',nullable=False),
        c('effective_from','timestamptz',nullable=False), c('effective_to','timestamptz',nullable=True), c('created_by_principal_id','uuid',nullable=False), created_col(),
    ],
    uniques=[('uq_freshness_policy_display',['display_id']),('uq_freshness_policy_version',['site_id','category_id','article_type','fact_type','version_no'])],
    checks=[
        ('ck_freshness_policy_version','version_no > 0'),('ck_freshness_policy_order','critical_after > warning_after'),
        ('ck_freshness_policy_refresh','refresh_interval > interval \'0 seconds\''),
        ('ck_freshness_policy_action',enum_check('on_critical_action',['WARN','BLOCK_NEW_PUBLICATION','DISABLE_AFFILIATE_LINK','SUSPEND_ARTICLE'])),
        ('ck_freshness_policy_effective','effective_to IS NULL OR effective_to > effective_from'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('category_id','portfolio.category'),fk('created_by_principal_id','iam.principal')],
    indexes=[idx('ix_freshness_policy_lookup',['site_id','category_id','fact_type','effective_from'])],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='CONFIG_PERMANENT',requirements=['FR-011','FR-019'],implementation_slice='SLICE-018',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'freshness','refresh_schedule','Product・Offer・Article・Link等の次回Refresh due、Lease、連続失敗、優先度を一元管理する。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('target_type','text',nullable=False), c('target_id','uuid',nullable=False),
        c('freshness_policy_id','uuid',nullable=False), c('status','text',nullable=False,default="'ACTIVE'"), c('priority','smallint',nullable=False,default='50'),
        c('next_due_at','timestamptz',nullable=False), c('last_started_at','timestamptz',nullable=True), c('last_succeeded_at','timestamptz',nullable=True),
        c('consecutive_failure_count','integer',nullable=False,default='0'), c('lease_owner','text',nullable=True), c('lease_until','timestamptz',nullable=True),
        *mutable_tail(),
    ],
    uniques=[('uq_freshness_schedule_target',['site_id','target_type','target_id'])],
    checks=[
        ('ck_freshness_schedule_target',enum_check('target_type',['PRODUCT','OFFER','ARTICLE','AFFILIATE_LINK','SOURCE_PACKET'])),
        ('ck_freshness_schedule_status',enum_check('status',['ACTIVE','PAUSED','DISABLED'])),
        ('ck_freshness_schedule_priority','priority BETWEEN 0 AND 100'),('ck_freshness_schedule_fail','consecutive_failure_count >= 0'),
        ('ck_freshness_schedule_lease','(lease_owner IS NULL) = (lease_until IS NULL)'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('freshness_policy_id','freshness.freshness_policy')],
    indexes=[idx('ix_freshness_schedule_due',['status','next_due_at','priority'],where="status = 'ACTIVE'")],
    write_pattern='MUTABLE',classification='INTERNAL',retention_class='BUSINESS_CORE',requirements=['FR-011','FR-018'],implementation_slice='SLICE-018',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'freshness','refresh_run','Scheduleまたは手動要求に基づくRefresh batchの範囲、Job、結果件数、Cursor、Errorを管理する。',
    [
        id_col(), display_col('RFR'), c('site_id','uuid',nullable=False), c('ops_job_id','uuid',nullable=False), c('run_type','text',nullable=False),
        c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=True), c('status','text',nullable=False),
        c('started_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True), c('target_count','integer',nullable=False,default='0'),
        c('success_count','integer',nullable=False,default='0'), c('failure_count','integer',nullable=False,default='0'),
        json_obj('continuation',description='Provider cursor・page・resume token。',classification='CONFIDENTIAL'),
        c('report_artifact_id','uuid',nullable=True), c('error_summary','text',nullable=True,classification='RESTRICTED'), created_col(),
    ],
    uniques=[('uq_freshness_run_display',['display_id']),('uq_freshness_run_job',['ops_job_id'])],
    checks=[
        ('ck_freshness_run_type',enum_check('run_type',['SCHEDULED','MANUAL','EVENT_DRIVEN','REPAIR'])),
        ('ck_freshness_run_scope',enum_check('scope_type',['SITE','CATEGORY','PRODUCT','OFFER','ARTICLE','LINK'])),
        ('ck_freshness_run_status',enum_check('status',['RUNNING','SUCCEEDED','PARTIAL','FAILED','CANCELLED'])),
        ('ck_freshness_run_counts','target_count >= 0 AND success_count >= 0 AND failure_count >= 0'),
        ('ck_freshness_run_continuation',json_object_check('continuation')),
    ],
    fks=[fk('site_id','portfolio.site'),fk('ops_job_id','ops.job'),fk('report_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_freshness_run_site',['site_id','started_at'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='OPS_2Y_PROVISIONAL',requirements=['FR-011','FR-018'],implementation_slice='SLICE-018',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'freshness','staleness_assessment','特定対象のObservation age・Policy・Fresh/Warning/Critical判定と推奨Actionを追記する。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('target_type','text',nullable=False), c('target_id','uuid',nullable=False),
        c('freshness_policy_id','uuid',nullable=False), c('observation_id','uuid',nullable=True), c('observation_at','timestamptz',nullable=True),
        c('assessed_at','timestamptz',nullable=False), c('age_seconds','bigint',nullable=True), c('freshness_status','text',nullable=False),
        c('recommended_action','text',nullable=False), c('reason_code','text',nullable=False), c('refresh_run_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_freshness_assessment_target',enum_check('target_type',['PRODUCT','OFFER','ARTICLE','AFFILIATE_LINK','SOURCE_PACKET'])),
        ('ck_freshness_assessment_status',enum_check('freshness_status',['FRESH','WARNING','CRITICAL','UNKNOWN'])),
        ('ck_freshness_assessment_action',enum_check('recommended_action',['NONE','REFRESH','BLOCK_PUBLICATION','DISABLE_LINK','SUSPEND_ARTICLE','MANUAL_REVIEW'])),
        ('ck_freshness_assessment_age','age_seconds IS NULL OR age_seconds >= 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('freshness_policy_id','freshness.freshness_policy'),fk('refresh_run_id','freshness.refresh_run')],
    indexes=[idx('ix_freshness_assessment_target',['target_type','target_id','assessed_at']),idx('ix_freshness_assessment_critical',['site_id','freshness_status','assessed_at'],where="freshness_status IN ('CRITICAL','UNKNOWN')")],
    write_pattern='APPEND_ONLY',classification='INTERNAL',retention_class='OPS_2Y_PROVISIONAL',requirements=['FR-011','FR-018'],implementation_slice='SLICE-018',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='RANGE assessed_at when >50M rows'
))

add(Table(
    'freshness','link_check','楽天Affiliate URLを経由せず検査し、HTTP・Destination host・API再取得一致・Riskを履歴化する。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('offer_id','uuid',nullable=False), c('affiliate_link_observation_id','uuid',nullable=True),
        c('refresh_run_id','uuid',nullable=True), c('checked_at','timestamptz',nullable=False), c('check_method','text',nullable=False),
        c('result','text',nullable=False), c('http_status','smallint',nullable=True), c('destination_host','text',nullable=True),
        c('destination_url_sha256','text',nullable=True), c('latency_ms','integer',nullable=True), c('risk_code','text',nullable=True),
        c('response_artifact_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_freshness_link_method',enum_check('check_method',['API_REISSUE','HEAD','GET_NO_REDIRECT','MANUAL'])),
        ('ck_freshness_link_result',enum_check('result',['VALID','REDIRECT_CHANGED','NOT_FOUND','SERVER_ERROR','TIMEOUT','MALFORMED','UNSAFE_HOST','UNKNOWN'])),
        ('ck_freshness_link_http','http_status IS NULL OR http_status BETWEEN 100 AND 599'),
        ('ck_freshness_link_hash','destination_url_sha256 IS NULL OR ' + hash_check('destination_url_sha256')),
        ('ck_freshness_link_latency','latency_ms IS NULL OR latency_ms >= 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('offer_id','catalog.offer'),fk('affiliate_link_observation_id','catalog.affiliate_link_observation'),fk('refresh_run_id','freshness.refresh_run'),fk('response_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_freshness_link_offer',['offer_id','checked_at']),idx('ix_freshness_link_invalid',['site_id','result','checked_at'],where="result <> 'VALID'")],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='OPS_2Y_PROVISIONAL',requirements=['FR-011','FR-012','FR-018'],implementation_slice='SLICE-018',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='RANGE checked_at when >50M rows'
))

add(Table(
    'freshness','impact_assessment','Source/Product/Offer変更がClaim・記事・公開Snapshotへ与える影響と必要Actionを追記する。',
    [
        id_col(), c('change_type','text',nullable=False), c('changed_entity_type','text',nullable=False), c('changed_entity_id','uuid',nullable=False),
        c('article_id','uuid',nullable=True), c('article_version_id','uuid',nullable=True), c('claim_id','uuid',nullable=True), c('publication_id','uuid',nullable=True),
        c('impact_level','text',nullable=False), c('required_action','text',nullable=False), c('reason','text',nullable=False),
        c('detected_at','timestamptz',nullable=False), c('resolved_at','timestamptz',nullable=True), c('resolved_by_job_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_freshness_impact_change',enum_check('change_type',['PRICE','AVAILABILITY','PRODUCT_ATTRIBUTE','AFFILIATE_LINK','SOURCE_CORRECTION','POLICY_CHANGE','PRODUCT_GROUPING'])),
        ('ck_freshness_impact_entity',enum_check('changed_entity_type',['SOURCE_SNAPSHOT','FACT','PRODUCT','OFFER','LINK','POLICY_BUNDLE'])),
        ('ck_freshness_impact_level',enum_check('impact_level',['NONE','LOW','MEDIUM','HIGH','CRITICAL'])),
        ('ck_freshness_impact_action',enum_check('required_action',['NONE','REFRESH_DRAFT','REVIEW','REPUBLISH','DISABLE_LINK','SUSPEND_PUBLICATION'])),
    ],
    fks=[fk('article_id','editorial.article'),fk('article_version_id','editorial.article_version'),fk('claim_id','evidence.claim'),fk('publication_id','publishing.publication'),fk('resolved_by_job_id','ops.job')],
    indexes=[idx('ix_freshness_impact_open',['impact_level','detected_at'],where='resolved_at IS NULL'),idx('ix_freshness_impact_article',['article_id','detected_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='CONTENT_7Y_PROVISIONAL',requirements=['FR-011','FR-018','FR-020'],implementation_slice='SLICE-018',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

# ---------------------------------------------------------------------------
# ANALYTICS SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'analytics','anonymous_event','個人識別情報を保存せず、Consent状態付きでPage view・CTA表示・Click等を受け付ける短期Event。',
    [
        id_col(), c('event_id','uuid',nullable=False), c('site_id','uuid',nullable=False), c('event_type','text',nullable=False),
        c('occurred_at','timestamptz',nullable=False), c('received_at','timestamptz',nullable=False,default='CURRENT_TIMESTAMP'), c('business_date','date',nullable=False),
        c('session_pseudonym_sha256','text',nullable=True,classification='CONFIDENTIAL'), c('visitor_pseudonym_sha256','text',nullable=True,classification='CONFIDENTIAL'),
        c('consent_state','text',nullable=False), c('privacy_mode','text',nullable=False), c('article_id','uuid',nullable=True),
        c('article_version_id','uuid',nullable=True), c('publication_snapshot_id','uuid',nullable=True), c('product_id','uuid',nullable=True), c('offer_id','uuid',nullable=True),
        c('page_path','text',nullable=True), c('referrer_host','text',nullable=True), c('device_class','text',nullable=True), c('country_code','char(2)',nullable=True),
        json_obj('event_properties',description='Allowlist済み低Cardinality属性のみ。URL query、IP、raw UA、email等は禁止。',classification='CONFIDENTIAL'), created_col(),
    ],
    uniques=[('uq_analytics_event_id',['event_id'])],
    checks=[
        ('ck_analytics_event_type',enum_check('event_type',['PAGE_VIEW','ARTICLE_ENGAGED','CTA_IMPRESSION','AFFILIATE_CLICK','INTERNAL_LINK_CLICK','SEARCH','ERROR'])),
        ('ck_analytics_event_consent',enum_check('consent_state',['GRANTED','DENIED','NOT_REQUIRED','UNKNOWN'])),
        ('ck_analytics_event_privacy',enum_check('privacy_mode',['FULL_CONSENT','COOKILESS','ESSENTIAL_ONLY'])),
        ('ck_analytics_event_session_hash','session_pseudonym_sha256 IS NULL OR ' + hash_check('session_pseudonym_sha256')),
        ('ck_analytics_event_visitor_hash','visitor_pseudonym_sha256 IS NULL OR ' + hash_check('visitor_pseudonym_sha256')),
        ('ck_analytics_event_props',json_object_check('event_properties')),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('article_version_id','editorial.article_version'),fk('publication_snapshot_id','publishing.publication_snapshot'),fk('product_id','catalog.canonical_product'),fk('offer_id','catalog.offer')],
    indexes=[idx('ix_analytics_event_site_date',['site_id','business_date','event_type']),idx('ix_analytics_event_article',['article_id','occurred_at']),idx('ix_analytics_event_received',['received_at'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='ANALYTICS_RAW_90D',requirements=['FR-013','NFR-SEC-004'],implementation_slice='SLICE-017',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY RANGE occurred_at from inception'
))

add(Table(
    'analytics','affiliate_click_event','楽天URLへ直接遷移させつつsendBeacon等で取得したクリック文脈を追記する。Redirect gatewayには使用しない。',
    [
        id_col(), c('anonymous_event_id','uuid',nullable=True), c('site_id','uuid',nullable=False), c('article_id','uuid',nullable=False),
        c('article_version_id','uuid',nullable=False), c('publication_snapshot_id','uuid',nullable=False), c('product_id','uuid',nullable=True), c('offer_id','uuid',nullable=False),
        c('affiliate_link_observation_id','uuid',nullable=False), c('destination_host','text',nullable=False), c('destination_url_sha256','text',nullable=False),
        c('cta_key','text',nullable=False), c('block_key','text',nullable=True), c('position_index','integer',nullable=True), c('occurred_at','timestamptz',nullable=False),
        c('business_date','date',nullable=False), c('delivery_state','text',nullable=False,default="'RECEIVED'"), created_col(),
    ],
    uniques=[('uq_analytics_click_event',['anonymous_event_id'])],
    checks=[
        ('ck_analytics_click_url_hash',hash_check('destination_url_sha256')),
        ('ck_analytics_click_position','position_index IS NULL OR position_index >= 0'),
        ('ck_analytics_click_delivery',enum_check('delivery_state',['RECEIVED','LATE','DUPLICATE_REJECTED'])),
    ],
    fks=[fk('anonymous_event_id','analytics.anonymous_event'),fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('article_version_id','editorial.article_version'),fk('publication_snapshot_id','publishing.publication_snapshot'),fk('product_id','catalog.canonical_product'),fk('offer_id','catalog.offer'),fk('affiliate_link_observation_id','catalog.affiliate_link_observation')],
    indexes=[idx('ix_analytics_click_article_date',['article_id','business_date']),idx('ix_analytics_click_offer_date',['offer_id','business_date'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='ANALYTICS_CLICK_25M',requirements=['FR-012','FR-013','FR-015'],implementation_slice='SLICE-017',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='MONTHLY RANGE occurred_at from inception'
))

add(Table(
    'analytics','import_run','Search Console・GA4等の集計取込範囲、Watermark、原本Artifact、件数、再実行状態を管理する。',
    [
        id_col(), display_col('AIR'), c('site_id','uuid',nullable=False), c('source_type','text',nullable=False), c('ops_job_id','uuid',nullable=False),
        c('source_artifact_id','uuid',nullable=True), c('status','text',nullable=False), c('date_from','date',nullable=False), c('date_to','date',nullable=False),
        json_obj('dimensions',description='要求したdimension・filter・property等。',classification='CONFIDENTIAL'), c('watermark','text',nullable=True),
        c('row_count','bigint',nullable=False,default='0'), c('inserted_count','bigint',nullable=False,default='0'), c('rejected_count','bigint',nullable=False,default='0'),
        c('started_at','timestamptz',nullable=False), c('completed_at','timestamptz',nullable=True), c('error_summary','text',nullable=True,classification='RESTRICTED'), created_col(),
    ],
    uniques=[('uq_analytics_import_display',['display_id']),('uq_analytics_import_job',['ops_job_id'])],
    checks=[
        ('ck_analytics_import_source',enum_check('source_type',['GSC','GA4','RANK_PROVIDER','MANUAL'])),
        ('ck_analytics_import_status',enum_check('status',['RUNNING','SUCCEEDED','PARTIAL','FAILED','CANCELLED'])),
        ('ck_analytics_import_dates','date_to >= date_from'),
        ('ck_analytics_import_counts','row_count >= 0 AND inserted_count >= 0 AND rejected_count >= 0'),
        ('ck_analytics_import_dimensions',json_object_check('dimensions')),
    ],
    fks=[fk('site_id','portfolio.site'),fk('ops_job_id','ops.job'),fk('source_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_analytics_import_source_date',['site_id','source_type','date_to'])],
    write_pattern='MUTABLE',classification='CONFIDENTIAL',retention_class='ANALYTICS_AGG_25M',requirements=['FR-013','FR-015'],implementation_slice='SLICE-019',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'analytics','gsc_observation','Search Console APIから取得した日・query・page等の集計値。Queryはsanitizeし、低Volume抑制を維持する。',
    [
        id_col(), c('import_run_id','uuid',nullable=False), c('site_id','uuid',nullable=False), c('metric_date','date',nullable=False),
        c('query_text','text',nullable=True,classification='RESTRICTED'), c('query_sha256','text',nullable=True,classification='CONFIDENTIAL'),
        c('page_path','text',nullable=True), c('country_code','char(2)',nullable=True), c('device','text',nullable=True), c('search_appearance','text',nullable=True),
        c('clicks','bigint',nullable=False), c('impressions','bigint',nullable=False), c('ctr','numeric(10,8)',nullable=False), c('average_position','numeric(10,4)',nullable=False),
        c('is_privacy_suppressed','boolean',nullable=False,default='false'), c('dimension_key_sha256','text',nullable=False), created_col(),
    ],
    checks=[
        ('ck_analytics_gsc_query_hash','query_sha256 IS NULL OR ' + hash_check('query_sha256')),
        ('ck_analytics_gsc_dim_hash',hash_check('dimension_key_sha256')),
        ('ck_analytics_gsc_counts','clicks >= 0 AND impressions >= 0 AND clicks <= impressions'),
        ('ck_analytics_gsc_ctr','ctr >= 0 AND ctr <= 1'),('ck_analytics_gsc_position','average_position >= 0'),
    ],
    fks=[fk('import_run_id','analytics.import_run'),fk('site_id','portfolio.site')],
    indexes=[idx('ux_analytics_gsc_grain',['site_id','metric_date','dimension_key_sha256'],unique=True),idx('ix_analytics_gsc_page_date',['site_id','page_path','metric_date']),idx('ix_analytics_gsc_query_hash',['query_sha256','metric_date'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='ANALYTICS_AGG_25M',requirements=['FR-013','FR-015'],implementation_slice='SLICE-019',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY RANGE metric_date when >50M rows'
))

add(Table(
    'analytics','ga4_observation','GA4 Data APIの集計Grainをdimension/metric schema versionとhashで保存する。Event raw exportはMVP対象外。',
    [
        id_col(), c('import_run_id','uuid',nullable=False), c('site_id','uuid',nullable=False), c('metric_date','date',nullable=False),
        c('dimension_schema_version','integer',nullable=False), json_obj('dimensions',description='pagePath、deviceCategory等のAllowlist dimension。',classification='CONFIDENTIAL'),
        json_obj('metrics',description='sessions、views、engagedSessions等の非負集計値。',classification='CONFIDENTIAL'),
        c('grain_key_sha256','text',nullable=False), c('is_thresholded','boolean',nullable=False,default='false'), created_col(),
    ],
    checks=[
        ('ck_analytics_ga4_schema','dimension_schema_version > 0'),('ck_analytics_ga4_dimensions',json_object_check('dimensions')),
        ('ck_analytics_ga4_metrics',json_object_check('metrics')),('ck_analytics_ga4_grain_hash',hash_check('grain_key_sha256')),
    ],
    fks=[fk('import_run_id','analytics.import_run'),fk('site_id','portfolio.site')],
    indexes=[idx('ux_analytics_ga4_grain',['site_id','metric_date','grain_key_sha256'],unique=True),idx('ix_analytics_ga4_date',['site_id','metric_date'])],
    write_pattern='APPEND_ONLY',classification='CONFIDENTIAL',retention_class='ANALYTICS_AGG_25M',requirements=['FR-013','FR-015'],implementation_slice='SLICE-019',
    expected_gate1_rows='<10m',expected_gate4_rows='<10b',partitioning='MONTHLY RANGE metric_date when >50M rows'
))

add(Table(
    'analytics','attribution_estimate','Provider Factと自サイト観測を混同せず、Direct・Estimated・Unattributedの配賦候補とConfidenceをVersion化する。',
    [
        id_col(), display_col('ATE'), c('site_id','uuid',nullable=False), c('commission_id','uuid',nullable=False), c('article_id','uuid',nullable=True),
        c('publication_snapshot_id','uuid',nullable=True), c('attribution_type','text',nullable=False), c('method_version','text',nullable=False),
        c('allocation_ratio','numeric(12,10)',nullable=False), c('confidence_score','numeric(5,2)',nullable=False),
        json_obj('signals',description='Time window、click count、direct provider fields等。Raw identifierは不可。',classification='RESTRICTED'),
        c('status','text',nullable=False,default="'PROPOSED'"), c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True),
        c('calculated_by_job_id','uuid',nullable=False), c('calculated_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_analytics_attribution_display',['display_id'])],
    checks=[
        ('ck_analytics_attribution_type',enum_check('attribution_type',['DIRECT','ESTIMATED','UNATTRIBUTED'])),
        ('ck_analytics_attribution_ratio','allocation_ratio >= 0 AND allocation_ratio <= 1'),
        ('ck_analytics_attribution_confidence',score_check('confidence_score')),
        ('ck_analytics_attribution_status',enum_check('status',['PROPOSED','APPROVED','REJECTED','SUPERSEDED'])),
        ('ck_analytics_attribution_signals',json_object_check('signals')),
        ('ck_analytics_attribution_article',"attribution_type = 'UNATTRIBUTED' OR article_id IS NOT NULL"),
        ('ck_analytics_attribution_approval','(approved_by_principal_id IS NULL) = (approved_at IS NULL)'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('commission_id','finance.commission'),fk('article_id','editorial.article'),fk('publication_snapshot_id','publishing.publication_snapshot'),fk('approved_by_principal_id','iam.principal'),fk('calculated_by_job_id','ops.job')],
    indexes=[idx('ix_analytics_attribution_commission',['commission_id','status']),idx('ix_analytics_attribution_article',['article_id','calculated_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-014','FR-015','FR-016'],implementation_slice='SLICE-020',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'analytics','data_quality_finding','Analytics取込の欠損、重複、集計不一致、Privacy violation、遅延をSource/Run/Dateへ紐付ける。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('import_run_id','uuid',nullable=True), c('finding_code','text',nullable=False),
        c('severity','text',nullable=False), c('status','text',nullable=False,default="'OPEN'"), c('metric_date','date',nullable=True),
        c('message','text',nullable=False), json_obj('evidence',description='Expected/actual/count/hashのみ。PIIは格納しない。',classification='RESTRICTED'),
        c('detected_at','timestamptz',nullable=False), c('resolved_at','timestamptz',nullable=True), c('resolved_by_principal_id','uuid',nullable=True), created_col(),
    ],
    checks=[
        ('ck_analytics_dq_severity',enum_check('severity',['INFO','LOW','MEDIUM','HIGH','CRITICAL'])),
        ('ck_analytics_dq_status',enum_check('status',['OPEN','FIXED','ACCEPTED','FALSE_POSITIVE'])),
        ('ck_analytics_dq_evidence',json_object_check('evidence')),('ck_analytics_dq_resolve','(resolved_at IS NULL) = (resolved_by_principal_id IS NULL)'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('import_run_id','analytics.import_run'),fk('resolved_by_principal_id','iam.principal')],
    indexes=[idx('ix_analytics_dq_open',['site_id','severity','detected_at'],where="status = 'OPEN'")],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='ANALYTICS_AGG_25M',requirements=['FR-013','FR-015','FR-020'],implementation_slice='SLICE-019',
    expected_gate1_rows='<100k',expected_gate4_rows='<10m'
))

add(Table(
    'analytics','daily_article_metric','日次・記事単位のPV、Session、検索表示、楽天Click等を再生成可能なProjectionとして保持する。',
    [
        c('site_id','uuid',nullable=False), c('article_id','uuid',nullable=False), c('metric_date','date',nullable=False),
        c('publication_snapshot_id','uuid',nullable=True), c('page_views','bigint',nullable=False,default='0'), c('sessions','bigint',nullable=False,default='0'),
        c('engaged_sessions','bigint',nullable=False,default='0'), c('affiliate_clicks','bigint',nullable=False,default='0'),
        c('gsc_clicks','bigint',nullable=False,default='0'), c('gsc_impressions','bigint',nullable=False,default='0'),
        c('average_position','numeric(10,4)',nullable=True), c('affiliate_click_rate','numeric(12,10)',nullable=True),
        c('source_watermark','text',nullable=False), c('projection_version','bigint',nullable=False), c('updated_at','timestamptz',nullable=False),
    ],
    pk=['site_id','article_id','metric_date'],
    checks=[
        ('ck_analytics_daily_counts','page_views >= 0 AND sessions >= 0 AND engaged_sessions >= 0 AND affiliate_clicks >= 0 AND gsc_clicks >= 0 AND gsc_impressions >= 0'),
        ('ck_analytics_daily_rate','affiliate_click_rate IS NULL OR (affiliate_click_rate >= 0 AND affiliate_click_rate <= 1)'),
        ('ck_analytics_daily_position','average_position IS NULL OR average_position >= 0'),('ck_analytics_daily_version','projection_version > 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('publication_snapshot_id','publishing.publication_snapshot')],
    indexes=[idx('ix_analytics_daily_date',['site_id','metric_date']),idx('ix_analytics_daily_article',['article_id','metric_date'])],
    write_pattern='PROJECTION',classification='CONFIDENTIAL',retention_class='ANALYTICS_AGG_25M',requirements=['FR-013','FR-015'],implementation_slice='SLICE-021',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m',partitioning='YEARLY RANGE metric_date when >50M rows'
))

# ---------------------------------------------------------------------------
# FINANCE SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'finance','parser_version','楽天成果CSV等のProvider・FormatごとのParser code/schema/test fixture versionを不変登録する。',
    [
        id_col(), c('provider_code','text',nullable=False), c('format_code','text',nullable=False), c('version','text',nullable=False),
        c('code_sha256','text',nullable=False), c('schema_artifact_id','uuid',nullable=False), c('fixture_artifact_id','uuid',nullable=True),
        c('status','text',nullable=False,default="'ACTIVE'"), c('released_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_finance_parser_version',['provider_code','format_code','version'])],
    checks=[('ck_finance_parser_hash',hash_check('code_sha256')),('ck_finance_parser_status',enum_check('status',['ACTIVE','DEPRECATED','DISABLED']))],
    fks=[fk('schema_artifact_id','ops.object_artifact'),fk('fixture_artifact_id','ops.object_artifact')],
    write_pattern='REFERENCE',classification='CONFIDENTIAL',retention_class='CONFIG_PERMANENT',requirements=['FR-014','FR-020'],implementation_slice='SLICE-020',
    expected_gate1_rows='<100',expected_gate4_rows='<10k'
))

add(Table(
    'finance','revenue_import','成果原本UploadからMalware/形式検査、Dry Run、人間確認、Canonical import、突合までの状態を管理する。',
    [
        id_col(), display_col('RVI'), c('site_id','uuid',nullable=False), c('provider_code','text',nullable=False), c('source_artifact_id','uuid',nullable=False),
        c('source_sha256','text',nullable=False), c('parser_version_id','uuid',nullable=False), c('ops_job_id','uuid',nullable=True),
        c('status','text',nullable=False,default="'UPLOADED'"), c('is_dry_run','boolean',nullable=False,default='true'),
        c('period_from','date',nullable=False), c('period_to','date',nullable=False), c('row_count','integer',nullable=False,default='0'),
        c('accepted_count','integer',nullable=False,default='0'), c('rejected_count','integer',nullable=False,default='0'),
        c('gross_order_amount_jpy','bigint',nullable=True), c('commission_amount_jpy','bigint',nullable=True),
        c('confirmed_by_principal_id','uuid',nullable=True), c('confirmed_at','timestamptz',nullable=True),
        c('reconciliation_status','text',nullable=False,default="'PENDING'"), c('report_artifact_id','uuid',nullable=True),
        c('error_summary','text',nullable=True,classification='RESTRICTED'), c('uploaded_at','timestamptz',nullable=False), *mutable_tail(),
    ],
    uniques=[('uq_finance_revenue_import_display',['display_id']),('uq_finance_revenue_import_hash',['site_id','provider_code','source_sha256'])],
    checks=[
        ('ck_finance_revenue_import_hash',hash_check('source_sha256')),('ck_finance_revenue_import_dates','period_to >= period_from'),
        ('ck_finance_revenue_import_status',enum_check('status',['UPLOADED','SCANNED','PARSED','DRY_RUN_READY','CONFIRMED','IMPORTED','REJECTED','FAILED'])),
        ('ck_finance_revenue_import_recon',enum_check('reconciliation_status',['PENDING','MATCHED','MISMATCH','WAIVED'])),
        ('ck_finance_revenue_import_counts','row_count >= 0 AND accepted_count >= 0 AND rejected_count >= 0'),
        ('ck_finance_revenue_import_confirm','(confirmed_by_principal_id IS NULL) = (confirmed_at IS NULL)'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('source_artifact_id','ops.object_artifact'),fk('parser_version_id','finance.parser_version'),fk('ops_job_id','ops.job'),fk('confirmed_by_principal_id','iam.principal'),fk('report_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_finance_revenue_import_period',['site_id','period_to','status'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-014','FR-016','FR-020'],implementation_slice='SLICE-020',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'finance','revenue_import_row','成果原本の各行をLine hashとParser resultで追跡するStaging。原文全体はArtifact、DBは必要最小限の正規化値のみ。',
    [
        id_col(), c('revenue_import_id','uuid',nullable=False), c('row_no','integer',nullable=False), c('row_sha256','text',nullable=False),
        c('parse_status','text',nullable=False), c('provider_event_id','text',nullable=True,classification='RESTRICTED'),
        c('provider_order_id_sha256','text',nullable=True,classification='RESTRICTED'), c('event_type','text',nullable=True),
        c('occurred_at','timestamptz',nullable=True), c('business_date','date',nullable=True), c('gross_order_amount_jpy','bigint',nullable=True),
        c('commission_amount_jpy','bigint',nullable=True), c('currency','char(3)',nullable=True), c('error_code','text',nullable=True),
        c('error_detail','text',nullable=True,classification='RESTRICTED'), json_obj('normalized_extra',description='Allowlist済みProvider固有field。',classification='RESTRICTED'), created_col(),
    ],
    uniques=[('uq_finance_revenue_row_no',['revenue_import_id','row_no']),('uq_finance_revenue_row_hash',['revenue_import_id','row_sha256'])],
    checks=[
        ('ck_finance_revenue_row_no','row_no > 0'),('ck_finance_revenue_row_hash',hash_check('row_sha256')),
        ('ck_finance_revenue_order_hash','provider_order_id_sha256 IS NULL OR ' + hash_check('provider_order_id_sha256')),
        ('ck_finance_revenue_parse',enum_check('parse_status',['ACCEPTED','REJECTED','DUPLICATE','IGNORED'])),
        ('ck_finance_revenue_extra',json_object_check('normalized_extra')),
    ],
    fks=[fk('revenue_import_id','finance.revenue_import',on_delete='CASCADE')],
    indexes=[idx('ix_finance_revenue_row_event',['provider_event_id']),idx('ix_finance_revenue_row_status',['revenue_import_id','parse_status'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-014','FR-016','FR-020'],implementation_slice='SLICE-020',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='HASH revenue_import_id only when operationally required'
))

add(Table(
    'finance','commission','楽天側の発生・確定・取消をCanonical provider factとして保持する。記事帰属や推定値をこのRecordへ上書きしない。',
    [
        id_col(), display_col('COM'), c('site_id','uuid',nullable=False), c('provider_code','text',nullable=False), c('provider_event_id','text',nullable=False,classification='RESTRICTED'),
        c('provider_order_id_sha256','text',nullable=True,classification='RESTRICTED'), c('source_import_row_id','uuid',nullable=False),
        c('status','text',nullable=False), c('ordered_at','timestamptz',nullable=True), c('confirmed_at','timestamptz',nullable=True), c('cancelled_at','timestamptz',nullable=True),
        c('business_month','date',nullable=False), c('gross_order_amount_jpy','bigint',nullable=True), c('confirmed_order_amount_jpy','bigint',nullable=True),
        c('generated_commission_jpy','bigint',nullable=True), c('confirmed_commission_jpy','bigint',nullable=True), c('currency','char(3)',nullable=False,default="'JPY'"),
        c('provider_category_code','text',nullable=True), c('provider_shop_code','text',nullable=True), c('provider_item_code','text',nullable=True),
        c('last_event_at','timestamptz',nullable=False), *mutable_tail(),
    ],
    uniques=[('uq_finance_commission_display',['display_id']),('uq_finance_commission_provider_event',['site_id','provider_code','provider_event_id'])],
    checks=[
        ('ck_finance_commission_status',enum_check('status',['GENERATED','CONFIRMED','CANCELLED','ADJUSTED','UNKNOWN'])),
        ('ck_finance_commission_order_hash','provider_order_id_sha256 IS NULL OR ' + hash_check('provider_order_id_sha256')),
        ('ck_finance_commission_month',"date_trunc('month', business_month)::date = business_month"),
    ],
    fks=[fk('site_id','portfolio.site'),fk('source_import_row_id','finance.revenue_import_row')],
    indexes=[idx('ix_finance_commission_month',['site_id','business_month','status']),idx('ix_finance_commission_item',['provider_item_code','business_month'])],
    write_pattern='MUTABLE',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-014','FR-015','FR-016'],implementation_slice='SLICE-020',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='YEARLY RANGE business_month when >50M rows'
))

add(Table(
    'finance','commission_event','Commissionの発生・確定・取消・金額変更をProvider event順に追記し、現在状態の根拠にする。',
    [
        id_col(), c('commission_id','uuid',nullable=False), c('source_import_row_id','uuid',nullable=False), c('event_sequence','integer',nullable=False),
        c('event_type','text',nullable=False), c('from_status','text',nullable=True), c('to_status','text',nullable=False),
        c('gross_order_amount_jpy','bigint',nullable=True), c('commission_amount_jpy','bigint',nullable=True),
        c('provider_occurred_at','timestamptz',nullable=True), c('recorded_at','timestamptz',nullable=False), c('event_sha256','text',nullable=False), created_col(),
    ],
    uniques=[('uq_finance_commission_event_seq',['commission_id','event_sequence']),('uq_finance_commission_event_hash',['commission_id','event_sha256'])],
    checks=[
        ('ck_finance_commission_event_seq','event_sequence > 0'),('ck_finance_commission_event_hash',hash_check('event_sha256')),
        ('ck_finance_commission_event_type',enum_check('event_type',['GENERATED','CONFIRMED','CANCELLED','AMOUNT_CHANGED','CORRECTED'])),
    ],
    fks=[fk('commission_id','finance.commission'),fk('source_import_row_id','finance.revenue_import_row')],
    indexes=[idx('ix_finance_commission_event_time',['commission_id','recorded_at'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-014','FR-016','FR-020'],implementation_slice='SLICE-020',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='YEARLY RANGE recorded_at when >50M rows'
))

add(Table(
    'finance','external_cost','LLM・API・Hosting・Tool等の外部費用をInvoice/Usage根拠付きでJPYへ正規化して追記する。',
    [
        id_col(), display_col('CST'), c('site_id','uuid',nullable=False), c('cost_type','text',nullable=False), c('vendor_code','text',nullable=False),
        c('service_code','text',nullable=True), c('occurred_on','date',nullable=False), c('amount_original','numeric(20,6)',nullable=False),
        c('currency_original','char(3)',nullable=False), c('fx_rate_to_jpy','numeric(20,10)',nullable=False,default='1'), c('amount_jpy','bigint',nullable=False),
        c('article_id','uuid',nullable=True), c('category_id','uuid',nullable=True), c('ai_job_id','uuid',nullable=True), c('source_artifact_id','uuid',nullable=True),
        c('source_record_key','text',nullable=False), c('recorded_by_actor_type','text',nullable=False), c('recorded_by_actor_id','uuid',nullable=True), created_col(),
    ],
    uniques=[('uq_finance_external_cost_display',['display_id']),('uq_finance_external_cost_source',['vendor_code','source_record_key'])],
    checks=[
        ('ck_finance_external_cost_type',enum_check('cost_type',['LLM','API','HOSTING','OBSERVABILITY','ANALYTICS','CONTENT_TOOL','OTHER'])),
        ('ck_finance_external_cost_values','amount_original >= 0 AND fx_rate_to_jpy > 0 AND amount_jpy >= 0'),
        ('ck_finance_external_cost_actor',enum_check('recorded_by_actor_type',['HUMAN','SERVICE','IMPORT'])),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','editorial.article'),fk('category_id','portfolio.category'),fk('ai_job_id','ai.ai_job'),fk('source_artifact_id','ops.object_artifact')],
    indexes=[idx('ix_finance_external_cost_date',['site_id','occurred_on','cost_type']),idx('ix_finance_external_cost_article',['article_id','occurred_on'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-015','FR-016'],implementation_slice='SLICE-020',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'finance','human_work_log','制作・編集・Review・更新等の人間作業時間と原価を記事・カテゴリへ配賦可能な形で記録する。',
    [
        id_col(), display_col('HWL'), c('site_id','uuid',nullable=False), c('principal_id','uuid',nullable=False), c('work_date','date',nullable=False),
        c('work_type','text',nullable=False), c('minutes','integer',nullable=False), c('hourly_cost_jpy','bigint',nullable=False), c('computed_cost_jpy','bigint',nullable=False),
        c('article_id','uuid',nullable=True), c('category_id','uuid',nullable=True), c('article_version_id','uuid',nullable=True),
        c('note','text',nullable=True,classification='RESTRICTED'), c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_finance_worklog_display',['display_id'])],
    checks=[
        ('ck_finance_worklog_type',enum_check('work_type',['RESEARCH','WRITING','EDITING','FACT_CHECK','COMPLIANCE','PUBLISHING','REFRESH','INCIDENT','ENGINEERING','OTHER'])),
        ('ck_finance_worklog_minutes','minutes > 0 AND minutes <= 1440'),('ck_finance_worklog_cost','hourly_cost_jpy >= 0 AND computed_cost_jpy >= 0'),
        ('ck_finance_worklog_approval','(approved_by_principal_id IS NULL) = (approved_at IS NULL)'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('principal_id','iam.principal'),fk('article_id','editorial.article'),fk('category_id','portfolio.category'),fk('article_version_id','editorial.article_version'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('ix_finance_worklog_date',['site_id','work_date','work_type']),idx('ix_finance_worklog_article',['article_id','work_date'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-015','FR-016'],implementation_slice='SLICE-020',
    expected_gate1_rows='<100k',expected_gate4_rows='<10m'
))

add(Table(
    'finance','allocation_rule','外部費用・人件費をSite/Category/Articleへ配賦するMethod、Weight、Scope、Versionを不変管理する。',
    [
        id_col(), display_col('ALR'), c('site_id','uuid',nullable=False), c('rule_code','text',nullable=False), c('version_no','integer',nullable=False),
        c('cost_source_type','text',nullable=False), c('method','text',nullable=False), json_obj('parameters',description='equal、session weight、token usage、manual weights等。',classification='RESTRICTED'),
        c('effective_from','date',nullable=False), c('effective_to','date',nullable=True), c('status','text',nullable=False,default="'ACTIVE'"),
        c('approved_by_principal_id','uuid',nullable=False), c('approved_at','timestamptz',nullable=False), created_col(),
    ],
    uniques=[('uq_finance_allocation_rule_display',['display_id']),('uq_finance_allocation_rule_version',['site_id','rule_code','version_no'])],
    checks=[
        ('ck_finance_allocation_rule_version','version_no > 0'),
        ('ck_finance_allocation_rule_source',enum_check('cost_source_type',['EXTERNAL_COST','HUMAN_WORK','SHARED_OVERHEAD'])),
        ('ck_finance_allocation_rule_method',enum_check('method',['DIRECT','EQUAL','SESSION_WEIGHTED','CLICK_WEIGHTED','AI_USAGE_WEIGHTED','MANUAL'])),
        ('ck_finance_allocation_rule_status',enum_check('status',['DRAFT','ACTIVE','RETIRED'])),
        ('ck_finance_allocation_rule_dates','effective_to IS NULL OR effective_to >= effective_from'),('ck_finance_allocation_rule_params',json_object_check('parameters')),
    ],
    fks=[fk('site_id','portfolio.site'),fk('approved_by_principal_id','iam.principal')],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='CONFIG_PERMANENT',requirements=['FR-015','FR-016','FR-020'],implementation_slice='SLICE-020',
    expected_gate1_rows='<1k',expected_gate4_rows='<100k'
))

add(Table(
    'finance','cost_allocation','特定原価をArticle/Category/SiteへRuleに従って配賦した不変結果。Source総額との合計一致をDQで検証する。',
    [
        id_col(), c('allocation_rule_id','uuid',nullable=False), c('source_type','text',nullable=False), c('source_id','uuid',nullable=False),
        c('target_type','text',nullable=False), c('target_id','uuid',nullable=False), c('period_month','date',nullable=False),
        c('allocation_ratio','numeric(12,10)',nullable=False), c('allocated_amount_jpy','bigint',nullable=False),
        c('calculated_by_job_id','uuid',nullable=False), c('calculated_at','timestamptz',nullable=False), c('calculation_sha256','text',nullable=False), created_col(),
    ],
    uniques=[('uq_finance_cost_allocation',['source_type','source_id','target_type','target_id','period_month','allocation_rule_id'])],
    checks=[
        ('ck_finance_cost_alloc_source',enum_check('source_type',['EXTERNAL_COST','HUMAN_WORK','SHARED_OVERHEAD'])),
        ('ck_finance_cost_alloc_target',enum_check('target_type',['SITE','CATEGORY','ARTICLE'])),
        ('ck_finance_cost_alloc_month',"date_trunc('month', period_month)::date = period_month"),
        ('ck_finance_cost_alloc_ratio','allocation_ratio >= 0 AND allocation_ratio <= 1'),('ck_finance_cost_alloc_amount','allocated_amount_jpy >= 0'),
        ('ck_finance_cost_alloc_hash',hash_check('calculation_sha256')),
    ],
    fks=[fk('allocation_rule_id','finance.allocation_rule'),fk('calculated_by_job_id','ops.job')],
    indexes=[idx('ix_finance_cost_alloc_target',['target_type','target_id','period_month'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-015','FR-016'],implementation_slice='SLICE-020',
    expected_gate1_rows='<1m',expected_gate4_rows='<1b',partitioning='YEARLY RANGE period_month when >50M rows'
))

add(Table(
    'finance','unit_economics_snapshot','Site/Category/Article単位の確定報酬、変動費、人件費、確定EPC/RPM、貢献利益を月次Versionとして凍結する。',
    [
        id_col(), display_col('UES'), c('site_id','uuid',nullable=False), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=False),
        c('period_month','date',nullable=False), c('calculation_version','text',nullable=False), c('status','text',nullable=False),
        c('confirmed_commission_jpy','bigint',nullable=False), c('generated_commission_jpy','bigint',nullable=False),
        c('external_cost_jpy','bigint',nullable=False), c('human_cost_jpy','bigint',nullable=False), c('contribution_profit_jpy','bigint',nullable=False),
        c('eligible_sessions','bigint',nullable=False), c('affiliate_clicks','bigint',nullable=False), c('confirmed_orders','bigint',nullable=False),
        c('confirmed_epc_jpy','numeric(20,6)',nullable=True), c('confirmed_rpm_jpy','numeric(20,6)',nullable=True), c('confirmation_rate','numeric(12,10)',nullable=True),
        c('cost_recovery_months','numeric(12,4)',nullable=True), c('source_watermark','text',nullable=False), c('report_artifact_id','uuid',nullable=False),
        c('calculated_by_job_id','uuid',nullable=False), c('calculated_at','timestamptz',nullable=False), c('approved_by_principal_id','uuid',nullable=True), c('approved_at','timestamptz',nullable=True), created_col(),
    ],
    uniques=[('uq_finance_unit_econ_display',['display_id']),('uq_finance_unit_econ_version',['site_id','scope_type','scope_id','period_month','calculation_version'])],
    checks=[
        ('ck_finance_unit_econ_scope',enum_check('scope_type',['SITE','CATEGORY','ARTICLE'])),
        ('ck_finance_unit_econ_month',"date_trunc('month', period_month)::date = period_month"),
        ('ck_finance_unit_econ_status',enum_check('status',['DRAFT','APPROVED','SUPERSEDED'])),
        ('ck_finance_unit_econ_nonnegative','confirmed_commission_jpy >= 0 AND generated_commission_jpy >= 0 AND external_cost_jpy >= 0 AND human_cost_jpy >= 0 AND eligible_sessions >= 0 AND affiliate_clicks >= 0 AND confirmed_orders >= 0'),
        ('ck_finance_unit_econ_rate','confirmation_rate IS NULL OR (confirmation_rate >= 0 AND confirmation_rate <= 1)'),
        ('ck_finance_unit_econ_approval','(approved_by_principal_id IS NULL) = (approved_at IS NULL)'),
        ('ck_finance_unit_econ_formula','contribution_profit_jpy = confirmed_commission_jpy - external_cost_jpy - human_cost_jpy'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('report_artifact_id','ops.object_artifact'),fk('calculated_by_job_id','ops.job'),fk('approved_by_principal_id','iam.principal')],
    indexes=[idx('ix_finance_unit_econ_scope',['scope_type','scope_id','period_month']),idx('ix_finance_unit_econ_site',['site_id','period_month','status'])],
    write_pattern='APPEND_ONLY',classification='RESTRICTED',retention_class='FINANCE_7Y_PROVISIONAL',requirements=['FR-015','FR-016','FR-019'],implementation_slice='SLICE-021',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

# ---------------------------------------------------------------------------
# READMODEL SCHEMA
# ---------------------------------------------------------------------------

add(Table(
    'readmodel','public_article','公開Rendererが読む現在記事Projection。承認済みPublication Snapshotからのみ再生成し、編集DBを直接参照させない。',
    [
        c('article_id','uuid',nullable=False), c('site_id','uuid',nullable=False), c('publication_id','uuid',nullable=False), c('publication_snapshot_id','uuid',nullable=False),
        c('canonical_path','text',nullable=False), c('title','text',nullable=False), c('meta_title','text',nullable=True), c('meta_description','text',nullable=True),
        c('excerpt','text',nullable=True), c('disclosure_text','text',nullable=False), c('article_type','text',nullable=False), c('language_tag','text',nullable=False,default="'ja-JP'"),
        c('content_sha256','text',nullable=False), json_obj('structured_data',description='Sanitize済みJSON-LD payload。',classification='PUBLIC'),
        c('freshness_status','text',nullable=False), c('published_at','timestamptz',nullable=False), c('updated_public_at','timestamptz',nullable=False),
        c('projection_generation','bigint',nullable=False), c('is_indexable','boolean',nullable=False),
    ],
    pk=['article_id'],
    uniques=[('uq_readmodel_public_article_snapshot',['publication_snapshot_id']),('uq_readmodel_public_article_path',['site_id','canonical_path'])],
    checks=[
        ('ck_readmodel_public_article_hash',hash_check('content_sha256')),('ck_readmodel_public_article_json',json_object_check('structured_data')),
        ('ck_readmodel_public_article_freshness',enum_check('freshness_status',['FRESH','WARNING','CRITICAL','UNKNOWN'])),
        ('ck_readmodel_public_article_generation','projection_generation > 0'),('ck_readmodel_public_article_path',"canonical_path ~ '^/' AND canonical_path !~ '[?#[:cntrl:]]'"),
    ],
    fks=[fk('article_id','editorial.article'),fk('site_id','portfolio.site'),fk('publication_id','publishing.publication'),fk('publication_snapshot_id','publishing.publication_snapshot')],
    indexes=[idx('ix_readmodel_public_article_site',['site_id','published_at'])],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-009','FR-010','NFR-PERF-001'],implementation_slice='SLICE-016',
    expected_gate1_rows='<1k',expected_gate4_rows='<1m'
))

add(Table(
    'readmodel','public_article_block','公開Snapshotの表示順Block、Sanitize済みHTML/JSON、Block hashを保持するProjection。',
    [
        id_col(), c('article_id','uuid',nullable=False), c('publication_snapshot_id','uuid',nullable=False), c('block_key','text',nullable=False),
        c('block_type','text',nullable=False), c('position','integer',nullable=False), c('heading_level','smallint',nullable=True), c('heading_text','text',nullable=True),
        c('rendered_html','text',nullable=True,classification='PUBLIC'), json_obj('render_payload',description='Component renderer用Allowlist payload。',classification='PUBLIC'),
        c('block_sha256','text',nullable=False), c('is_visible','boolean',nullable=False,default='true'),
    ],
    uniques=[('uq_readmodel_public_block_key',['publication_snapshot_id','block_key']),('uq_readmodel_public_block_pos',['publication_snapshot_id','position'])],
    checks=[
        ('ck_readmodel_public_block_position','position >= 0'),('ck_readmodel_public_block_heading','heading_level IS NULL OR heading_level BETWEEN 2 AND 6'),
        ('ck_readmodel_public_block_payload',json_object_check('render_payload')),('ck_readmodel_public_block_hash',hash_check('block_sha256')),
    ],
    fks=[fk('article_id','readmodel.public_article','article_id',on_delete='CASCADE'),fk('publication_snapshot_id','publishing.publication_snapshot')],
    indexes=[idx('ix_readmodel_public_block_article',['article_id','position'])],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-009','FR-010'],implementation_slice='SLICE-016',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'readmodel','public_product_card','公開記事内のProduct表示名、比較属性、Badge、画像参照をSnapshot単位で保持する。報酬率は含めない。',
    [
        id_col(), c('article_id','uuid',nullable=False), c('publication_snapshot_id','uuid',nullable=False), c('product_id','uuid',nullable=False),
        c('card_key','text',nullable=False), c('display_name','text',nullable=False), c('short_description','text',nullable=True),
        c('image_url','text',nullable=True), c('image_alt','text',nullable=True), json_obj('badges',description='根拠付き表示Badge。',classification='PUBLIC'),
        json_obj('comparison_attributes',description='公開可能FactのみをSnapshot化。',classification='PUBLIC'), c('position','integer',nullable=False),
        c('product_freshness_status','text',nullable=False), c('content_sha256','text',nullable=False),
    ],
    uniques=[('uq_readmodel_public_card_key',['publication_snapshot_id','card_key']),('uq_readmodel_public_card_product',['publication_snapshot_id','product_id'])],
    checks=[
        ('ck_readmodel_public_card_badges',json_object_check('badges')),('ck_readmodel_public_card_attrs',json_object_check('comparison_attributes')),
        ('ck_readmodel_public_card_position','position >= 0'),('ck_readmodel_public_card_freshness',enum_check('product_freshness_status',['FRESH','WARNING','CRITICAL','UNKNOWN'])),
        ('ck_readmodel_public_card_hash',hash_check('content_sha256')),
    ],
    fks=[fk('article_id','readmodel.public_article','article_id',on_delete='CASCADE'),fk('publication_snapshot_id','publishing.publication_snapshot'),fk('product_id','catalog.canonical_product')],
    indexes=[idx('ix_readmodel_public_card_article',['article_id','position'])],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-006','FR-009','FR-010'],implementation_slice='SLICE-016',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'readmodel','public_offer','公開Product Cardに紐づく価格・在庫・楽天Affiliate URL・観測時刻を保持する安全Projection。料率・収益情報は禁止。',
    [
        id_col(), c('public_product_card_id','uuid',nullable=False), c('offer_id','uuid',nullable=False), c('shop_id','uuid',nullable=False),
        c('shop_name','text',nullable=False), c('price_jpy','bigint',nullable=True), c('shipping_fee_jpy','bigint',nullable=True),
        c('availability','text',nullable=False), c('affiliate_url','text',nullable=True), c('destination_host','text',nullable=True),
        c('price_observed_at','timestamptz',nullable=True), c('availability_observed_at','timestamptz',nullable=True), c('link_observed_at','timestamptz',nullable=True),
        c('freshness_status','text',nullable=False), c('is_cta_enabled','boolean',nullable=False), c('cta_disabled_reason','text',nullable=True),
        c('position','integer',nullable=False), c('projection_generation','bigint',nullable=False),
    ],
    uniques=[('uq_readmodel_public_offer',['public_product_card_id','offer_id'])],
    checks=[
        ('ck_readmodel_public_offer_price','price_jpy IS NULL OR price_jpy >= 0'),('ck_readmodel_public_offer_shipping','shipping_fee_jpy IS NULL OR shipping_fee_jpy >= 0'),
        ('ck_readmodel_public_offer_avail',enum_check('availability',['IN_STOCK','OUT_OF_STOCK','BACKORDER','DISCONTINUED','UNKNOWN'])),
        ('ck_readmodel_public_offer_freshness',enum_check('freshness_status',['FRESH','WARNING','CRITICAL','UNKNOWN'])),
        ('ck_readmodel_public_offer_cta',"is_cta_enabled OR cta_disabled_reason IS NOT NULL"),('ck_readmodel_public_offer_position','position >= 0'),
        ('ck_readmodel_public_offer_generation','projection_generation > 0'),
    ],
    fks=[fk('public_product_card_id','readmodel.public_product_card',on_delete='CASCADE'),fk('offer_id','catalog.offer'),fk('shop_id','catalog.shop')],
    indexes=[idx('ix_readmodel_public_offer_card',['public_product_card_id','position'])],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-004','FR-006','FR-009','FR-012'],implementation_slice='SLICE-016',
    expected_gate1_rows='<100k',expected_gate4_rows='<100m'
))

add(Table(
    'readmodel','public_route','Public WebのPath解決に必要なArticle/Redirect/Gone Projection。公開RoleはこのSchema以外を読まない。',
    [
        c('site_id','uuid',nullable=False), c('path','text',nullable=False), c('route_type','text',nullable=False), c('article_id','uuid',nullable=True),
        c('redirect_path','text',nullable=True), c('http_status','smallint',nullable=False), c('is_indexable','boolean',nullable=False),
        c('projection_generation','bigint',nullable=False), c('updated_at','timestamptz',nullable=False),
    ],
    pk=['site_id','path'],
    checks=[
        ('ck_readmodel_route_type',enum_check('route_type',['ARTICLE','REDIRECT','GONE','STATIC'])),
        ('ck_readmodel_route_path',"path ~ '^/' AND path !~ '[?#[:cntrl:]]'"),('ck_readmodel_route_http','http_status BETWEEN 200 AND 599'),
        ('ck_readmodel_route_redirect',"route_type <> 'REDIRECT' OR redirect_path IS NOT NULL"),
        ('ck_readmodel_route_article',"route_type <> 'ARTICLE' OR article_id IS NOT NULL"),('ck_readmodel_route_generation','projection_generation > 0'),
    ],
    fks=[fk('site_id','portfolio.site'),fk('article_id','readmodel.public_article','article_id',on_delete='CASCADE')],
    indexes=[idx('ix_readmodel_route_article',['article_id'])],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-009','FR-010','NFR-PERF-001'],implementation_slice='SLICE-016',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

add(Table(
    'readmodel','runtime_control','Public Rendererが低Latencyで参照するPublication/Affiliate Link Kill Switchの安全Projection。障害時は停止側へ倒す。',
    [
        id_col(), c('site_id','uuid',nullable=False), c('scope_type','text',nullable=False), c('scope_id','uuid',nullable=True),
        c('publication_enabled','boolean',nullable=False), c('affiliate_links_enabled','boolean',nullable=False),
        c('generation','bigint',nullable=False), c('reason_code','text',nullable=True), c('expires_at','timestamptz',nullable=True),
        c('projected_at','timestamptz',nullable=False),
    ],
    indexes=[idx('ux_readmodel_runtime_scope',['site_id','scope_type','scope_id'],unique=True,nulls_not_distinct=True)],
    checks=[
        ('ck_readmodel_runtime_scope',enum_check('scope_type',['GLOBAL','SITE','CATEGORY','ARTICLE'])),
        ('ck_readmodel_runtime_scope_id',"(scope_type IN ('GLOBAL','SITE') AND scope_id IS NULL) OR (scope_type IN ('CATEGORY','ARTICLE') AND scope_id IS NOT NULL)"),
        ('ck_readmodel_runtime_generation','generation >= 0'),
    ],
    fks=[fk('site_id','portfolio.site')],
    write_pattern='PROJECTION',classification='PUBLIC',retention_class='REGENERABLE',requirements=['FR-018','NFR-AVAIL-001'],implementation_slice='SLICE-022',
    expected_gate1_rows='<10k',expected_gate4_rows='<10m'
))

# ---------------------------------------------------------------------------
# GENERATION METADATA
# ---------------------------------------------------------------------------

RETENTION_CLASSES: dict[str, dict[str, Any]] = {
    'BUSINESS_CORE': {
        'minimum': 'active lifetime + 7 years (provisional)',
        'action': 'archive then reviewed delete/anonymize',
        'legal_review_required': True,
        'description': 'Core entity/state needed to reproduce business decisions.'
    },
    'CONFIG_PERMANENT': {
        'minimum': 'indefinite', 'action': 'retain all versions', 'legal_review_required': False,
        'description': 'Versioned rules, schemas, parsers, prompts, and operating configuration.'
    },
    'CONTENT_7Y_PROVISIONAL': {
        'minimum': '7 years after last use/publication (provisional)', 'action': 'archive; delete only after hold check', 'legal_review_required': True,
        'description': 'Editorial/evidence lineage and review records.'
    },
    'AUDIT_7Y_PROVISIONAL': {
        'minimum': '7 years (provisional)', 'action': 'WORM archive; no routine mutation', 'legal_review_required': True,
        'description': 'Audit, approvals, policy decisions, incidents, publication events.'
    },
    'PUBLICATION_PERMANENT': {
        'minimum': 'indefinite while site exists', 'action': 'retain immutable snapshot and hash', 'legal_review_required': True,
        'description': 'Published snapshot lineage needed for exact rollback and dispute response.'
    },
    'OPS_2Y_PROVISIONAL': {
        'minimum': '25 months (provisional)', 'action': 'aggregate then delete after incident/legal hold check', 'legal_review_required': True,
        'description': 'Operational executions, freshness checks, and diagnostic records.'
    },
    'ANALYTICS_RAW_90D': {
        'minimum': '90 days maximum by default', 'action': 'aggregate then hard delete', 'legal_review_required': True,
        'description': 'Privacy-minimized first-party anonymous event stream.'
    },
    'ANALYTICS_CLICK_25M': {
        'minimum': '25 months (provisional)', 'action': 'retain pseudonymous click facts; delete on approved schedule', 'legal_review_required': True,
        'description': 'Affiliate click facts needed for trend analysis and estimated attribution.'
    },
    'ANALYTICS_AGG_25M': {
        'minimum': '25 months online; longer aggregate archive optional', 'action': 'roll up or archive', 'legal_review_required': True,
        'description': 'GSC, GA4, and derived aggregate metrics.'
    },
    'FINANCE_7Y_PROVISIONAL': {
        'minimum': '7 fiscal years or longer where required (provisional)', 'action': 'archive; delete only after finance/legal approval', 'legal_review_required': True,
        'description': 'Revenue source files, canonical commission facts, cost, and calculation evidence.'
    },
    'REGENERABLE': {
        'minimum': 'none beyond recovery window', 'action': 'truncate and rebuild from immutable source', 'legal_review_required': False,
        'description': 'Read models and projections that are never a system of record.'
    },
}

DATA_CLASSIFICATIONS = {
    'PUBLIC': 'Intended for public rendering; still must pass publication policy.',
    'INTERNAL': 'Ordinary operating data available to authorized staff/services.',
    'CONFIDENTIAL': 'Business-sensitive or pseudonymous data; limited access and logging required.',
    'RESTRICTED': 'Audit, finance, security, review, or potentially sensitive data; least privilege and export controls.',
}

HARD_IMMUTABLE_TABLES = {
    'ops.object_artifact', 'ops.audit_event', 'ops.kill_switch_change',
    'catalog.grouping_decision', 'catalog.price_observation', 'catalog.availability_observation',
    'catalog.review_aggregate_observation', 'catalog.affiliate_link_observation',
    'evidence.source_snapshot', 'evidence.fact', 'evidence.fact_derivation',
    'evidence.source_packet_fact', 'evidence.source_packet_product', 'evidence.claim_evidence_link',
    'publishing.review_decision', 'publishing.publication_snapshot', 'publishing.publication_event',
    'analytics.anonymous_event', 'analytics.affiliate_click_event',
    'finance.commission_event', 'finance.cost_allocation',
}

LIFECYCLE_TABLES = {
    'ops.job_attempt', 'ops.audit_export', 'ops.runtime_setting_version', 'ops.retention_policy', 'ops.release',
    'iam.principal_role_assignment', 'catalog.provider_endpoint', 'catalog.ingestion_request',
    'evidence.source_packet_version', 'editorial.article_slug', 'editorial.recommendation', 'editorial.review_comment',
    'ai.task_definition', 'ai.prompt_version', 'ai.output_schema_version', 'ai.model_definition', 'ai.model_route_version', 'ai.ai_attempt',
    'policy.policy_bundle', 'policy.rule_version', 'policy.quality_check_run',
    'publishing.approval', 'publishing.rollback_record', 'freshness.impact_assessment',
    'analytics.attribution_estimate', 'finance.parser_version', 'finance.allocation_rule', 'finance.unit_economics_snapshot',
}
for _t in TABLES:
    if _t.fq in LIFECYCLE_TABLES:
        _t.write_pattern = 'LIFECYCLE'

MIGRATION_WAVES = [
    {'id':'MIG-001','name':'Foundation schemas and shared operations','schemas':['ops','iam'],'slices':['SLICE-003','SLICE-004','SLICE-005','SLICE-007']},
    {'id':'MIG-002','name':'Portfolio planning','schemas':['portfolio'],'slices':['SLICE-006']},
    {'id':'MIG-003','name':'Rakuten catalog and observations','schemas':['catalog'],'slices':['SLICE-008','SLICE-009']},
    {'id':'MIG-004','name':'Evidence lineage','schemas':['evidence'],'slices':['SLICE-010']},
    {'id':'MIG-005','name':'AI and structured editorial','schemas':['ai','editorial'],'slices':['SLICE-011','SLICE-012']},
    {'id':'MIG-006','name':'Policy, human approval, and publication','schemas':['policy','publishing'],'slices':['SLICE-013','SLICE-014','SLICE-015']},
    {'id':'MIG-007','name':'Public projection and freshness','schemas':['readmodel','freshness'],'slices':['SLICE-016','SLICE-018','SLICE-022']},
    {'id':'MIG-008','name':'Analytics and finance','schemas':['analytics','finance'],'slices':['SLICE-017','SLICE-019','SLICE-020','SLICE-021']},
    {'id':'MIG-009','name':'Operational hardening and validation','schemas':SCHEMA_ORDER,'slices':['SLICE-023','SLICE-024','SLICE-025']},
]

OFFICIAL_REFERENCES = [
    {'id':'REF-PG-UUID','title':'PostgreSQL 18 — UUID Functions','url':'https://www.postgresql.org/docs/18/functions-uuid.html','use':'Built-in uuidv7() and UUID extraction.'},
    {'id':'REF-PG-CONSTRAINTS','title':'PostgreSQL 18 — Constraints','url':'https://www.postgresql.org/docs/18/ddl-constraints.html','use':'PK, unique, check, FK semantics and FK indexing note.'},
    {'id':'REF-PG-PARTITION','title':'PostgreSQL 18 — Table Partitioning','url':'https://www.postgresql.org/docs/18/ddl-partitioning.html','use':'Declarative partitioning and pruning.'},
    {'id':'REF-PG-ALTER','title':'PostgreSQL 18 — ALTER TABLE','url':'https://www.postgresql.org/docs/18/sql-altertable.html','use':'NOT VALID / VALIDATE and online-safe migration procedures.'},
    {'id':'REF-PG-RLS','title':'PostgreSQL 18 — Row Security Policies','url':'https://www.postgresql.org/docs/18/ddl-rowsecurity.html','use':'Optional future tenant isolation; not the MVP primary boundary.'},
    {'id':'REF-PG-PRIV','title':'PostgreSQL 18 — Privileges','url':'https://www.postgresql.org/docs/18/ddl-priv.html','use':'Least-privilege database roles and grants.'},
    {'id':'REF-RDS-VERSION','title':'Amazon RDS for PostgreSQL release calendar','url':'https://docs.aws.amazon.com/AmazonRDS/latest/PostgreSQLReleaseNotes/postgresql-release-calendar.html','use':'RDS availability and support lifecycle for PostgreSQL 18.4.'},
]

DQ_RULES: list[dict[str, Any]] = [
    {'id':'DQ-001','name':'Primary key completeness','severity':'CRITICAL','scope':'ALL_TABLES','enforcement':'DDL','assertion':'Every table has a non-null primary key.'},
    {'id':'DQ-002','name':'Foreign key target integrity','severity':'CRITICAL','scope':'ALL_FK','enforcement':'DDL','assertion':'Every FK targets a PK/unique key of compatible types.'},
    {'id':'DQ-003','name':'Foreign key lookup index','severity':'HIGH','scope':'ALL_FK','enforcement':'STATIC_LINT','assertion':'Every FK column tuple is a left-prefix of an index/PK/unique key.'},
    {'id':'DQ-004','name':'Immutable artifact digest','severity':'CRITICAL','scope':'ops.object_artifact','enforcement':'CHECK+SERVICE','assertion':'sha256 is lowercase 64 hex and the object digest matches.'},
    {'id':'DQ-005','name':'No secret material in database schema','severity':'CRITICAL','scope':'ALL_COLUMNS','enforcement':'STATIC_LINT','assertion':'No password, access key, secret, private key, or bearer token column exists.'},
    {'id':'DQ-006','name':'No Rakuten review body','severity':'CRITICAL','scope':'catalog','enforcement':'STATIC_LINT+POLICY','assertion':'No review body, author, text, or copied review content field is stored.'},
    {'id':'DQ-007','name':'Affiliate rate editorial isolation','severity':'CRITICAL','scope':'editorial,readmodel','enforcement':'STATIC_LINT','assertion':'No affiliate_rate, commission, revenue, or profit field is present.'},
    {'id':'DQ-008','name':'AI source packet approval','severity':'CRITICAL','scope':'ai.ai_job','enforcement':'TRIGGER','assertion':'AI job source packet version is APPROVED before insertion or reroute.'},
    {'id':'DQ-009','name':'Claim evidence coverage','severity':'CRITICAL','scope':'evidence.claim','enforcement':'BATCH_GATE','assertion':'Every publishable factual/quantitative/recommendation claim has at least one valid support link.'},
    {'id':'DQ-010','name':'Contradicted claim block','severity':'CRITICAL','scope':'evidence.claim_evidence_link','enforcement':'BATCH_GATE','assertion':'No publishable claim has an unresolved CONTRADICTS relation.'},
    {'id':'DQ-011','name':'Source packet immutability','severity':'CRITICAL','scope':'evidence.source_packet_version','enforcement':'ARTIFACT_HASH','assertion':'Approved packet content hash and artifact are never mutated.'},
    {'id':'DQ-012','name':'Article version sequence','severity':'HIGH','scope':'editorial.article_version','enforcement':'UNIQUE+SERVICE','assertion':'Version numbers start at one and are contiguous per article.'},
    {'id':'DQ-013','name':'Block order uniqueness','severity':'HIGH','scope':'editorial.article_block','enforcement':'UNIQUE','assertion':'block_key and position are unique within article version.'},
    {'id':'DQ-014','name':'Recommendation independence','severity':'CRITICAL','scope':'editorial.recommendation','enforcement':'CODE_REVIEW+STATIC_LINT','assertion':'Rank computation does not read affiliate rate or finance tables.'},
    {'id':'DQ-015','name':'Quality score formula','severity':'CRITICAL','scope':'policy.quality_score','enforcement':'CHECK','assertion':'passed requires total >= pass score, factual >=18/20, disclosure=5/5.'},
    {'id':'DQ-016','name':'Blocking finding absence','severity':'CRITICAL','scope':'publishing','enforcement':'TRIGGER','assertion':'Final approval and publication candidate have no unresolved blocking finding.'},
    {'id':'DQ-017','name':'Human final approval','severity':'CRITICAL','scope':'publishing.approval','enforcement':'TRIGGER+RBAC','assertion':'Final APPROVED decision is made by an active USER principal.'},
    {'id':'DQ-018','name':'Revoked approval exclusion','severity':'CRITICAL','scope':'publishing.approval','enforcement':'TRIGGER','assertion':'Publication cannot use an approval superseded by REVOKED.'},
    {'id':'DQ-019','name':'Publication kill switch','severity':'CRITICAL','scope':'publishing','enforcement':'TRIGGER+SERVICE','assertion':'No publish transition occurs while an applicable publication switch is engaged.'},
    {'id':'DQ-020','name':'Snapshot exactness','severity':'CRITICAL','scope':'publishing.publication_snapshot','enforcement':'HASH+CONTRACT_TEST','assertion':'Manifest digest equals stored artifact bytes and rendered projection input.'},
    {'id':'DQ-021','name':'Public projection lineage','severity':'CRITICAL','scope':'readmodel','enforcement':'FK+PROJECTION_TEST','assertion':'Every public row traces to the current approved publication snapshot.'},
    {'id':'DQ-022','name':'Public schema access boundary','severity':'CRITICAL','scope':'raos_public_ro','enforcement':'GRANT_TEST','assertion':'Public role can SELECT only readmodel objects and safe functions.'},
    {'id':'DQ-023','name':'Affiliate URL provenance','severity':'CRITICAL','scope':'catalog.affiliate_link_observation','enforcement':'CHECK+ADAPTER_TEST','assertion':'Affiliate URL is HTTPS, API returned, and has valid destination host/hash.'},
    {'id':'DQ-024','name':'No redirect measurement gateway','severity':'CRITICAL','scope':'analytics.affiliate_click_event','enforcement':'ARCH_TEST','assertion':'Click analytics is a side-channel beacon and never becomes the outbound URL.'},
    {'id':'DQ-025','name':'Price nonnegative','severity':'HIGH','scope':'catalog.price_observation','enforcement':'CHECK','assertion':'Price and shipping amounts are nonnegative JPY integers or unknown.'},
    {'id':'DQ-026','name':'Observation temporal order','severity':'HIGH','scope':'catalog observations','enforcement':'CHECK+BATCH','assertion':'valid_until is after observed_at and current projection picks latest accepted observation.'},
    {'id':'DQ-027','name':'Product grouping human correction','severity':'HIGH','scope':'catalog.grouping_decision','enforcement':'WORKFLOW','assertion':'Merge/split decisions retain actor, evidence, method, and supersession chain.'},
    {'id':'DQ-028','name':'Freshness critical action','severity':'CRITICAL','scope':'freshness.staleness_assessment','enforcement':'EVENT_HANDLER','assertion':'Critical price/link/source staleness applies configured block or disable action.'},
    {'id':'DQ-029','name':'Link host allowlist','severity':'CRITICAL','scope':'freshness.link_check','enforcement':'SERVICE+BATCH','assertion':'CTA is disabled for unsafe or unexpected destination hosts.'},
    {'id':'DQ-030','name':'Anonymous event minimization','severity':'CRITICAL','scope':'analytics.anonymous_event','enforcement':'SCHEMA+INGEST_ALLOWLIST','assertion':'No raw IP, full user agent, email, URL query, or free-form identifier is accepted.'},
    {'id':'DQ-031','name':'Anonymous raw retention','severity':'CRITICAL','scope':'analytics.anonymous_event','enforcement':'RETENTION_JOB','assertion':'Raw anonymous events older than configured maximum are deleted after aggregate verification.'},
    {'id':'DQ-032','name':'GSC privacy suppression','severity':'HIGH','scope':'analytics.gsc_observation','enforcement':'IMPORT_TEST','assertion':'Provider suppression/threshold flags are preserved and query is sanitized.'},
    {'id':'DQ-033','name':'Analytics aggregate uniqueness','severity':'HIGH','scope':'analytics','enforcement':'UNIQUE','assertion':'Source/date/dimension grain cannot be imported twice.'},
    {'id':'DQ-034','name':'Attribution type separation','severity':'CRITICAL','scope':'analytics.attribution_estimate','enforcement':'CHECK+UI','assertion':'DIRECT, ESTIMATED, and UNATTRIBUTED remain visibly distinct.'},
    {'id':'DQ-035','name':'Attribution allocation balance','severity':'HIGH','scope':'analytics.attribution_estimate','enforcement':'BATCH','assertion':'Approved allocations per commission sum to one within decimal tolerance.'},
    {'id':'DQ-036','name':'Revenue source deduplication','severity':'CRITICAL','scope':'finance.revenue_import','enforcement':'UNIQUE+HASH','assertion':'Same provider source artifact cannot be canonically imported twice.'},
    {'id':'DQ-037','name':'Revenue dry-run approval','severity':'CRITICAL','scope':'finance.revenue_import','enforcement':'WORKFLOW','assertion':'Canonical import requires malware/format pass, dry-run, and human confirmation.'},
    {'id':'DQ-038','name':'Commission event idempotency','severity':'CRITICAL','scope':'finance.commission_event','enforcement':'UNIQUE+HASH','assertion':'Same provider event cannot create duplicate commission transitions.'},
    {'id':'DQ-039','name':'Confirmed revenue authority','severity':'CRITICAL','scope':'finance.commission','enforcement':'CALCULATION_POLICY','assertion':'North-star revenue uses confirmed commission, never generated commission.'},
    {'id':'DQ-040','name':'Cost allocation balance','severity':'CRITICAL','scope':'finance.cost_allocation','enforcement':'BATCH','assertion':'Allocated amounts and ratios reconcile to each source cost.'},
    {'id':'DQ-041','name':'Contribution profit formula','severity':'CRITICAL','scope':'finance.unit_economics_snapshot','enforcement':'CHECK','assertion':'confirmed commission - external cost - human cost equals contribution profit.'},
    {'id':'DQ-042','name':'JPY integer rule','severity':'HIGH','scope':'money fields','enforcement':'SCHEMA_LINT','assertion':'JPY amounts use bigint integers; rates use explicit numeric scales.'},
    {'id':'DQ-043','name':'UTC and JST business date','severity':'HIGH','scope':'time fields','enforcement':'CONTRACT_TEST','assertion':'Instants are timestamptz UTC; business_date/month is derived using site Asia/Tokyo policy.'},
    {'id':'DQ-044','name':'Outbox atomicity','severity':'CRITICAL','scope':'ops.outbox_event','enforcement':'INTEGRATION_TEST','assertion':'Domain state and outbox insert commit in one transaction.'},
    {'id':'DQ-045','name':'Inbox idempotency','severity':'CRITICAL','scope':'ops.inbox_receipt','enforcement':'UNIQUE+INTEGRATION_TEST','assertion':'Duplicate delivery does not repeat domain side effects.'},
    {'id':'DQ-046','name':'Job lease correctness','severity':'CRITICAL','scope':'ops.job','enforcement':'CHECK+CONCURRENCY_TEST','assertion':'Only current lease owner may complete a running job; expired jobs can be recovered.'},
    {'id':'DQ-047','name':'Audit chain export','severity':'HIGH','scope':'ops.audit_event','enforcement':'BATCH','assertion':'Audit export count/hash reconciles to source range and object artifact.'},
    {'id':'DQ-048','name':'Kill switch generation monotonicity','severity':'CRITICAL','scope':'ops.kill_switch','enforcement':'TRIGGER','assertion':'Each state change increments generation and emits immutable change/audit records.'},
    {'id':'DQ-049','name':'No unbounded JSON query dependency','severity':'MEDIUM','scope':'jsonb columns','enforcement':'QUERY_REVIEW','assertion':'Core joins/filters use typed columns; JSONB is payload/evidence, not hidden relational schema.'},
    {'id':'DQ-050','name':'Partition readiness threshold','severity':'MEDIUM','scope':'large facts','enforcement':'CAPACITY_REVIEW','assertion':'Partition only at documented thresholds and prove pruning/maintenance benefit.'},
    {'id':'DQ-051','name':'Migration backward compatibility','severity':'CRITICAL','scope':'all migrations','enforcement':'CI','assertion':'Expand/migrate/contract sequence supports at least one previous application release.'},
    {'id':'DQ-052','name':'New constraint rollout','severity':'HIGH','scope':'large tables','enforcement':'MIGRATION_REVIEW','assertion':'Use NOT VALID then VALIDATE where supported and needed to avoid long blocking scans.'},
    {'id':'DQ-053','name':'Restore drill','severity':'CRITICAL','scope':'database+objects','enforcement':'OPERATIONS','assertion':'Quarterly restore verifies RPO/RTO, artifact hashes, and projection rebuild.'},
    {'id':'DQ-054','name':'Schema drift detection','severity':'HIGH','scope':'database','enforcement':'CI+DAILY_JOB','assertion':'Live catalog matches approved migration digest except approved emergency changes.'},
    {'id':'DQ-055','name':'Retention legal hold','severity':'CRITICAL','scope':'retention','enforcement':'RETENTION_JOB','assertion':'Deletion is blocked by open incident, dispute, audit, finance close, or legal hold.'},
]


def pg_identifier(raw: str) -> str:
    """Return a deterministic PostgreSQL identifier no longer than NAMEDATALEN-1."""
    if len(raw.encode('utf-8')) <= 63:
        return raw
    digest = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:10]
    # All generated names are ASCII; leave room for underscore and digest.
    return raw[:52] + '_' + digest


def sql_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def table_map() -> dict[str, Table]:
    return {t.fq: t for t in TABLES}


def key_sets(t: Table) -> list[tuple[str, ...]]:
    keys: list[tuple[str, ...]] = []
    if t.pk:
        keys.append(tuple(t.pk))
    keys.extend(tuple(cols) for _, cols in t.uniques)
    keys.extend(tuple(i.columns) for i in t.indexes if i.unique and i.columns and i.where is None and i.expression is None)
    return keys


def validate_model() -> tuple[list[str], list[str], dict[str, Any]]:
    ensure_fk_indexes()
    errors: list[str] = []
    warnings: list[str] = []
    metrics: dict[str, Any] = {}
    tm = table_map()
    seen_tables: set[str] = set()
    index_names: dict[str, set[str]] = {s:set() for s in SCHEMA_ORDER}
    constraint_names: dict[str, set[str]] = {s:set() for s in SCHEMA_ORDER}

    for t in TABLES:
        if t.fq in seen_tables:
            errors.append(f'duplicate table: {t.fq}')
        seen_tables.add(t.fq)
        if t.schema not in SCHEMA_ORDER:
            errors.append(f'unknown schema: {t.fq}')
        col_names = [x.name for x in t.columns]
        if len(col_names) != len(set(col_names)):
            errors.append(f'duplicate column in {t.fq}')
        for p in t.pk:
            if p not in col_names:
                errors.append(f'{t.fq}: PK column missing: {p}')
        for cname, cols in t.uniques + t.checks:
            n = pg_identifier(cname)
            if n in constraint_names[t.schema]:
                errors.append(f'duplicate constraint name in schema {t.schema}: {n}')
            constraint_names[t.schema].add(n)
            if isinstance(cols, list):
                for col in cols:
                    if col not in col_names:
                        errors.append(f'{t.fq}: unique column missing: {col}')
        for i in t.indexes:
            n = pg_identifier(i.name)
            if n in index_names[t.schema]:
                errors.append(f'duplicate index name in schema {t.schema}: {n}')
            index_names[t.schema].add(n)
            for col in i.columns + i.include:
                if col not in col_names:
                    errors.append(f'{t.fq}: index {i.name} column missing: {col}')
        for f in t.fks:
            for col in f.columns:
                if col not in col_names:
                    errors.append(f'{t.fq}: FK column missing: {col}')
            ref_fq = f'{f.ref_schema}.{f.ref_table}'
            rt = tm.get(ref_fq)
            if rt is None:
                errors.append(f'{t.fq}: FK target missing: {ref_fq}')
                continue
            ref_names = [x.name for x in rt.columns]
            for col in f.ref_columns:
                if col not in ref_names:
                    errors.append(f'{t.fq}: FK target column missing: {ref_fq}.{col}')
            if len(f.columns) != len(f.ref_columns):
                errors.append(f'{t.fq}: FK cardinality mismatch to {ref_fq}')
            if tuple(f.ref_columns) not in key_sets(rt):
                errors.append(f'{t.fq}: FK target is not PK/unique: {ref_fq}{tuple(f.ref_columns)}')
            for src_col, ref_col in zip(f.columns, f.ref_columns):
                sc = next((x for x in t.columns if x.name == src_col), None)
                rc = next((x for x in rt.columns if x.name == ref_col), None)
                if sc and rc and sc.sql_type != rc.sql_type:
                    errors.append(f'{t.fq}: FK type mismatch {src_col}:{sc.sql_type} -> {ref_fq}.{ref_col}:{rc.sql_type}')
        if t.retention_class not in RETENTION_CLASSES:
            errors.append(f'{t.fq}: unknown retention class {t.retention_class}')
        if t.classification not in DATA_CLASSIFICATIONS:
            errors.append(f'{t.fq}: unknown classification {t.classification}')
        for col in t.columns:
            if col.classification not in DATA_CLASSIFICATIONS:
                errors.append(f'{t.fq}.{col.name}: unknown classification {col.classification}')

    banned_secret = re.compile(r'(password|passwd|access_key|secret_key|private_key|bearer_token|api_key)', re.I)
    banned_review = re.compile(r'(review_body|review_text|review_content|review_author|reviewer_name)', re.I)
    banned_independence = re.compile(r'(affiliate_rate|commission|revenue|profit|margin)', re.I)
    for t in TABLES:
        for col in t.columns:
            fqcol = f'{t.fq}.{col.name}'
            if banned_secret.search(col.name):
                errors.append(f'forbidden secret column: {fqcol}')
            if t.schema == 'catalog' and banned_review.search(col.name):
                errors.append(f'forbidden review body column: {fqcol}')
            if t.schema in {'editorial','readmodel'} and banned_independence.search(col.name):
                errors.append(f'editorial independence violation: {fqcol}')
            if col.pii and col.classification not in {'CONFIDENTIAL','RESTRICTED'}:
                errors.append(f'PII classification too low: {fqcol}')

    # Readmodel may contain outbound affiliate_url, but never rate/commission economics.
    if any(c.name == 'affiliate_rate' for t in TABLES if t.schema == 'readmodel' for c in t.columns):
        errors.append('readmodel contains affiliate_rate')

    fr_expected = {f'FR-{i:03d}' for i in range(1,21)}
    fr_covered = {r for t in TABLES for r in t.requirements if r.startswith('FR-')}
    missing_fr = sorted(fr_expected - fr_covered)
    if missing_fr:
        errors.append('uncovered functional requirements: ' + ', '.join(missing_fr))

    # Verify every FK has a supporting left-prefix index after ensure_fk_indexes().
    for t in TABLES:
        prefixes: list[tuple[str,...]] = []
        if t.pk: prefixes.append(tuple(t.pk))
        prefixes.extend(tuple(cols) for _, cols in t.uniques)
        prefixes.extend(tuple(i.columns) for i in t.indexes if i.columns)
        for f in t.fks:
            key = tuple(f.columns)
            if not any(p[:len(key)] == key for p in prefixes):
                errors.append(f'{t.fq}: FK has no supporting index: {key}')

    # Warnings are intentional design review flags rather than build failures.
    generic_id_count = sum(1 for t in TABLES for c0 in t.columns if c0.name in {'scope_id','target_id','entity_id','actor_id','source_id'})
    if generic_id_count:
        warnings.append(f'{generic_id_count} polymorphic/generic identifier columns require service-level type validation.')
    warnings.append('Retention periods marked provisional require Japanese legal/tax/privacy counsel confirmation before production deletion jobs are enabled.')
    warnings.append('DDL was generated for PostgreSQL 18.4; execute integration tests against the exact RDS parameter group and minor version before production.')

    metrics.update({
        'schemas': len(SCHEMA_ORDER),
        'tables': len(TABLES),
        'columns': sum(len(t.columns) for t in TABLES),
        'foreign_keys': sum(len(t.fks) for t in TABLES),
        'indexes': sum(len(t.indexes) for t in TABLES),
        'unique_constraints': sum(len(t.uniques) for t in TABLES),
        'check_constraints': sum(len(t.checks) for t in TABLES),
        'hard_immutable_tables': len(HARD_IMMUTABLE_TABLES),
        'dq_rules': len(DQ_RULES),
        'functional_requirements_covered': sorted(fr_covered),
    })
    return errors, warnings, metrics


def render_column(col: Column) -> str:
    bits = [col.name, col.sql_type]
    if col.default is not None:
        bits += ['DEFAULT', col.default]
    if not col.nullable:
        bits.append('NOT NULL')
    return ' '.join(bits)


def render_baseline_sql() -> str:
    errors, _, _ = validate_model()
    if errors:
        raise RuntimeError('model validation failed:\n' + '\n'.join(errors))
    lines: list[str] = []
    lines += [
        '-- RAOS-DATA-001 PostgreSQL baseline DDL',
        f'-- Version {VERSION}; generated {DOC_DATE}; target PostgreSQL {PG_TARGET}',
        '-- Execute through the approved migration tool with a dedicated migrator role.',
        'BEGIN;',
        "SET LOCAL TIME ZONE 'UTC';",
        "SET LOCAL lock_timeout = '5s';",
        "SET LOCAL statement_timeout = '15min';",
        "DO $$ BEGIN IF current_setting('server_version_num')::integer < 180000 THEN RAISE EXCEPTION 'RAOS requires PostgreSQL 18 or later'; END IF; END $$;",
        '',
    ]
    for schema in SCHEMA_ORDER:
        lines.append(f'CREATE SCHEMA IF NOT EXISTS {schema};')
        lines.append(f"COMMENT ON SCHEMA {schema} IS {sql_literal(SCHEMA_META[schema][1])};")
    lines.append('')

    for t in TABLES:
        defs: list[str] = ['    ' + render_column(col) for col in t.columns]
        if t.pk:
            defs.append(f"    CONSTRAINT {pg_identifier('pk_'+t.schema+'_'+t.name)} PRIMARY KEY ({', '.join(t.pk)})")
        for cname, cols in t.uniques:
            defs.append(f"    CONSTRAINT {pg_identifier(cname)} UNIQUE ({', '.join(cols)})")
        for cname, expr in t.checks:
            defs.append(f"    CONSTRAINT {pg_identifier(cname)} CHECK ({expr})")
        lines.append(f'CREATE TABLE {t.fq} (')
        lines.append(',\n'.join(defs))
        lines.append(');')
        lines.append(f'COMMENT ON TABLE {t.fq} IS {sql_literal(t.purpose)};')
        for col in t.columns:
            lines.append(f'COMMENT ON COLUMN {t.fq}.{col.name} IS {sql_literal(col.desc())};')
        lines.append('')

    lines += ['-- Foreign keys are added after all tables exist to allow explicit circular aggregate links.']
    for t in TABLES:
        for f in t.fks:
            raw_name = f.name or f"fk_{t.schema}_{t.name}_{'_'.join(f.columns)}"
            on_delete = 'NO ACTION' if f.deferrable and f.on_delete == 'RESTRICT' else f.on_delete
            clause = (
                f"ALTER TABLE {t.fq} ADD CONSTRAINT {pg_identifier(raw_name)} "
                f"FOREIGN KEY ({', '.join(f.columns)}) REFERENCES {f.ref_schema}.{f.ref_table} ({', '.join(f.ref_columns)}) "
                f"ON DELETE {on_delete}"
            )
            if f.deferrable:
                clause += ' DEFERRABLE'
                if f.initially_deferred:
                    clause += ' INITIALLY DEFERRED'
            clause += ';'
            lines.append(clause)
    lines.append('')

    lines += ['-- Explicit supporting and query indexes. PostgreSQL does not automatically index referencing FK columns.']
    for t in TABLES:
        for i in t.indexes:
            unique = 'UNIQUE ' if i.unique else ''
            target = i.expression if i.expression else ', '.join(i.columns)
            line = f"CREATE {unique}INDEX {pg_identifier(i.name)} ON {t.fq} USING {i.method} ({target})"
            if i.include:
                line += f" INCLUDE ({', '.join(i.include)})"
            if i.nulls_not_distinct:
                line += ' NULLS NOT DISTINCT'
            if i.where:
                line += f' WHERE {i.where}'
            line += ';'
            lines.append(line)
    lines.append('')

    lines += [
        '-- Standard mutable-row timestamp and optimistic version maintenance.',
        '''CREATE OR REPLACE FUNCTION ops.touch_mutable_row() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW IS DISTINCT FROM OLD THEN
        NEW.updated_at := statement_timestamp();
        NEW.lock_version := OLD.lock_version + 1;
    END IF;
    RETURN NEW;
END;
$$;''',
    ]
    for t in TABLES:
        cols = {x.name for x in t.columns}
        if 'updated_at' in cols and 'lock_version' in cols:
            trg = pg_identifier(f'trg_{t.schema}_{t.name}_touch')
            lines.append(f'CREATE TRIGGER {trg} BEFORE UPDATE ON {t.fq} FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();')
    lines.append('')

    lines += [
        '-- Hard immutable rows can only be changed during an explicit migrator maintenance window.',
        '''CREATE OR REPLACE FUNCTION ops.reject_immutable_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF current_setting('raos.allow_immutable_maintenance', true) = 'on'
       AND pg_has_role(current_user, 'raos_migrator', 'MEMBER') THEN
        IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
    END IF;
    RAISE EXCEPTION 'immutable table %.% does not allow %', TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP
        USING ERRCODE = '55000';
END;
$$;''',
    ]
    for fq in sorted(HARD_IMMUTABLE_TABLES):
        schema, name = fq.split('.',1)
        trg = pg_identifier(f'trg_{schema}_{name}_immutable')
        lines.append(f'CREATE TRIGGER {trg} BEFORE UPDATE OR DELETE ON {fq} FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();')
    lines.append('')

    lines += [
        '-- AI jobs may consume only reviewed and approved source packets.',
        '''CREATE OR REPLACE FUNCTION ai.guard_approved_source_packet() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE packet_status text;
BEGIN
    SELECT status INTO packet_status FROM evidence.source_packet_version WHERE id = NEW.source_packet_version_id;
    IF packet_status IS DISTINCT FROM 'APPROVED' THEN
        RAISE EXCEPTION 'AI job requires APPROVED source packet version; got %', packet_status USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;''',
        'CREATE TRIGGER trg_ai_job_approved_packet BEFORE INSERT OR UPDATE OF source_packet_version_id ON ai.ai_job FOR EACH ROW EXECUTE FUNCTION ai.guard_approved_source_packet();',
        '',
        '-- Final approval is a human decision and requires a passed quality run with no open blockers.',
        '''CREATE OR REPLACE FUNCTION publishing.guard_final_approval() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE p_type text; q_passed boolean; q_article uuid; packet_status text; blockers bigint;
BEGIN
    IF NEW.approval_type <> 'FINAL' OR NEW.decision <> 'APPROVED' THEN RETURN NEW; END IF;
    SELECT principal_type INTO p_type FROM iam.principal WHERE id = NEW.approved_by_principal_id AND status = 'ACTIVE';
    IF p_type IS DISTINCT FROM 'USER' THEN
        RAISE EXCEPTION 'FINAL approval requires an active USER principal' USING ERRCODE='23514';
    END IF;
    IF NEW.quality_check_run_id IS NULL THEN
        RAISE EXCEPTION 'FINAL approval requires quality_check_run_id' USING ERRCODE='23514';
    END IF;
    SELECT qs.passed, qr.article_version_id INTO q_passed, q_article
      FROM policy.quality_check_run qr JOIN policy.quality_score qs ON qs.quality_check_run_id = qr.id
     WHERE qr.id = NEW.quality_check_run_id AND qr.status = 'PASSED';
    IF q_passed IS DISTINCT FROM true OR q_article IS DISTINCT FROM NEW.article_version_id THEN
        RAISE EXCEPTION 'FINAL approval requires a passed matching quality run' USING ERRCODE='23514';
    END IF;
    SELECT count(*) INTO blockers FROM policy.finding
     WHERE quality_check_run_id = NEW.quality_check_run_id AND is_blocking AND status = 'OPEN';
    IF blockers > 0 THEN RAISE EXCEPTION 'FINAL approval blocked by % open findings', blockers USING ERRCODE='23514'; END IF;
    SELECT spv.status INTO packet_status
      FROM editorial.article_version av JOIN evidence.source_packet_version spv ON spv.id = av.source_packet_version_id
     WHERE av.id = NEW.article_version_id;
    IF packet_status IS DISTINCT FROM 'APPROVED' THEN
        RAISE EXCEPTION 'FINAL approval requires APPROVED source packet' USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;''',
        'CREATE TRIGGER trg_publishing_final_approval BEFORE INSERT ON publishing.approval FOR EACH ROW EXECUTE FUNCTION publishing.guard_final_approval();',
        '',
        '-- Publication candidate repeats critical checks at the database boundary.',
        '''CREATE OR REPLACE FUNCTION publishing.guard_publication_candidate() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE a publishing.approval%ROWTYPE; q_passed boolean; q_article uuid; blockers bigint; article_id_v uuid; category_id_v uuid; switch_count bigint;
BEGIN
    SELECT * INTO a FROM publishing.approval WHERE id = NEW.final_approval_id;
    IF a.id IS NULL OR a.article_version_id <> NEW.article_version_id OR a.approval_type <> 'FINAL' OR a.decision <> 'APPROVED'
       OR a.revoked_at IS NOT NULL OR (a.valid_until IS NOT NULL AND a.valid_until <= statement_timestamp()) THEN
        RAISE EXCEPTION 'invalid final approval for publication candidate' USING ERRCODE='23514';
    END IF;
    IF EXISTS (SELECT 1 FROM publishing.approval r WHERE r.supersedes_approval_id = a.id AND r.decision = 'REVOKED') THEN
        RAISE EXCEPTION 'final approval has been revoked' USING ERRCODE='23514';
    END IF;
    SELECT qs.passed, qr.article_version_id INTO q_passed, q_article
      FROM policy.quality_check_run qr JOIN policy.quality_score qs ON qs.quality_check_run_id = qr.id
     WHERE qr.id = NEW.quality_check_run_id AND qr.status = 'PASSED';
    IF q_passed IS DISTINCT FROM true OR q_article IS DISTINCT FROM NEW.article_version_id THEN
        RAISE EXCEPTION 'publication candidate quality run is not a passed matching run' USING ERRCODE='23514';
    END IF;
    SELECT count(*) INTO blockers FROM policy.finding WHERE quality_check_run_id=NEW.quality_check_run_id AND is_blocking AND status='OPEN';
    IF blockers > 0 THEN RAISE EXCEPTION 'publication blocked by open findings' USING ERRCODE='23514'; END IF;
    SELECT ar.id, ap.category_id INTO article_id_v, category_id_v
      FROM editorial.article_version av JOIN editorial.article ar ON ar.id=av.article_id JOIN editorial.article_plan ap ON ap.id=ar.article_plan_id
     WHERE av.id=NEW.article_version_id AND ar.site_id=NEW.site_id;
    IF article_id_v IS NULL THEN RAISE EXCEPTION 'article/site mismatch' USING ERRCODE='23514'; END IF;
    SELECT count(*) INTO switch_count FROM ops.kill_switch ks
     WHERE ks.is_engaged AND ks.switch_type='PUBLICATION' AND (ks.expires_at IS NULL OR ks.expires_at>statement_timestamp())
       AND ((ks.scope_type='GLOBAL' AND ks.scope_id IS NULL)
         OR (ks.scope_type='SITE' AND ks.scope_id=NEW.site_id)
         OR (ks.scope_type='CATEGORY' AND ks.scope_id=category_id_v)
         OR (ks.scope_type='ARTICLE' AND ks.scope_id=article_id_v));
    IF switch_count > 0 THEN RAISE EXCEPTION 'publication kill switch is engaged' USING ERRCODE='55000'; END IF;
    RETURN NEW;
END;
$$;''',
        'CREATE TRIGGER trg_publishing_candidate_guard BEFORE INSERT OR UPDATE OF final_approval_id, quality_check_run_id, status ON publishing.publication_candidate FOR EACH ROW EXECUTE FUNCTION publishing.guard_publication_candidate();',
        '',
        '-- Current publication cannot transition to PUBLISHED while an applicable kill switch is engaged.',
        '''CREATE OR REPLACE FUNCTION publishing.guard_publication_transition() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE category_id_v uuid; switch_count bigint;
BEGIN
    IF NEW.state <> 'PUBLISHED' THEN RETURN NEW; END IF;
    SELECT ap.category_id INTO category_id_v FROM editorial.article ar JOIN editorial.article_plan ap ON ap.id=ar.article_plan_id WHERE ar.id=NEW.article_id;
    SELECT count(*) INTO switch_count FROM ops.kill_switch ks
     WHERE ks.is_engaged AND ks.switch_type='PUBLICATION' AND (ks.expires_at IS NULL OR ks.expires_at>statement_timestamp())
       AND ((ks.scope_type='GLOBAL' AND ks.scope_id IS NULL)
         OR (ks.scope_type='SITE' AND ks.scope_id=NEW.site_id)
         OR (ks.scope_type='CATEGORY' AND ks.scope_id=category_id_v)
         OR (ks.scope_type='ARTICLE' AND ks.scope_id=NEW.article_id));
    IF switch_count > 0 THEN RAISE EXCEPTION 'publication kill switch is engaged' USING ERRCODE='55000'; END IF;
    RETURN NEW;
END;
$$;''',
        'CREATE TRIGGER trg_publishing_transition_guard BEFORE INSERT OR UPDATE OF state, current_snapshot_id ON publishing.publication FOR EACH ROW EXECUTE FUNCTION publishing.guard_publication_transition();',
        '',
        '-- Kill switch generation is monotonic and changes are projected through explicit application events.',
        '''CREATE OR REPLACE FUNCTION ops.guard_kill_switch_generation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP='UPDATE' AND (NEW.is_engaged IS DISTINCT FROM OLD.is_engaged OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.expires_at IS DISTINCT FROM OLD.expires_at) THEN
        NEW.generation := OLD.generation + 1;
        NEW.changed_at := statement_timestamp();
    ELSIF TG_OP='UPDATE' AND NEW.generation <> OLD.generation THEN
        RAISE EXCEPTION 'kill switch generation may only change with state/reason/expiry' USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;''',
        'CREATE TRIGGER trg_ops_kill_switch_generation BEFORE UPDATE ON ops.kill_switch FOR EACH ROW EXECUTE FUNCTION ops.guard_kill_switch_generation();',
        '',
    ]

    lines += [
        '-- Safe operational/read views.',
        '''CREATE OR REPLACE VIEW ops.v_outbox_ready AS
SELECT * FROM ops.outbox_event
 WHERE status IN ('PENDING','FAILED') AND available_at <= statement_timestamp()
 ORDER BY available_at, created_at;''',
        '''CREATE OR REPLACE VIEW catalog.v_safe_offer_current AS
SELECT p.offer_id, p.product_id, o.shop_id, p.current_price_jpy, p.current_shipping_fee_jpy,
       p.current_availability, p.review_count, p.review_average, p.affiliate_url,
       p.destination_host, p.price_observed_at, p.availability_observed_at,
       p.link_observed_at, p.freshness_status, p.projection_version, p.updated_at
  FROM catalog.offer_current_projection p JOIN catalog.offer o ON o.id=p.offer_id;''',
        '''CREATE OR REPLACE VIEW publishing.v_publishable_article AS
SELECT av.id AS article_version_id, av.article_id, qr.id AS quality_check_run_id, qs.total_score,
       a.id AS final_approval_id, a.approved_at
  FROM editorial.article_version av
  JOIN policy.quality_check_run qr ON qr.article_version_id=av.id AND qr.status='PASSED'
  JOIN policy.quality_score qs ON qs.quality_check_run_id=qr.id AND qs.passed
  JOIN publishing.approval a ON a.article_version_id=av.id AND a.approval_type='FINAL' AND a.decision='APPROVED'
 WHERE a.revoked_at IS NULL
   AND (a.valid_until IS NULL OR a.valid_until>statement_timestamp())
   AND NOT EXISTS (SELECT 1 FROM policy.finding f WHERE f.quality_check_run_id=qr.id AND f.is_blocking AND f.status='OPEN')
   AND NOT EXISTS (SELECT 1 FROM publishing.approval r WHERE r.supersedes_approval_id=a.id AND r.decision='REVOKED');''',
        '''CREATE OR REPLACE VIEW finance.v_latest_unit_economics AS
SELECT DISTINCT ON (site_id, scope_type, scope_id, period_month) *
  FROM finance.unit_economics_snapshot
 WHERE status='APPROVED'
 ORDER BY site_id, scope_type, scope_id, period_month, calculated_at DESC;''',
        '',
        'COMMIT;',
        '',
    ]
    return '\n'.join(lines)

# Retention classes inherited from the architecture catalog. They remain
# deliberately explicit rather than being collapsed into one generic period.
RETENTION_CLASSES.update({
    'BY_ARTIFACT_KIND': {'minimum':'policy by artifact_kind','action':'object lock/archive/delete per registered policy','legal_review_required':True,'description':'Artifact-specific retention resolved by ops.retention_policy.'},
    'OPS_JOB_2Y': {'minimum':'25 months (provisional)','action':'retain summary; expire large payload artifacts separately','legal_review_required':True,'description':'Job and attempt execution history.'},
    'OUTBOX_180D': {'minimum':'180 days after successful publication','action':'delete after consumer reconciliation and audit export','legal_review_required':False,'description':'Transactional outbox delivery history.'},
    'INBOX_400D': {'minimum':'400 days','action':'delete after deduplication horizon','legal_review_required':False,'description':'Consumer idempotency receipts.'},
    'IDEMPOTENCY_UNTIL_EXPIRY': {'minimum':'record expires_at plus safety buffer','action':'delete after related workflow reaches terminal state','legal_review_required':False,'description':'Request idempotency records.'},
    'OPS_ALERT_2Y': {'minimum':'25 months','action':'archive aggregate and delete details','legal_review_required':False,'description':'Alert lifecycle records.'},
    'INCIDENT_7Y_PROVISIONAL': {'minimum':'7 years after closure (provisional)','action':'retain with audit/legal hold','legal_review_required':True,'description':'Incident and timeline evidence.'},
    'CONFIG_7Y': {'minimum':'7 years after supersession','action':'archive; preserve versions used by retained decisions','legal_review_required':True,'description':'General versioned configuration.'},
    'RELEASE_7Y': {'minimum':'7 years','action':'retain manifest, digest and rollback lineage','legal_review_required':True,'description':'Application/database release history.'},
    'IAM_LIFECYCLE': {'minimum':'account lifetime + 7 years (provisional)','action':'pseudonymize contact data when no longer needed; retain audit key','legal_review_required':True,'description':'Principals and identity mappings.'},
    'IAM_SESSION_2Y': {'minimum':'25 months maximum','action':'delete after security horizon','legal_review_required':True,'description':'Session revocation and access security evidence.'},
    'ANALYTICS_25M': {'minimum':'25 months','action':'roll up/archive','legal_review_required':True,'description':'Portfolio/search metric observations.'},
    'RAW_PROVIDER_2Y': {'minimum':'25 months unless source-specific policy is longer','action':'archive or delete after normalized reconciliation','legal_review_required':True,'description':'Provider ingestion request and raw response metadata.'},
    'CATALOG_CURRENT': {'minimum':'while provider taxonomy is active + 25 months','action':'retain superseded taxonomy for lineage','legal_review_required':False,'description':'Provider category/genre reference data.'},
    'CATALOG_HISTORY': {'minimum':'site lifetime + 7 years (provisional)','action':'archive inactive entities; never break publication lineage','legal_review_required':True,'description':'Canonical product, offer, grouping and attribute history.'},
    'OBSERVATION_3Y': {'minimum':'37 months online/nearline','action':'retain monthly rollups longer where needed','legal_review_required':True,'description':'Price, availability, rating aggregate and link observations.'},
    'REBUILDABLE': {'minimum':'recovery window only','action':'truncate/rebuild','legal_review_required':False,'description':'Internal current-state projections.'},
    'SOURCE_SNAPSHOT_7Y_PROVISIONAL': {'minimum':'7 years after last referenced publication (provisional)','action':'WORM archive; delete only after lineage/hold check','legal_review_required':True,'description':'External source snapshots.'},
    'EVIDENCE_7Y_PROVISIONAL': {'minimum':'7 years after last referenced publication (provisional)','action':'archive with hashes and lineage','legal_review_required':True,'description':'Facts, packet versions and evidence links.'},
    'AI_CONFIG_7Y': {'minimum':'7 years after last use','action':'retain prompt/schema/model-route version','legal_review_required':True,'description':'AI reproducibility configuration.'},
    'AI_RUN_3Y': {'minimum':'37 months online; longer artifact retention where publication-referenced','action':'aggregate usage; retain referenced I/O by artifact policy','legal_review_required':True,'description':'AI jobs, attempts and usage.'},
    'AI_EVAL_3Y': {'minimum':'37 months','action':'retain aggregate evaluation and sampled evidence','legal_review_required':True,'description':'AI evaluation results.'},
    'POLICY_7Y': {'minimum':'7 years after supersession','action':'retain all policy/rule versions used for decisions','legal_review_required':True,'description':'Policy bundles and quality rules.'},
})


def render_roles_sql() -> str:
    schemas_internal = [s for s in SCHEMA_ORDER if s != 'readmodel']
    lines = [
        '-- RAOS-DATA-001 database roles and grants',
        '-- Run as the database owner after the baseline DDL. No LOGIN roles or credentials are created here.',
        'BEGIN;',
        "SET LOCAL lock_timeout = '5s';",
        '',
    ]
    roles = [
        'raos_migrator','raos_api_rw','raos_worker_rw','raos_dispatcher_rw',
        'raos_projection_rw','raos_public_ro','raos_reporting_ro','raos_auditor_ro'
    ]
    for role in roles:
        lines += [
            f"DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname={sql_literal(role)}) THEN CREATE ROLE {role} NOLOGIN; END IF; END $$;"
        ]
    lines += ['', 'REVOKE CREATE ON SCHEMA public FROM PUBLIC;', 'REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;', '']
    for schema in SCHEMA_ORDER:
        lines.append(f'REVOKE ALL ON SCHEMA {schema} FROM PUBLIC;')
        lines.append(f'REVOKE ALL ON ALL TABLES IN SCHEMA {schema} FROM PUBLIC;')
        lines.append(f'REVOKE ALL ON ALL FUNCTIONS IN SCHEMA {schema} FROM PUBLIC;')
    lines.append('')

    lines += [
        '-- Application/API role. It never reads public-only projection through a broader owner connection.',
        'GRANT USAGE ON SCHEMA iam, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance, ops TO raos_api_rw;',
    ]
    for schema in schemas_internal:
        lines.append(f'GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA {schema} TO raos_api_rw;')
    lines += [
        'REVOKE DELETE ON ALL TABLES IN SCHEMA ops, iam, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance FROM raos_api_rw;',
        'GRANT EXECUTE ON FUNCTION ai.guard_approved_source_packet(), publishing.guard_final_approval(), publishing.guard_publication_candidate(), publishing.guard_publication_transition() TO raos_api_rw;',
        '',
        '-- Worker role for deterministic jobs and adapters.',
        'GRANT USAGE ON SCHEMA ops, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance TO raos_worker_rw;',
    ]
    for schema in ['ops','portfolio','catalog','evidence','editorial','ai','policy','publishing','freshness','analytics','finance']:
        lines.append(f'GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA {schema} TO raos_worker_rw;')
    lines += [
        'REVOKE DELETE ON ALL TABLES IN SCHEMA ops, portfolio, catalog, evidence, editorial, ai, policy, publishing, freshness, analytics, finance FROM raos_worker_rw;',
        '',
        '-- Outbox dispatcher has narrowly scoped queue permissions.',
        'GRANT USAGE ON SCHEMA ops TO raos_dispatcher_rw;',
        'GRANT SELECT, UPDATE ON ops.outbox_event, ops.job TO raos_dispatcher_rw;',
        'GRANT SELECT, INSERT ON ops.inbox_receipt, ops.job_attempt, ops.audit_event TO raos_dispatcher_rw;',
        '',
        '-- Projection writer may read systems of record and replace regenerable read models.',
    ]
    for schema in SCHEMA_ORDER:
        lines.append(f'GRANT USAGE ON SCHEMA {schema} TO raos_projection_rw;')
    for schema in schemas_internal:
        lines.append(f'GRANT SELECT ON ALL TABLES IN SCHEMA {schema} TO raos_projection_rw;')
    lines += [
        'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA readmodel TO raos_projection_rw;',
        '',
        '-- Public renderer is intentionally blind to editorial, evidence, AI, analytics and finance schemas.',
        'GRANT USAGE ON SCHEMA readmodel TO raos_public_ro;',
        'GRANT SELECT ON ALL TABLES IN SCHEMA readmodel TO raos_public_ro;',
        '',
        '-- Reporting and audit roles.',
        'GRANT USAGE ON SCHEMA analytics, finance, readmodel, portfolio, editorial, publishing TO raos_reporting_ro;',
        'GRANT SELECT ON ALL TABLES IN SCHEMA analytics, finance, readmodel, portfolio, editorial, publishing TO raos_reporting_ro;',
        'GRANT USAGE ON SCHEMA ops, iam, policy, publishing, evidence TO raos_auditor_ro;',
        'GRANT SELECT ON ops.audit_event, ops.audit_export, ops.incident, ops.incident_event, ops.kill_switch_change, ops.release TO raos_auditor_ro;',
        'GRANT SELECT ON iam.principal, iam.principal_role_assignment, iam.break_glass_record TO raos_auditor_ro;',
        'GRANT SELECT ON policy.policy_bundle, policy.rule_version, policy.quality_check_run, policy.finding, policy.quality_score, policy.waiver, policy.gate_decision TO raos_auditor_ro;',
        'GRANT SELECT ON publishing.review_assignment, publishing.review_decision, publishing.approval, publishing.publication_snapshot, publishing.publication_event, publishing.rollback_record TO raos_auditor_ro;',
        'GRANT SELECT ON evidence.source_packet_version, evidence.claim, evidence.claim_evidence_link TO raos_auditor_ro;',
        '',
        '-- Default privileges must be executed by the same owner that will create future objects.',
    ]
    for schema in SCHEMA_ORDER:
        if schema == 'readmodel':
            lines.append('ALTER DEFAULT PRIVILEGES IN SCHEMA readmodel GRANT SELECT ON TABLES TO raos_public_ro;')
            lines.append('ALTER DEFAULT PRIVILEGES IN SCHEMA readmodel GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO raos_projection_rw;')
        else:
            lines.append(f'ALTER DEFAULT PRIVILEGES IN SCHEMA {schema} GRANT SELECT ON TABLES TO raos_projection_rw;')
    lines += ['', 'COMMIT;', '']
    return '\n'.join(lines)


PERMISSIONS = [
    ('portfolio.read','Read portfolio planning data','LOW'),('portfolio.write','Create and change portfolio plans','MEDIUM'),
    ('catalog.read','Read normalized product catalog','LOW'),('catalog.refresh','Run provider refresh jobs','MEDIUM'),('catalog.group','Approve product grouping decisions','HIGH'),
    ('evidence.read','Read evidence and source packets','MEDIUM'),('evidence.review','Approve or reject source packets','HIGH'),
    ('editorial.plan','Create article plans','MEDIUM'),('editorial.edit','Edit article versions','MEDIUM'),('editorial.review','Perform editorial/fact review','HIGH'),
    ('policy.review','Run and adjudicate policy checks','HIGH'),('policy.waive','Approve bounded policy waivers','CRITICAL'),
    ('publishing.approve','Issue final human approval','CRITICAL'),('publishing.publish','Publish approved snapshots','CRITICAL'),('publishing.rollback','Rollback a publication','CRITICAL'),
    ('analytics.read','Read aggregate analytics','MEDIUM'),('finance.read','Read finance and contribution metrics','HIGH'),('finance.import','Confirm revenue imports','CRITICAL'),
    ('ops.kill_switch','Engage or release kill switches','CRITICAL'),('ops.incident','Manage incidents','HIGH'),('audit.read','Read audit evidence','HIGH'),
]
ROLES = [
    ('OWNER','Owner','Full business and emergency authority; use only with MFA and separation of duties.'),
    ('EDITOR','Editor','Plan and edit content; cannot final-approve or publish alone.'),
    ('REVIEWER','Reviewer','Editorial and fact review.'),
    ('COMPLIANCE_APPROVER','Compliance approver','Policy review, bounded waivers, and final approval.'),
    ('OPERATOR','Operator','Refresh, publication execution, rollback, incidents, and kill switches.'),
    ('ANALYST','Analyst','Analytics and finance read access.'),
    ('AUDITOR','Auditor','Read-only access to audit and decision evidence.'),
]
ROLE_PERMISSION_MAP = {
    'OWNER':[p[0] for p in PERMISSIONS],
    'EDITOR':['portfolio.read','portfolio.write','catalog.read','evidence.read','editorial.plan','editorial.edit','analytics.read'],
    'REVIEWER':['portfolio.read','catalog.read','evidence.read','evidence.review','editorial.review','policy.review'],
    'COMPLIANCE_APPROVER':['catalog.read','evidence.read','evidence.review','editorial.review','policy.review','policy.waive','publishing.approve','audit.read'],
    'OPERATOR':['catalog.read','catalog.refresh','publishing.publish','publishing.rollback','ops.kill_switch','ops.incident','audit.read'],
    'ANALYST':['portfolio.read','catalog.read','analytics.read','finance.read'],
    'AUDITOR':['audit.read','evidence.read','finance.read'],
}


def stable_uuid(namespace: str, value: str) -> str:
    # Deterministic fixture IDs; do not encode production secrets or user data.
    h = hashlib.sha256((namespace + ':' + value).encode()).hexdigest()
    return f'{h[:8]}-{h[8:12]}-7{h[13:16]}-a{h[17:20]}-{h[20:32]}'


def render_seed_sql() -> str:
    lines = [
        '-- RAOS-DATA-001 deterministic application RBAC reference seed',
        '-- Idempotent and safe to rerun. It creates no user accounts, credentials, sites, or provider endpoints.',
        'BEGIN;',
    ]
    role_ids = {code: stable_uuid('role',code) for code,_,_ in ROLES}
    perm_ids = {code: stable_uuid('permission',code) for code,_,_ in PERMISSIONS}
    for code,name,desc in ROLES:
        lines.append(
            "INSERT INTO iam.role (id, role_code, name, description, is_system_role, status) VALUES "
            f"('{role_ids[code]}'::uuid, {sql_literal(code)}, {sql_literal(name)}, {sql_literal(desc)}, true, 'ACTIVE') "
            "ON CONFLICT (role_code) DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description;"
        )
    for code,desc,risk in PERMISSIONS:
        lines.append(
            "INSERT INTO iam.permission (id, permission_code, description, risk_level, status) VALUES "
            f"('{perm_ids[code]}'::uuid, {sql_literal(code)}, {sql_literal(desc)}, {sql_literal(risk)}, 'ACTIVE') "
            "ON CONFLICT (permission_code) DO UPDATE SET description=EXCLUDED.description, risk_level=EXCLUDED.risk_level;"
        )
    for role, perms in ROLE_PERMISSION_MAP.items():
        for perm in perms:
            lines.append(
                "INSERT INTO iam.role_permission (role_id, permission_id) VALUES "
                f"('{role_ids[role]}'::uuid, '{perm_ids[perm]}'::uuid) ON CONFLICT DO NOTHING;"
            )
    lines += ['COMMIT;', '']
    return '\n'.join(lines)


def render_post_deploy_validation_sql() -> str:
    expected_tables = len(TABLES)
    expected_fks = sum(len(t.fks) for t in TABLES)
    return f'''-- RAOS-DATA-001 post-deploy validation queries
-- Execute in CI and capture the result as an artifact. Any exception is a failed deployment.
DO $$
DECLARE n bigint;
BEGIN
  SELECT count(*) INTO n FROM information_schema.tables
   WHERE table_schema IN ({', '.join(sql_literal(s) for s in SCHEMA_ORDER)}) AND table_type='BASE TABLE';
  IF n <> {expected_tables} THEN RAISE EXCEPTION 'expected {expected_tables} RAOS tables, found %', n; END IF;

  SELECT count(*) INTO n FROM pg_constraint c JOIN pg_namespace nsp ON nsp.oid=c.connamespace
   WHERE nsp.nspname IN ({', '.join(sql_literal(s) for s in SCHEMA_ORDER)}) AND c.contype='f';
  IF n <> {expected_fks} THEN RAISE EXCEPTION 'expected {expected_fks} foreign keys, found %', n; END IF;

  IF has_schema_privilege('raos_public_ro','editorial','USAGE')
     OR has_schema_privilege('raos_public_ro','finance','USAGE')
     OR has_schema_privilege('raos_public_ro','evidence','USAGE') THEN
     RAISE EXCEPTION 'public role has forbidden internal schema access';
  END IF;

  IF NOT has_schema_privilege('raos_public_ro','readmodel','USAGE') THEN
     RAISE EXCEPTION 'public role lacks readmodel access';
  END IF;
END $$;

-- The following SELECTs must return zero rows.
SELECT 'open publication without snapshot' AS violation, id
  FROM publishing.publication WHERE state='PUBLISHED' AND current_snapshot_id IS NULL;

SELECT 'public offer with enabled CTA but no affiliate URL' AS violation, id
  FROM readmodel.public_offer WHERE is_cta_enabled AND affiliate_url IS NULL;

SELECT 'passed quality score with invalid mandatory subscores' AS violation, id
  FROM policy.quality_score
 WHERE passed AND (total_score < pass_score OR factual_accuracy_score < 18 OR disclosure_policy_score <> 5);

SELECT 'unbalanced attribution commission' AS violation, commission_id
  FROM analytics.attribution_estimate WHERE status='APPROVED'
 GROUP BY commission_id HAVING abs(sum(allocation_ratio)-1) > 0.0000000001;

SELECT 'unbalanced cost allocation source' AS violation, source_type, source_id, period_month
  FROM finance.cost_allocation
 GROUP BY source_type, source_id, period_month HAVING sum(allocation_ratio) > 1.0000000001;
'''


def md_cell(value: Any) -> str:
    if value is None:
        return '—'
    s = str(value).replace('\n','<br>').replace('|','\\|')
    return s if s else '—'


def render_data_catalog() -> dict[str, Any]:
    errors, warnings, metrics = validate_model()
    if errors:
        raise RuntimeError(errors)
    schemas: list[dict[str, Any]] = []
    for schema in SCHEMA_ORDER:
        title, purpose = SCHEMA_META[schema]
        tables = []
        for t in [x for x in TABLES if x.schema == schema]:
            tables.append({
                'name': t.name,
                'fully_qualified_name': t.fq,
                'purpose': t.purpose,
                'owner_module': t.owner_module,
                'write_pattern': t.write_pattern,
                'classification': t.classification,
                'retention_class': t.retention_class,
                'primary_key': t.pk,
                'expected_scale': {'gate_1': t.expected_gate1_rows, 'gate_4': t.expected_gate4_rows},
                'partitioning': t.partitioning,
                'requirements': t.requirements,
                'architecture_refs': t.architecture_refs,
                'implementation_slice': t.implementation_slice,
                'notes': t.notes,
                'columns': [
                    {
                        'name': col.name, 'type': col.sql_type, 'nullable': col.nullable,
                        'default': col.default, 'description': col.desc(),
                        'classification': col.classification, 'pii': col.pii,
                    } for col in t.columns
                ],
                'unique_constraints': [{'name':n,'columns':cols} for n,cols in t.uniques],
                'check_constraints': [{'name':n,'expression':expr} for n,expr in t.checks],
                'foreign_keys': [
                    {
                        'name': f.name or pg_identifier(f"fk_{t.schema}_{t.name}_{'_'.join(f.columns)}"),
                        'columns': f.columns, 'references': f'{f.ref_schema}.{f.ref_table}',
                        'referenced_columns': f.ref_columns, 'on_delete': f.on_delete,
                        'deferrable': f.deferrable, 'initially_deferred': f.initially_deferred,
                    } for f in t.fks
                ],
                'indexes': [
                    {
                        'name': pg_identifier(i.name), 'columns': i.columns, 'expression': i.expression,
                        'unique': i.unique, 'method': i.method, 'where': i.where,
                        'include': i.include, 'nulls_not_distinct': i.nulls_not_distinct,
                        'description': i.description,
                    } for i in t.indexes
                ],
            })
        schemas.append({'id':schema,'name':title,'purpose':purpose,'tables':tables})
    return {
        'document': {
            'id':'RAOS-DATA-001','title':'RAOS Data Model and PostgreSQL Catalog','version':VERSION,
            'status':'BASELINE_CANDIDATE','date':DOC_DATE,'target_postgresql':PG_TARGET,
            'upstream':['RAOS-REQ-001 v0.1','RAOS-ARCH-001 v0.1'],
        },
        'principles': [
            'PostgreSQL is the transactional system of record; immutable large payloads live in object storage with URI and SHA-256 registry.',
            'Provider facts, internal decisions, estimates, and public projections are distinct records.',
            'Published content is an immutable snapshot, never a live join over draft/editorial tables.',
            'AI output has no authority to approve or publish.',
            'Affiliate economics are structurally isolated from editorial recommendation and public read models.',
            'Raw analytics are privacy-minimized and short-lived; finance uses confirmed provider facts.',
        ],
        'metrics': metrics,
        'validation_warnings': warnings,
        'classifications': DATA_CLASSIFICATIONS,
        'retention_classes': RETENTION_CLASSES,
        'hard_immutable_tables': sorted(HARD_IMMUTABLE_TABLES),
        'migration_waves': MIGRATION_WAVES,
        'schemas': schemas,
        'data_quality_rule_ids': [r['id'] for r in DQ_RULES],
        'official_references': OFFICIAL_REFERENCES,
    }


def table_summary_rows(schema: str) -> list[str]:
    rows = ['| Table | Responsibility | Pattern | Class | Retention | Gate-1 / Gate-4 | Slice |',
            '|---|---|---|---|---|---:|---|']
    for t in [x for x in TABLES if x.schema == schema]:
        rows.append(
            f"| `{t.fq}` | {md_cell(t.purpose)} | `{t.write_pattern}` | `{t.classification}` | `{t.retention_class}` | "
            f"{md_cell(t.expected_gate1_rows)} / {md_cell(t.expected_gate4_rows)} | `{md_cell(t.implementation_slice)}` |"
        )
    return rows


def render_table_detail(t: Table) -> str:
    out: list[str] = []
    out += [f'### `{t.fq}`', '', t.purpose, '']
    out += [
        f'- **Owner:** `{t.owner_module}`',
        f'- **Write pattern:** `{t.write_pattern}`' + ('; database mutation guard enabled' if t.fq in HARD_IMMUTABLE_TABLES else ''),
        f'- **Classification:** `{t.classification}`',
        f'- **Retention:** `{t.retention_class}` — {RETENTION_CLASSES[t.retention_class]["minimum"]}',
        f'- **Expected rows:** GATE-1 {t.expected_gate1_rows}; GATE-4 {t.expected_gate4_rows}',
        f'- **Partitioning:** {t.partitioning}',
        f'- **Requirement trace:** {", ".join(f"`{x}`" for x in t.requirements) or "—"}',
        f'- **Implementation slice:** `{t.implementation_slice or "—"}`',
        '',
    ]
    if t.notes:
        out += ['**Design notes**', ''] + [f'- {n}' for n in t.notes] + ['']
    out += ['| Column | PostgreSQL type | Null | Default | Class | Description |',
            '|---|---|---:|---|---|---|']
    for col in t.columns:
        out.append(f'| `{col.name}` | `{col.sql_type}` | {"YES" if col.nullable else "NO"} | `{md_cell(col.default)}` | `{col.classification}` | {md_cell(col.desc())} |')
    out += ['', f'**Primary key:** `{", ".join(t.pk)}`' if t.pk else '**Primary key:** none', '']
    if t.uniques:
        out += ['**Unique constraints**', ''] + [f'- `{n}`: (`{", ".join(cols)}`)' for n,cols in t.uniques] + ['']
    if t.fks:
        out += ['**Foreign keys**', '']
        for f in t.fks:
            flags = []
            if f.deferrable: flags.append('DEFERRABLE')
            if f.initially_deferred: flags.append('INITIALLY DEFERRED')
            out.append(f'- (`{", ".join(f.columns)}`) → `{f.ref_schema}.{f.ref_table}` (`{", ".join(f.ref_columns)}`); ON DELETE `{f.on_delete}`' + (f'; {", ".join(flags)}' if flags else ''))
        out.append('')
    if t.checks:
        out += ['**Check constraints**', ''] + [f'- `{pg_identifier(n)}`: `{expr}`' for n,expr in t.checks] + ['']
    if t.indexes:
        out += ['**Indexes**', '']
        for i in t.indexes:
            target = i.expression or ', '.join(i.columns)
            attrs = ['UNIQUE' if i.unique else 'NONUNIQUE', i.method]
            if i.nulls_not_distinct: attrs.append('NULLS NOT DISTINCT')
            if i.include: attrs.append('INCLUDE ' + ','.join(i.include))
            if i.where: attrs.append('WHERE ' + i.where)
            out.append(f'- `{pg_identifier(i.name)}` on (`{target}`) — {"; ".join(attrs)}')
        out.append('')
    return '\n'.join(out)


def render_main_design(metrics: dict[str, Any]) -> str:
    by_schema = {s:[t for t in TABLES if t.schema==s] for s in SCHEMA_ORDER}
    out: list[str] = [
        '# RAOS-DATA-001 データモデル・PostgreSQL設計書',
        '',
        '| 項目 | 内容 |', '|---|---|',
        f'| 文書ID | `RAOS-DATA-001` |', f'| Version | `{VERSION}` |', f'| 作成日 | `{DOC_DATE}` |',
        '| Status | Baseline Candidate / Codex implementation input |',
        '| 上位文書 | `RAOS-REQ-001 v0.1`, `RAOS-ARCH-001 v0.1` |',
        f'| 対象DB | PostgreSQL `{PG_TARGET}` / Amazon RDS for PostgreSQL reference deployment |',
        '| Timezone | DB instantはUTC、事業日付はsite timezone `Asia/Tokyo` |',
        '',
        '> 本書は論理モデル、物理モデル、DDL、保持・監査、権限、移行、品質検査を一つの正本として定義する。法定保存期間・個人情報保持期間はproduction有効化前に日本法・税務・プライバシーの専門確認を行う。',
        '',
        '## 1. Executive decision',
        '',
        'RAOSのデータ層は「記事を保存するDB」ではない。外部の商品事実、根拠、AI処理、人間判断、公開物、匿名計測、楽天側成果、費用、運用監査を、相互に混同せず再現できる意思決定台帳である。',
        '',
        '最重要の設計判断は次のとおり。',
        '',
        '1. **単一PostgreSQL・複数Schema**をMVPの整合性境界とし、モジュール間の直接更新を権限とService boundaryで制限する。',
        '2. **UUIDv7**を内部IDの標準とし、外部Provider IDを主キーにしない。',
        '3. API原本、AI入出力、Source Packet、公開Snapshot、成果原本等の大きな不変PayloadはObject Storageへ置き、DBにはURI・Version・SHA-256・分類・保持Policyを登録する。',
        '4. 外部情報はObservationとして追記し、Current Projectionは再生成可能にする。',
        '5. 推薦順位はAffiliate rate・Commission・Revenue・Profitを読めない構造にする。',
        '6. 公開はHuman approval済みArticle Versionからimmutable Publication Snapshotを生成し、Public Webは`readmodel`だけを読む。',
        '7. Analyticsの観測、Providerの成果事実、直接帰属、推定帰属、未帰属を区別する。経営指標は確定成果報酬を正本とする。',
        '8. Outbox/Inbox、Idempotency、Job leaseをDBモデルへ含め、at-least-once deliveryを前提にする。',
        '9. Kill SwitchはPublicationとAffiliate Linkを分離し、公開DBにも低Latency Projectionを持つ。',
        '10. Partitioningは最初から乱用せず、件数・Maintenance時間・Query planで閾値を満たしたFact tableだけに導入する。',
        '',
        '## 2. Scope and acceptance',
        '',
        '### 2.1 Included',
        '',
        '- 13 PostgreSQL Schemaと全Table/Column/Constraint/Index/FK',
        '- Object Artifact registry、Outbox/Inbox、Job、Audit、Incident、Kill Switch',
        '- Portfolio、楽天Catalog、Evidence、Editorial、AI、Policy、Publishing',
        '- Freshness、Analytics、Finance、Public Read Model',
        '- DB Role/Grant、Reference seed、Post-deploy validation SQL',
        '- Retention matrix、Data quality rules、Migration playbook、ER diagrams',
        '',
        '### 2.2 Excluded from this baseline',
        '',
        '- CMS固有テーブル、WordPress内部Schema',
        '- 楽天レビュー本文・投稿者情報・レビュー転載データ',
        '- Customer account、会員プロフィール、決済、注文処理',
        '- Raw IP address、raw user agent、email等を含む行動ログ',
        '- Dedicated vector database、Kafka、Kubernetes、cross-region active/active',
        '- 検索順位SERPの無許諾スクレイピングデータ',
        '',
        '### 2.3 Quantitative baseline',
        '',
        '| Metric | Count |', '|---|---:|',
        f'| Schemas | {metrics["schemas"]} |', f'| Tables | {metrics["tables"]} |', f'| Columns | {metrics["columns"]} |',
        f'| Foreign keys | {metrics["foreign_keys"]} |', f'| Explicit/generated indexes | {metrics["indexes"]} |',
        f'| Unique constraints | {metrics["unique_constraints"]} |', f'| Check constraints | {metrics["check_constraints"]} |',
        f'| Hard immutable tables | {metrics["hard_immutable_tables"]} |', f'| Data quality rules | {metrics["dq_rules"]} |',
        '',
        'Acceptanceは、YAML構文、参照整合性、FK索引、要求追跡、禁止Column、identifier長、DDL構造、ZIP checksumが全てPASSし、さらに実環境PostgreSQL 18.4でMigration/rollback/restore/permission integration testを通過した時点とする。',
        '',
        '## 3. Context and lineage architecture',
        '',
        '```mermaid',
        'flowchart LR',
        '  R[楽天API・許諾済みSource] --> A[ops.object_artifact]',
        '  A --> C[catalog Observation]',
        '  A --> E[evidence Source Snapshot / Fact]',
        '  C --> P[evidence Source Packet Version]',
        '  E --> P',
        '  P --> J[ai.ai_job / ai.ai_attempt]',
        '  J --> V[editorial.article_version]',
        '  P --> V',
        '  V --> Q[policy.quality_check_run]',
        '  Q --> H[publishing Human Review / Approval]',
        '  H --> S[publishing.publication_snapshot]',
        '  S --> M[readmodel Public Projection]',
        '  M --> X[Public Web]',
        '  X --> N[analytics Anonymous/Click Facts]',
        '  F[楽天成果原本] --> CF[finance Commission Facts]',
        '  N --> AT[Direct / Estimated / Unattributed]',
        '  CF --> AT',
        '  CF --> U[finance Unit Economics]',
        '  AT --> U',
        '```',
        '',
        '各矢印は「参照可能」を意味し、逆方向の権限を意味しない。特にPublic WebからEditorial/Evidence/Financeへ到達するDB Roleは存在しない。',
        '',
        '## 4. PostgreSQL platform baseline',
        '',
        f'- Target major/minor baseline: PostgreSQL `{PG_TARGET}`.',
        '- `uuidv7()`を組み込み関数として使用するため、baseline DDLはserver_version_num 180000未満を拒否する。',
        '- 全identifierは63 byte以下へ決定的に短縮し、末尾にhashを付ける。',
        '- Extension依存はMVP baselineでゼロとする。`pgcrypto`や`uuid-ossp`へID生成を依存させない。',
        '- Transactional DDLを基本とし、`CREATE INDEX CONCURRENTLY`が必要な本番拡張MigrationはTransaction外の別Revisionとする。',
        '- Foreign keyは参照側Indexを自動生成しないため、本設計Generatorが全FKのleft-prefix Indexを検査・追加する。',
        '',
        '## 5. Universal data conventions',
        '',
        '### 5.1 IDs',
        '',
        '- 内部Entity/Fact/Event IDは`uuid DEFAULT uuidv7()`。時系列順は運用上有用だが、IDの時刻を業務時刻の正本にしない。',
        '- 外部IDは`provider_code`等と組み合わせてUniqueにし、変更・再利用・Provider移行へ耐える。',
        '- UI/問い合わせ用には`display_id`を別に持ち、UUIDを一般利用者へ露出しない。',
        '- Polymorphic IDは限定的に使用し、`target_type`等のEnumとService-level validatorを必須にする。',
        '',
        '### 5.2 Time',
        '',
        '- Instantは`timestamp with time zone`。Connection timezoneはUTC。',
        '- 楽天成果や日次KPIの`business_date`/`business_month`はsite timezoneで算出し、日付だけを保存する。',
        '- `created_at`は生成時刻、`occurred_at`は事象時刻、`observed_at`は観測時刻、`received_at`は受信時刻を意味し、代替使用しない。',
        '',
        '### 5.3 Money, rates, unknown values',
        '',
        '- JPY金額は`bigint`で円単位。浮動小数点型を使わない。',
        '- 比率は意味ごとに`numeric(p,s)`を明示する。0、NULL、UNKNOWNを同一視しない。',
        '- Revenueの発生・確定・取消、売上金額・報酬金額、Provider Fact・推定配賦を別Column/Recordで保持する。',
        '',
        '### 5.4 JSONB',
        '',
        '- JSONBは外部Payload、Evidence locator、Versioned setting、Renderer payload等に限定する。',
        '- Core join、状態、金額、時刻、検索・制約対象はtyped columnにする。',
        '- JSONB object/arrayのtop-level typeをCHECKし、Schema versionまたはPrompt/Output schema versionへ紐付ける。',
        '- 秘密、レビュー本文、任意のHTML、個人識別子を「柔軟だから」という理由でJSONBへ逃がさない。',
        '',
        '### 5.5 Null semantics',
        '',
        '- NULLはunknown/not applicableを意味する。0、false、empty stringの代用にしない。',
        '- Nullable business keyの一意性が必要な箇所はPostgreSQLの`NULLS NOT DISTINCT` unique indexを使用する。',
        '',
        '## 6. Schema ownership map',
        '',
        '| Schema | Module | Tables | Purpose |', '|---|---|---:|---|',
    ]
    for s in SCHEMA_ORDER:
        title,purpose=SCHEMA_META[s]
        out.append(f'| `{s}` | {title} | {len(by_schema[s])} | {purpose} |')
    out += ['',
        '## 7. Transaction and consistency boundaries', '',
        '### 7.1 Command transaction', '',
        'Domain Aggregateの変更と`ops.outbox_event`のInsertは同一Transactionでcommitする。外部API、LLM、Object Storage upload、通知はTransaction内で実行しない。大きなArtifactは先にupload・digest検証し、その参照だけを短いDB Transactionへ登録する。', '',
        '### 7.2 Worker idempotency', '',
        '`ops.job.idempotency_key`、`ops.inbox_receipt`、Provider event hash、Artifact SHA-256、Publication request keyを使い、同じMessage/CSV/API responseが再処理されても副作用が一度だけになるようにする。', '',
        '### 7.3 Snapshot transaction', '',
        'Publication Snapshot buildは、対象Article Version、Source Packet、Policy Bundle、Quality Run、Final Approvalを固定し、Object Artifact upload成功後にSnapshot manifestとCandidate状態を同一Transactionで確定する。Public projectionはSnapshot IDを入力に別Jobで再生成する。', '',
        '### 7.4 Finance import transaction', '',
        '成果原本はUpload→scan→parse→dry run→human confirm→canonical import→reconcileの段階を分ける。Provider rowとCommission eventの冪等Keyを先に確定し、推定帰属をCommission本体へ書き戻さない。', '',
        '## 8. Immutability and correction model', '',
        '不変とは「誤りを放置する」ことではない。訂正は旧Recordを変更せず、新Record、supersedes relation、correction event、current projection更新で表現する。Baseline DDLでは特に重要な21 TableにUPDATE/DELETE拒否Triggerを設定する。Retention/法的削除は`raos_migrator`かつ明示的maintenance settingの二条件がなければ実行できない。', '',
        '**不変対象の代表例:**', '',
    ]
    out += [f'- `{x}`' for x in sorted(HARD_IMMUTABLE_TABLES)]
    out += ['',
        '## 9. Security, privacy, and segregation of duties', '',
        '- DB Login roleとGroup roleを分離する。生成SQLはNOLOGIN group roleのみを作る。CredentialはSecrets Manager/OIDC/IAM authentication等の外部Secret boundaryで管理する。',
        '- `raos_public_ro`は`readmodel`のみUSAGE/SELECT。',
        '- `raos_projection_rw`だけがreadmodelを書き換え、Public Webは書き込まない。',
        '- Final approval、Revenue import confirmation、Waiver、Kill Switch、RollbackはCRITICAL permission。',
        '- Audit readerは決定証拠を読めるが業務Recordを更新できない。',
        '- Raw analyticsではIP、raw UA、email、URL query、自由入力Identifierを受けない。PseudonymはSHA-256等の一方向値と短い保持期間を使う。',
        '- IAM emailはRESTRICTED PIIであり、行動・記事・収益分析のjoin keyにしない。',
        '',
        '## 10. Publication database invariants', '',
        'DB Triggerは最終防衛線として以下を検査する。Application serviceは同じ検査を先に実施し、利用者へ理解可能なErrorを返す。', '',
        '1. AI JobのSource Packet Versionは`APPROVED`。',
        '2. Final approval actorはactiveなHuman USER principal。',
        '3. Quality Runは対象Article Versionと一致し`PASSED`、mandatory subscoreを満たす。',
        '4. Open blocking findingは0。',
        '5. Final Approvalは失効・取消されていない。',
        '6. Publication Kill SwitchがGlobal/Site/Category/Articleのいずれにもengagedでない。',
        '7. Publication state=`PUBLISHED`にはCurrent Snapshotが必要。',
        '8. Public Read ModelはCurrent Publication Snapshotからのみ生成する。',
        '',
        '## 11. Catalog and evidence semantics', '',
        '### 11.1 Product identity', '',
        '楽天の商品ListingをそのままCanonical Productとみなさない。`product_candidate`がProvider由来候補、`grouping_decision`がmerge/split判断、`product_group_membership`が有効期間付き関係、`canonical_product`が比較対象となる商品概念、`offer`がショップ単位の販売Listingである。', '',
        '### 11.2 Observations and current projection', '',
        '価格、在庫、レビュー件数/平均、Affiliate URLは取得時点のObservationとして追記する。`offer_current_projection`は最新の受理済みObservationを指すだけで、過去を破壊しない。レビュー本文は保持しない。', '',
        '### 11.3 Facts, claims, and support', '',
        '`source_snapshot`は原本、`fact`は正規化事実、`source_packet_version`は生成時の入力集合、`claim`は記事内主張、`claim_evidence_link`はSUPPORTS/CONTRADICTS/QUALIFIESの関係である。Public claimはSource Packet IDと具体的Fact/Source locatorを辿れることを必須とする。', '',
        '## 12. Analytics and finance truth model', '',
        '| Layer | Authority | Example | May drive North Star directly |', '|---|---|---|---:|',
        '| First-party observation | 自サイトで観測 | page view / affiliate click | No |',
        '| Provider fact | 楽天成果原本 | generated / confirmed / cancelled commission | **Yes, confirmed only** |',
        '| Direct attribution | Providerが提供する直接Key | article/sub-ID等へ直接対応 | Yes, with label |',
        '| Estimated attribution | RAOS model | time-window/statistical allocation | No; separate display |',
        '| Unattributed | 合理的配賦不能 | Site total only | Site total only |',
        '',
        '記事別貢献利益はapproved attributionと配賦済みcostで計算する。推定値をProvider Factとして表示せず、計算Version・Confidence・Signalを保存する。',
        '',
        '## 13. Index strategy', '',
        '- PK/UniqueはPostgreSQLがB-tree indexを作る。FK参照側は自動作成されないため全FKをstatic lintしleft-prefix Indexを生成する。',
        '- Job queue、Outbox、Review queue、Open finding、Active route等はpartial indexを使う。',
        '- High-cardinality Observationは`entity_id, observed_at`順。Date-only分析は日/月列を先頭にした別Indexを必要Queryで追加する。',
        '- JSONB GIN indexはAccess patternが証明されるまで作らない。Payload全体GINはwrite amplificationとindex bloatを招くため禁止を既定とする。',
        '- Covering INCLUDE indexはEXPLAIN/BUFFERSと実測Read pathで決める。',
        '- Index追加はproductionで`CREATE INDEX CONCURRENTLY`、失敗index cleanup、replica lag監視を含む専用Migrationにする。',
        '',
        '## 14. Partition strategy', '',
        'MVPの30〜45記事規模で全TableをPartition化する必要はない。Partition candidateはRaw event、Affiliate click、GSC/GA4 Observation、価格・Link check、Commission event等の時間系列Factである。', '',
        '**導入条件:**', '',
        '- 1 Tableが50 million rows、または100 GB、またはretention deleteが30分超、またはvacuum/index maintenanceがSLOへ影響する。',
        '- Target queryがpartition keyを含み、EXPLAINでpruningが確認できる。',
        '- Global uniqueness/FK制約の制限を受け入れられる。',
        '- 事前にfuture/default partition、late event、detach/archive、partition creation alertを実装する。',
        '',
        'Metadataの`partitioning`は将来方針であり、baseline DDLは通常Tableを作成する。初日からのpartitioning指定があるanonymous/click eventも、Codex実装時に負荷試験と運用能力を確認し、Migration Waveで最終選択する。',
        '',
        '## 15. Retention and deletion', '',
        '保持期間は技術値ではなくPolicy Versionで管理する。`ops.retention_policy`がEffective date、Scope、Action、Hold条件を持ち、JobはDry Run report→Approver→Deletion/Anonymization→Audit Eventの順で実行する。', '',
        '| Retention class | Minimum / maximum | Default action | Legal review |', '|---|---|---|---:|',
    ]
    for key in sorted(RETENTION_CLASSES):
        v=RETENTION_CLASSES[key]
        out.append(f'| `{key}` | {md_cell(v["minimum"])} | {md_cell(v["action"])} | {"YES" if v["legal_review_required"] else "NO"} |')
    out += ['',
        'Retention Jobはopen incident、legal hold、audit request、financial close未完、publication lineage参照、disputeを検査し、一件でも該当すれば削除しない。Object StorageとDB rowの削除順はDB tombstone/plan→object delete→verification→registry finalizationとし、孤児検査を日次実行する。',
        '',
        '## 16. Migration strategy', '',
        '詳細は同梱のMigration Playbookを正本とする。原則はExpand → Backfill → Dual-read/write → Validate → Cutover → Contractであり、Applicationの一つ前のReleaseと後方互換を維持する。Large tableへFK/CHECKを追加する際は可能な場合`NOT VALID`で追加し、別工程で`VALIDATE CONSTRAINT`する。UniqueはCONCURRENTLY indexを作成後、必要ならConstraintへattachする。',
        '',
        '## 17. Test strategy', '',
        '### 17.1 Static model tests', '',
        '- Table/Column/Index/Constraint ID重複、63-byte limit、FK target/type/key、FK supporting index',
        '- 禁止Secret field、楽天Review本文field、Editorial/ReadmodelのAffiliate economics field',
        '- FR-001〜FR-020のTable trace coverage、Retention/Class coverage',
        '- YAML parse、CSV row count、DDL lexical balance、Manifest checksum',
        '',
        '### 17.2 PostgreSQL integration tests', '',
        '- Baseline DDL fresh install、seed rerun、post-deploy validation',
        '- Circular FK transaction、immutable guard、maintenance override',
        '- AI packet approval guard、Final approval guard、Kill Switch guard',
        '- Role privilege positive/negative tests',
        '- Outbox atomicity、Inbox duplicate delivery、Job lease races',
        '- Publication Snapshot exact rollback、readmodel full rebuild',
        '- Revenue duplicate import、Commission state transition、allocation reconciliation',
        '- PITR restore、Object artifact hash restore、quarterly disaster recovery drill',
        '',
        '### 17.3 Performance tests', '',
        '- Public route/article/product/offer read P95/P99 under expected CDN miss load',
        '- Queue claim with competing workers',
        '- Offer current projection refresh',
        '- GSC/GA4 and revenue batch import throughput',
        '- 10x expected GATE-4 data EXPLAIN/BUFFERS and bloat/vacuum behavior',
        '',
        '## 18. Codex implementation sequence', '',
    ]
    for w in MIGRATION_WAVES:
        out += [f'### {w["id"]}: {w["name"]}', '', f'- Schemas: {", ".join(f"`{x}`" for x in w["schemas"])}', f'- Architecture slices: {", ".join(f"`{x}`" for x in w["slices"])}', '- Deliverables: Alembic revision(s), SQLAlchemy models, repository/transaction tests, permission tests, migration README.', '']
    out += [
        'Codexは一度に全130 Tableを実装せず、各WaveをPR分割する。各PRはmigration upgrade/downgrade、model、repository contract、fixture、unit/integration test、generated catalog drift testを含む。DDL正本とORM modelが不一致ならCIを失敗させる。',
        '',
        '## 19. Data quality rules', '',
        f'機械可読正本は`RAOS_03_data_quality_rules_v{VERSION}.yaml`。全{len(DQ_RULES)} RuleをRule IDでMonitoring、Gate、Runbookへ接続する。', '',
        '| ID | Severity | Scope | Enforcement | Assertion |', '|---|---|---|---|---|',
    ]
    for r in DQ_RULES:
        out.append(f'| `{r["id"]}` | `{r["severity"]}` | `{r["scope"]}` | `{r["enforcement"]}` | {md_cell(r["assertion"])} |')
    out += ['',
        '## 20. Open production decisions', '',
        '以下は設計不足ではなく、production contextで確定すべき明示的Decisionである。暫定値をCodeへ埋め込まない。', '',
        '1. RDS instance class、Multi-AZ、storage type/IOPS、backup window、PITR retention。',
        '2. IAM DB authenticationかrotating passwordか、connection poolerの採否。',
        '3. Anonymous analyticsの同意要件、Salt rotation、最大保持日数。',
        '4. Finance/Tax recordの最終法定保持期間とlegal hold process。',
        '5. GSC query textを保存するか、hash/aggregateだけにするか。',
        '6. GATE-4でのPartitioning閾値とArchive storage class。',
        '7. Public rendererでHTMLを保存するかcomponent JSONのみとするか。Baselineはsanitize済みHTMLとallowlist JSONの両方を許容する。',
        '8. Product同定のhuman review thresholdと誤merge correction SLO。',
        '9. Direct attribution用の楽天側提供field/sub-IDの最終可用性。',
        '10. RLSの導入。MVPはSchema/Role/Service authorizationを主境界とし、複数Tenant化時に再評価する。',
        '',
        '## 21. Schema and table specification', '',
        '以下がTable/Columnレベルの物理正本である。SQL DDLとYAML Catalogはこの定義から生成する。', '',
    ]
    for s in SCHEMA_ORDER:
        title,purpose=SCHEMA_META[s]
        out += [f'## 21.{SCHEMA_ORDER.index(s)+1} `{s}` — {title}', '', purpose, '', *table_summary_rows(s), '']
        for t in by_schema[s]:
            out.append(render_table_detail(t))
    out += [
        '## 22. Requirement traceability', '',
        'Table metadataの`requirements`が要件正本とのtraceを持つ。FR-001〜FR-020は全て1 Table以上へ割り当てられている。詳細CSVを同梱する。', '',
        '| Requirement | Tables |', '|---|---|',
    ]
    req_map: dict[str,list[str]] = {}
    for t in TABLES:
        for r in t.requirements:
            req_map.setdefault(r,[]).append(t.fq)
    for r in sorted(req_map):
        out.append(f'| `{r}` | {", ".join(f"`{x}`" for x in req_map[r])} |')
    out += ['',
        '## 23. Official technical references', '',
    ]
    for ref in OFFICIAL_REFERENCES:
        out.append(f'- **{ref["id"]}: {ref["title"]}** — {ref["url"]} — {ref["use"]}')
    out += ['',
        '## 24. Definition of done', '',
        '- [ ] PostgreSQL 18.4 ephemeral/RDS-compatible environmentでbaseline DDLが成功する。',
        '- [ ] 130 Table、全FK、Index、Trigger、View、Role、Seedが期待数と一致する。',
        '- [ ] Public role negative privilege testが成功する。',
        '- [ ] AI、Final approval、Publication、Kill SwitchのDB guard integration testが成功する。',
        '- [ ] Object Artifact digest、Publication rollback、Revenue import、Outbox/Inboxのend-to-end testが成功する。',
        '- [ ] Restore drillでRPO/RTOとReadmodel rebuildを実証する。',
        '- [ ] Retention Policyは法務・税務・Privacy review完了までdelete-disabledである。',
        '- [ ] Generated catalog/DDL/checksumとGit commitがRelease manifestへ登録される。',
        '',
    ]
    return '\n'.join(out)


def entity_name(t: Table) -> str:
    return (t.schema + '_' + t.name).upper()


def render_er_diagrams() -> str:
    out = ['# RAOS-DATA-001 ER図集', '', f'Version `{VERSION}` / `{DOC_DATE}`', '',
           '図は関係理解用であり、Cardinality・Column・制約の正本はData Catalog/DDLである。', '',
           '## 1. Schema dependency overview', '', '```mermaid', 'flowchart LR']
    edges: set[tuple[str,str]] = set()
    for t in TABLES:
        for f in t.fks:
            if t.schema != f.ref_schema:
                edges.add((t.schema,f.ref_schema))
    for s in SCHEMA_ORDER:
        out.append(f'  {s.upper()}["{s}<br/>{SCHEMA_META[s][0]}"]')
    for src,dst in sorted(edges):
        out.append(f'  {src.upper()} --> {dst.upper()}')
    out += ['```', '']
    for no,schema in enumerate(SCHEMA_ORDER, start=2):
        tables=[t for t in TABLES if t.schema==schema]
        out += [f'## {no}. `{schema}` ER', '', '```mermaid', 'erDiagram']
        related=set()
        rels=[]
        for t in TABLES:
            for f in t.fks:
                if t.schema==schema or f.ref_schema==schema:
                    # Keep internal edges and immediate cross-schema dependencies.
                    src=entity_name(t); rt=table_map()[f'{f.ref_schema}.{f.ref_table}']; dst=entity_name(rt)
                    label='_'.join(f.columns)[:40]
                    rels.append((dst,src,label))
                    related.add(t.fq); related.add(rt.fq)
        # Define owned entities, including isolated tables.
        for t in tables:
            out.append(f'  {entity_name(t)} {{')
            for pk in t.pk[:3]:
                col=next(c0 for c0 in t.columns if c0.name==pk)
                out.append(f'    {col.sql_type.replace(" ","_").replace("(","_").replace(")","")} {pk} PK')
            out.append('  }')
        for dst,src,label in sorted(set(rels)):
            out.append(f'  {dst} ||--o{{ {src} : "{label}"')
        out += ['```', '']
    out += ['## 15. Publication lineage sequence', '', '```mermaid', 'sequenceDiagram',
            '  participant U as Human Reviewer', '  participant API as Core API', '  participant DB as PostgreSQL', '  participant W as Worker', '  participant OS as Object Storage', '  participant WEB as Public Web',
            '  U->>API: Final approval command', '  API->>DB: INSERT publishing.approval', '  DB-->>API: quality/source/human guard',
            '  U->>API: Publish command + idempotency key', '  API->>DB: INSERT publication_candidate + outbox',
            '  W->>DB: Claim snapshot build job', '  W->>DB: Read fixed article/evidence/policy/approval IDs', '  W->>OS: Write immutable snapshot artifact',
            '  W->>DB: Register artifact + snapshot + publication event', '  W->>DB: Rebuild readmodel in transaction', '  WEB->>DB: SELECT readmodel only',
            '```', '']
    return '\n'.join(out)


def render_migration_playbook() -> str:
    out = [
        '# RAOS-DATA-001 Migration Playbook', '', f'Version `{VERSION}` / `{DOC_DATE}`', '',
        '## 1. Purpose', '',
        'Codexおよび人間開発者が、PostgreSQL変更を安全・可逆・監査可能に実施するための手順を定義する。Baseline SQLは参照正本であり、実装RepositoryではAlembic revisionへWave単位で分割する。', '',
        '## 2. Non-negotiable rules', '',
        '1. Production DBへ手動DDLを直接投入しない。緊急変更もincident IDとfollow-up migrationを必須にする。',
        '2. Migration PRはApplicationの旧版・新版の両方と互換なExpand stateから開始する。',
        '3. Destructive changeはBackfill、Read cutover、観測期間、Contract approval後にのみ実施する。',
        '4. Table rewrite、長時間AccessExclusive lock、replica lag、WAL爆発の可能性を事前評価する。',
        '5. `lock_timeout`を短く設定し、待ち続けるMigrationではなく安全に失敗するMigrationにする。',
        '6. Migration実行中に外部API、LLM、Object Storage処理を呼ばない。',
        '7. DDL、data migration、projection rebuildを必要に応じて別Revision/Jobへ分離する。',
        '',
        '## 3. Revision naming', '',
        '`YYYYMMDDHHMM_<wave>_<imperative_description>.py`。例: `202608010900_mig003_create_catalog_observations.py`。Revision metadataへRequirement IDs、Architecture slice、risk class、estimated lock、backfill job、rollback categoryを記載する。',
        '',
        '## 4. Change classes', '',
        '| Class | Example | Default procedure | Rollback |', '|---|---|---|---|',
        '| A — additive | nullable column, new table, new nonunique index | expand | schema downgrade usually allowed |',
        '| B — validated additive | NOT NULL, FK, CHECK, unique | add unvalidated/index, backfill, validate | remove new constraint after app rollback |',
        '| C — semantic | enum/status meaning, calculation version | dual support and versioned data | forward correction preferred |',
        '| D — destructive | drop/rename/type rewrite | expand/migrate/contract across releases | restore/forward fix; no instant downgrade assumption |',
        '| E — privacy/retention | delete/anonymize | dry run + approval + legal hold check | generally irreversible; backup/hold required |',
        '',
        '## 5. Expand–migrate–contract', '',
        '### 5.1 Add a required column to a large table', '',
        '1. Add nullable column without volatile default.',
        '2. Deploy application dual-write with telemetry.',
        '3. Backfill in bounded primary-key/time windows with pause/resume checkpoint.',
        '4. Verify zero NULL and semantic reconciliation.',
        '5. Add CHECK `column IS NOT NULL` as `NOT VALID` when appropriate; validate separately.',
        '6. Convert to `SET NOT NULL` using the validated proof where supported.',
        '7. Remove old write path only after one full release observation window.',
        '',
        '### 5.2 Add a foreign key', '',
        '1. Create the referencing index, `CONCURRENTLY` in production if table is large.',
        '2. Detect/repair orphan rows.',
        '3. `ALTER TABLE ... ADD CONSTRAINT ... FOREIGN KEY ... NOT VALID`.',
        '4. `VALIDATE CONSTRAINT` in a controlled window.',
        '5. Add permission/integration tests and update generated catalog.',
        '',
        '### 5.3 Add uniqueness', '',
        '1. Query and remediate duplicates with an auditable plan.',
        '2. Create unique index concurrently.',
        '3. Attach as a constraint using the existing index where a named constraint is required.',
        '4. Never add a large blocking UNIQUE constraint without a lock/replica impact rehearsal.',
        '',
        '### 5.4 Rename or split a column', '',
        'Add new column → dual-write → backfill → compare → read-new fallback-old → read-new only → stop old write → contract later. Direct rename is limited to private, single-release, demonstrably unused columns.',
        '',
        '### 5.5 Change data type', '',
        'Avoid in-place rewrite on large tables. Add new typed column, batch convert with error quarantine, dual-write, validate, cut over, then drop old in a later release.',
        '',
        '### 5.6 Introduce partitioning', '',
        'Create partitioned successor, copy by closed time ranges, dual-write or logical replication, reconcile count/hash, cut over through view/name swap in controlled downtime, retain old table read-only until acceptance. Prove partition pruning and FK/unique behavior first.',
        '',
        '## 6. Migration waves', '',
    ]
    for w in MIGRATION_WAVES:
        out += [f'### {w["id"]} — {w["name"]}', '', f'- Schemas: {", ".join(w["schemas"])}', f'- Depends on previous wave: {"yes" if w["id"] != "MIG-001" else "no"}', f'- Architecture slices: {", ".join(w["slices"])}', '- Exit: upgrade/downgrade test, generated catalog drift=0, permission tests, representative fixtures, post-deploy SQL pass.', '']
    out += [
        '## 7. Production execution checklist', '',
        '### Before', '',
        '- Approved PR, release/incident ID, owner, observer, rollback decision point.',
        '- Fresh backup/PITR confirmed; restore procedure and object artifact availability checked.',
        '- `pg_stat_activity`, long transactions, replica lag, table/index size, bloat, lock graph captured.',
        '- Query and job load window selected; autoscaling/connection pool limits reviewed.',
        '- Estimated rows, WAL, runtime, lock type, statement/lock timeout documented.',
        '',
        '### During', '',
        '- Run with dedicated migrator identity and captured stdout/stderr.',
        '- Monitor locks, blocked sessions, replica lag, CPU, storage, IOPS, WAL, error rate.',
        '- Abort at predefined threshold; do not improvise destructive remediation.',
        '- Batch backfill uses idempotent checkpoints and commits small windows.',
        '',
        '### After', '',
        '- Run `RAOS_03_004_post_deploy_validation_v0.1.sql`.',
        '- Compare schema digest, row counts, DQ rules, business reconciliation, query plans.',
        '- Deploy/read both versions as planned; observe at least one normal workload cycle.',
        '- Record release and migration revision in `ops.release`; attach validation artifact.',
        '',
        '## 8. Rollback philosophy', '',
        '- Additive schema rollback is allowed only if no newer writer depends on it.',
        '- Data corrections and append-only events use compensating forward records rather than history deletion.',
        '- Published content rollback switches immutable Snapshot pointer; it never edits the previous Snapshot.',
        '- Finance import rollback marks/reverses canonical events with correction lineage; source artifact remains.',
        '- Irreversible privacy deletion requires restore escrow/hold decision before execution, not after.',
        '',
        '## 9. Codex acceptance prompt fragment', '',
        '```text',
        'Implement only the assigned MIG wave. Read RAOS-REQ-001, RAOS-ARCH-001, RAOS-DATA-001, the YAML catalog, and migration playbook first.',
        'Do not change table semantics or weaken constraints to make tests pass. Do not add secrets, review bodies, affiliate-rate fields to editorial/readmodel, or public access to internal schemas.',
        'Produce Alembic upgrade/downgrade, SQLAlchemy models, unit/integration/permission tests, fixture factories, generated-catalog drift test, and a migration risk note.',
        'Run fresh-install, upgrade-from-previous, downgrade where supported, duplicate-delivery, concurrency, and post-deploy validation tests. Stop after one PR-sized wave.',
        '```',
        '',
        '## 10. Required production rehearsal', '',
        'Baseline package was statically generated and validated in this environment; a live PostgreSQL server was not available here. Before merge, CI must execute all SQL against PostgreSQL 18.4, and before production, the same migration must be rehearsed on a recent production-size snapshot with masked/restricted data handling.',
        '',
    ]
    return '\n'.join(out)


def render_readme(metrics: dict[str, Any]) -> str:
    return f'''# RAOS-DATA-001 v{VERSION}

このPackageは、RAOSの要件定義・システムアーキテクチャをPostgreSQLの実装正本へ変換したものです。

## Codexの読み順

1. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
2. `upstream/RAOS_01_requirements_catalog_v0.1.yaml`
3. `upstream/RAOS_02_system_architecture_v0.1.md`
4. `upstream/RAOS_02_architecture_catalog_v0.1.yaml`
5. `RAOS_03_data_model_database_design_v0.1.md`
6. `RAOS_03_data_catalog_v0.1.yaml`
7. `RAOS_03_migration_playbook_v0.1.md`
8. 対象Migration WaveのSQL/DDLとDQ rules

## Contents

- `{metrics['schemas']}` schemas / `{metrics['tables']}` tables / `{metrics['columns']}` columns
- `{metrics['foreign_keys']}` foreign keys / `{metrics['indexes']}` indexes
- `{metrics['check_constraints']}` check constraints / `{len(DQ_RULES)}` data-quality rules
- PostgreSQL `{PG_TARGET}` baseline DDL
- DB roles and grants, deterministic RBAC seed, post-deploy validation
- ER diagrams, retention matrix, table inventory, requirement traceability
- Validation report, manifest, SHA-256 checksums

## Prohibited implementation shortcuts

- Do not store Rakuten review body or reviewer information.
- Do not place affiliate rate, commission, revenue, profit, or margin into editorial or public read models.
- Do not let AI approve or publish.
- Do not let the public renderer read internal schemas.
- Do not replace immutable publication snapshots with live joins.
- Do not treat estimated attribution as provider fact.
- Do not weaken DB constraints merely to satisfy ORM fixtures.
- Do not enable destructive retention jobs before legal/tax/privacy approval.

## Start point

Codexは`MIG-001`から一つのPR単位で実装します。全Waveの一括実装は禁止です。各PRでDDL、ORM、migration、tests、permission checks、catalog drift checkを揃えます。

## Validation limitation

このPackageでは静的モデル検査、DDL構造検査、YAML/CSV/ZIP/checksum検査を実施しています。実PostgreSQL 18.4への実行は、Codex実装CIの必須Acceptanceとして残しています。
'''


def strip_sql_for_balance(sql: str) -> str:
    out=[]; i=0; n=len(sql); state='normal'; dollar=''
    while i<n:
        if state=='normal':
            if sql.startswith('--',i): state='line'; i+=2; continue
            if sql.startswith('/*',i): state='block'; i+=2; continue
            if sql[i]=="'": state='single'; i+=1; continue
            m=re.match(r'\$[A-Za-z_0-9]*\$',sql[i:])
            if m: dollar=m.group(0); state='dollar'; i+=len(dollar); continue
            out.append(sql[i]); i+=1
        elif state=='line':
            if sql[i]=='\n': out.append('\n'); state='normal'
            i+=1
        elif state=='block':
            if sql.startswith('*/',i): state='normal'; i+=2
            else: i+=1
        elif state=='single':
            if sql[i]=="'":
                if i+1<n and sql[i+1]=="'": i+=2
                else: state='normal'; i+=1
            else: i+=1
        elif state=='dollar':
            if sql.startswith(dollar,i): state='normal'; i+=len(dollar)
            else: i+=1
    if state not in {'normal','line'}:
        raise ValueError(f'unclosed SQL lexical state: {state}')
    return ''.join(out)


def static_sql_checks(sql: str) -> dict[str, Any]:
    stripped=strip_sql_for_balance(sql)
    depth=0; min_depth=0
    for ch in stripped:
        if ch=='(': depth+=1
        elif ch==')': depth-=1; min_depth=min(min_depth,depth)
    return {
        'balanced_parentheses': depth==0 and min_depth>=0,
        'parenthesis_final_depth': depth,
        'create_table_count': len(re.findall(r'\bCREATE\s+TABLE\b',stripped,re.I)),
        'foreign_key_count': len(re.findall(r'\bFOREIGN\s+KEY\b',stripped,re.I)),
        'create_index_count': len(re.findall(r'\bCREATE\s+(?:UNIQUE\s+)?INDEX\b',stripped,re.I)),
        'trigger_count': len(re.findall(r'\bCREATE\s+TRIGGER\b',stripped,re.I)),
        'view_count': len(re.findall(r'\bCREATE\s+OR\s+REPLACE\s+VIEW\b',stripped,re.I)),
        'transaction_begin': bool(re.search(r'\bBEGIN\s*;',stripped,re.I)),
        'transaction_commit': bool(re.search(r'\bCOMMIT\s*;',stripped,re.I)),
    }


def render_validation_report(errors: list[str], warnings: list[str], metrics: dict[str, Any], sql_checks: dict[str, Any], file_stats: dict[str, Any]) -> str:
    status='PASS' if not errors and all([
        sql_checks['balanced_parentheses'], sql_checks['create_table_count']==metrics['tables'],
        sql_checks['foreign_key_count']==metrics['foreign_keys'], sql_checks['create_index_count']==metrics['indexes'],
        sql_checks['transaction_begin'],sql_checks['transaction_commit']]) else 'FAIL'
    out=['# RAOS-DATA-001 Validation Report','',f'- Date: `{DOC_DATE}`',f'- Static package validation: **{status}**','',
         '## Model metrics','', '| Metric | Value |','|---|---:|']
    for k,v in metrics.items():
        if isinstance(v,(int,float,str)): out.append(f'| `{k}` | {v} |')
    out += ['', '## Static validations', '', '| Check | Result | Detail |','|---|---|---|']
    checks=[
        ('Python generator syntax','PASS','`python -m py_compile`'),
        ('Duplicate table/column/index/constraint','PASS' if not any('duplicate' in e for e in errors) else 'FAIL','deterministic model lint'),
        ('FK target/key/type','PASS' if not any('FK ' in e for e in errors) else 'FAIL',f'{metrics["foreign_keys"]} relationships'),
        ('FK supporting index','PASS' if not any('supporting index' in e for e in errors) else 'FAIL',f'{metrics["indexes"]} indexes after generation'),
        ('FR-001..FR-020 trace','PASS' if len(metrics['functional_requirements_covered'])==20 else 'FAIL',', '.join(metrics['functional_requirements_covered'])),
        ('Secret/review/economics schema lint','PASS' if not any(x in e for e in errors for x in ['secret','review body','independence']) else 'FAIL','forbidden column patterns'),
        ('DDL parentheses','PASS' if sql_checks['balanced_parentheses'] else 'FAIL',str(sql_checks['parenthesis_final_depth'])),
        ('DDL CREATE TABLE count','PASS' if sql_checks['create_table_count']==metrics['tables'] else 'FAIL',str(sql_checks['create_table_count'])),
        ('DDL FOREIGN KEY count','PASS' if sql_checks['foreign_key_count']==metrics['foreign_keys'] else 'FAIL',str(sql_checks['foreign_key_count'])),
        ('DDL CREATE INDEX count','PASS' if sql_checks['create_index_count']==metrics['indexes'] else 'FAIL',str(sql_checks['create_index_count'])),
        ('YAML round trip','PASS',str(file_stats.get('yaml_files',0))+' files'),
        ('CSV parse/count','PASS',str(file_stats.get('csv_files',0))+' files'),
        ('ZIP integrity','PASS' if file_stats.get('zip_test') else 'FAIL',str(file_stats.get('zip_entries',0))+' entries'),
        ('SHA-256 manifest','PASS' if file_stats.get('checksums_match') else 'FAIL',str(file_stats.get('checksum_files',0))+' files'),
    ]
    out += [f'| {a} | **{b}** | {md_cell(c)} |' for a,b,c in checks]
    out += ['', '## Errors', '']
    out += [f'- {e}' for e in errors] if errors else ['- None.']
    out += ['', '## Warnings / required production follow-up', ''] + [f'- {w}' for w in warnings]
    out += ['',
        '## Explicit limitation', '',
        'この実行環境にはPostgreSQL server/psqlが存在しないため、生成DDLを実DBへ適用するparser/execution testは実施していない。静的構造検査だけを「実DB検証済み」と解釈してはならない。Codex実装CIでPostgreSQL 18.4 containerまたはRDS-compatible test instanceに対し、fresh install、upgrade、permission、trigger、concurrency、restore testを実行することがRelease条件である。',
        '',
        '## Recommended CI commands', '',
        '```bash',
        'python -m pytest tests/data_model tests/migrations tests/permissions',
        'alembic upgrade head',
        'psql "$TEST_DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/RAOS_03_004_post_deploy_validation_v0.1.sql',
        'alembic downgrade <previous_revision>  # only revisions classified as reversible',
        '```',
        '',
    ]
    return '\n'.join(out)


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + '\n', encoding='utf-8')


def write_csv_file(path: Path, headers: list[str], rows: Iterable[Iterable[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.writer(f)
        w.writerow(headers)
        for row in rows:
            w.writerow(list(row))


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def build_package() -> dict[str, Any]:
    import shutil
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    sql_dir=OUT/'sql'; upstream_dir=OUT/'upstream'; tools_dir=OUT/'tools'
    sql_dir.mkdir(); upstream_dir.mkdir(); tools_dir.mkdir()

    errors,warnings,metrics=validate_model()
    if errors:
        raise RuntimeError('\n'.join(errors))

    baseline=render_baseline_sql()
    sql_checks=static_sql_checks(baseline)
    if not sql_checks['balanced_parentheses']:
        raise RuntimeError('generated SQL has unbalanced parentheses')
    if sql_checks['create_table_count'] != metrics['tables']:
        raise RuntimeError(f'CREATE TABLE count mismatch: {sql_checks}')
    if sql_checks['foreign_key_count'] != metrics['foreign_keys']:
        raise RuntimeError(f'FK count mismatch: {sql_checks}')
    if sql_checks['create_index_count'] != metrics['indexes']:
        raise RuntimeError(f'index count mismatch: {sql_checks}')

    main_name=f'RAOS_03_data_model_database_design_v{VERSION}.md'
    catalog_name=f'RAOS_03_data_catalog_v{VERSION}.yaml'
    er_name=f'RAOS_03_ER_diagrams_v{VERSION}.md'
    migration_name=f'RAOS_03_migration_playbook_v{VERSION}.md'
    dq_name=f'RAOS_03_data_quality_rules_v{VERSION}.yaml'
    retention_name=f'RAOS_03_retention_matrix_v{VERSION}.csv'
    inventory_name=f'RAOS_03_table_inventory_v{VERSION}.csv'
    trace_name=f'RAOS_03_traceability_matrix_v{VERSION}.csv'
    validation_name=f'RAOS_03_validation_report_v{VERSION}.md'
    readme_name=f'RAOS_03_README_v{VERSION}.md'
    manifest_name=f'RAOS_03_manifest_v{VERSION}.json'
    checksums_name='SHA256SUMS.txt'

    write_text(OUT/main_name, render_main_design(metrics))
    with (OUT/catalog_name).open('w',encoding='utf-8') as f:
        yaml.safe_dump(render_data_catalog(),f,allow_unicode=True,sort_keys=False,width=140)
    write_text(OUT/er_name, render_er_diagrams())
    write_text(OUT/migration_name, render_migration_playbook())
    with (OUT/dq_name).open('w',encoding='utf-8') as f:
        yaml.safe_dump({
            'document':{'id':'RAOS-DQ-001','version':VERSION,'date':DOC_DATE,'status':'BASELINE_CANDIDATE'},
            'severity_order':['INFO','LOW','MEDIUM','HIGH','CRITICAL'],
            'release_policy':{'critical_open_allowed':0,'high_open_allowed_at_gate_1':0,'warning':'Waiver does not change source data and zero-tolerance rules cannot be waived.'},
            'rules':DQ_RULES,
        },f,allow_unicode=True,sort_keys=False,width=140)

    table_rows=[]
    for t in TABLES:
        table_rows.append([
            t.schema,t.name,t.fq,t.purpose,t.owner_module,t.write_pattern,t.classification,t.retention_class,
            ','.join(t.pk),len(t.columns),len(t.fks),len(t.uniques),len(t.checks),len(t.indexes),
            t.expected_gate1_rows,t.expected_gate4_rows,t.partitioning,','.join(t.requirements),t.implementation_slice,
            'YES' if t.fq in HARD_IMMUTABLE_TABLES else 'NO'
        ])
    write_csv_file(OUT/inventory_name,
        ['schema','table','fully_qualified_name','purpose','owner_module','write_pattern','classification','retention_class','primary_key','column_count','foreign_key_count','unique_count','check_count','index_count','gate1_rows','gate4_rows','partitioning','requirements','implementation_slice','hard_immutable'],
        table_rows)

    retention_rows=[]
    for rc,v in sorted(RETENTION_CLASSES.items()):
        affected=sorted(t.fq for t in TABLES if t.retention_class==rc)
        retention_rows.append([rc,v['minimum'],v['action'],'YES' if v['legal_review_required'] else 'NO',v['description'],len(affected),';'.join(affected)])
    write_csv_file(OUT/retention_name,['retention_class','minimum_or_maximum','default_action','legal_review_required','description','table_count','tables'],retention_rows)

    trace_rows=[]
    req_map:dict[str,list[str]]={}
    for t in TABLES:
        for r in t.requirements:
            req_map.setdefault(r,[]).append(t.fq)
            trace_rows.append([r,t.fq,t.implementation_slice,t.owner_module,t.purpose])
    write_csv_file(OUT/trace_name,['requirement_id','table','implementation_slice','owner_module','coverage_reason'],sorted(trace_rows))

    write_text(OUT/readme_name,render_readme(metrics))
    write_text(sql_dir/f'RAOS_03_001_baseline_v{VERSION}.sql',baseline)
    write_text(sql_dir/f'RAOS_03_002_roles_and_grants_v{VERSION}.sql',render_roles_sql())
    write_text(sql_dir/f'RAOS_03_003_reference_seed_v{VERSION}.sql',render_seed_sql())
    write_text(sql_dir/f'RAOS_03_004_post_deploy_validation_v{VERSION}.sql',render_post_deploy_validation_sql())
    write_text(sql_dir/f'RAOS_03_005_dev_reset_v{VERSION}.sql',f'''-- DEVELOPMENT/EPHEMERAL ENVIRONMENTS ONLY. Never grant this to application roles.
DO $$
BEGIN
  IF current_setting('raos.allow_destructive_reset', true) IS DISTINCT FROM 'on' THEN
    RAISE EXCEPTION 'set raos.allow_destructive_reset=on explicitly in an ephemeral database';
  END IF;
  IF current_database() !~ '(dev|test|ci|ephemeral)' THEN
    RAISE EXCEPTION 'database name does not look ephemeral: %', current_database();
  END IF;
END $$;

{chr(10).join(f'DROP SCHEMA IF EXISTS {s} CASCADE;' for s in reversed(SCHEMA_ORDER))}
''')

    upstream_files=[
        'RAOS_01_requirements_purpose_success_v0.1.md','RAOS_01_requirements_catalog_v0.1.yaml',
        'RAOS_02_system_architecture_v0.1.md','RAOS_02_architecture_catalog_v0.1.yaml',
        'RAOS_02_architecture_diagrams_v0.1.md','RAOS_02_README_v0.1.md',
    ]
    for name in upstream_files:
        src=BASE/name
        if not src.exists():
            raise FileNotFoundError(src)
        shutil.copy2(src,upstream_dir/name)
    shutil.copy2(Path(__file__),tools_dir/'raos_data_build.py')

    # Parse generated machine-readable files and CSVs before packaging.
    yaml_files=[OUT/catalog_name,OUT/dq_name,upstream_dir/'RAOS_01_requirements_catalog_v0.1.yaml',upstream_dir/'RAOS_02_architecture_catalog_v0.1.yaml']
    for p in yaml_files:
        yaml.safe_load(p.read_text(encoding='utf-8'))
    csv_files=[OUT/inventory_name,OUT/retention_name,OUT/trace_name]
    for p in csv_files:
        with p.open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.reader(f))
            if len(rows)<2: raise RuntimeError(f'empty CSV: {p}')

    # Preliminary validation report; final ZIP/checksum facts are filled as expected and then verified.
    file_stats={'yaml_files':len(yaml_files),'csv_files':len(csv_files),'zip_test':True,'zip_entries':0,'checksums_match':True,'checksum_files':0}
    write_text(OUT/validation_name,render_validation_report(errors,warnings,metrics,sql_checks,file_stats))

    def write_manifest_and_checksums() -> tuple[dict[str,Any],list[Path]]:
        files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in {manifest_name,checksums_name})
        manifest={
            'document_id':'RAOS-DATA-001','version':VERSION,'date':DOC_DATE,'target_postgresql':PG_TARGET,
            'metrics':metrics,'sql_static_checks':sql_checks,'warnings':warnings,
            'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha256_file(p)} for p in files],
        }
        (OUT/manifest_name).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        files2=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!=checksums_name)
        checksum_lines=[f'{sha256_file(p)}  {p.relative_to(OUT)}' for p in files2]
        write_text(OUT/checksums_name,'\n'.join(checksum_lines))
        return manifest,files2

    manifest,checksum_files=write_manifest_and_checksums()

    zip_path=BASE/f'RAOS_03_data_model_package_v{VERSION}.zip'
    def create_zip() -> int:
        if zip_path.exists(): zip_path.unlink()
        root=f'RAOS_03_data_model_package_v{VERSION}'
        with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in sorted(OUT.rglob('*')):
                if p.is_file():
                    z.write(p,Path(root)/p.relative_to(OUT))
        with zipfile.ZipFile(zip_path,'r') as z:
            bad=z.testzip()
            if bad: raise RuntimeError(f'bad zip entry: {bad}')
            return len(z.infolist())

    zip_entries=create_zip()

    # Verify checksum file against the final directory state.
    checksum_ok=True; checksum_count=0
    for line in (OUT/checksums_name).read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        expected,rel=line.split('  ',1); checksum_count+=1
        if sha256_file(OUT/rel)!=expected:
            checksum_ok=False; break
    if not checksum_ok:
        raise RuntimeError('checksum verification failed')

    # Rewrite validation with actual package facts, then refresh manifest/checksums/ZIP and verify again.
    file_stats.update({'zip_entries':zip_entries,'checksum_files':checksum_count,'checksums_match':checksum_ok,'zip_test':True})
    write_text(OUT/validation_name,render_validation_report(errors,warnings,metrics,sql_checks,file_stats))
    manifest,checksum_files=write_manifest_and_checksums()
    zip_entries=create_zip()
    with zipfile.ZipFile(zip_path,'r') as z:
        if z.testzip() is not None: raise RuntimeError('final zip integrity failed')
    for line in (OUT/checksums_name).read_text(encoding='utf-8').splitlines():
        if line.strip():
            expected,rel=line.split('  ',1)
            if sha256_file(OUT/rel)!=expected: raise RuntimeError(f'final checksum mismatch: {rel}')

    # Copy main individual deliverables to /mnt/data for direct download links.
    direct_files=[main_name,catalog_name,er_name,migration_name,dq_name,retention_name,inventory_name,trace_name,validation_name,readme_name,manifest_name,checksums_name]
    direct_files += [str(p.relative_to(OUT)) for p in sorted(sql_dir.glob('*'))]
    direct_paths=[]
    for rel in direct_files:
        src=OUT/rel
        dst=BASE/Path(rel).name
        shutil.copy2(src,dst)
        direct_paths.append(dst)

    return {
        'out_dir':str(OUT),'zip_path':str(zip_path),'zip_entries':zip_entries,
        'metrics':metrics,'sql_checks':sql_checks,'warnings':warnings,
        'direct_paths':[str(x) for x in direct_paths],
        'main_lines':len((OUT/main_name).read_text(encoding='utf-8').splitlines()),
        'main_chars':len((OUT/main_name).read_text(encoding='utf-8')),
        'catalog_bytes':(OUT/catalog_name).stat().st_size,
        'baseline_lines':len((sql_dir/f'RAOS_03_001_baseline_v{VERSION}.sql').read_text(encoding='utf-8').splitlines()),
        'baseline_bytes':(sql_dir/f'RAOS_03_001_baseline_v{VERSION}.sql').stat().st_size,
        'package_bytes':zip_path.stat().st_size,
    }


if __name__ == '__main__':
    result=build_package()
    print(json.dumps(result,ensure_ascii=False,indent=2))
