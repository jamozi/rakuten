# RAOS-DATA-001 Validation Report

- Date: `2026-07-30`
- Static package validation: **PASS**

## Model metrics

| Metric | Value |
|---|---:|
| `schemas` | 13 |
| `tables` | 130 |
| `columns` | 1772 |
| `foreign_keys` | 357 |
| `indexes` | 406 |
| `unique_constraints` | 135 |
| `check_constraints` | 549 |
| `hard_immutable_tables` | 21 |
| `dq_rules` | 55 |

## Static validations

| Check | Result | Detail |
|---|---|---|
| Python generator syntax | **PASS** | `python -m py_compile` |
| Duplicate table/column/index/constraint | **PASS** | deterministic model lint |
| FK target/key/type | **PASS** | 357 relationships |
| FK supporting index | **PASS** | 406 indexes after generation |
| FR-001..FR-020 trace | **PASS** | FR-001, FR-002, FR-003, FR-004, FR-005, FR-006, FR-007, FR-008, FR-009, FR-010, FR-011, FR-012, FR-013, FR-014, FR-015, FR-016, FR-017, FR-018, FR-019, FR-020 |
| Secret/review/economics schema lint | **PASS** | forbidden column patterns |
| DDL parentheses | **PASS** | 0 |
| DDL CREATE TABLE count | **PASS** | 130 |
| DDL FOREIGN KEY count | **PASS** | 357 |
| DDL CREATE INDEX count | **PASS** | 406 |
| YAML round trip | **PASS** | 4 files |
| CSV parse/count | **PASS** | 3 files |
| ZIP integrity | **PASS** | 24 entries |
| SHA-256 manifest | **PASS** | 23 files |

## Errors

- None.

## Warnings / required production follow-up

- 18 polymorphic/generic identifier columns require service-level type validation.
- Retention periods marked provisional require Japanese legal/tax/privacy counsel confirmation before production deletion jobs are enabled.
- DDL was generated for PostgreSQL 18.4; execute integration tests against the exact RDS parameter group and minor version before production.

## Explicit limitation

この実行環境にはPostgreSQL server/psqlが存在しないため、生成DDLを実DBへ適用するparser/execution testは実施していない。静的構造検査だけを「実DB検証済み」と解釈してはならない。Codex実装CIでPostgreSQL 18.4 containerまたはRDS-compatible test instanceに対し、fresh install、upgrade、permission、trigger、concurrency、restore testを実行することがRelease条件である。

## Recommended CI commands

```bash
python -m pytest tests/data_model tests/migrations tests/permissions
alembic upgrade head
psql "$TEST_DATABASE_URL" -v ON_ERROR_STOP=1 -f sql/RAOS_03_004_post_deploy_validation_v0.1.sql
alembic downgrade <previous_revision>  # only revisions classified as reversible
```
