# RAOS-DATA-001 ER図集

Version `0.1` / `2026-07-30`

図は関係理解用であり、Cardinality・Column・制約の正本はData Catalog/DDLである。

## 1. Schema dependency overview

```mermaid
flowchart LR
  OPS["ops<br/>Operations"]
  IAM["iam<br/>Identity and Access"]
  PORTFOLIO["portfolio<br/>Portfolio"]
  CATALOG["catalog<br/>Catalog"]
  EVIDENCE["evidence<br/>Evidence"]
  EDITORIAL["editorial<br/>Editorial"]
  AI["ai<br/>AI Orchestration"]
  POLICY["policy<br/>Quality and Policy"]
  PUBLISHING["publishing<br/>Publishing"]
  FRESHNESS["freshness<br/>Freshness"]
  ANALYTICS["analytics<br/>Analytics"]
  FINANCE["finance<br/>Finance"]
  READMODEL["readmodel<br/>Public Read Model"]
  AI --> EDITORIAL
  AI --> EVIDENCE
  AI --> IAM
  AI --> OPS
  ANALYTICS --> CATALOG
  ANALYTICS --> EDITORIAL
  ANALYTICS --> FINANCE
  ANALYTICS --> IAM
  ANALYTICS --> OPS
  ANALYTICS --> PORTFOLIO
  ANALYTICS --> PUBLISHING
  CATALOG --> EVIDENCE
  CATALOG --> IAM
  CATALOG --> OPS
  CATALOG --> PORTFOLIO
  EDITORIAL --> AI
  EDITORIAL --> CATALOG
  EDITORIAL --> EVIDENCE
  EDITORIAL --> IAM
  EDITORIAL --> PORTFOLIO
  EVIDENCE --> AI
  EVIDENCE --> CATALOG
  EVIDENCE --> EDITORIAL
  EVIDENCE --> IAM
  EVIDENCE --> OPS
  FINANCE --> AI
  FINANCE --> EDITORIAL
  FINANCE --> IAM
  FINANCE --> OPS
  FINANCE --> PORTFOLIO
  FRESHNESS --> CATALOG
  FRESHNESS --> EDITORIAL
  FRESHNESS --> EVIDENCE
  FRESHNESS --> IAM
  FRESHNESS --> OPS
  FRESHNESS --> PORTFOLIO
  FRESHNESS --> PUBLISHING
  IAM --> OPS
  OPS --> IAM
  OPS --> PORTFOLIO
  POLICY --> EDITORIAL
  POLICY --> EVIDENCE
  POLICY --> IAM
  POLICY --> OPS
  PORTFOLIO --> IAM
  PORTFOLIO --> OPS
  PUBLISHING --> EDITORIAL
  PUBLISHING --> EVIDENCE
  PUBLISHING --> IAM
  PUBLISHING --> OPS
  PUBLISHING --> POLICY
  PUBLISHING --> PORTFOLIO
  READMODEL --> CATALOG
  READMODEL --> EDITORIAL
  READMODEL --> PORTFOLIO
  READMODEL --> PUBLISHING
```

## 2. `ops` ER

```mermaid
erDiagram
  OPS_OBJECT_ARTIFACT {
    uuid id PK
  }
  OPS_JOB {
    uuid id PK
  }
  OPS_JOB_ATTEMPT {
    uuid id PK
  }
  OPS_OUTBOX_EVENT {
    uuid id PK
  }
  OPS_INBOX_RECEIPT {
    uuid id PK
  }
  OPS_IDEMPOTENCY_RECORD {
    uuid id PK
  }
  OPS_AUDIT_EVENT {
    uuid id PK
  }
  OPS_AUDIT_EXPORT {
    uuid id PK
  }
  OPS_ALERT {
    uuid id PK
  }
  OPS_INCIDENT {
    uuid id PK
  }
  OPS_INCIDENT_EVENT {
    uuid id PK
  }
  OPS_KILL_SWITCH {
    uuid id PK
  }
  OPS_KILL_SWITCH_CHANGE {
    uuid id PK
  }
  OPS_RUNTIME_SETTING_VERSION {
    uuid id PK
  }
  OPS_RETENTION_POLICY {
    uuid id PK
  }
  OPS_RELEASE {
    uuid id PK
  }
  IAM_PRINCIPAL ||--o{ OPS_ALERT : "acknowledged_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT : "commander_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT : "declared_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT_EVENT : "actor_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_KILL_SWITCH : "changed_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_KILL_SWITCH_CHANGE : "actor_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RELEASE : "deployed_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RETENTION_POLICY : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RUNTIME_SETTING_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RUNTIME_SETTING_VERSION : "created_by_principal_id"
  OPS_INCIDENT ||--o{ IAM_BREAK_GLASS_RECORD : "incident_id"
  OPS_INCIDENT ||--o{ OPS_ALERT : "incident_id"
  OPS_INCIDENT ||--o{ OPS_INCIDENT_EVENT : "incident_id"
  OPS_INCIDENT ||--o{ OPS_KILL_SWITCH : "incident_id"
  OPS_INCIDENT ||--o{ OPS_KILL_SWITCH_CHANGE : "incident_id"
  OPS_INCIDENT ||--o{ PUBLISHING_ROLLBACK_RECORD : "incident_id"
  OPS_JOB ||--o{ AI_AI_JOB : "ops_job_id"
  OPS_JOB ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "calculated_by_job_id"
  OPS_JOB ||--o{ ANALYTICS_IMPORT_RUN : "ops_job_id"
  OPS_JOB ||--o{ CATALOG_INGESTION_REQUEST : "job_id"
  OPS_JOB ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "built_by_job_id"
  OPS_JOB ||--o{ FINANCE_COST_ALLOCATION : "calculated_by_job_id"
  OPS_JOB ||--o{ FINANCE_REVENUE_IMPORT : "ops_job_id"
  OPS_JOB ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "calculated_by_job_id"
  OPS_JOB ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "resolved_by_job_id"
  OPS_JOB ||--o{ FRESHNESS_REFRESH_RUN : "ops_job_id"
  OPS_JOB ||--o{ OPS_JOB : "parent_job_id"
  OPS_JOB ||--o{ OPS_JOB_ATTEMPT : "job_id"
  OPS_JOB ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "snapshot_build_job_id"
  OPS_JOB ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "built_by_job_id"
  OPS_KILL_SWITCH ||--o{ OPS_KILL_SWITCH_CHANGE : "kill_switch_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_AI_ATTEMPT : "input_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_AI_ATTEMPT : "output_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_EVALUATION_RESULT : "result_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ ANALYTICS_IMPORT_RUN : "source_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ CATALOG_INGESTION_REQUEST : "raw_response_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ EVIDENCE_SOURCE_SNAPSHOT : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_EXTERNAL_COST : "source_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_PARSER_VERSION : "fixture_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_PARSER_VERSION : "schema_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_REVENUE_IMPORT : "report_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_REVENUE_IMPORT : "source_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "report_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FRESHNESS_LINK_CHECK : "response_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FRESHNESS_REFRESH_RUN : "report_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_AUDIT_EXPORT : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_IDEMPOTENCY_RECORD : "response_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_JOB : "payload_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_JOB_ATTEMPT : "input_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_JOB_ATTEMPT : "output_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ OPS_RELEASE : "manifest_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ POLICY_GATE_DECISION : "evidence_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ POLICY_QUALITY_CHECK_RUN : "report_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ PORTFOLIO_KEYWORD_METRIC_OBSERVATION : "raw_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ PUBLISHING_REVIEW_DECISION : "decision_artifact_id"
  OPS_RELEASE ||--o{ OPS_RELEASE : "rollback_of_release_id"
  OPS_RELEASE ||--o{ PUBLISHING_PUBLICATION_EVENT : "release_id"
  PORTFOLIO_SITE ||--o{ OPS_JOB : "site_id"
```

## 3. `iam` ER

```mermaid
erDiagram
  IAM_PRINCIPAL {
    uuid id PK
  }
  IAM_USER_ACCOUNT {
    uuid principal_id PK
  }
  IAM_SERVICE_PRINCIPAL {
    uuid principal_id PK
  }
  IAM_ROLE {
    uuid id PK
  }
  IAM_PERMISSION {
    uuid id PK
  }
  IAM_ROLE_PERMISSION {
    uuid role_id PK
    uuid permission_id PK
  }
  IAM_PRINCIPAL_ROLE_ASSIGNMENT {
    uuid id PK
  }
  IAM_SESSION_REVOCATION {
    uuid id PK
  }
  IAM_BREAK_GLASS_RECORD {
    uuid id PK
  }
  IAM_PERMISSION ||--o{ IAM_ROLE_PERMISSION : "permission_id"
  IAM_PRINCIPAL ||--o{ AI_MODEL_ROUTE_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ AI_PROMPT_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ ANALYTICS_DATA_QUALITY_FINDING : "resolved_by_principal_id"
  IAM_PRINCIPAL ||--o{ CATALOG_CATEGORY_GENRE_MAPPING : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_ARTICLE_PLAN : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_ARTICLE_PLAN : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_REVIEW_COMMENT : "author_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_REVIEW_COMMENT : "resolved_by_principal_id"
  IAM_PRINCIPAL ||--o{ EVIDENCE_SOURCE : "terms_checked_by_principal_id"
  IAM_PRINCIPAL ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "reviewed_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_ALLOCATION_RULE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_HUMAN_WORK_LOG : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_HUMAN_WORK_LOG : "principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_REVENUE_IMPORT : "confirmed_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ FRESHNESS_FRESHNESS_POLICY : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ IAM_BREAK_GLASS_RECORD : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ IAM_BREAK_GLASS_RECORD : "principal_id"
  IAM_PRINCIPAL ||--o{ IAM_PRINCIPAL_ROLE_ASSIGNMENT : "assigned_by_principal_id"
  IAM_PRINCIPAL ||--o{ IAM_PRINCIPAL_ROLE_ASSIGNMENT : "principal_id"
  IAM_PRINCIPAL ||--o{ IAM_PRINCIPAL_ROLE_ASSIGNMENT : "revoked_by_principal_id"
  IAM_PRINCIPAL ||--o{ IAM_SERVICE_PRINCIPAL : "principal_id"
  IAM_PRINCIPAL ||--o{ IAM_SESSION_REVOCATION : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ IAM_SESSION_REVOCATION : "principal_id"
  IAM_PRINCIPAL ||--o{ IAM_USER_ACCOUNT : "principal_id"
  IAM_PRINCIPAL ||--o{ OPS_ALERT : "acknowledged_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT : "commander_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT : "declared_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_INCIDENT_EVENT : "actor_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_KILL_SWITCH : "changed_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_KILL_SWITCH_CHANGE : "actor_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RELEASE : "deployed_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RETENTION_POLICY : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RUNTIME_SETTING_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ OPS_RUNTIME_SETTING_VERSION : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_FINDING : "resolved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_GATE_DECISION : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_POLICY_BUNDLE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_RULE_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_RULE_VERSION : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_WAIVER : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_WAIVER : "requested_by_principal_id"
  IAM_PRINCIPAL ||--o{ PORTFOLIO_ACTION_CANDIDATE : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ PORTFOLIO_CATEGORY : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_APPROVAL : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_APPROVAL : "revoked_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "requested_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "assigned_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "assigned_to_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_DECISION : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "executed_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "requested_by_principal_id"
  IAM_ROLE ||--o{ IAM_PRINCIPAL_ROLE_ASSIGNMENT : "role_id"
  IAM_ROLE ||--o{ IAM_ROLE_PERMISSION : "role_id"
  OPS_INCIDENT ||--o{ IAM_BREAK_GLASS_RECORD : "incident_id"
```

## 4. `portfolio` ER

```mermaid
erDiagram
  PORTFOLIO_SITE {
    uuid id PK
  }
  PORTFOLIO_CATEGORY {
    uuid id PK
  }
  PORTFOLIO_INTENT_CLUSTER {
    uuid id PK
  }
  PORTFOLIO_KEYWORD {
    uuid id PK
  }
  PORTFOLIO_INTENT_CLUSTER_KEYWORD {
    uuid intent_cluster_id PK
    uuid keyword_id PK
  }
  PORTFOLIO_KEYWORD_METRIC_OBSERVATION {
    uuid id PK
  }
  PORTFOLIO_OPPORTUNITY_ASSESSMENT {
    uuid id PK
  }
  PORTFOLIO_ACTION_CANDIDATE {
    uuid id PK
  }
  IAM_PRINCIPAL ||--o{ PORTFOLIO_ACTION_CANDIDATE : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ PORTFOLIO_CATEGORY : "approved_by_principal_id"
  OPS_OBJECT_ARTIFACT ||--o{ PORTFOLIO_KEYWORD_METRIC_OBSERVATION : "raw_artifact_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_ATTRIBUTE_DEFINITION : "category_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_CANONICAL_PRODUCT : "category_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_CATEGORY_GENRE_MAPPING : "category_id"
  PORTFOLIO_CATEGORY ||--o{ EDITORIAL_ARTICLE_PLAN : "category_id"
  PORTFOLIO_CATEGORY ||--o{ FINANCE_EXTERNAL_COST : "category_id"
  PORTFOLIO_CATEGORY ||--o{ FINANCE_HUMAN_WORK_LOG : "category_id"
  PORTFOLIO_CATEGORY ||--o{ FRESHNESS_FRESHNESS_POLICY : "category_id"
  PORTFOLIO_CATEGORY ||--o{ PORTFOLIO_ACTION_CANDIDATE : "category_id"
  PORTFOLIO_CATEGORY ||--o{ PORTFOLIO_CATEGORY : "parent_category_id"
  PORTFOLIO_CATEGORY ||--o{ PORTFOLIO_INTENT_CLUSTER : "category_id"
  PORTFOLIO_CATEGORY ||--o{ PORTFOLIO_OPPORTUNITY_ASSESSMENT : "category_id"
  PORTFOLIO_INTENT_CLUSTER ||--o{ EDITORIAL_ARTICLE_PLAN : "intent_cluster_id"
  PORTFOLIO_INTENT_CLUSTER ||--o{ PORTFOLIO_INTENT_CLUSTER_KEYWORD : "intent_cluster_id"
  PORTFOLIO_INTENT_CLUSTER ||--o{ PORTFOLIO_OPPORTUNITY_ASSESSMENT : "intent_cluster_id"
  PORTFOLIO_KEYWORD ||--o{ EDITORIAL_ARTICLE_PLAN : "primary_keyword_id"
  PORTFOLIO_KEYWORD ||--o{ PORTFOLIO_INTENT_CLUSTER_KEYWORD : "keyword_id"
  PORTFOLIO_KEYWORD ||--o{ PORTFOLIO_KEYWORD_METRIC_OBSERVATION : "keyword_id"
  PORTFOLIO_KEYWORD ||--o{ PORTFOLIO_OPPORTUNITY_ASSESSMENT : "keyword_id"
  PORTFOLIO_OPPORTUNITY_ASSESSMENT ||--o{ EDITORIAL_ARTICLE_PLAN : "opportunity_assessment_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_ANONYMOUS_EVENT : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_DATA_QUALITY_FINDING : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_GA4_OBSERVATION : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_GSC_OBSERVATION : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_IMPORT_RUN : "site_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE : "site_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE_PLAN : "site_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE_SLUG : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_ALLOCATION_RULE : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_COMMISSION : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_EXTERNAL_COST : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_HUMAN_WORK_LOG : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_REVENUE_IMPORT : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_FRESHNESS_POLICY : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_LINK_CHECK : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_REFRESH_RUN : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_REFRESH_SCHEDULE : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_STALENESS_ASSESSMENT : "site_id"
  PORTFOLIO_SITE ||--o{ OPS_JOB : "site_id"
  PORTFOLIO_SITE ||--o{ PORTFOLIO_ACTION_CANDIDATE : "site_id"
  PORTFOLIO_SITE ||--o{ PORTFOLIO_CATEGORY : "site_id"
  PORTFOLIO_SITE ||--o{ PORTFOLIO_KEYWORD : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLIC_ROUTE : "site_id"
  PORTFOLIO_SITE ||--o{ READMODEL_PUBLIC_ARTICLE : "site_id"
  PORTFOLIO_SITE ||--o{ READMODEL_PUBLIC_ROUTE : "site_id"
  PORTFOLIO_SITE ||--o{ READMODEL_RUNTIME_CONTROL : "site_id"
```

## 5. `catalog` ER

```mermaid
erDiagram
  CATALOG_PROVIDER_ENDPOINT {
    uuid id PK
  }
  CATALOG_INGESTION_REQUEST {
    uuid id PK
  }
  CATALOG_RAKUTEN_GENRE {
    uuid id PK
  }
  CATALOG_SHOP {
    uuid id PK
  }
  CATALOG_CANONICAL_PRODUCT {
    uuid id PK
  }
  CATALOG_PRODUCT_CANDIDATE {
    uuid id PK
  }
  CATALOG_GROUPING_DECISION {
    uuid id PK
  }
  CATALOG_PRODUCT_GROUP_MEMBERSHIP {
    uuid id PK
  }
  CATALOG_ATTRIBUTE_DEFINITION {
    uuid id PK
  }
  CATALOG_PRODUCT_ATTRIBUTE_VALUE {
    uuid id PK
  }
  CATALOG_PRODUCT_RELATION {
    uuid id PK
  }
  CATALOG_OFFER {
    uuid id PK
  }
  CATALOG_PRICE_OBSERVATION {
    uuid id PK
  }
  CATALOG_AVAILABILITY_OBSERVATION {
    uuid id PK
  }
  CATALOG_REVIEW_AGGREGATE_OBSERVATION {
    uuid id PK
  }
  CATALOG_AFFILIATE_LINK_OBSERVATION {
    uuid id PK
  }
  CATALOG_OFFER_CURRENT_PROJECTION {
    uuid offer_id PK
  }
  CATALOG_CATEGORY_GENRE_MAPPING {
    uuid id PK
  }
  CATALOG_AFFILIATE_LINK_OBSERVATION ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "affiliate_link_observation_id"
  CATALOG_AFFILIATE_LINK_OBSERVATION ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "affiliate_link_observation_id"
  CATALOG_AFFILIATE_LINK_OBSERVATION ||--o{ FRESHNESS_LINK_CHECK : "affiliate_link_observation_id"
  CATALOG_ATTRIBUTE_DEFINITION ||--o{ CATALOG_PRODUCT_ATTRIBUTE_VALUE : "attribute_definition_id"
  CATALOG_AVAILABILITY_OBSERVATION ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "availability_observation_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ ANALYTICS_ANONYMOUS_EVENT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_CANONICAL_PRODUCT : "merged_into_product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_GROUPING_DECISION : "proposed_product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_OFFER : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_PRODUCT_ATTRIBUTE_VALUE : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_PRODUCT_GROUP_MEMBERSHIP : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_PRODUCT_RELATION : "from_product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ CATALOG_PRODUCT_RELATION : "to_product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_ARTICLE_BLOCK_PRODUCT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_COMPARISON_VALUE : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_RECOMMENDATION : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EVIDENCE_SOURCE_PACKET_PRODUCT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ READMODEL_PUBLIC_PRODUCT_CARD : "product_id"
  CATALOG_GROUPING_DECISION ||--o{ CATALOG_GROUPING_DECISION : "supersedes_decision_id"
  CATALOG_GROUPING_DECISION ||--o{ CATALOG_PRODUCT_GROUP_MEMBERSHIP : "grouping_decision_id"
  CATALOG_OFFER ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "offer_id"
  CATALOG_OFFER ||--o{ ANALYTICS_ANONYMOUS_EVENT : "offer_id"
  CATALOG_OFFER ||--o{ CATALOG_AFFILIATE_LINK_OBSERVATION : "offer_id"
  CATALOG_OFFER ||--o{ CATALOG_AVAILABILITY_OBSERVATION : "offer_id"
  CATALOG_OFFER ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "offer_id"
  CATALOG_OFFER ||--o{ CATALOG_PRICE_OBSERVATION : "offer_id"
  CATALOG_OFFER ||--o{ CATALOG_REVIEW_AGGREGATE_OBSERVATION : "offer_id"
  CATALOG_OFFER ||--o{ EDITORIAL_ARTICLE_BLOCK_PRODUCT : "offer_id"
  CATALOG_OFFER ||--o{ EVIDENCE_SOURCE_PACKET_PRODUCT : "offer_id"
  CATALOG_OFFER ||--o{ FRESHNESS_LINK_CHECK : "offer_id"
  CATALOG_OFFER ||--o{ READMODEL_PUBLIC_OFFER : "offer_id"
  CATALOG_PRICE_OBSERVATION ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "price_observation_id"
  CATALOG_PRODUCT_CANDIDATE ||--o{ CATALOG_GROUPING_DECISION : "product_candidate_id"
  CATALOG_PRODUCT_CANDIDATE ||--o{ CATALOG_OFFER : "product_candidate_id"
  CATALOG_PRODUCT_CANDIDATE ||--o{ CATALOG_PRODUCT_GROUP_MEMBERSHIP : "product_candidate_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ CATALOG_INGESTION_REQUEST : "provider_endpoint_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ CATALOG_OFFER : "provider_endpoint_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ CATALOG_PRODUCT_CANDIDATE : "provider_endpoint_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ CATALOG_RAKUTEN_GENRE : "provider_endpoint_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ CATALOG_SHOP : "provider_endpoint_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ EVIDENCE_SOURCE : "provider_endpoint_id"
  CATALOG_RAKUTEN_GENRE ||--o{ CATALOG_CATEGORY_GENRE_MAPPING : "rakuten_genre_id"
  CATALOG_RAKUTEN_GENRE ||--o{ CATALOG_PRODUCT_CANDIDATE : "rakuten_genre_id"
  CATALOG_REVIEW_AGGREGATE_OBSERVATION ||--o{ CATALOG_OFFER_CURRENT_PROJECTION : "review_observation_id"
  CATALOG_SHOP ||--o{ CATALOG_OFFER : "shop_id"
  CATALOG_SHOP ||--o{ CATALOG_PRODUCT_CANDIDATE : "shop_id"
  CATALOG_SHOP ||--o{ READMODEL_PUBLIC_OFFER : "shop_id"
  EVIDENCE_FACT ||--o{ CATALOG_PRODUCT_ATTRIBUTE_VALUE : "source_fact_id"
  EVIDENCE_FACT ||--o{ CATALOG_PRODUCT_RELATION : "source_fact_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_AFFILIATE_LINK_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_AVAILABILITY_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_PRICE_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_PRODUCT_CANDIDATE : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_RAKUTEN_GENRE : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_REVIEW_AGGREGATE_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_SHOP : "source_snapshot_id"
  IAM_PRINCIPAL ||--o{ CATALOG_CATEGORY_GENRE_MAPPING : "decided_by_principal_id"
  OPS_JOB ||--o{ CATALOG_INGESTION_REQUEST : "job_id"
  OPS_OBJECT_ARTIFACT ||--o{ CATALOG_INGESTION_REQUEST : "raw_response_artifact_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_ATTRIBUTE_DEFINITION : "category_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_CANONICAL_PRODUCT : "category_id"
  PORTFOLIO_CATEGORY ||--o{ CATALOG_CATEGORY_GENRE_MAPPING : "category_id"
```

## 6. `evidence` ER

```mermaid
erDiagram
  EVIDENCE_SOURCE {
    uuid id PK
  }
  EVIDENCE_SOURCE_SNAPSHOT {
    uuid id PK
  }
  EVIDENCE_FACT {
    uuid id PK
  }
  EVIDENCE_FACT_DERIVATION {
    uuid derived_fact_id PK
    uuid input_fact_id PK
    text derivation_role PK
  }
  EVIDENCE_SOURCE_PACKET {
    uuid id PK
  }
  EVIDENCE_SOURCE_PACKET_VERSION {
    uuid id PK
  }
  EVIDENCE_SOURCE_PACKET_FACT {
    uuid source_packet_version_id PK
    uuid fact_id PK
  }
  EVIDENCE_SOURCE_PACKET_PRODUCT {
    uuid source_packet_version_id PK
    uuid product_id PK
    text product_role PK
  }
  EVIDENCE_CLAIM {
    uuid id PK
  }
  EVIDENCE_CLAIM_EVIDENCE_LINK {
    uuid claim_id PK
    uuid fact_id PK
    text support_type PK
  }
  AI_AI_ATTEMPT ||--o{ EVIDENCE_CLAIM : "generated_by_ai_attempt_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EVIDENCE_SOURCE_PACKET_PRODUCT : "product_id"
  CATALOG_OFFER ||--o{ EVIDENCE_SOURCE_PACKET_PRODUCT : "offer_id"
  CATALOG_PROVIDER_ENDPOINT ||--o{ EVIDENCE_SOURCE : "provider_endpoint_id"
  EDITORIAL_ARTICLE_BLOCK ||--o{ EVIDENCE_CLAIM : "block_id_article_version_id"
  EDITORIAL_ARTICLE_PLAN ||--o{ EVIDENCE_SOURCE_PACKET : "article_plan_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EVIDENCE_CLAIM : "article_version_id"
  EVIDENCE_CLAIM ||--o{ EDITORIAL_RECOMMENDATION_RATIONALE : "claim_id"
  EVIDENCE_CLAIM ||--o{ EDITORIAL_REVIEW_COMMENT : "claim_id"
  EVIDENCE_CLAIM ||--o{ EVIDENCE_CLAIM_EVIDENCE_LINK : "claim_id"
  EVIDENCE_CLAIM ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "claim_id"
  EVIDENCE_CLAIM ||--o{ POLICY_FINDING : "claim_id"
  EVIDENCE_FACT ||--o{ CATALOG_PRODUCT_ATTRIBUTE_VALUE : "source_fact_id"
  EVIDENCE_FACT ||--o{ CATALOG_PRODUCT_RELATION : "source_fact_id"
  EVIDENCE_FACT ||--o{ EDITORIAL_COMPARISON_VALUE : "source_fact_id"
  EVIDENCE_FACT ||--o{ EDITORIAL_RECOMMENDATION_RATIONALE : "source_fact_id"
  EVIDENCE_FACT ||--o{ EVIDENCE_CLAIM_EVIDENCE_LINK : "fact_id"
  EVIDENCE_FACT ||--o{ EVIDENCE_FACT_DERIVATION : "derived_fact_id"
  EVIDENCE_FACT ||--o{ EVIDENCE_FACT_DERIVATION : "input_fact_id"
  EVIDENCE_FACT ||--o{ EVIDENCE_SOURCE_PACKET_FACT : "fact_id"
  EVIDENCE_SOURCE ||--o{ EVIDENCE_SOURCE_SNAPSHOT : "source_id"
  EVIDENCE_SOURCE_PACKET ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "source_packet_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ AI_AI_JOB : "source_packet_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ EDITORIAL_ARTICLE_VERSION : "source_packet_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ EVIDENCE_SOURCE_PACKET_FACT : "source_packet_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ EVIDENCE_SOURCE_PACKET_PRODUCT : "source_packet_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ POLICY_QUALITY_CHECK_RUN : "source_packet_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "source_packet_version_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_AFFILIATE_LINK_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_AVAILABILITY_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_PRICE_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_PRODUCT_CANDIDATE : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_RAKUTEN_GENRE : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_REVIEW_AGGREGATE_OBSERVATION : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ CATALOG_SHOP : "source_snapshot_id"
  EVIDENCE_SOURCE_SNAPSHOT ||--o{ EVIDENCE_FACT : "source_snapshot_id"
  IAM_PRINCIPAL ||--o{ EVIDENCE_SOURCE : "terms_checked_by_principal_id"
  IAM_PRINCIPAL ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "reviewed_by_principal_id"
  OPS_JOB ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "built_by_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ EVIDENCE_SOURCE_PACKET_VERSION : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ EVIDENCE_SOURCE_SNAPSHOT : "artifact_id"
```

## 7. `editorial` ER

```mermaid
erDiagram
  EDITORIAL_ARTICLE_PLAN {
    uuid id PK
  }
  EDITORIAL_ARTICLE {
    uuid id PK
  }
  EDITORIAL_ARTICLE_SLUG {
    uuid id PK
  }
  EDITORIAL_ARTICLE_VERSION {
    uuid id PK
  }
  EDITORIAL_ARTICLE_BLOCK {
    uuid id PK
  }
  EDITORIAL_ARTICLE_BLOCK_PRODUCT {
    uuid article_block_id PK
    uuid product_id PK
    text placement_role PK
  }
  EDITORIAL_COMPARISON_AXIS {
    uuid id PK
  }
  EDITORIAL_COMPARISON_VALUE {
    uuid id PK
  }
  EDITORIAL_RECOMMENDATION_SET {
    uuid id PK
  }
  EDITORIAL_RECOMMENDATION {
    uuid id PK
  }
  EDITORIAL_RECOMMENDATION_RATIONALE {
    uuid id PK
  }
  EDITORIAL_REVIEW_COMMENT {
    uuid id PK
  }
  EDITORIAL_ARTICLE_LINK {
    uuid id PK
  }
  AI_AI_JOB ||--o{ EDITORIAL_ARTICLE_VERSION : "ai_job_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_ARTICLE_BLOCK_PRODUCT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_COMPARISON_VALUE : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ EDITORIAL_RECOMMENDATION : "product_id"
  CATALOG_OFFER ||--o{ EDITORIAL_ARTICLE_BLOCK_PRODUCT : "offer_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_ANONYMOUS_EVENT : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "article_id"
  EDITORIAL_ARTICLE ||--o{ EDITORIAL_ARTICLE_LINK : "from_article_id"
  EDITORIAL_ARTICLE ||--o{ EDITORIAL_ARTICLE_LINK : "to_article_id"
  EDITORIAL_ARTICLE ||--o{ EDITORIAL_ARTICLE_SLUG : "article_id"
  EDITORIAL_ARTICLE ||--o{ EDITORIAL_ARTICLE_VERSION : "article_id"
  EDITORIAL_ARTICLE ||--o{ FINANCE_EXTERNAL_COST : "article_id"
  EDITORIAL_ARTICLE ||--o{ FINANCE_HUMAN_WORK_LOG : "article_id"
  EDITORIAL_ARTICLE ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "article_id"
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLICATION : "article_id"
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "article_id"
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLIC_ROUTE : "article_id"
  EDITORIAL_ARTICLE ||--o{ READMODEL_PUBLIC_ARTICLE : "article_id"
  EDITORIAL_ARTICLE_BLOCK ||--o{ EDITORIAL_ARTICLE_BLOCK_PRODUCT : "article_block_id"
  EDITORIAL_ARTICLE_BLOCK ||--o{ EDITORIAL_REVIEW_COMMENT : "article_block_id"
  EDITORIAL_ARTICLE_BLOCK ||--o{ EVIDENCE_CLAIM : "block_id_article_version_id"
  EDITORIAL_ARTICLE_BLOCK ||--o{ POLICY_FINDING : "article_block_id"
  EDITORIAL_ARTICLE_PLAN ||--o{ AI_AI_JOB : "article_plan_id"
  EDITORIAL_ARTICLE_PLAN ||--o{ EDITORIAL_ARTICLE : "article_plan_id"
  EDITORIAL_ARTICLE_PLAN ||--o{ EVIDENCE_SOURCE_PACKET : "article_plan_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ AI_AI_JOB : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ ANALYTICS_ANONYMOUS_EVENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_ARTICLE : "current_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_ARTICLE : "published_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_ARTICLE_BLOCK : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_ARTICLE_VERSION : "based_on_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_COMPARISON_AXIS : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_RECOMMENDATION_SET : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EDITORIAL_REVIEW_COMMENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ EVIDENCE_CLAIM : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ FINANCE_HUMAN_WORK_LOG : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ POLICY_QUALITY_CHECK_RUN : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_APPROVAL : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_REVIEW_DECISION : "article_version_id"
  EDITORIAL_COMPARISON_AXIS ||--o{ EDITORIAL_COMPARISON_VALUE : "comparison_axis_id"
  EDITORIAL_RECOMMENDATION ||--o{ EDITORIAL_RECOMMENDATION_RATIONALE : "recommendation_id"
  EDITORIAL_RECOMMENDATION_SET ||--o{ EDITORIAL_RECOMMENDATION : "recommendation_set_id"
  EDITORIAL_REVIEW_COMMENT ||--o{ EDITORIAL_REVIEW_COMMENT : "parent_comment_id"
  EVIDENCE_CLAIM ||--o{ EDITORIAL_RECOMMENDATION_RATIONALE : "claim_id"
  EVIDENCE_CLAIM ||--o{ EDITORIAL_REVIEW_COMMENT : "claim_id"
  EVIDENCE_FACT ||--o{ EDITORIAL_COMPARISON_VALUE : "source_fact_id"
  EVIDENCE_FACT ||--o{ EDITORIAL_RECOMMENDATION_RATIONALE : "source_fact_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ EDITORIAL_ARTICLE_VERSION : "source_packet_version_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_ARTICLE_PLAN : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_ARTICLE_PLAN : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_REVIEW_COMMENT : "author_principal_id"
  IAM_PRINCIPAL ||--o{ EDITORIAL_REVIEW_COMMENT : "resolved_by_principal_id"
  PORTFOLIO_CATEGORY ||--o{ EDITORIAL_ARTICLE_PLAN : "category_id"
  PORTFOLIO_INTENT_CLUSTER ||--o{ EDITORIAL_ARTICLE_PLAN : "intent_cluster_id"
  PORTFOLIO_KEYWORD ||--o{ EDITORIAL_ARTICLE_PLAN : "primary_keyword_id"
  PORTFOLIO_OPPORTUNITY_ASSESSMENT ||--o{ EDITORIAL_ARTICLE_PLAN : "opportunity_assessment_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE : "site_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE_PLAN : "site_id"
  PORTFOLIO_SITE ||--o{ EDITORIAL_ARTICLE_SLUG : "site_id"
```

## 8. `ai` ER

```mermaid
erDiagram
  AI_TASK_DEFINITION {
    uuid id PK
  }
  AI_PROMPT_VERSION {
    uuid id PK
  }
  AI_OUTPUT_SCHEMA_VERSION {
    uuid id PK
  }
  AI_MODEL_DEFINITION {
    uuid id PK
  }
  AI_MODEL_ROUTE_VERSION {
    uuid id PK
  }
  AI_AI_JOB {
    uuid id PK
  }
  AI_AI_ATTEMPT {
    uuid id PK
  }
  AI_USAGE_COST {
    uuid id PK
  }
  AI_EVALUATION_RESULT {
    uuid id PK
  }
  AI_AI_ATTEMPT ||--o{ AI_USAGE_COST : "ai_attempt_id"
  AI_AI_ATTEMPT ||--o{ EVIDENCE_CLAIM : "generated_by_ai_attempt_id"
  AI_AI_JOB ||--o{ AI_AI_ATTEMPT : "ai_job_id"
  AI_AI_JOB ||--o{ EDITORIAL_ARTICLE_VERSION : "ai_job_id"
  AI_AI_JOB ||--o{ FINANCE_EXTERNAL_COST : "ai_job_id"
  AI_MODEL_DEFINITION ||--o{ AI_AI_ATTEMPT : "model_id"
  AI_MODEL_DEFINITION ||--o{ AI_MODEL_ROUTE_VERSION : "fallback_model_id"
  AI_MODEL_DEFINITION ||--o{ AI_MODEL_ROUTE_VERSION : "primary_model_id"
  AI_MODEL_ROUTE_VERSION ||--o{ AI_AI_JOB : "model_route_version_id"
  AI_MODEL_ROUTE_VERSION ||--o{ AI_EVALUATION_RESULT : "model_route_version_id"
  AI_OUTPUT_SCHEMA_VERSION ||--o{ AI_AI_JOB : "output_schema_version_id"
  AI_PROMPT_VERSION ||--o{ AI_AI_JOB : "prompt_version_id"
  AI_PROMPT_VERSION ||--o{ AI_EVALUATION_RESULT : "prompt_version_id"
  AI_TASK_DEFINITION ||--o{ AI_AI_JOB : "task_definition_id"
  AI_TASK_DEFINITION ||--o{ AI_EVALUATION_RESULT : "task_definition_id"
  AI_TASK_DEFINITION ||--o{ AI_MODEL_ROUTE_VERSION : "task_definition_id"
  AI_TASK_DEFINITION ||--o{ AI_PROMPT_VERSION : "task_definition_id"
  EDITORIAL_ARTICLE_PLAN ||--o{ AI_AI_JOB : "article_plan_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ AI_AI_JOB : "article_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ AI_AI_JOB : "source_packet_version_id"
  IAM_PRINCIPAL ||--o{ AI_MODEL_ROUTE_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ AI_PROMPT_VERSION : "approved_by_principal_id"
  OPS_JOB ||--o{ AI_AI_JOB : "ops_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_AI_ATTEMPT : "input_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_AI_ATTEMPT : "output_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ AI_EVALUATION_RESULT : "result_artifact_id"
```

## 9. `policy` ER

```mermaid
erDiagram
  POLICY_POLICY_BUNDLE {
    uuid id PK
  }
  POLICY_RULE_VERSION {
    uuid id PK
  }
  POLICY_BUNDLE_RULE {
    uuid policy_bundle_id PK
    uuid rule_version_id PK
  }
  POLICY_QUALITY_CHECK_RUN {
    uuid id PK
  }
  POLICY_FINDING {
    uuid id PK
  }
  POLICY_QUALITY_SCORE {
    uuid id PK
  }
  POLICY_WAIVER {
    uuid id PK
  }
  POLICY_GATE_DECISION {
    uuid id PK
  }
  EDITORIAL_ARTICLE_BLOCK ||--o{ POLICY_FINDING : "article_block_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ POLICY_QUALITY_CHECK_RUN : "article_version_id"
  EVIDENCE_CLAIM ||--o{ POLICY_FINDING : "claim_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ POLICY_QUALITY_CHECK_RUN : "source_packet_version_id"
  IAM_PRINCIPAL ||--o{ POLICY_FINDING : "resolved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_GATE_DECISION : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_POLICY_BUNDLE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_RULE_VERSION : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_RULE_VERSION : "created_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_WAIVER : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ POLICY_WAIVER : "requested_by_principal_id"
  OPS_OBJECT_ARTIFACT ||--o{ POLICY_GATE_DECISION : "evidence_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ POLICY_QUALITY_CHECK_RUN : "report_artifact_id"
  POLICY_FINDING ||--o{ POLICY_WAIVER : "finding_id"
  POLICY_POLICY_BUNDLE ||--o{ POLICY_BUNDLE_RULE : "policy_bundle_id"
  POLICY_POLICY_BUNDLE ||--o{ POLICY_GATE_DECISION : "policy_bundle_id"
  POLICY_POLICY_BUNDLE ||--o{ POLICY_QUALITY_CHECK_RUN : "policy_bundle_id"
  POLICY_POLICY_BUNDLE ||--o{ PUBLISHING_APPROVAL : "policy_bundle_id"
  POLICY_POLICY_BUNDLE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "policy_bundle_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ POLICY_FINDING : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ POLICY_QUALITY_SCORE : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_APPROVAL : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "quality_check_run_id"
  POLICY_RULE_VERSION ||--o{ POLICY_BUNDLE_RULE : "rule_version_id"
  POLICY_RULE_VERSION ||--o{ POLICY_FINDING : "rule_version_id"
```

## 10. `publishing` ER

```mermaid
erDiagram
  PUBLISHING_REVIEW_ASSIGNMENT {
    uuid id PK
  }
  PUBLISHING_REVIEW_DECISION {
    uuid id PK
  }
  PUBLISHING_APPROVAL {
    uuid id PK
  }
  PUBLISHING_PUBLICATION_CANDIDATE {
    uuid id PK
  }
  PUBLISHING_PUBLICATION_SNAPSHOT {
    uuid id PK
  }
  PUBLISHING_PUBLICATION {
    uuid id PK
  }
  PUBLISHING_PUBLICATION_EVENT {
    uuid id PK
  }
  PUBLISHING_PUBLIC_ROUTE {
    uuid id PK
  }
  PUBLISHING_ROLLBACK_RECORD {
    uuid id PK
  }
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLICATION : "article_id"
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "article_id"
  EDITORIAL_ARTICLE ||--o{ PUBLISHING_PUBLIC_ROUTE : "article_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_APPROVAL : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ PUBLISHING_REVIEW_DECISION : "article_version_id"
  EVIDENCE_SOURCE_PACKET_VERSION ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "source_packet_version_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_APPROVAL : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_APPROVAL : "revoked_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "requested_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "assigned_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_ASSIGNMENT : "assigned_to_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_REVIEW_DECISION : "decided_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "executed_by_principal_id"
  IAM_PRINCIPAL ||--o{ PUBLISHING_ROLLBACK_RECORD : "requested_by_principal_id"
  OPS_INCIDENT ||--o{ PUBLISHING_ROLLBACK_RECORD : "incident_id"
  OPS_JOB ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "snapshot_build_job_id"
  OPS_JOB ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "built_by_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ PUBLISHING_REVIEW_DECISION : "decision_artifact_id"
  OPS_RELEASE ||--o{ PUBLISHING_PUBLICATION_EVENT : "release_id"
  POLICY_POLICY_BUNDLE ||--o{ PUBLISHING_APPROVAL : "policy_bundle_id"
  POLICY_POLICY_BUNDLE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "policy_bundle_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_APPROVAL : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "quality_check_run_id"
  POLICY_QUALITY_CHECK_RUN ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "quality_check_run_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "site_id"
  PORTFOLIO_SITE ||--o{ PUBLISHING_PUBLIC_ROUTE : "site_id"
  PUBLISHING_APPROVAL ||--o{ PUBLISHING_APPROVAL : "supersedes_approval_id"
  PUBLISHING_APPROVAL ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "final_approval_id"
  PUBLISHING_APPROVAL ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "final_approval_id"
  PUBLISHING_PUBLICATION ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "publication_id"
  PUBLISHING_PUBLICATION ||--o{ PUBLISHING_PUBLICATION_EVENT : "publication_id"
  PUBLISHING_PUBLICATION ||--o{ PUBLISHING_PUBLIC_ROUTE : "publication_id"
  PUBLISHING_PUBLICATION ||--o{ PUBLISHING_ROLLBACK_RECORD : "publication_id"
  PUBLISHING_PUBLICATION ||--o{ READMODEL_PUBLIC_ARTICLE : "publication_id"
  PUBLISHING_PUBLICATION_CANDIDATE ||--o{ PUBLISHING_PUBLICATION_EVENT : "publication_candidate_id"
  PUBLISHING_PUBLICATION_CANDIDATE ||--o{ PUBLISHING_PUBLICATION_SNAPSHOT : "publication_candidate_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_ANONYMOUS_EVENT : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_PUBLICATION : "current_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_PUBLICATION_CANDIDATE : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_PUBLICATION_EVENT : "from_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_PUBLICATION_EVENT : "to_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_ROLLBACK_RECORD : "from_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ PUBLISHING_ROLLBACK_RECORD : "to_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_ARTICLE : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_ARTICLE_BLOCK : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_PRODUCT_CARD : "publication_snapshot_id"
  PUBLISHING_PUBLIC_ROUTE ||--o{ PUBLISHING_PUBLICATION : "current_route_id"
  PUBLISHING_PUBLIC_ROUTE ||--o{ PUBLISHING_PUBLIC_ROUTE : "redirect_target_route_id"
  PUBLISHING_REVIEW_ASSIGNMENT ||--o{ PUBLISHING_REVIEW_DECISION : "review_assignment_id"
  PUBLISHING_REVIEW_DECISION ||--o{ PUBLISHING_REVIEW_DECISION : "supersedes_decision_id"
```

## 11. `freshness` ER

```mermaid
erDiagram
  FRESHNESS_FRESHNESS_POLICY {
    uuid id PK
  }
  FRESHNESS_REFRESH_SCHEDULE {
    uuid id PK
  }
  FRESHNESS_REFRESH_RUN {
    uuid id PK
  }
  FRESHNESS_STALENESS_ASSESSMENT {
    uuid id PK
  }
  FRESHNESS_LINK_CHECK {
    uuid id PK
  }
  FRESHNESS_IMPACT_ASSESSMENT {
    uuid id PK
  }
  CATALOG_AFFILIATE_LINK_OBSERVATION ||--o{ FRESHNESS_LINK_CHECK : "affiliate_link_observation_id"
  CATALOG_OFFER ||--o{ FRESHNESS_LINK_CHECK : "offer_id"
  EDITORIAL_ARTICLE ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "article_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "article_version_id"
  EVIDENCE_CLAIM ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "claim_id"
  FRESHNESS_FRESHNESS_POLICY ||--o{ FRESHNESS_REFRESH_SCHEDULE : "freshness_policy_id"
  FRESHNESS_FRESHNESS_POLICY ||--o{ FRESHNESS_STALENESS_ASSESSMENT : "freshness_policy_id"
  FRESHNESS_REFRESH_RUN ||--o{ FRESHNESS_LINK_CHECK : "refresh_run_id"
  FRESHNESS_REFRESH_RUN ||--o{ FRESHNESS_STALENESS_ASSESSMENT : "refresh_run_id"
  IAM_PRINCIPAL ||--o{ FRESHNESS_FRESHNESS_POLICY : "created_by_principal_id"
  OPS_JOB ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "resolved_by_job_id"
  OPS_JOB ||--o{ FRESHNESS_REFRESH_RUN : "ops_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ FRESHNESS_LINK_CHECK : "response_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FRESHNESS_REFRESH_RUN : "report_artifact_id"
  PORTFOLIO_CATEGORY ||--o{ FRESHNESS_FRESHNESS_POLICY : "category_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_FRESHNESS_POLICY : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_LINK_CHECK : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_REFRESH_RUN : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_REFRESH_SCHEDULE : "site_id"
  PORTFOLIO_SITE ||--o{ FRESHNESS_STALENESS_ASSESSMENT : "site_id"
  PUBLISHING_PUBLICATION ||--o{ FRESHNESS_IMPACT_ASSESSMENT : "publication_id"
```

## 12. `analytics` ER

```mermaid
erDiagram
  ANALYTICS_ANONYMOUS_EVENT {
    uuid id PK
  }
  ANALYTICS_AFFILIATE_CLICK_EVENT {
    uuid id PK
  }
  ANALYTICS_IMPORT_RUN {
    uuid id PK
  }
  ANALYTICS_GSC_OBSERVATION {
    uuid id PK
  }
  ANALYTICS_GA4_OBSERVATION {
    uuid id PK
  }
  ANALYTICS_ATTRIBUTION_ESTIMATE {
    uuid id PK
  }
  ANALYTICS_DATA_QUALITY_FINDING {
    uuid id PK
  }
  ANALYTICS_DAILY_ARTICLE_METRIC {
    uuid site_id PK
    uuid article_id PK
    date metric_date PK
  }
  ANALYTICS_ANONYMOUS_EVENT ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "anonymous_event_id"
  ANALYTICS_IMPORT_RUN ||--o{ ANALYTICS_DATA_QUALITY_FINDING : "import_run_id"
  ANALYTICS_IMPORT_RUN ||--o{ ANALYTICS_GA4_OBSERVATION : "import_run_id"
  ANALYTICS_IMPORT_RUN ||--o{ ANALYTICS_GSC_OBSERVATION : "import_run_id"
  CATALOG_AFFILIATE_LINK_OBSERVATION ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "affiliate_link_observation_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "product_id"
  CATALOG_CANONICAL_PRODUCT ||--o{ ANALYTICS_ANONYMOUS_EVENT : "product_id"
  CATALOG_OFFER ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "offer_id"
  CATALOG_OFFER ||--o{ ANALYTICS_ANONYMOUS_EVENT : "offer_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_ANONYMOUS_EVENT : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "article_id"
  EDITORIAL_ARTICLE ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "article_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "article_version_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ ANALYTICS_ANONYMOUS_EVENT : "article_version_id"
  FINANCE_COMMISSION ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "commission_id"
  IAM_PRINCIPAL ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ ANALYTICS_DATA_QUALITY_FINDING : "resolved_by_principal_id"
  OPS_JOB ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "calculated_by_job_id"
  OPS_JOB ||--o{ ANALYTICS_IMPORT_RUN : "ops_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ ANALYTICS_IMPORT_RUN : "source_artifact_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_ANONYMOUS_EVENT : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_DATA_QUALITY_FINDING : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_GA4_OBSERVATION : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_GSC_OBSERVATION : "site_id"
  PORTFOLIO_SITE ||--o{ ANALYTICS_IMPORT_RUN : "site_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_AFFILIATE_CLICK_EVENT : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_ANONYMOUS_EVENT : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ ANALYTICS_DAILY_ARTICLE_METRIC : "publication_snapshot_id"
```

## 13. `finance` ER

```mermaid
erDiagram
  FINANCE_PARSER_VERSION {
    uuid id PK
  }
  FINANCE_REVENUE_IMPORT {
    uuid id PK
  }
  FINANCE_REVENUE_IMPORT_ROW {
    uuid id PK
  }
  FINANCE_COMMISSION {
    uuid id PK
  }
  FINANCE_COMMISSION_EVENT {
    uuid id PK
  }
  FINANCE_EXTERNAL_COST {
    uuid id PK
  }
  FINANCE_HUMAN_WORK_LOG {
    uuid id PK
  }
  FINANCE_ALLOCATION_RULE {
    uuid id PK
  }
  FINANCE_COST_ALLOCATION {
    uuid id PK
  }
  FINANCE_UNIT_ECONOMICS_SNAPSHOT {
    uuid id PK
  }
  AI_AI_JOB ||--o{ FINANCE_EXTERNAL_COST : "ai_job_id"
  EDITORIAL_ARTICLE ||--o{ FINANCE_EXTERNAL_COST : "article_id"
  EDITORIAL_ARTICLE ||--o{ FINANCE_HUMAN_WORK_LOG : "article_id"
  EDITORIAL_ARTICLE_VERSION ||--o{ FINANCE_HUMAN_WORK_LOG : "article_version_id"
  FINANCE_ALLOCATION_RULE ||--o{ FINANCE_COST_ALLOCATION : "allocation_rule_id"
  FINANCE_COMMISSION ||--o{ ANALYTICS_ATTRIBUTION_ESTIMATE : "commission_id"
  FINANCE_COMMISSION ||--o{ FINANCE_COMMISSION_EVENT : "commission_id"
  FINANCE_PARSER_VERSION ||--o{ FINANCE_REVENUE_IMPORT : "parser_version_id"
  FINANCE_REVENUE_IMPORT ||--o{ FINANCE_REVENUE_IMPORT_ROW : "revenue_import_id"
  FINANCE_REVENUE_IMPORT_ROW ||--o{ FINANCE_COMMISSION : "source_import_row_id"
  FINANCE_REVENUE_IMPORT_ROW ||--o{ FINANCE_COMMISSION_EVENT : "source_import_row_id"
  IAM_PRINCIPAL ||--o{ FINANCE_ALLOCATION_RULE : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_HUMAN_WORK_LOG : "approved_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_HUMAN_WORK_LOG : "principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_REVENUE_IMPORT : "confirmed_by_principal_id"
  IAM_PRINCIPAL ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "approved_by_principal_id"
  OPS_JOB ||--o{ FINANCE_COST_ALLOCATION : "calculated_by_job_id"
  OPS_JOB ||--o{ FINANCE_REVENUE_IMPORT : "ops_job_id"
  OPS_JOB ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "calculated_by_job_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_EXTERNAL_COST : "source_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_PARSER_VERSION : "fixture_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_PARSER_VERSION : "schema_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_REVENUE_IMPORT : "report_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_REVENUE_IMPORT : "source_artifact_id"
  OPS_OBJECT_ARTIFACT ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "report_artifact_id"
  PORTFOLIO_CATEGORY ||--o{ FINANCE_EXTERNAL_COST : "category_id"
  PORTFOLIO_CATEGORY ||--o{ FINANCE_HUMAN_WORK_LOG : "category_id"
  PORTFOLIO_SITE ||--o{ FINANCE_ALLOCATION_RULE : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_COMMISSION : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_EXTERNAL_COST : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_HUMAN_WORK_LOG : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_REVENUE_IMPORT : "site_id"
  PORTFOLIO_SITE ||--o{ FINANCE_UNIT_ECONOMICS_SNAPSHOT : "site_id"
```

## 14. `readmodel` ER

```mermaid
erDiagram
  READMODEL_PUBLIC_ARTICLE {
    uuid article_id PK
  }
  READMODEL_PUBLIC_ARTICLE_BLOCK {
    uuid id PK
  }
  READMODEL_PUBLIC_PRODUCT_CARD {
    uuid id PK
  }
  READMODEL_PUBLIC_OFFER {
    uuid id PK
  }
  READMODEL_PUBLIC_ROUTE {
    uuid site_id PK
    text path PK
  }
  READMODEL_RUNTIME_CONTROL {
    uuid id PK
  }
  CATALOG_CANONICAL_PRODUCT ||--o{ READMODEL_PUBLIC_PRODUCT_CARD : "product_id"
  CATALOG_OFFER ||--o{ READMODEL_PUBLIC_OFFER : "offer_id"
  CATALOG_SHOP ||--o{ READMODEL_PUBLIC_OFFER : "shop_id"
  EDITORIAL_ARTICLE ||--o{ READMODEL_PUBLIC_ARTICLE : "article_id"
  PORTFOLIO_SITE ||--o{ READMODEL_PUBLIC_ARTICLE : "site_id"
  PORTFOLIO_SITE ||--o{ READMODEL_PUBLIC_ROUTE : "site_id"
  PORTFOLIO_SITE ||--o{ READMODEL_RUNTIME_CONTROL : "site_id"
  PUBLISHING_PUBLICATION ||--o{ READMODEL_PUBLIC_ARTICLE : "publication_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_ARTICLE : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_ARTICLE_BLOCK : "publication_snapshot_id"
  PUBLISHING_PUBLICATION_SNAPSHOT ||--o{ READMODEL_PUBLIC_PRODUCT_CARD : "publication_snapshot_id"
  READMODEL_PUBLIC_ARTICLE ||--o{ READMODEL_PUBLIC_ARTICLE_BLOCK : "article_id"
  READMODEL_PUBLIC_ARTICLE ||--o{ READMODEL_PUBLIC_PRODUCT_CARD : "article_id"
  READMODEL_PUBLIC_ARTICLE ||--o{ READMODEL_PUBLIC_ROUTE : "article_id"
  READMODEL_PUBLIC_PRODUCT_CARD ||--o{ READMODEL_PUBLIC_OFFER : "public_product_card_id"
```

## 15. Publication lineage sequence

```mermaid
sequenceDiagram
  participant U as Human Reviewer
  participant API as Core API
  participant DB as PostgreSQL
  participant W as Worker
  participant OS as Object Storage
  participant WEB as Public Web
  U->>API: Final approval command
  API->>DB: INSERT publishing.approval
  DB-->>API: quality/source/human guard
  U->>API: Publish command + idempotency key
  API->>DB: INSERT publication_candidate + outbox
  W->>DB: Claim snapshot build job
  W->>DB: Read fixed article/evidence/policy/approval IDs
  W->>OS: Write immutable snapshot artifact
  W->>DB: Register artifact + snapshot + publication event
  W->>DB: Rebuild readmodel in transaction
  WEB->>DB: SELECT readmodel only
```
