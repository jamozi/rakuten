# RAOS-DATA-001 v0.1

このPackageは、RAOSの要件定義・システムアーキテクチャをPostgreSQLの実装正本へ変換したものです。

## Codexの読み順

1. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
2. `upstream/RAOS_01_requirements_catalog_v0.1.yaml`
3. `upstream/RAOS_02_system_architecture_v0.1.md`
4. `upstream/RAOS_02_architecture_catalog_v0.1.yaml`
5. `RAOS_03_data_model_database_design_v0.1.md`
6. `RAOS_03_data_catalog_v0.1.yaml`
7. `RAOS_03_migration_playbook_v0.1.md`
8. 対象Migration WaveのSQL/DDLとDQ rules

## Contents

- `13` schemas / `130` tables / `1772` columns
- `357` foreign keys / `406` indexes
- `549` check constraints / `55` data-quality rules
- PostgreSQL `18.4` baseline DDL
- DB roles and grants, deterministic RBAC seed, post-deploy validation
- ER diagrams, retention matrix, table inventory, requirement traceability
- Validation report, manifest, SHA-256 checksums

## Prohibited implementation shortcuts

- Do not store Rakuten review body or reviewer information.
- Do not place affiliate rate, commission, revenue, profit, or margin into editorial or public read models.
- Do not let AI approve or publish.
- Do not let the public renderer read internal schemas.
- Do not replace immutable publication snapshots with live joins.
- Do not treat estimated attribution as provider fact.
- Do not weaken DB constraints merely to satisfy ORM fixtures.
- Do not enable destructive retention jobs before legal/tax/privacy approval.

## Start point

Codexは`MIG-001`から一つのPR単位で実装します。全Waveの一括実装は禁止です。各PRでDDL、ORM、migration、tests、permission checks、catalog drift checkを揃えます。

## Validation limitation

このPackageでは静的モデル検査、DDL構造検査、YAML/CSV/ZIP/checksum検査を実施しています。実PostgreSQL 18.4への実行は、Codex実装CIの必須Acceptanceとして残しています。
