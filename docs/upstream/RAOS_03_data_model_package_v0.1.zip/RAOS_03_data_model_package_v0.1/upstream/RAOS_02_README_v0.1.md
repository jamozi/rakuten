# RAOS-ARCH-001 v0.1 — Codex投入パッケージ

## 1. パッケージの目的

本パッケージは、AI×楽天アフィリエイト運営OS（RAOS）のMVPを、Codexが段階的に実装するためのシステムアーキテクチャ基準です。上位の要件定義、設計本文、機械可読カタログ、Mermaid図集を同梱しています。

## 2. 読む順序

Codexは、次の順番で内容を読み、上位文書との矛盾がないことを確認してください。

1. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
2. `upstream/RAOS_01_requirements_catalog_v0.1.yaml`
3. `architecture/RAOS_02_system_architecture_v0.1.md`
4. `architecture/RAOS_02_architecture_catalog_v0.1.yaml`
5. `architecture/RAOS_02_architecture_diagrams_v0.1.md`
6. `manifest/VALIDATION_REPORT.txt`

矛盾時の優先順位は、上位要件定義、アーキテクチャ設計本文、アーキテクチャYAML、図集の順です。

## 3. 実装の開始方法

最初のPRは `SLICE-001 Repository Bootstrap` のみを対象としてください。複数スライスを一つのPRへまとめず、各スライスについて次を実施してください。

1. 対象スライス、関連FR/NFR、ADR、受入条件を列挙する。
2. 実装前に変更対象ファイルと設計上の判断を短く提示する。
3. コード、migration、test、fixture、observability、documentationを同じPRで整合させる。
4. 受入条件を自動テストへ変換する。
5. 設計変更が必要なら、コードより先にADR差分を提案する。
6. 完了時に、実行したコマンド、テスト結果、未解決事項、セキュリティ影響を報告する。

## 4. 変更してはならない基準

明示的な人間承認なしに、次の基準を緩和・回避してはなりません。

- AI単独公開の禁止
- 楽天レビュー本文の取得・保存・要約の禁止
- 正規アフィリエイトURLの改変禁止
- 広告表示とAPIクレジットの削除禁止
- 料率・収益を推薦順位へ入力することの禁止
- 公開サイトから下書き・秘密・原本へ到達させない境界
- immutable publication snapshot
- outbox/inboxと冪等consumer
- publication kill switchとaffiliate-link kill switchの分離
- 本番データを非本番へ複製しない原則
- MVPでKubernetes、Kafka、専用Vector DB、マイクロサービスを導入しない方針

変更が必要な場合は、影響する要求ID、リスク、代替統制、migration/rollbackを含む新ADRを作成してください。

## 5. 採用アーキテクチャの要約

- Web: Next.js / TypeScript
- Core API: FastAPI / Python
- Worker: Pythonの用途別worker
- DB: PostgreSQL（必要時のみpgvector）
- Artifact: S3互換オブジェクトストレージ
- Async: managed queue + DLQ、at-least-once、冪等consumer
- Deployment reference: AWS東京リージョン、ECS/Fargate、RDS、S3、SQS、EventBridge、CloudFront/WAF
- Content source of truth: RAOSネイティブ構造化コンテンツ
- Publication: hash付き不変snapshotからpublic projectionへ反映
- AI: provider adapter + schema-constrained output。DB、queue、publishへ直接アクセス不可

## 6. 文書の役割

| ファイル | 用途 |
|---|---|
| 要件定義Markdown | 目的、スコープ、成功条件、停止条件の正本 |
| 要求YAML | 要求IDとゲートを機械的に参照するためのカタログ |
| アーキテクチャMarkdown | コンポーネント、データフロー、障害・運用・セキュリティ設計の正本 |
| アーキテクチャYAML | ADR、module、container、SLO、実装sliceの機械可読カタログ |
| 図集 | Mermaid図のレビュー・転記用抽出版 |
| validation report | 構文・参照・完全性検査の結果 |
| package manifest | ファイル一覧、サイズ、ハッシュ、依存関係 |

## 7. 次に作成する正式設計

アーキテクチャ承認後の次工程は `RAOS-DATA-001` です。PostgreSQLの論理・物理データモデル、テーブル、制約、索引、履歴、PII分類、retention、migration、seed、data-quality ruleを確定します。
