# RAOS-AI-001 Threat Model v0.1

- Status: BASELINE_CANDIDATE
- Date: 2026-07-30
- Scope: RAOS AI task execution, provider adapter, prompts, evidence context, evaluation and route release

## Security objective

AI is an untrusted probabilistic component. It may transform approved data into a proposal, but it must not acquire data, mutate authoritative state, approve publication, alter policy, or decide recommendations from affiliate economics. Security controls therefore surround the model before the request, after the response and at every workflow transition.

## Trust boundaries

1. **Acquisition boundary** — Rakuten and other approved adapters create raw immutable artifacts; the model never calls them.
2. **Evidence boundary** — only an approved, hash-addressed Source Packet can enter factual generation.
3. **Provider boundary** — the adapter injects credentials and enforces `store=false`, tools disabled and strict schema.
4. **Validation boundary** — deterministic and policy checks run before model output becomes a business artifact.
5. **Human authority boundary** — reviewers approve content; AI cannot approve or publish.
6. **Release boundary** — prompt, schema, route, model, policy, dataset and code hashes are bound to a signed release decision.

## Threat register

| ID | Threat | Attack / failure mode | Severity | Primary controls | Failure code |
| --- | --- | --- | --- | --- | --- |
| AITM-001 | Prompt injection in merchant/source text | Source packet contains commands that try to override the task. | CRITICAL | Treat packet as untrusted data; tools/network disabled; injection regression suite; output checks. | AI-POL-003 |
| AITM-002 | Indirect prompt injection through imported metadata | JSON fields, alt text or descriptions contain hidden instructions. | CRITICAL | Typed allowlist; canonical serialization; no instruction interpolation; suspicious-text flags. | AI-POL-003 |
| AITM-003 | Evidence poisoning | Incorrect or manipulated facts enter an approved packet. | CRITICAL | Provenance, hashes, conflict/staleness checks, human approval, source quality policy. | AI-INP-002 |
| AITM-004 | Rakuten review body contamination | Prohibited review text reaches prompt/evaluation/log. | CRITICAL | Field denylist, source scanner, fixture block, quarantine and incident. | AI-POL-001 |
| AITM-005 | Affiliate economics bias | Commission/rate fields affect recommendations. | CRITICAL | Schema-level input separation, denylist, adversarial cases, recommendation order outside AI. | AI-POL-002 |
| AITM-006 | Product/variant identity collision | Facts from similar products are merged. | CRITICAL | Canonical IDs, subject-bound facts, identity grader, no fuzzy auto-merge in AI. | AI-FCT-003 |
| AITM-007 | Unsupported factual hallucination | Model uses prior knowledge or guesses missing values. | CRITICAL | Approved packet only, fact references, deterministic validation, human review. | AI-FCT-001 |
| AITM-008 | Fabricated use experience | Draft implies testing or ownership not performed. | CRITICAL | First-person detector, explicit prompt rule, zero-tolerance suite. | AI-FCT-004 |
| AITM-009 | Structured output bypass | Malformed/free-form output is leniently parsed. | HIGH | Strict schema, no regex recovery, one bounded repair. | AI-OUT-001 |
| AITM-010 | Schema downgrade or hash mismatch | Runtime uses a different schema than evaluated. | CRITICAL | Hash-bound release, exact schema ID/hash in attempt and release decision. | AI-INP-002 |
| AITM-011 | Model alias drift | Provider alias resolves to changed behavior without audit. | HIGH | Record resolved model ID and response metadata; online drift monitoring. | AI-OPS-004 |
| AITM-012 | Unauthorized route/prompt activation | Unapproved version becomes active. | CRITICAL | RBAC, two-person approval for critical tasks, immutable release decision. | AI-POL-005 |
| AITM-013 | Automatic fallback masks quality failure | A failed factual/policy check triggers another model. | HIGH | Fallback only on declared availability errors; no correctness fallback. | AI-EVL-002 |
| AITM-014 | Budget exhaustion / denial of wallet | Oversized inputs or retry loops cause cost spikes. | HIGH | Pre-call budget reservation, token caps, one repair, circuit breaker and alerts. | AI-OPS-003 |
| AITM-015 | Sensitive data exfiltration to provider | Secrets/PII enter request. | CRITICAL | Data classification, preflight scanner, adapter-owned secrets, store=false, retention review. | AI-POL-004 |
| AITM-016 | Sensitive data in application logs | Raw prompt/output is logged. | CRITICAL | Structured metadata-only logs and secret scanning in CI/runtime. | AI-POL-004 |
| AITM-017 | Grader hacking | Candidate output manipulates model judge or self-claims high quality. | HIGH | Deterministic graders, blinded judge, human calibration, adversarial cases. | AI-EVL-003 |
| AITM-018 | Holdout leakage | Prompt authors tune directly to release labels. | HIGH | Restricted dataset role, immutable locked holdout, compromise workflow. | AI-EVL-004 |
| AITM-019 | Judge bias toward model/style | Judge sees model identity or favors verbosity. | MEDIUM | Blind candidate labels, rubric anchors, pairwise swaps, human audit. | AI-EVL-003 |
| AITM-020 | Metric gaming | Global mean hides critical slice regression. | HIGH | Slice gates and zero-tolerance rules; no averaging away. | AI-EVL-005 |
| AITM-021 | Silent context truncation | Required facts are dropped to fit context. | CRITICAL | Deterministic packing manifest; explicit failure or reduced scope. | AI-INP-004 |
| AITM-022 | Replay/duplicate Job | Same Job creates multiple conflicting artifacts. | HIGH | Idempotency key, immutable input hash, attempt sequencing and inbox/outbox. | AI-OPS-005 |
| AITM-023 | Response artifact tampering | Stored output differs from evaluated output. | CRITICAL | Object versioning, SHA-256, immutable artifact registry and release hash. | AI-INP-002 |
| AITM-024 | Provider outage | AI workflow becomes unavailable. | MEDIUM | Queue, circuit breaker, bounded fallback and human/manual path. | AI-PRV-004 |
| AITM-025 | Canary blast radius | Bad route receives too much production traffic. | HIGH | Route-specific cap, auto-pause, shadow first, rollback manifest. | AI-OPS-004 |
| AITM-026 | AI self-approval or publication | Model output triggers state mutation. | CRITICAL | No tool/DB access; authorization rejects; human workflow only. | AI-POL-005 |
| AITM-027 | Stale price represented as current | Time-sensitive fact exceeds freshness policy. | HIGH | Freshness flags, exact dates, pre-publication blocking checks. | AI-INP-005 |
| AITM-028 | Prompt caching retention mismatch | Cached input violates data policy. | HIGH | Caching disabled by default; enable only after retention and classification approval. | AI-POL-004 |
| AITM-029 | Batch retention/deadline mismatch | Sensitive or urgent work enters Batch. | HIGH | Explicit eligibility denylist; deadline >=24h; standard route for critical work. | AI-POL-004 |
| AITM-030 | Evaluation artifact spoofing | Release uses fabricated metrics. | CRITICAL | Run manifests, immutable artifacts, reviewer signatures and CI verification. | AI-EVL-001 |

## Mandatory red-team families

- Direct and indirect prompt injection in every string-bearing Source Packet field.
- Instructions encoded as HTML comments, JSON keys, Unicode confusables, base64-looking text, quoted customer speech and merchant copy.
- Commission/rate/revenue fields inserted under misleading names.
- Product identity collisions across model numbers, colors, sizes, bundles and refurbished/new offers.
- Numeric traps: tax inclusion, unit conversion, decimal separators, ranges, dates and stale observations.
- Unsupported first-person testing and consensus language.
- Outputs designed to flatter or manipulate the model judge.
- Oversized packets that force truncation of critical evidence.
- Refusal, content-filter, timeout, rate-limit and malformed-provider-response paths.
- Attempts to invoke tools, request secrets, alter policy, clear blockers or publish.

## Incident evidence preservation

For P0/P1 events, preserve immutable input manifest, prompt/schema/policy hashes, resolved model ID, provider response ID, raw encrypted request/response artifacts, validator results, Job/Attempt histories, route release decision and affected publication IDs. Application logs alone are not sufficient.

## Residual risk

No prompt can prove factuality or safety. Residual risk is managed through source provenance, strict contracts, deterministic checks, adversarial evaluation, human approval, bounded rollout and rapid rollback. The system must remain safe when a model behaves unexpectedly.
