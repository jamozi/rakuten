# RAOS-AI-001 AI Architecture Diagrams v0.1

## 1. Bounded task context

```mermaid
flowchart LR
    A[Approved adapters] --> B[Raw immutable artifacts]
    B --> C[Normalized Facts]
    C --> D[Approved Source Packet]
    D --> E[Context assembler]
    P[Git prompt + schema + policy] --> E
    E --> R[Certified model route]
    R --> O[Structured output]
    O --> V[Deterministic + policy validation]
    V --> H[Human review]
    H -->|approved through publishing workflow| S[Article version / proposal artifact]
    R -. no tools / no DB / no web .-> X[Blocked authority]
```

## 2. AI Job lifecycle

```mermaid
stateDiagram-v2
    [*] --> REQUESTED
    REQUESTED --> VALIDATING_INPUT
    VALIDATING_INPUT --> QUEUED: gates pass
    VALIDATING_INPUT --> FAILED_TERMINAL: invalid contract
    VALIDATING_INPUT --> QUARANTINED: integrity/security
    QUEUED --> RUNNING
    RUNNING --> VALIDATING_OUTPUT
    RUNNING --> FAILED_RETRYABLE: transient provider
    FAILED_RETRYABLE --> RETRY_SCHEDULED
    RETRY_SCHEDULED --> QUEUED
    VALIDATING_OUTPUT --> AWAITING_HUMAN: valid proposal
    VALIDATING_OUTPUT --> FAILED_TERMINAL: contract/fact/policy
    VALIDATING_OUTPUT --> QUARANTINED: critical failure
    AWAITING_HUMAN --> SUCCEEDED: reviewed/accepted workflow result
    AWAITING_HUMAN --> FAILED_TERMINAL: rejected
```

## 3. Context packing

```mermaid
flowchart TD
    M[Signed input manifest] --> A{Allowlist / denylist}
    A -->|fail| Z[No provider call]
    A --> B[Resolve immutable artifacts]
    B --> C[Check approval, freshness, conflicts]
    C --> D[Rank required evidence by declared priority]
    D --> E[Estimate tokens]
    E -->|fits| F[Canonical JSON context]
    E -->|does not fit| G[Deterministic scope reduction]
    G --> H{All required facts retained?}
    H -->|yes| F
    H -->|no| Z
    F --> I[Input manifest hash]
```

## 4. Accuracy-first routing

```mermaid
flowchart TD
    T[Task request] --> G[Hard eligibility gates]
    G -->|none eligible| F[Fail without provider call]
    G --> C[Certified candidates]
    C --> Q[Quality and reliability floor]
    Q --> U[Utility: latency, cost, capacity, governance]
    U --> P[Primary route]
    P --> R{Provider result}
    R -->|availability error and allowed| B[Certified fallback]
    R -->|fact/policy/contract failure| X[Block; never fallback]
    B --> V[Full validation again]
    R -->|success| V
```

## 5. Output gates

```mermaid
flowchart LR
    O[Provider response] --> C[Completion/refusal check]
    C --> J[JSON parse]
    J --> S[Exact schema]
    S --> I[Resource IDs]
    I --> N[Numbers / units / dates]
    N --> P[Product identity]
    P --> F[Fact support]
    F --> Y[Policy / injection / secret scans]
    Y --> H[Human review or downstream proposal]
    C & J & S & I & N & P & F & Y -->|failure| B[Block / retry once / quarantine per taxonomy]
```

## 6. Evaluation and route release

```mermaid
flowchart TD
    D[Locked dataset version] --> E[Evaluation run]
    P[Prompt + schema + policy + code hashes] --> E
    R[Candidate route/model] --> E
    E --> G1[Deterministic graders]
    E --> G2[Human rubric]
    E --> G3[Calibrated judge where allowed]
    G1 & G2 & G3 --> M[Slice metrics + zero-tolerance checks]
    M -->|fail| K[Keep champion]
    M -->|pass| S[Shadow]
    S --> C[Bounded canary]
    C -->|online pass| A[Active]
    C -->|failure| RB[Pause and rollback]
```

## 7. Human evaluation

```mermaid
flowchart LR
    C[Blind case assignment] --> R1[Reviewer 1]
    C --> R2[Reviewer 2 for critical/sample]
    R1 & R2 --> D{Agreement?}
    D -->|yes| L[Locked label]
    D -->|no| A[Adjudicator]
    A --> L
    L --> J[Judge calibration / release metrics]
```

## 8. Critical incident

```mermaid
flowchart TD
    A[Critical alert] --> P[Auto-pause affected route]
    P --> E[Preserve artifacts and manifests]
    E --> I[Declare incident]
    I --> B[Determine blast radius]
    B --> R[Rollback to certified release]
    R --> C[Correct prompt/data/code/control]
    C --> X[Add sanitized regression cases]
    X --> V[Full evaluation and approval]
    V -->|approved| Y[Canary re-entry]
```

## 9. Governance data model proposal

```mermaid
erDiagram
    TASK_DEFINITION ||--o{ PROMPT_VERSION : has
    TASK_DEFINITION ||--o{ EVALUATION_SUITE : governs
    EVALUATION_DATASET_VERSION ||--o{ EVALUATION_CASE : contains
    EVALUATION_SUITE ||--o{ EVALUATION_RUN : executes
    EVALUATION_DATASET_VERSION ||--o{ EVALUATION_RUN : used_by
    EVALUATION_RUN ||--o{ EVALUATION_CASE_RESULT : produces
    EVALUATION_CASE ||--o{ EVALUATION_CASE_RESULT : evaluated_as
    EVALUATION_CASE_RESULT ||--o{ HUMAN_EVALUATION : labeled_by
    MODEL_ROUTE_VERSION ||--o{ JUDGE_CALIBRATION : calibrates
    EVALUATION_RUN ||--o{ RELEASE_DECISION : supports
    MODEL_ROUTE_VERSION ||--o{ RELEASE_DECISION : releases
```
