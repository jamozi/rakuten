# RAOS-AI-001 — AI Agent / Prompt / Routing / Evaluation Design v0.1

## Purpose

This package turns the RAOS AI layer into a bounded, auditable and testable subsystem. It defines typed AI tasks, code-managed prompts, strict output schemas, model routes, evaluation datasets, graders, release gates, human review, security controls, observability and staged implementation slices.

It does **not** authorize autonomous publication, policy clearance, financial ranking, unrestricted web access or direct database mutation by a model.

## Source-of-truth order

1. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
2. `upstream/RAOS_01_requirements_catalog_v0.1.yaml`
3. `upstream/RAOS_02_system_architecture_v0.1.md`
4. `upstream/RAOS_02_architecture_catalog_v0.1.yaml`
5. `upstream/RAOS_03_data_model_database_design_v0.1.md`
6. `upstream/RAOS_03_data_catalog_v0.1.yaml`
7. `upstream/RAOS_04_api_event_job_contract_design_v0.1.md`
8. `upstream/RAOS_04_job_catalog_v0.1.yaml`
9. `RAOS_05_ai_agent_prompt_routing_evaluation_design_v0.1.md`
10. Machine-readable RAOS-05 catalogs, prompts and JSON Schemas
11. `proposals/*` — proposal only; never silently overrides upstream contracts

When artifacts conflict, stop implementation, record the conflict and create an explicit versioned upstream revision. Do not choose a convenient interpretation.

## Recommended reading order

1. `RAOS_05_ai_agent_prompt_routing_evaluation_design_v0.1.md`
2. `RAOS_05_ai_task_catalog_v0.1.yaml`
3. `RAOS_05_prompt_registry_v0.1.yaml` and `prompts/*.md`
4. `RAOS_05_model_routing_catalog_v0.1.yaml`
5. `RAOS_05_evaluation_catalog_v0.1.yaml`
6. `RAOS_05_quality_gate_catalog_v0.1.yaml`
7. `RAOS_05_failure_taxonomy_v0.1.yaml`
8. `RAOS_05_human_review_rubric_v0.1.yaml`
9. `RAOS_05_threat_model_v0.1.md`
10. `RAOS_05_implementation_slices_v0.1.yaml`
11. `RAOS_05_CODEX_KICKOFF_v0.1.md`

## Package scale

| Item | Count |
|---|---:|
| Bounded AI tasks | 12 |
| Prompt templates | 12 |
| Model routes | 7 |
| Model candidates | 3 |
| Task output schemas | 12 |
| Evaluation schemas | 2 |
| Evaluation suites | 12 |
| Metrics | 31 |
| Graders | 10 |
| Quality gates | 10 |
| Failure codes | 35 |
| Threat scenarios | 30 |
| State machines | 6 |
| ADRs | 40 |
| Implementation slices | 18 |
| Bootstrap evaluation cases | 120 |
| Contract/evaluation tests | 537 |

## Important baseline decisions

- The OpenAI Responses API is the initial provider adapter boundary; provider-specific objects do not enter domain modules.
- Prompts are Git-managed executable configuration with typed variables, immutable hashes, tests and release decisions.
- All outputs use strict JSON Schema. A syntactically valid output is not considered factually or policy-valid by itself.
- Model selection is accuracy-first. Cost and latency are optimized only among candidates that passed the task's locked evaluation suite.
- Initial model names and prices are **candidate metadata as observed on 2026-07-30**, not permanent business logic. Runtime configuration and release records bind the resolved model ID.
- `store=false`, no tools and no network are the defaults. Provider data-retention controls still require account/endpoint review.
- Every publication remains subject to the existing deterministic checks and human approval workflow.
- The synthetic bootstrap dataset is a harness test only. It cannot certify a production model route.

## Upstream alignment findings

The actual RAOS-API-001 package defines seven AI-related Job contracts but only four AI-specific output schemas. It also has Job contracts for search-intent classification and policy assistance that were not represented as complete RAOS-AI task contracts. RAOS-AI-001 adds full task definitions and schemas and places required DB/API changes in `proposals/`.

- `proposals/RAOS_05_001_ai_data_alignment_patch_v0.1.sql`
- `proposals/RAOS_05_002_api_alignment_patch_v0.1.yaml`

These files are **design inputs**, not production-ready migrations or in-place OpenAPI edits.

## Directory map

```text
RAOS_05_ai_design_package_v0.1/
├── RAOS_05_*.md / *.yaml / *.csv
├── prompts/                 # 12 code-managed prompt templates
├── schemas/tasks/           # 12 strict task-output schemas
├── schemas/eval/            # evaluation case and judge schemas
├── fixtures/source_packets/ # adversarial and normal source packets
├── fixtures/expected/       # schema-smoke expected outputs
├── eval_cases/              # 120 bootstrap cases
├── proposals/               # upstream alignment proposals only
├── upstream/                # inherited requirements/architecture/data/API artifacts
├── manifest.json
└── SHA256SUMS.txt
```

## Validation boundary

Static validation covers YAML/JSON parsing, JSON Schema meta-validation, fixture validation, prompt/frontmatter/hash integrity, registry references, task-route-suite coverage, upstream copies, traceability, test counts, secret/review-body scans and package checksums. It does not replace:

- live OpenAI Responses API integration tests,
- PostgreSQL 18 migration/role/trigger tests,
- full OpenAPI/AsyncAPI regeneration and compatibility checks,
- production data-control/ZDR verification,
- human labeling and adjudicated production evaluation datasets,
- canary and rollback drills.

## Start implementation

Read `RAOS_05_CODEX_KICKOFF_v0.1.md`. Implement only `AI-SLICE-001` first. Do not implement all AI tasks or call a live model in the first PR.
