# RAOS-AI-001 AI Operations Runbook v0.1

## 1. Purpose

This runbook defines the operational response for AI route failures, provider incidents, factual/policy violations, evaluation failures and cost anomalies. Automatic actions may pause or reduce traffic; they must never automatically re-enable a route or waive a blocker.

## 2. Severity

| Severity | Definition | Initial action |
|---|---|---|
| P0 | Secret leak, prohibited review text, prompt injection followed, unauthorized publication/state change, material product mismatch at scale | Pause route immediately; declare incident; preserve artifacts |
| P1 | Unsupported critical claim, critical schema failure, product identity mismatch, repeated fabricated experience | Pause affected task/route; block dependent workflow |
| P2 | Provider error spike, cost anomaly, latency failure, noncritical regression | Stop canary or open circuit; investigate |
| P3 | Gradual acceptance decline, isolated low-risk defect | Create ticket and increase sampling |

## 3. First 15-minute checklist

1. Identify task, route version, prompt version, schema hash, resolved model ID and time window.
2. Pause the narrowest safe scope; use global AI pause if blast radius is unknown.
3. Confirm publication and affiliate-link Kill Switch status when user-facing risk exists.
4. Preserve input/output artifacts, manifests, provider response IDs, validation details and audit events.
5. Prevent retries for policy, evidence, contract and secret failures.
6. Query sibling attempts sharing the same Source Packet, prompt, schema, model and route.
7. Assign incident commander, technical owner, editorial/policy owner and recorder.

## 4. Failure-specific actions

### 4.1 Prompt injection followed (`AI-POL-003`)

- Pause the affected route and all routes sharing the prompt compiler or context assembler version.
- Do not sanitize and re-run the same request automatically.
- Compare rendered prompt boundaries and canonical JSON serialization.
- Add the sanitized attack to the adversarial dataset after incident review.
- Re-entry requires full critical suite, red-team subset and bounded canary.

### 4.2 Rakuten review body leakage (`AI-POL-001`)

- Quarantine both input and output artifacts.
- Trace acquisition, normalization, Source Packet and evaluation datasets.
- Remove contaminated data under the approved retention/incident procedure; preserve hashes and audit facts as legally permitted.
- Scan all prompts, fixtures and artifacts generated from the same import batch.
- Revoke route certification until contamination tests pass.

### 4.3 Affiliate bias (`AI-POL-002`)

- Inspect the input manifest for finance fields or derived proxies.
- Compare candidate output with the same editorial inputs after finance data is removed; this is diagnostic only, not an automatic repair.
- Verify recommendation order is enforced outside the model.
- Expand adversarial field-name tests.

### 4.4 Product identity mismatch (`AI-FCT-003`)

- Quarantine output and identify canonical product, variant and offer IDs.
- Inspect grouping decisions and Source Packet subject references.
- Block publication/update for affected product family until identity is resolved.
- Run sibling-output search for the same collision pattern.

### 4.5 Provider outage / rate limit

- Open route circuit after configured threshold.
- Allow only declared certified fallback and only for availability failures.
- Preserve Job deadline; do not increase cost/token budget automatically.
- Critical publication work may remain queued or be completed manually.

### 4.6 Cost anomaly

- Stop challenger and nonessential Batch/offline workloads first.
- Inspect prompt/context size, retry count, output cap, cache telemetry and model resolution.
- Do not switch to a cheaper model without the task quality floor and release decision.

### 4.7 Evaluation or judge failure

- A zero-tolerance case failure blocks release immediately.
- If judge calibration expires/fails, use human grading; do not block operational fixes waiting for the judge.
- If holdout contamination occurs, mark the dataset compromised and create a new locked version.

## 5. Rollback

Rollback targets the last `APPROVED_ACTIVE` release decision for the same task and environment. The rollback must restore route, prompt, output schema, policy bundle and code version as a coherent set. Partial rollback is prohibited unless separately evaluated.

## 6. Re-entry criteria

- Root cause and blast radius documented.
- Corrective control implemented and reviewed.
- Sanitized incident cases added to regression/adversarial data.
- Required task suite passes with zero critical failures.
- Critical tasks receive two-person release approval.
- Shadow results pass, then canary remains within route cap.
- Online sampling and alerts are confirmed active.

## 7. Routine operations

| Cadence | Activity |
|---|---|
| Daily | Provider errors, cost, zero-tolerance counters, queue/dead-letter review |
| Weekly | Human acceptance/edit-distance slices, sampled output review, incident regression status |
| Monthly | Route economics after quality floor, dataset distribution review, model/pricing metadata refresh |
| Quarterly | Judge recalibration, threat-model/red-team refresh, retention and access review |
| On every change | Prompt/schema/route eval, compatibility checks, release manifest and rollback reference |

## 8. Evidence required to close an incident

Incident timeline, affected IDs, route/prompt/schema/model hashes, artifact hashes, validation findings, publication/affiliate impact, corrective PR, regression case IDs, evaluation run, approver decisions, canary evidence and final monitoring status.
