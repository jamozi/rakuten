# RAOS-ARCH-001 アーキテクチャ図集

**版**: v0.1 Draft  
**基準日**: 2026-07-30  
**図数**: 13  
**正本**: `RAOS_02_system_architecture_v0.1.md`

本ファイルは、Codex、設計レビュー、README転記用にMermaid図だけを抽出したものです。図の意味と制約は正本の本文を優先します。

## 図一覧

1. 4.3 System Context Diagram
2. 6.1 Container Diagram
3. 8.13 データ系統
4. 10.6 Workflow 1：商品取得
5. 10.8 Workflow 3：AI Draft生成
6. 10.10 Workflow 5：公開
7. 10.14 Workflow 9：成果取込と採算
8. 14.2 AWS基準Topology
9. C.1 Article
10. C.2 Source Packet
11. C.3 Publication
12. C.4 Commission
13. C.5 Incident

---

## Diagram 1: 4.3 System Context Diagram

```mermaid
flowchart LR
    Visitor[一般訪問者]
    Staff[PO・編集・レビュー・運用]
    RAOS[RAOS]
    RakutenAPI[楽天Web Service]
    RakutenReport[楽天成果レポート]
    GSC[Google Search Console]
    GA[Google Analytics]
    LLM[OpenAI / LLM Provider]
    KWP[許諾済みKeyword・Rank Provider]
    Primary[メーカー等一次情報]
    IdP[OIDC Identity Provider]
    Notify[通知サービス]

    Visitor -->|HTTPS 閲覧・直接Affiliate Link| RAOS
    Staff -->|HTTPS 管理操作| RAOS
    RAOS -->|商品・ジャンル取得| RakutenAPI
    RakutenReport -->|CSV / 将来Adapter| RAOS
    RAOS -->|検索分析Query| GSC
    RAOS -->|集計Query| GA
    RAOS -->|構造化生成要求| LLM
    RAOS -->|許諾済みQuery| KWP
    RAOS -->|Allowlist Fetch / 手動Source| Primary
    RAOS <-->|OIDC/OAuth| IdP
    RAOS -->|Alert| Notify
```

## Diagram 2: 6.1 Container Diagram

```mermaid
flowchart TB
    subgraph Internet
      Visitor[一般訪問者]
      Staff[管理ユーザー]
    end

    CDN[CDN + WAF]
    Web[Web Container\nNext.js]
    API[Core API Container\nFastAPI]
    Worker[Worker Containers\nPython]
    Scheduler[Managed Scheduler]
    Queue[Managed Queue + DLQ]
    DB[(PostgreSQL)]
    Obj[(Object Storage)]
    IdP[OIDC IdP]
    Obs[Logs / Metrics / Traces]
    Ext[楽天・Google・OpenAI・一次情報]

    Visitor --> CDN --> Web
    Staff --> CDN --> Web
    Web -->|Public/Admin REST| API
    Web <-->|OIDC| IdP
    API --> DB
    API --> Obj
    API --> Queue
    Scheduler --> Queue
    Queue --> Worker
    Worker --> DB
    Worker --> Obj
    Worker --> Ext
    Worker --> Queue
    API --> Obs
    Web --> Obs
    Worker --> Obs
```

## Diagram 3: 8.13 データ系統

```mermaid
flowchart LR
    Raw[Raw Source Snapshot] --> Fact[Normalized Fact]
    Fact --> Packet[Source Packet Version]
    Packet --> AI[AI Attempt]
    AI --> Claim[Claim Draft]
    Claim --> Review[Human Review]
    Review --> Version[Approved Article Version]
    Version --> Snapshot[Publication Snapshot]
    Snapshot --> Page[Public Page]
    Page --> Click[Outbound Click Event]
    Click --> Attribution[Attribution / Estimate]
    Report[Rakuten Commission Import] --> Attribution
    Attribution --> Profit[Unit Economics]
```

## Diagram 4: 10.6 Workflow 1：商品取得

```mermaid
sequenceDiagram
    participant U as Editor
    participant API as Core API
    participant DB as PostgreSQL
    participant Q as Queue
    participant W as Worker
    participant R as Rakuten API
    participant O as Object Storage

    U->>API: 商品取得Command
    API->>DB: Job + OutboxをTransaction保存
    API-->>U: 202 Accepted / Job ID
    DB->>Q: Outbox Dispatcher
    Q->>W: Ingestion Job
    W->>R: API Request
    R-->>W: Response
    W->>O: Raw Response保存
    W->>DB: Observation/Normalization/InboxをTransaction保存
    W->>DB: catalog.raw_ingested Event
```

## Diagram 5: 10.8 Workflow 3：AI Draft生成

```mermaid
sequenceDiagram
    participant E as Editor
    participant API as Core API
    participant Q as AI Queue
    participant W as AI Worker
    participant L as LLM Provider
    participant P as Policy Engine
    participant DB as PostgreSQL
    participant O as Object Storage

    E->>API: Generate Draft
    API->>DB: Packet Approved確認・Job登録
    API->>Q: Outbox経由
    Q->>W: AI Job
    W->>O: Source Packet取得・hash検証
    W->>L: Prompt + Schema + Packet
    L-->>W: Structured Result
    W->>O: Raw Input/Output保存
    W->>P: Deterministic/AI-assisted Check
    P-->>W: Findings
    W->>DB: Draft Version + Claims + Cost + Findings
    DB-->>E: Review Queue更新
```

## Diagram 6: 10.10 Workflow 5：公開

```mermaid
sequenceDiagram
    participant R as Reviewer
    participant API as Core API
    participant DB as PostgreSQL
    participant Q as Publication Queue
    participant W as Publish Worker
    participant O as Object Storage
    participant RM as Public Read Model
    participant CDN as CDN

    R->>API: Publish Approved Version
    API->>DB: Approval/Policy/Kill Switch再確認
    API->>DB: Publication Job + Outbox
    DB->>Q: Dispatch
    Q->>W: Publish Job
    W->>DB: VersionとCurrent State再確認
    W->>W: Render Schema/Link/Disclosure検査
    W->>O: Publication Snapshot保存
    W->>RM: Public Projection更新
    W->>CDN: Tag/Path Invalidation
    W->>DB: Publication Succeeded
```

## Diagram 7: 10.14 Workflow 9：成果取込と採算

```mermaid
flowchart LR
    Upload[成果CSV Upload] --> Scan[検査・重複判定]
    Scan --> Preview[Dry Run Preview]
    Preview --> Approve{人間確認}
    Approve -- Reject --> Quarantine[隔離]
    Approve -- Approve --> Import[Canonical Import]
    Import --> Reconcile[合計・期間突合]
    Reconcile --> Attribute[帰属 Fact / Estimate]
    Attribute --> Cost[Job・人件費配賦]
    Cost --> Economics[EPC・RPM・貢献利益]
```

## Diagram 8: 14.2 AWS基準Topology

```mermaid
flowchart TB
    DNS[Route 53 / DNS]
    CDN[CloudFront + WAF + TLS]
    ALB[Application Load Balancer]
    Web[ECS Fargate Web]
    API[ECS Fargate API]
    Worker[ECS Fargate Workers]
    Event[EventBridge Scheduler]
    SQS[SQS Queues + DLQ]
    RDS[(RDS PostgreSQL)]
    S3[(S3 Versioned Buckets)]
    Cognito[Cognito / OIDC]
    Secrets[Secrets Manager]
    Obs[CloudWatch + OpenTelemetry]
    ECR[ECR]
    GH[GitHub Actions via OIDC]

    DNS --> CDN --> ALB
    ALB --> Web
    ALB --> API
    Web <--> Cognito
    API --> RDS
    API --> S3
    API --> SQS
    Event --> SQS
    SQS --> Worker
    Worker --> RDS
    Worker --> S3
    Worker --> Secrets
    API --> Secrets
    Web --> Obs
    API --> Obs
    Worker --> Obs
    GH --> ECR
    GH -->|Terraform / Deploy| Web
    GH --> API
    GH --> Worker
```

## Diagram 9: C.1 Article

```mermaid
stateDiagram-v2
    [*] --> IDEA
    IDEA --> PLANNED
    PLANNED --> SOURCES_PENDING
    SOURCES_PENDING --> PACKET_READY
    PACKET_READY --> GENERATING
    GENERATING --> DRAFT
    DRAFT --> AUTO_REVIEW
    AUTO_REVIEW --> HUMAN_REVIEW
    HUMAN_REVIEW --> DRAFT: changes requested
    HUMAN_REVIEW --> APPROVED
    APPROVED --> SCHEDULED
    APPROVED --> PUBLISHED
    SCHEDULED --> PUBLISHED
    PUBLISHED --> UPDATE_PENDING
    UPDATE_PENDING --> HUMAN_REVIEW
    PUBLISHED --> PAUSED
    PAUSED --> PUBLISHED
    PUBLISHED --> ARCHIVED
    PAUSED --> ARCHIVED
```

## Diagram 10: C.2 Source Packet

```mermaid
stateDiagram-v2
    [*] --> BUILDING
    BUILDING --> INVALID
    BUILDING --> READY
    READY --> IN_REVIEW
    IN_REVIEW --> BUILDING: changes requested
    IN_REVIEW --> APPROVED
    APPROVED --> SUPERSEDED
    INVALID --> BUILDING
```

## Diagram 11: C.3 Publication

```mermaid
stateDiagram-v2
    [*] --> REQUESTED
    REQUESTED --> VALIDATING
    VALIDATING --> BLOCKED
    VALIDATING --> SNAPSHOTTING
    SNAPSHOTTING --> DEPLOYING
    DEPLOYING --> PUBLISHED
    DEPLOYING --> FAILED
    PUBLISHED --> ROLLBACK_REQUESTED
    ROLLBACK_REQUESTED --> PUBLISHED
    PUBLISHED --> PAUSED
    PAUSED --> PUBLISHED
    PAUSED --> ARCHIVED
```

## Diagram 12: C.4 Commission

```mermaid
stateDiagram-v2
    [*] --> IMPORTED
    IMPORTED --> GENERATED
    GENERATED --> CONFIRMED
    GENERATED --> CANCELLED
    CONFIRMED --> ADJUSTED
    CANCELLED --> ADJUSTED
```

## Diagram 13: C.5 Incident

```mermaid
stateDiagram-v2
    [*] --> DECLARED
    DECLARED --> CONTAINING
    CONTAINING --> CONTAINED
    CONTAINED --> RECOVERING
    RECOVERING --> MONITORING
    MONITORING --> CLOSED
    CLOSED --> REOPENED
    REOPENED --> CONTAINING
```

