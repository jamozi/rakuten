-- RAOS-DATA-001 PostgreSQL baseline DDL
-- Version 0.1; generated 2026-07-30; target PostgreSQL 18.4
-- Execute through the approved migration tool with a dedicated migrator role.
BEGIN;
SET LOCAL TIME ZONE 'UTC';
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '15min';
DO $$ BEGIN IF current_setting('server_version_num')::integer < 180000 THEN RAISE EXCEPTION 'RAOS requires PostgreSQL 18 or later'; END IF; END $$;

CREATE SCHEMA IF NOT EXISTS ops;
COMMENT ON SCHEMA ops IS 'ジョブ、原本レジストリ、監査、障害、Kill Switch、実行時設定';
CREATE SCHEMA IF NOT EXISTS iam;
COMMENT ON SCHEMA iam IS 'OIDC主体、アプリケーションRole、権限、緊急アクセス';
CREATE SCHEMA IF NOT EXISTS portfolio;
COMMENT ON SCHEMA portfolio IS 'サイト、カテゴリ、検索意図、キーワード、機会評価、優先アクション';
CREATE SCHEMA IF NOT EXISTS catalog;
COMMENT ON SCHEMA catalog IS '楽天取得、商品同定、ショップ、Offer、外部事実Observation、Current Projection';
CREATE SCHEMA IF NOT EXISTS evidence;
COMMENT ON SCHEMA evidence IS 'Source、Snapshot、Fact、Source Packet、Claim、根拠対応';
CREATE SCHEMA IF NOT EXISTS editorial;
COMMENT ON SCHEMA editorial IS '記事企画、構造化記事版、比較、推薦、レビューコメント、内部リンク';
CREATE SCHEMA IF NOT EXISTS ai;
COMMENT ON SCHEMA ai IS 'AI Task、Prompt、Schema、Model Route、Job、Attempt、Token・費用、評価';
CREATE SCHEMA IF NOT EXISTS policy;
COMMENT ON SCHEMA policy IS 'Policy Bundle、Rule、品質検査、Finding、Score、Waiver、Gate';
CREATE SCHEMA IF NOT EXISTS publishing;
COMMENT ON SCHEMA publishing IS '人間Review、Approval、Publication Snapshot、公開状態、Route、Rollback';
CREATE SCHEMA IF NOT EXISTS freshness;
COMMENT ON SCHEMA freshness IS '鮮度SLA、Refresh、Staleness、Affiliate Link検査、影響分析';
CREATE SCHEMA IF NOT EXISTS analytics;
COMMENT ON SCHEMA analytics IS '匿名行動、楽天クリック、GSC・GA4取込、帰属推定、日次指標';
CREATE SCHEMA IF NOT EXISTS finance;
COMMENT ON SCHEMA finance IS '成果原本取込、発生・確定・取消、費用配賦、確定ユニットエコノミクス';
CREATE SCHEMA IF NOT EXISTS readmodel;
COMMENT ON SCHEMA readmodel IS '公開Rendererが読む安全な再生成可能Projection';

CREATE TABLE ops.object_artifact (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    artifact_kind text NOT NULL,
    storage_provider text DEFAULT 's3' NOT NULL,
    bucket_name text NOT NULL,
    object_key text NOT NULL,
    object_version text,
    content_type text NOT NULL,
    byte_size bigint NOT NULL,
    sha256 text NOT NULL,
    encryption_state text NOT NULL,
    retention_class text NOT NULL,
    is_immutable boolean DEFAULT true NOT NULL,
    source_system text NOT NULL,
    acquired_at timestamptz,
    created_by_principal_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_object_artifact PRIMARY KEY (id),
    CONSTRAINT uq_ops_object_artifact_display_id UNIQUE (display_id),
    CONSTRAINT ck_ops_object_artifact_kind CHECK (artifact_kind IN ('raw_provider_response', 'raw_primary_source', 'source_snapshot', 'source_packet', 'ai_input', 'ai_output', 'publication_snapshot', 'revenue_original', 'revenue_rejects', 'audit_export', 'quality_report', 'diff', 'import_report', 'other')),
    CONSTRAINT ck_ops_object_artifact_size CHECK (byte_size >= 0),
    CONSTRAINT ck_ops_object_artifact_sha CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_object_artifact_enc CHECK (encryption_state IN ('SSE_KMS', 'SSE_S3', 'LOCAL_DEV')),
    CONSTRAINT ck_ops_object_artifact_meta CHECK (jsonb_typeof(metadata) = 'object')
);
COMMENT ON TABLE ops.object_artifact IS 'S3互換Object Storage上の原本・入力・出力・公開Snapshotを登録する不変レジストリ。';
COMMENT ON COLUMN ops.object_artifact.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.object_artifact.display_id IS 'OBJ-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ops.object_artifact.artifact_kind IS 'raw_provider_response、source_snapshot、source_packet、ai_input、ai_output、publication_snapshot、revenue_original、audit_export等。';
COMMENT ON COLUMN ops.object_artifact.storage_provider IS 'storage provider';
COMMENT ON COLUMN ops.object_artifact.bucket_name IS 'bucket name';
COMMENT ON COLUMN ops.object_artifact.object_key IS 'object key';
COMMENT ON COLUMN ops.object_artifact.object_version IS 'Object VersioningのVersion ID。ローカル環境ではNULL可。';
COMMENT ON COLUMN ops.object_artifact.content_type IS 'content type';
COMMENT ON COLUMN ops.object_artifact.byte_size IS 'byte size';
COMMENT ON COLUMN ops.object_artifact.sha256 IS 'sha256';
COMMENT ON COLUMN ops.object_artifact.encryption_state IS 'encryption state';
COMMENT ON COLUMN ops.object_artifact.retention_class IS 'retention class';
COMMENT ON COLUMN ops.object_artifact.is_immutable IS 'is immutable';
COMMENT ON COLUMN ops.object_artifact.source_system IS 'source system';
COMMENT ON COLUMN ops.object_artifact.acquired_at IS 'acquired at';
COMMENT ON COLUMN ops.object_artifact.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN ops.object_artifact.metadata IS 'Objectタグ、parser、provider request ID等。秘密・原本文は含めない。';
COMMENT ON COLUMN ops.object_artifact.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.job (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    job_type text NOT NULL,
    queue_name text NOT NULL,
    status text DEFAULT 'PENDING' NOT NULL,
    priority smallint DEFAULT 50 NOT NULL,
    idempotency_key text,
    site_id uuid,
    aggregate_type text,
    aggregate_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    payload_artifact_id uuid,
    scheduled_at timestamptz,
    available_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamptz,
    completed_at timestamptz,
    max_attempts smallint DEFAULT 5 NOT NULL,
    attempt_count smallint DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamptz,
    correlation_id uuid DEFAULT uuidv7() NOT NULL,
    causation_id uuid,
    parent_job_id uuid,
    budget_jpy bigint,
    created_by_actor_type text NOT NULL,
    created_by_actor_id uuid,
    last_error_class text,
    last_error_code text,
    last_error_message text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_ops_job PRIMARY KEY (id),
    CONSTRAINT uq_ops_job_display_id UNIQUE (display_id),
    CONSTRAINT ck_ops_job_status CHECK (status IN ('PENDING', 'READY', 'RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'QUARANTINED')),
    CONSTRAINT ck_ops_job_priority CHECK (priority BETWEEN 0 AND 100),
    CONSTRAINT ck_ops_job_attempts CHECK (max_attempts BETWEEN 1 AND 50 AND attempt_count BETWEEN 0 AND max_attempts),
    CONSTRAINT ck_ops_job_budget CHECK (budget_jpy IS NULL OR budget_jpy >= 0),
    CONSTRAINT ck_ops_job_payload CHECK (jsonb_typeof(payload) = 'object'),
    CONSTRAINT ck_ops_job_lease_pair CHECK ((lease_owner IS NULL) = (lease_expires_at IS NULL)),
    CONSTRAINT ck_ops_job_completion CHECK (status NOT IN ('SUCCEEDED','FAILED','CANCELLED','QUARANTINED') OR completed_at IS NOT NULL),
    CONSTRAINT ck_ops_job_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE ops.job IS '非同期作業の業務上の正本。Scheduler、API、Eventから作成され、Attemptとは分離する。';
COMMENT ON COLUMN ops.job.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.job.display_id IS 'JOB-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ops.job.job_type IS 'job type';
COMMENT ON COLUMN ops.job.queue_name IS 'queue name';
COMMENT ON COLUMN ops.job.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.job.priority IS 'priority';
COMMENT ON COLUMN ops.job.idempotency_key IS 'idempotency key';
COMMENT ON COLUMN ops.job.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN ops.job.aggregate_type IS 'aggregate type';
COMMENT ON COLUMN ops.job.aggregate_id IS 'aggregate id';
COMMENT ON COLUMN ops.job.payload IS '小さなCommand payload。大容量入力はpayload_artifact_idへ分離する。';
COMMENT ON COLUMN ops.job.payload_artifact_id IS 'payload artifact id';
COMMENT ON COLUMN ops.job.scheduled_at IS 'scheduled at';
COMMENT ON COLUMN ops.job.available_at IS 'available at';
COMMENT ON COLUMN ops.job.started_at IS 'started at';
COMMENT ON COLUMN ops.job.completed_at IS 'completed at';
COMMENT ON COLUMN ops.job.max_attempts IS 'max attempts';
COMMENT ON COLUMN ops.job.attempt_count IS 'attempt count';
COMMENT ON COLUMN ops.job.lease_owner IS 'lease owner';
COMMENT ON COLUMN ops.job.lease_expires_at IS 'lease expires at';
COMMENT ON COLUMN ops.job.correlation_id IS '要求・Job・Eventを横断して追跡するCorrelation ID。';
COMMENT ON COLUMN ops.job.causation_id IS 'この事実を直接発生させたCommand/Event/Job ID。';
COMMENT ON COLUMN ops.job.parent_job_id IS 'parent job id';
COMMENT ON COLUMN ops.job.budget_jpy IS 'budget jpy';
COMMENT ON COLUMN ops.job.created_by_actor_type IS 'created by actor type';
COMMENT ON COLUMN ops.job.created_by_actor_id IS 'created by actor id';
COMMENT ON COLUMN ops.job.last_error_class IS 'last error class';
COMMENT ON COLUMN ops.job.last_error_code IS 'last error code';
COMMENT ON COLUMN ops.job.last_error_message IS 'last error message';
COMMENT ON COLUMN ops.job.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.job.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.job.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE ops.job_attempt (
    id uuid DEFAULT uuidv7() NOT NULL,
    job_id uuid NOT NULL,
    attempt_no smallint NOT NULL,
    status text NOT NULL,
    worker_id text NOT NULL,
    handler_version text NOT NULL,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    provider_request_id text,
    input_artifact_id uuid,
    output_artifact_id uuid,
    error_class text,
    error_code text,
    error_message text,
    retry_after_at timestamptz,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_job_attempt PRIMARY KEY (id),
    CONSTRAINT uq_ops_job_attempt_no UNIQUE (job_id, attempt_no),
    CONSTRAINT ck_ops_job_attempt_status CHECK (status IN ('RUNNING', 'SUCCEEDED', 'FAILED', 'CANCELLED', 'TIMED_OUT')),
    CONSTRAINT ck_ops_job_attempt_no CHECK (attempt_no >= 1),
    CONSTRAINT ck_ops_job_attempt_metrics CHECK (jsonb_typeof(metrics) = 'object'),
    CONSTRAINT ck_ops_job_attempt_end CHECK (status = 'RUNNING' OR completed_at IS NOT NULL)
);
COMMENT ON TABLE ops.job_attempt IS 'Jobの各実行Attemptを追記保存し、Retry、Provider call、入出力Artifact、失敗原因を再現可能にする。';
COMMENT ON COLUMN ops.job_attempt.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.job_attempt.job_id IS '非同期Job。';
COMMENT ON COLUMN ops.job_attempt.attempt_no IS 'attempt no';
COMMENT ON COLUMN ops.job_attempt.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.job_attempt.worker_id IS 'worker id';
COMMENT ON COLUMN ops.job_attempt.handler_version IS 'handler version';
COMMENT ON COLUMN ops.job_attempt.started_at IS 'started at';
COMMENT ON COLUMN ops.job_attempt.completed_at IS 'completed at';
COMMENT ON COLUMN ops.job_attempt.provider_request_id IS 'provider request id';
COMMENT ON COLUMN ops.job_attempt.input_artifact_id IS 'input artifact id';
COMMENT ON COLUMN ops.job_attempt.output_artifact_id IS 'output artifact id';
COMMENT ON COLUMN ops.job_attempt.error_class IS 'error class';
COMMENT ON COLUMN ops.job_attempt.error_code IS 'error code';
COMMENT ON COLUMN ops.job_attempt.error_message IS 'error message';
COMMENT ON COLUMN ops.job_attempt.retry_after_at IS 'retry after at';
COMMENT ON COLUMN ops.job_attempt.metrics IS 'Duration、row count、provider quota等の低カーディナリティ指標。';
COMMENT ON COLUMN ops.job_attempt.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.outbox_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    event_type text NOT NULL,
    event_version integer DEFAULT 1 NOT NULL,
    producer text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id uuid NOT NULL,
    aggregate_version bigint NOT NULL,
    correlation_id uuid NOT NULL,
    causation_id uuid,
    actor_type text NOT NULL,
    actor_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    payload_schema_hash text NOT NULL,
    status text DEFAULT 'PENDING' NOT NULL,
    available_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    published_at timestamptz,
    publish_attempts smallint DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_outbox_event PRIMARY KEY (id),
    CONSTRAINT ck_ops_outbox_event_version CHECK (event_version >= 1 AND aggregate_version >= 0),
    CONSTRAINT ck_ops_outbox_payload CHECK (jsonb_typeof(payload) = 'object'),
    CONSTRAINT ck_ops_outbox_hash CHECK (payload_schema_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_outbox_status CHECK (status IN ('PENDING', 'DISPATCHING', 'PUBLISHED', 'FAILED', 'DEAD')),
    CONSTRAINT ck_ops_outbox_attempts CHECK (publish_attempts >= 0),
    CONSTRAINT ck_ops_outbox_published CHECK (status <> 'PUBLISHED' OR published_at IS NOT NULL)
);
COMMENT ON TABLE ops.outbox_event IS '業務TransactionとEvent発行を原子的に接続するTransactional Outbox。';
COMMENT ON COLUMN ops.outbox_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.outbox_event.event_type IS 'event type';
COMMENT ON COLUMN ops.outbox_event.event_version IS 'event version';
COMMENT ON COLUMN ops.outbox_event.producer IS 'producer';
COMMENT ON COLUMN ops.outbox_event.aggregate_type IS 'aggregate type';
COMMENT ON COLUMN ops.outbox_event.aggregate_id IS 'aggregate id';
COMMENT ON COLUMN ops.outbox_event.aggregate_version IS 'aggregate version';
COMMENT ON COLUMN ops.outbox_event.correlation_id IS '要求・Job・Eventを横断して追跡するCorrelation ID。';
COMMENT ON COLUMN ops.outbox_event.causation_id IS 'この事実を直接発生させたCommand/Event/Job ID。';
COMMENT ON COLUMN ops.outbox_event.actor_type IS 'actor type';
COMMENT ON COLUMN ops.outbox_event.actor_id IS 'actor id';
COMMENT ON COLUMN ops.outbox_event.payload IS 'Version付きEvent payload。秘密・大容量原本を含めない。';
COMMENT ON COLUMN ops.outbox_event.payload_schema_hash IS 'payload schema hash';
COMMENT ON COLUMN ops.outbox_event.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.outbox_event.available_at IS 'available at';
COMMENT ON COLUMN ops.outbox_event.published_at IS 'published at';
COMMENT ON COLUMN ops.outbox_event.publish_attempts IS 'publish attempts';
COMMENT ON COLUMN ops.outbox_event.last_error IS 'last error';
COMMENT ON COLUMN ops.outbox_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.inbox_receipt (
    id uuid DEFAULT uuidv7() NOT NULL,
    consumer_name text NOT NULL,
    handler_version text NOT NULL,
    event_id uuid NOT NULL,
    status text NOT NULL,
    received_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamptz,
    result_hash text,
    error_code text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_inbox_receipt PRIMARY KEY (id),
    CONSTRAINT uq_ops_inbox_receipt UNIQUE (consumer_name, handler_version, event_id),
    CONSTRAINT ck_ops_inbox_status CHECK (status IN ('PROCESSING', 'PROCESSED', 'FAILED', 'IGNORED')),
    CONSTRAINT ck_ops_inbox_hash CHECK (result_hash IS NULL OR result_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_inbox_processed CHECK (status = 'PROCESSING' OR processed_at IS NOT NULL)
);
COMMENT ON TABLE ops.inbox_receipt IS 'Consumer単位でEvent処理済みを記録し、at-least-once配送の重複を無害化する。';
COMMENT ON COLUMN ops.inbox_receipt.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.inbox_receipt.consumer_name IS 'consumer name';
COMMENT ON COLUMN ops.inbox_receipt.handler_version IS 'handler version';
COMMENT ON COLUMN ops.inbox_receipt.event_id IS 'event id';
COMMENT ON COLUMN ops.inbox_receipt.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.inbox_receipt.received_at IS 'received at';
COMMENT ON COLUMN ops.inbox_receipt.processed_at IS 'processed at';
COMMENT ON COLUMN ops.inbox_receipt.result_hash IS 'result hash';
COMMENT ON COLUMN ops.inbox_receipt.error_code IS 'error code';
COMMENT ON COLUMN ops.inbox_receipt.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.idempotency_record (
    id uuid DEFAULT uuidv7() NOT NULL,
    actor_fingerprint text NOT NULL,
    route_key text NOT NULL,
    idempotency_key text NOT NULL,
    request_hash text NOT NULL,
    status text DEFAULT 'IN_PROGRESS' NOT NULL,
    response_status integer,
    response_body jsonb,
    response_artifact_id uuid,
    resource_type text,
    resource_id uuid,
    expires_at timestamptz NOT NULL,
    completed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_idempotency_record PRIMARY KEY (id),
    CONSTRAINT uq_ops_idempotency UNIQUE (actor_fingerprint, route_key, idempotency_key),
    CONSTRAINT ck_ops_idem_request_hash CHECK (request_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_idem_status CHECK (status IN ('IN_PROGRESS', 'COMPLETED', 'FAILED')),
    CONSTRAINT ck_ops_idem_response CHECK (status = 'IN_PROGRESS' OR response_status IS NOT NULL),
    CONSTRAINT ck_ops_idem_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_ops_idem_response_body CHECK (response_body IS NULL OR jsonb_typeof(response_body) = 'object')
);
COMMENT ON TABLE ops.idempotency_record IS 'HTTP Command等の二重送信を検出し、同じKey＋同じpayloadへ同じ結果を返す。';
COMMENT ON COLUMN ops.idempotency_record.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.idempotency_record.actor_fingerprint IS 'actor fingerprint';
COMMENT ON COLUMN ops.idempotency_record.route_key IS 'route key';
COMMENT ON COLUMN ops.idempotency_record.idempotency_key IS 'idempotency key';
COMMENT ON COLUMN ops.idempotency_record.request_hash IS 'request hash';
COMMENT ON COLUMN ops.idempotency_record.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.idempotency_record.response_status IS 'response status';
COMMENT ON COLUMN ops.idempotency_record.response_body IS '小さな再送応答。大きい応答はArtifactへ保存。';
COMMENT ON COLUMN ops.idempotency_record.response_artifact_id IS 'response artifact id';
COMMENT ON COLUMN ops.idempotency_record.resource_type IS 'resource type';
COMMENT ON COLUMN ops.idempotency_record.resource_id IS 'resource id';
COMMENT ON COLUMN ops.idempotency_record.expires_at IS 'expires at';
COMMENT ON COLUMN ops.idempotency_record.completed_at IS 'completed at';
COMMENT ON COLUMN ops.idempotency_record.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.audit_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    occurred_at timestamptz NOT NULL,
    actor_type text NOT NULL,
    actor_id uuid,
    action text NOT NULL,
    target_type text NOT NULL,
    target_id uuid,
    outcome text NOT NULL,
    severity text DEFAULT 'INFO' NOT NULL,
    correlation_id uuid NOT NULL,
    request_id text,
    before_hash text,
    after_hash text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_audit_event PRIMARY KEY (id),
    CONSTRAINT ck_ops_audit_actor CHECK (actor_type IN ('USER', 'SERVICE', 'SCHEDULE', 'SYSTEM', 'ANONYMOUS')),
    CONSTRAINT ck_ops_audit_outcome CHECK (outcome IN ('SUCCESS', 'DENIED', 'FAILED', 'NOOP')),
    CONSTRAINT ck_ops_audit_severity CHECK (severity IN ('INFO', 'NOTICE', 'WARNING', 'CRITICAL')),
    CONSTRAINT ck_ops_audit_before_hash CHECK (before_hash IS NULL OR before_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_audit_after_hash CHECK (after_hash IS NULL OR after_hash ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_audit_details CHECK (jsonb_typeof(details) = 'object')
);
COMMENT ON TABLE ops.audit_event IS '管理操作・自動化操作・権限変更・公開・Kill Switch等を追記記録する監査正本。';
COMMENT ON COLUMN ops.audit_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.audit_event.occurred_at IS 'occurred at';
COMMENT ON COLUMN ops.audit_event.actor_type IS 'actor type';
COMMENT ON COLUMN ops.audit_event.actor_id IS 'actor id';
COMMENT ON COLUMN ops.audit_event.action IS 'action';
COMMENT ON COLUMN ops.audit_event.target_type IS 'target type';
COMMENT ON COLUMN ops.audit_event.target_id IS 'target id';
COMMENT ON COLUMN ops.audit_event.outcome IS 'outcome';
COMMENT ON COLUMN ops.audit_event.severity IS 'severity';
COMMENT ON COLUMN ops.audit_event.correlation_id IS '要求・Job・Eventを横断して追跡するCorrelation ID。';
COMMENT ON COLUMN ops.audit_event.request_id IS 'request id';
COMMENT ON COLUMN ops.audit_event.before_hash IS 'before hash';
COMMENT ON COLUMN ops.audit_event.after_hash IS 'after hash';
COMMENT ON COLUMN ops.audit_event.details IS '差分要約、理由、Policy/Prompt版。秘密、原文、raw IPは含めない。';
COMMENT ON COLUMN ops.audit_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.audit_export (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    period_start timestamptz NOT NULL,
    period_end timestamptz NOT NULL,
    artifact_id uuid NOT NULL,
    event_count bigint NOT NULL,
    first_event_id uuid,
    last_event_id uuid,
    manifest_sha256 text NOT NULL,
    status text NOT NULL,
    completed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_audit_export PRIMARY KEY (id),
    CONSTRAINT uq_ops_audit_export_display UNIQUE (display_id),
    CONSTRAINT uq_ops_audit_export_period UNIQUE (period_start, period_end),
    CONSTRAINT ck_ops_audit_export_period CHECK (period_end > period_start),
    CONSTRAINT ck_ops_audit_export_count CHECK (event_count >= 0),
    CONSTRAINT ck_ops_audit_export_hash CHECK (manifest_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_audit_export_status CHECK (status IN ('CREATING', 'COMPLETED', 'FAILED', 'VERIFIED'))
);
COMMENT ON TABLE ops.audit_export IS 'Audit Eventの定期不変Export、件数、範囲、manifest hashを登録する。';
COMMENT ON COLUMN ops.audit_export.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.audit_export.display_id IS 'AEX-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ops.audit_export.period_start IS 'period start';
COMMENT ON COLUMN ops.audit_export.period_end IS 'period end';
COMMENT ON COLUMN ops.audit_export.artifact_id IS 'S3互換Object Storage上の不変Artifactレジストリ。';
COMMENT ON COLUMN ops.audit_export.event_count IS 'event count';
COMMENT ON COLUMN ops.audit_export.first_event_id IS 'first event id';
COMMENT ON COLUMN ops.audit_export.last_event_id IS 'last event id';
COMMENT ON COLUMN ops.audit_export.manifest_sha256 IS 'manifest sha256';
COMMENT ON COLUMN ops.audit_export.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.audit_export.completed_at IS 'completed at';
COMMENT ON COLUMN ops.audit_export.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.alert (
    id uuid DEFAULT uuidv7() NOT NULL,
    alert_key text NOT NULL,
    severity text NOT NULL,
    status text DEFAULT 'OPEN' NOT NULL,
    source text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    first_seen_at timestamptz NOT NULL,
    last_seen_at timestamptz NOT NULL,
    occurrence_count bigint DEFAULT 1 NOT NULL,
    incident_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    acknowledged_by_principal_id uuid,
    acknowledged_at timestamptz,
    resolved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_ops_alert PRIMARY KEY (id),
    CONSTRAINT ck_ops_alert_severity CHECK (severity IN ('P0', 'P1', 'P2', 'P3')),
    CONSTRAINT ck_ops_alert_status CHECK (status IN ('OPEN', 'ACKNOWLEDGED', 'RESOLVED', 'SUPPRESSED')),
    CONSTRAINT ck_ops_alert_count CHECK (occurrence_count >= 1),
    CONSTRAINT ck_ops_alert_times CHECK (last_seen_at >= first_seen_at),
    CONSTRAINT ck_ops_alert_meta CHECK (jsonb_typeof(metadata) = 'object')
);
COMMENT ON TABLE ops.alert IS '監視・契約変更・データ品質・鮮度・SecurityのAlertを重複集約する。';
COMMENT ON COLUMN ops.alert.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.alert.alert_key IS 'alert key';
COMMENT ON COLUMN ops.alert.severity IS 'severity';
COMMENT ON COLUMN ops.alert.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.alert.source IS 'source';
COMMENT ON COLUMN ops.alert.title IS 'title';
COMMENT ON COLUMN ops.alert.description IS 'description';
COMMENT ON COLUMN ops.alert.first_seen_at IS 'first seen at';
COMMENT ON COLUMN ops.alert.last_seen_at IS 'last seen at';
COMMENT ON COLUMN ops.alert.occurrence_count IS 'occurrence count';
COMMENT ON COLUMN ops.alert.incident_id IS 'incident id';
COMMENT ON COLUMN ops.alert.metadata IS '検索対象を限定した補助メタデータ。原本や秘密を格納しない。';
COMMENT ON COLUMN ops.alert.acknowledged_by_principal_id IS 'acknowledged by principal id';
COMMENT ON COLUMN ops.alert.acknowledged_at IS 'acknowledged at';
COMMENT ON COLUMN ops.alert.resolved_at IS 'resolved at';
COMMENT ON COLUMN ops.alert.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.alert.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.alert.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE ops.incident (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    severity text NOT NULL,
    status text NOT NULL,
    title text NOT NULL,
    summary text NOT NULL,
    declared_at timestamptz NOT NULL,
    declared_by_principal_id uuid NOT NULL,
    commander_principal_id uuid,
    contained_at timestamptz,
    recovered_at timestamptz,
    closed_at timestamptz,
    root_cause text,
    impact jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_ops_incident PRIMARY KEY (id),
    CONSTRAINT uq_ops_incident_display UNIQUE (display_id),
    CONSTRAINT ck_ops_incident_severity CHECK (severity IN ('P0', 'P1', 'P2', 'P3')),
    CONSTRAINT ck_ops_incident_status CHECK (status IN ('DECLARED', 'CONTAINING', 'CONTAINED', 'RECOVERING', 'MONITORING', 'CLOSED', 'REOPENED')),
    CONSTRAINT ck_ops_incident_impact CHECK (jsonb_typeof(impact) = 'object'),
    CONSTRAINT ck_ops_incident_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE ops.incident IS '重大障害・規約・誤送客・Security事象のライフサイクル正本。';
COMMENT ON COLUMN ops.incident.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.incident.display_id IS 'INC-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ops.incident.severity IS 'severity';
COMMENT ON COLUMN ops.incident.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.incident.title IS 'title';
COMMENT ON COLUMN ops.incident.summary IS 'summary';
COMMENT ON COLUMN ops.incident.declared_at IS 'declared at';
COMMENT ON COLUMN ops.incident.declared_by_principal_id IS 'declared by principal id';
COMMENT ON COLUMN ops.incident.commander_principal_id IS 'commander principal id';
COMMENT ON COLUMN ops.incident.contained_at IS 'contained at';
COMMENT ON COLUMN ops.incident.recovered_at IS 'recovered at';
COMMENT ON COLUMN ops.incident.closed_at IS 'closed at';
COMMENT ON COLUMN ops.incident.root_cause IS 'root cause';
COMMENT ON COLUMN ops.incident.impact IS '影響ページ、期間、件数、金額、ユーザー影響の構造化要約。';
COMMENT ON COLUMN ops.incident.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.incident.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.incident.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE ops.incident_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    incident_id uuid NOT NULL,
    event_type text NOT NULL,
    note text NOT NULL,
    actor_principal_id uuid NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_incident_event PRIMARY KEY (id),
    CONSTRAINT ck_ops_incident_event_type CHECK (event_type IN ('NOTE', 'STATUS_CHANGE', 'CONTAINMENT', 'DECISION', 'RECOVERY', 'EVIDENCE', 'ACTION_ITEM')),
    CONSTRAINT ck_ops_incident_event_meta CHECK (jsonb_typeof(metadata) = 'object')
);
COMMENT ON TABLE ops.incident_event IS 'IncidentのContainment、判断、復旧、再発防止等の時系列イベント。';
COMMENT ON COLUMN ops.incident_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.incident_event.incident_id IS 'incident id';
COMMENT ON COLUMN ops.incident_event.event_type IS 'event type';
COMMENT ON COLUMN ops.incident_event.note IS 'note';
COMMENT ON COLUMN ops.incident_event.actor_principal_id IS 'actor principal id';
COMMENT ON COLUMN ops.incident_event.metadata IS '検索対象を限定した補助メタデータ。原本や秘密を格納しない。';
COMMENT ON COLUMN ops.incident_event.occurred_at IS 'occurred at';
COMMENT ON COLUMN ops.incident_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.kill_switch (
    id uuid DEFAULT uuidv7() NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid,
    switch_type text NOT NULL,
    is_engaged boolean DEFAULT false NOT NULL,
    generation bigint DEFAULT 0 NOT NULL,
    reason text,
    incident_id uuid,
    changed_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    changed_by_principal_id uuid,
    expires_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_ops_kill_switch PRIMARY KEY (id),
    CONSTRAINT ck_ops_kill_scope CHECK (scope_type IN ('GLOBAL', 'SITE', 'CATEGORY', 'ARTICLE', 'PROVIDER')),
    CONSTRAINT ck_ops_kill_scope_id CHECK ((scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)),
    CONSTRAINT ck_ops_kill_type CHECK (switch_type IN ('PUBLICATION', 'AFFILIATE_LINK', 'PROVIDER_CALL')),
    CONSTRAINT ck_ops_kill_generation CHECK (generation >= 0),
    CONSTRAINT ck_ops_kill_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE ops.kill_switch IS 'Publication、Affiliate Link、Providerをglobal/site/category/article/provider scopeで緊急停止する現在状態。';
COMMENT ON COLUMN ops.kill_switch.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.kill_switch.scope_type IS 'scope type';
COMMENT ON COLUMN ops.kill_switch.scope_id IS 'scope id';
COMMENT ON COLUMN ops.kill_switch.switch_type IS 'switch type';
COMMENT ON COLUMN ops.kill_switch.is_engaged IS 'is engaged';
COMMENT ON COLUMN ops.kill_switch.generation IS 'generation';
COMMENT ON COLUMN ops.kill_switch.reason IS 'reason';
COMMENT ON COLUMN ops.kill_switch.incident_id IS 'incident id';
COMMENT ON COLUMN ops.kill_switch.changed_at IS 'changed at';
COMMENT ON COLUMN ops.kill_switch.changed_by_principal_id IS 'changed by principal id';
COMMENT ON COLUMN ops.kill_switch.expires_at IS 'expires at';
COMMENT ON COLUMN ops.kill_switch.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.kill_switch.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN ops.kill_switch.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE ops.kill_switch_change (
    id uuid DEFAULT uuidv7() NOT NULL,
    kill_switch_id uuid NOT NULL,
    previous_engaged boolean NOT NULL,
    new_engaged boolean NOT NULL,
    previous_generation bigint NOT NULL,
    new_generation bigint NOT NULL,
    reason text NOT NULL,
    incident_id uuid,
    actor_principal_id uuid NOT NULL,
    occurred_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_kill_switch_change PRIMARY KEY (id),
    CONSTRAINT ck_ops_kill_change_generation CHECK (new_generation = previous_generation + 1),
    CONSTRAINT ck_ops_kill_change_state CHECK (new_engaged <> previous_engaged)
);
COMMENT ON TABLE ops.kill_switch_change IS 'Kill Switch変更を追記保存し、誰が、なぜ、どのgenerationへ変更したかを残す。';
COMMENT ON COLUMN ops.kill_switch_change.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.kill_switch_change.kill_switch_id IS 'kill switch id';
COMMENT ON COLUMN ops.kill_switch_change.previous_engaged IS 'previous engaged';
COMMENT ON COLUMN ops.kill_switch_change.new_engaged IS 'new engaged';
COMMENT ON COLUMN ops.kill_switch_change.previous_generation IS 'previous generation';
COMMENT ON COLUMN ops.kill_switch_change.new_generation IS 'new generation';
COMMENT ON COLUMN ops.kill_switch_change.reason IS 'reason';
COMMENT ON COLUMN ops.kill_switch_change.incident_id IS 'incident id';
COMMENT ON COLUMN ops.kill_switch_change.actor_principal_id IS 'actor principal id';
COMMENT ON COLUMN ops.kill_switch_change.occurred_at IS 'occurred at';
COMMENT ON COLUMN ops.kill_switch_change.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.runtime_setting_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    setting_key text NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid,
    version_no integer NOT NULL,
    setting_class text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    value_sha256 text NOT NULL,
    status text NOT NULL,
    effective_from timestamptz,
    effective_to timestamptz,
    created_by_principal_id uuid NOT NULL,
    approved_by_principal_id uuid,
    approval_reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_runtime_setting_version PRIMARY KEY (id),
    CONSTRAINT uq_ops_setting_version UNIQUE (setting_key, scope_type, scope_id, version_no),
    CONSTRAINT ck_ops_setting_scope CHECK (scope_type IN ('GLOBAL', 'SITE', 'CATEGORY', 'ARTICLE', 'PROVIDER', 'TASK')),
    CONSTRAINT ck_ops_setting_scope_id CHECK ((scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)),
    CONSTRAINT ck_ops_setting_version CHECK (version_no >= 1),
    CONSTRAINT ck_ops_setting_class CHECK (setting_class IN ('FEATURE_FLAG', 'THRESHOLD', 'PROVIDER', 'FRESHNESS', 'BUDGET', 'UI', 'OTHER')),
    CONSTRAINT ck_ops_setting_no_secret CHECK (setting_class <> 'SECRET'),
    CONSTRAINT ck_ops_setting_value CHECK (jsonb_typeof(value) = 'object'),
    CONSTRAINT ck_ops_setting_hash CHECK (value_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ops_setting_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED', 'REJECTED')),
    CONSTRAINT ck_ops_setting_window CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from)
);
COMMENT ON TABLE ops.runtime_setting_version IS 'Feature Flag、閾値、Provider version、SLA等の非秘密設定をVersion管理する。';
COMMENT ON COLUMN ops.runtime_setting_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.runtime_setting_version.setting_key IS 'setting key';
COMMENT ON COLUMN ops.runtime_setting_version.scope_type IS 'scope type';
COMMENT ON COLUMN ops.runtime_setting_version.scope_id IS 'scope id';
COMMENT ON COLUMN ops.runtime_setting_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN ops.runtime_setting_version.setting_class IS 'setting class';
COMMENT ON COLUMN ops.runtime_setting_version.value IS 'value';
COMMENT ON COLUMN ops.runtime_setting_version.value_sha256 IS 'value sha256';
COMMENT ON COLUMN ops.runtime_setting_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.runtime_setting_version.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN ops.runtime_setting_version.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN ops.runtime_setting_version.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN ops.runtime_setting_version.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN ops.runtime_setting_version.approval_reason IS 'approval reason';
COMMENT ON COLUMN ops.runtime_setting_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.retention_policy (
    id uuid DEFAULT uuidv7() NOT NULL,
    retention_class text NOT NULL,
    policy_version integer NOT NULL,
    data_classification text NOT NULL,
    duration_days integer,
    delete_mode text NOT NULL,
    legal_hold_supported boolean DEFAULT true NOT NULL,
    status text NOT NULL,
    notes text,
    effective_from timestamptz NOT NULL,
    effective_to timestamptz,
    approved_by_principal_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_retention_policy PRIMARY KEY (id),
    CONSTRAINT uq_ops_retention_version UNIQUE (retention_class, policy_version),
    CONSTRAINT ck_ops_retention_version CHECK (policy_version >= 1),
    CONSTRAINT ck_ops_retention_duration CHECK (duration_days IS NULL OR duration_days >= 1),
    CONSTRAINT ck_ops_retention_classification CHECK (data_classification IN ('PUBLIC', 'INTERNAL', 'CONFIDENTIAL', 'RESTRICTED')),
    CONSTRAINT ck_ops_retention_mode CHECK (delete_mode IN ('HARD_DELETE', 'ANONYMIZE', 'ARCHIVE_THEN_DELETE', 'RETAIN')),
    CONSTRAINT ck_ops_retention_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED')),
    CONSTRAINT ck_ops_retention_window CHECK (effective_to IS NULL OR effective_to > effective_from)
);
COMMENT ON TABLE ops.retention_policy IS 'Data Classごとの保持、匿名化、削除、Legal Hold可否をVersion付きで定義する。';
COMMENT ON COLUMN ops.retention_policy.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.retention_policy.retention_class IS 'retention class';
COMMENT ON COLUMN ops.retention_policy.policy_version IS 'policy version';
COMMENT ON COLUMN ops.retention_policy.data_classification IS 'data classification';
COMMENT ON COLUMN ops.retention_policy.duration_days IS 'duration days';
COMMENT ON COLUMN ops.retention_policy.delete_mode IS 'delete mode';
COMMENT ON COLUMN ops.retention_policy.legal_hold_supported IS 'legal hold supported';
COMMENT ON COLUMN ops.retention_policy.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.retention_policy.notes IS 'notes';
COMMENT ON COLUMN ops.retention_policy.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN ops.retention_policy.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN ops.retention_policy.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN ops.retention_policy.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ops.release (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    release_version text NOT NULL,
    git_sha text NOT NULL,
    image_digests jsonb DEFAULT '{}'::jsonb NOT NULL,
    database_revision text NOT NULL,
    environment text NOT NULL,
    status text NOT NULL,
    deployed_at timestamptz,
    deployed_by_principal_id uuid,
    rollback_of_release_id uuid,
    manifest_artifact_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ops_release PRIMARY KEY (id),
    CONSTRAINT uq_ops_release_display UNIQUE (display_id),
    CONSTRAINT uq_ops_release_env_version UNIQUE (environment, release_version),
    CONSTRAINT ck_ops_release_git CHECK (git_sha ~ '^[0-9a-f]{40,64}$'),
    CONSTRAINT ck_ops_release_images CHECK (jsonb_typeof(image_digests) = 'object'),
    CONSTRAINT ck_ops_release_env CHECK (environment IN ('LOCAL', 'CI', 'STAGING', 'PRODUCTION')),
    CONSTRAINT ck_ops_release_status CHECK (status IN ('BUILT', 'DEPLOYING', 'DEPLOYED', 'FAILED', 'ROLLED_BACK'))
);
COMMENT ON TABLE ops.release IS 'Git SHA、Container image、DB revision、環境、Rollback関係を記録するRelease台帳。';
COMMENT ON COLUMN ops.release.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ops.release.display_id IS 'REL-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ops.release.release_version IS 'release version';
COMMENT ON COLUMN ops.release.git_sha IS 'git sha';
COMMENT ON COLUMN ops.release.image_digests IS 'web/api/worker image digest。';
COMMENT ON COLUMN ops.release.database_revision IS 'database revision';
COMMENT ON COLUMN ops.release.environment IS 'environment';
COMMENT ON COLUMN ops.release.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ops.release.deployed_at IS 'deployed at';
COMMENT ON COLUMN ops.release.deployed_by_principal_id IS 'deployed by principal id';
COMMENT ON COLUMN ops.release.rollback_of_release_id IS 'rollback of release id';
COMMENT ON COLUMN ops.release.manifest_artifact_id IS 'manifest artifact id';
COMMENT ON COLUMN ops.release.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.principal (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    principal_type text NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    display_name text NOT NULL,
    deactivated_at timestamptz,
    deactivation_reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_iam_principal PRIMARY KEY (id),
    CONSTRAINT uq_iam_principal_display UNIQUE (display_id),
    CONSTRAINT ck_iam_principal_type CHECK (principal_type IN ('USER', 'SERVICE')),
    CONSTRAINT ck_iam_principal_status CHECK (status IN ('ACTIVE', 'SUSPENDED', 'DEACTIVATED')),
    CONSTRAINT ck_iam_principal_deactivation CHECK (status <> 'DEACTIVATED' OR deactivated_at IS NOT NULL),
    CONSTRAINT ck_iam_principal_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE iam.principal IS '管理ユーザーとService Principalを共通IDで表すIAM Root。PasswordやSecretは保持しない。';
COMMENT ON COLUMN iam.principal.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.principal.display_id IS 'PRN-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN iam.principal.principal_type IS 'principal type';
COMMENT ON COLUMN iam.principal.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN iam.principal.display_name IS 'display name';
COMMENT ON COLUMN iam.principal.deactivated_at IS 'deactivated at';
COMMENT ON COLUMN iam.principal.deactivation_reason IS 'deactivation reason';
COMMENT ON COLUMN iam.principal.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN iam.principal.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN iam.principal.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE iam.user_account (
    principal_id uuid NOT NULL,
    oidc_issuer text NOT NULL,
    oidc_subject text NOT NULL,
    email text,
    email_verified boolean DEFAULT false NOT NULL,
    mfa_required boolean DEFAULT true NOT NULL,
    last_login_at timestamptz,
    last_mfa_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_user_account PRIMARY KEY (principal_id),
    CONSTRAINT uq_iam_user_oidc UNIQUE (oidc_issuer, oidc_subject),
    CONSTRAINT ck_iam_user_https_issuer CHECK (oidc_issuer ~ '^https://')
);
COMMENT ON TABLE iam.user_account IS 'OIDC UserのIssuer/Subject、表示用Email、MFA claim等をPrincipalへ紐付ける。';
COMMENT ON COLUMN iam.user_account.principal_id IS 'principal id';
COMMENT ON COLUMN iam.user_account.oidc_issuer IS 'oidc issuer';
COMMENT ON COLUMN iam.user_account.oidc_subject IS 'oidc subject';
COMMENT ON COLUMN iam.user_account.email IS 'email';
COMMENT ON COLUMN iam.user_account.email_verified IS 'email verified';
COMMENT ON COLUMN iam.user_account.mfa_required IS 'mfa required';
COMMENT ON COLUMN iam.user_account.last_login_at IS 'last login at';
COMMENT ON COLUMN iam.user_account.last_mfa_at IS 'last mfa at';
COMMENT ON COLUMN iam.user_account.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.service_principal (
    principal_id uuid NOT NULL,
    service_code text NOT NULL,
    workload_identity text NOT NULL,
    allowed_environment text NOT NULL,
    credential_rotated_at timestamptz,
    last_used_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_service_principal PRIMARY KEY (principal_id),
    CONSTRAINT uq_iam_service_code UNIQUE (service_code),
    CONSTRAINT uq_iam_service_workload UNIQUE (workload_identity, allowed_environment),
    CONSTRAINT ck_iam_service_env CHECK (allowed_environment IN ('LOCAL', 'CI', 'STAGING', 'PRODUCTION'))
);
COMMENT ON TABLE iam.service_principal IS 'Worker、Dispatcher、CI等のWorkload IdentityをPrincipalへ紐付ける。Credential本体はSecrets Manager/OIDCに置く。';
COMMENT ON COLUMN iam.service_principal.principal_id IS 'principal id';
COMMENT ON COLUMN iam.service_principal.service_code IS 'service code';
COMMENT ON COLUMN iam.service_principal.workload_identity IS 'workload identity';
COMMENT ON COLUMN iam.service_principal.allowed_environment IS 'allowed environment';
COMMENT ON COLUMN iam.service_principal.credential_rotated_at IS 'credential rotated at';
COMMENT ON COLUMN iam.service_principal.last_used_at IS 'last used at';
COMMENT ON COLUMN iam.service_principal.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.role (
    id uuid DEFAULT uuidv7() NOT NULL,
    role_code text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    is_system_role boolean DEFAULT true NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_role PRIMARY KEY (id),
    CONSTRAINT uq_iam_role_code UNIQUE (role_code),
    CONSTRAINT ck_iam_role_status CHECK (status IN ('ACTIVE', 'RETIRED'))
);
COMMENT ON TABLE iam.role IS 'RAOSアプリケーション内Roleの定義。DB Roleとは分離する。';
COMMENT ON COLUMN iam.role.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.role.role_code IS 'role code';
COMMENT ON COLUMN iam.role.name IS 'name';
COMMENT ON COLUMN iam.role.description IS 'description';
COMMENT ON COLUMN iam.role.is_system_role IS 'is system role';
COMMENT ON COLUMN iam.role.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN iam.role.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.permission (
    id uuid DEFAULT uuidv7() NOT NULL,
    permission_code text NOT NULL,
    description text NOT NULL,
    risk_level text NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_permission PRIMARY KEY (id),
    CONSTRAINT uq_iam_permission_code UNIQUE (permission_code),
    CONSTRAINT ck_iam_permission_risk CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_iam_permission_status CHECK (status IN ('ACTIVE', 'RETIRED'))
);
COMMENT ON TABLE iam.permission IS 'API/Command単位の安定Permission code。';
COMMENT ON COLUMN iam.permission.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.permission.permission_code IS 'permission code';
COMMENT ON COLUMN iam.permission.description IS 'description';
COMMENT ON COLUMN iam.permission.risk_level IS 'risk level';
COMMENT ON COLUMN iam.permission.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN iam.permission.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.role_permission (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_role_permission PRIMARY KEY (role_id, permission_id)
);
COMMENT ON TABLE iam.role_permission IS 'RoleとPermissionの多対多対応。';
COMMENT ON COLUMN iam.role_permission.role_id IS 'role id';
COMMENT ON COLUMN iam.role_permission.permission_id IS 'permission id';
COMMENT ON COLUMN iam.role_permission.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.principal_role_assignment (
    id uuid DEFAULT uuidv7() NOT NULL,
    principal_id uuid NOT NULL,
    role_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid,
    valid_from timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    valid_to timestamptz,
    assigned_by_principal_id uuid NOT NULL,
    assignment_reason text NOT NULL,
    revoked_at timestamptz,
    revoked_by_principal_id uuid,
    revocation_reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_principal_role_assignment PRIMARY KEY (id),
    CONSTRAINT ck_iam_assignment_scope CHECK (scope_type IN ('GLOBAL', 'SITE', 'CATEGORY', 'ARTICLE')),
    CONSTRAINT ck_iam_assignment_scope_id CHECK ((scope_type = 'GLOBAL' AND scope_id IS NULL) OR (scope_type <> 'GLOBAL' AND scope_id IS NOT NULL)),
    CONSTRAINT ck_iam_assignment_window CHECK (valid_to IS NULL OR valid_to > valid_from),
    CONSTRAINT ck_iam_assignment_revoke_pair CHECK ((revoked_at IS NULL) = (revoked_by_principal_id IS NULL))
);
COMMENT ON TABLE iam.principal_role_assignment IS 'Principalへglobal/site/category/article scopeのRoleを期限付き付与する。';
COMMENT ON COLUMN iam.principal_role_assignment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.principal_role_assignment.principal_id IS 'principal id';
COMMENT ON COLUMN iam.principal_role_assignment.role_id IS 'role id';
COMMENT ON COLUMN iam.principal_role_assignment.scope_type IS 'scope type';
COMMENT ON COLUMN iam.principal_role_assignment.scope_id IS 'scope id';
COMMENT ON COLUMN iam.principal_role_assignment.valid_from IS 'valid from';
COMMENT ON COLUMN iam.principal_role_assignment.valid_to IS 'valid to';
COMMENT ON COLUMN iam.principal_role_assignment.assigned_by_principal_id IS 'assigned by principal id';
COMMENT ON COLUMN iam.principal_role_assignment.assignment_reason IS 'assignment reason';
COMMENT ON COLUMN iam.principal_role_assignment.revoked_at IS 'revoked at';
COMMENT ON COLUMN iam.principal_role_assignment.revoked_by_principal_id IS 'revoked by principal id';
COMMENT ON COLUMN iam.principal_role_assignment.revocation_reason IS 'revocation reason';
COMMENT ON COLUMN iam.principal_role_assignment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.session_revocation (
    id uuid DEFAULT uuidv7() NOT NULL,
    principal_id uuid NOT NULL,
    oidc_issuer text NOT NULL,
    oidc_subject text NOT NULL,
    revoke_before timestamptz NOT NULL,
    reason text NOT NULL,
    created_by_principal_id uuid NOT NULL,
    expires_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_session_revocation PRIMARY KEY (id),
    CONSTRAINT ck_iam_session_issuer CHECK (oidc_issuer ~ '^https://'),
    CONSTRAINT ck_iam_session_expiry CHECK (expires_at IS NULL OR expires_at > revoke_before)
);
COMMENT ON TABLE iam.session_revocation IS 'PrincipalまたはOIDC Subjectのrevoke-beforeを保持し、既存Sessionを無効化する。';
COMMENT ON COLUMN iam.session_revocation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.session_revocation.principal_id IS 'principal id';
COMMENT ON COLUMN iam.session_revocation.oidc_issuer IS 'oidc issuer';
COMMENT ON COLUMN iam.session_revocation.oidc_subject IS 'oidc subject';
COMMENT ON COLUMN iam.session_revocation.revoke_before IS 'revoke before';
COMMENT ON COLUMN iam.session_revocation.reason IS 'reason';
COMMENT ON COLUMN iam.session_revocation.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN iam.session_revocation.expires_at IS 'expires at';
COMMENT ON COLUMN iam.session_revocation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE iam.break_glass_record (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    principal_id uuid NOT NULL,
    incident_id uuid NOT NULL,
    reason text NOT NULL,
    approved_by_principal_id uuid NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamptz NOT NULL,
    expires_at timestamptz NOT NULL,
    ended_at timestamptz,
    end_reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_iam_break_glass_record PRIMARY KEY (id),
    CONSTRAINT uq_iam_break_glass_display UNIQUE (display_id),
    CONSTRAINT ck_iam_break_glass_window CHECK (expires_at > started_at AND (ended_at IS NULL OR ended_at >= started_at)),
    CONSTRAINT ck_iam_break_glass_permissions CHECK (jsonb_typeof(permissions) = 'object')
);
COMMENT ON TABLE iam.break_glass_record IS '緊急権限の理由、Incident、承認、権限集合、有効期間、終了を記録する。';
COMMENT ON COLUMN iam.break_glass_record.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN iam.break_glass_record.display_id IS 'BGA-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN iam.break_glass_record.principal_id IS 'principal id';
COMMENT ON COLUMN iam.break_glass_record.incident_id IS 'incident id';
COMMENT ON COLUMN iam.break_glass_record.reason IS 'reason';
COMMENT ON COLUMN iam.break_glass_record.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN iam.break_glass_record.permissions IS '緊急時に一時付与したPermission code集合。';
COMMENT ON COLUMN iam.break_glass_record.started_at IS 'started at';
COMMENT ON COLUMN iam.break_glass_record.expires_at IS 'expires at';
COMMENT ON COLUMN iam.break_glass_record.ended_at IS 'ended at';
COMMENT ON COLUMN iam.break_glass_record.end_reason IS 'end reason';
COMMENT ON COLUMN iam.break_glass_record.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE portfolio.site (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_code text NOT NULL,
    name text NOT NULL,
    primary_domain text NOT NULL,
    brand_name text NOT NULL,
    locale text DEFAULT 'ja-JP' NOT NULL,
    timezone text DEFAULT 'Asia/Tokyo' NOT NULL,
    currency text DEFAULT 'JPY' NOT NULL,
    status text DEFAULT 'PLANNING' NOT NULL,
    public_settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_portfolio_site PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_site_display UNIQUE (display_id),
    CONSTRAINT uq_portfolio_site_code UNIQUE (site_code),
    CONSTRAINT uq_portfolio_site_domain UNIQUE (primary_domain),
    CONSTRAINT ck_portfolio_site_domain CHECK (primary_domain ~ '^[a-z0-9.-]+$'),
    CONSTRAINT ck_portfolio_site_currency CHECK (currency ~ '^[A-Z]{3}$'),
    CONSTRAINT ck_portfolio_site_status CHECK (status IN ('PLANNING', 'ACTIVE', 'PAUSED', 'RETIRED')),
    CONSTRAINT ck_portfolio_site_settings CHECK (jsonb_typeof(public_settings) = 'object'),
    CONSTRAINT ck_portfolio_site_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE portfolio.site IS 'RAOSが運営するMedia SiteのRoot。MVPは1件だがCategory、Article、Analytics、Financeのscope基準となる。';
COMMENT ON COLUMN portfolio.site.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.site.display_id IS 'SITE-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.site.site_code IS 'site code';
COMMENT ON COLUMN portfolio.site.name IS 'name';
COMMENT ON COLUMN portfolio.site.primary_domain IS 'primary domain';
COMMENT ON COLUMN portfolio.site.brand_name IS 'brand name';
COMMENT ON COLUMN portfolio.site.locale IS 'locale';
COMMENT ON COLUMN portfolio.site.timezone IS 'timezone';
COMMENT ON COLUMN portfolio.site.currency IS 'currency';
COMMENT ON COLUMN portfolio.site.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN portfolio.site.public_settings IS '公開表示に安全なSite設定。秘密や内部KPIを含めない。';
COMMENT ON COLUMN portfolio.site.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.site.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.site.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE portfolio.category (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    parent_category_id uuid,
    category_code text NOT NULL,
    name text NOT NULL,
    description text,
    risk_class text NOT NULL,
    stage text DEFAULT 'CANDIDATE' NOT NULL,
    article_limit integer,
    approved_at timestamptz,
    approved_by_principal_id uuid,
    entry_criteria jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_portfolio_category PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_category_display UNIQUE (display_id),
    CONSTRAINT uq_portfolio_category_code UNIQUE (site_id, category_code),
    CONSTRAINT ck_portfolio_category_risk CHECK (risk_class IN ('LOW', 'MEDIUM', 'HIGH', 'PROHIBITED')),
    CONSTRAINT ck_portfolio_category_stage CHECK (stage IN ('CANDIDATE', 'RESEARCH', 'APPROVED', 'ACTIVE', 'PAUSED', 'RETIRED', 'REJECTED')),
    CONSTRAINT ck_portfolio_category_limit CHECK (article_limit IS NULL OR article_limit >= 0),
    CONSTRAINT ck_portfolio_category_entry CHECK (jsonb_typeof(entry_criteria) = 'object'),
    CONSTRAINT ck_portfolio_category_approval CHECK (stage NOT IN ('APPROVED','ACTIVE') OR (approved_at IS NOT NULL AND approved_by_principal_id IS NOT NULL)),
    CONSTRAINT ck_portfolio_category_parent CHECK (parent_category_id IS NULL OR parent_category_id <> id),
    CONSTRAINT ck_portfolio_category_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE portfolio.category IS '運営上のCategory階層、Risk、Gate stage、公開上限、承認を管理する。';
COMMENT ON COLUMN portfolio.category.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.category.display_id IS 'CAT-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.category.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN portfolio.category.parent_category_id IS 'parent category id';
COMMENT ON COLUMN portfolio.category.category_code IS 'category code';
COMMENT ON COLUMN portfolio.category.name IS 'name';
COMMENT ON COLUMN portfolio.category.description IS 'description';
COMMENT ON COLUMN portfolio.category.risk_class IS 'risk class';
COMMENT ON COLUMN portfolio.category.stage IS 'stage';
COMMENT ON COLUMN portfolio.category.article_limit IS 'article limit';
COMMENT ON COLUMN portfolio.category.approved_at IS 'approved at';
COMMENT ON COLUMN portfolio.category.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN portfolio.category.entry_criteria IS '当該Categoryへ参入するための定量・定性基準。';
COMMENT ON COLUMN portfolio.category.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.category.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.category.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE portfolio.intent_cluster (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    category_id uuid NOT NULL,
    cluster_code text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    intent_type text NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    decision_requirements jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_portfolio_intent_cluster PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_intent_display UNIQUE (display_id),
    CONSTRAINT uq_portfolio_intent_code UNIQUE (category_id, cluster_code),
    CONSTRAINT ck_portfolio_intent_type CHECK (intent_type IN ('SELECTION_GUIDE', 'USE_CASE', 'COMPARISON', 'MODEL_DIFFERENCE', 'CONDITION_FILTER', 'INFORMATIONAL_SUPPORT')),
    CONSTRAINT ck_portfolio_intent_status CHECK (status IN ('ACTIVE', 'PAUSED', 'RETIRED')),
    CONSTRAINT ck_portfolio_intent_requirements CHECK (jsonb_typeof(decision_requirements) = 'object'),
    CONSTRAINT ck_portfolio_intent_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE portfolio.intent_cluster IS 'Category内の検索意図Cluster。Article PlanとKeywordを結び、同一意図の重複記事を防ぐ。';
COMMENT ON COLUMN portfolio.intent_cluster.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.intent_cluster.display_id IS 'INT-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.intent_cluster.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN portfolio.intent_cluster.cluster_code IS 'cluster code';
COMMENT ON COLUMN portfolio.intent_cluster.name IS 'name';
COMMENT ON COLUMN portfolio.intent_cluster.description IS 'description';
COMMENT ON COLUMN portfolio.intent_cluster.intent_type IS 'intent type';
COMMENT ON COLUMN portfolio.intent_cluster.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN portfolio.intent_cluster.decision_requirements IS 'ユーザーが当該意図で判断するために必要な比較軸・疑問・不安。';
COMMENT ON COLUMN portfolio.intent_cluster.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.intent_cluster.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.intent_cluster.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE portfolio.keyword (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    display_text text NOT NULL,
    normalized_text text NOT NULL,
    locale text DEFAULT 'ja-JP' NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    sensitive_query boolean DEFAULT false NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_portfolio_keyword PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_keyword_display UNIQUE (display_id),
    CONSTRAINT uq_portfolio_keyword_normalized UNIQUE (site_id, locale, normalized_text),
    CONSTRAINT ck_portfolio_keyword_status CHECK (status IN ('ACTIVE', 'PAUSED', 'RETIRED', 'BLOCKED')),
    CONSTRAINT ck_portfolio_keyword_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE portfolio.keyword IS '検索Queryを表示形と正規化形に分け、文字列変更に依存しないStable IDを付与する。';
COMMENT ON COLUMN portfolio.keyword.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.keyword.display_id IS 'KW-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.keyword.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN portfolio.keyword.display_text IS 'display text';
COMMENT ON COLUMN portfolio.keyword.normalized_text IS 'normalized text';
COMMENT ON COLUMN portfolio.keyword.locale IS 'locale';
COMMENT ON COLUMN portfolio.keyword.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN portfolio.keyword.sensitive_query IS 'sensitive query';
COMMENT ON COLUMN portfolio.keyword.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.keyword.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.keyword.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE portfolio.intent_cluster_keyword (
    intent_cluster_id uuid NOT NULL,
    keyword_id uuid NOT NULL,
    keyword_role text NOT NULL,
    priority smallint DEFAULT 50 NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_portfolio_intent_cluster_keyword PRIMARY KEY (intent_cluster_id, keyword_id),
    CONSTRAINT ck_portfolio_cluster_keyword_role CHECK (keyword_role IN ('PRIMARY', 'SECONDARY', 'QUESTION', 'EXCLUSION')),
    CONSTRAINT ck_portfolio_cluster_keyword_priority CHECK (priority BETWEEN 0 AND 100)
);
COMMENT ON TABLE portfolio.intent_cluster_keyword IS 'Intent Cluster内でKeywordをprimary、secondary、question、exclusionに分類する。';
COMMENT ON COLUMN portfolio.intent_cluster_keyword.intent_cluster_id IS 'intent cluster id';
COMMENT ON COLUMN portfolio.intent_cluster_keyword.keyword_id IS 'keyword id';
COMMENT ON COLUMN portfolio.intent_cluster_keyword.keyword_role IS 'keyword role';
COMMENT ON COLUMN portfolio.intent_cluster_keyword.priority IS 'priority';
COMMENT ON COLUMN portfolio.intent_cluster_keyword.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE portfolio.keyword_metric_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    keyword_id uuid NOT NULL,
    provider_code text NOT NULL,
    metric_type text NOT NULL,
    metric_value numeric(24,8) NOT NULL,
    unit text NOT NULL,
    country_code text DEFAULT 'JP' NOT NULL,
    device text DEFAULT 'ALL' NOT NULL,
    observed_date date NOT NULL,
    confidence numeric(5,4),
    raw_artifact_id uuid,
    ingested_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_portfolio_keyword_metric_observation PRIMARY KEY (id),
    CONSTRAINT ck_portfolio_kw_metric_type CHECK (metric_type IN ('SEARCH_VOLUME', 'COMPETITION', 'RANK', 'CPC', 'TREND_INDEX', 'RESULT_COUNT_ESTIMATE')),
    CONSTRAINT ck_portfolio_kw_metric_device CHECK (device IN ('ALL', 'DESKTOP', 'MOBILE', 'TABLET')),
    CONSTRAINT ck_portfolio_kw_metric_conf CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1)
);
COMMENT ON TABLE portfolio.keyword_metric_observation IS '許諾済みProviderまたはCSVから得た検索需要、競争、順位、Trend等の時点Observation。';
COMMENT ON COLUMN portfolio.keyword_metric_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.keyword_metric_observation.keyword_id IS 'keyword id';
COMMENT ON COLUMN portfolio.keyword_metric_observation.provider_code IS 'provider code';
COMMENT ON COLUMN portfolio.keyword_metric_observation.metric_type IS 'metric type';
COMMENT ON COLUMN portfolio.keyword_metric_observation.metric_value IS 'metric value';
COMMENT ON COLUMN portfolio.keyword_metric_observation.unit IS 'unit';
COMMENT ON COLUMN portfolio.keyword_metric_observation.country_code IS 'country code';
COMMENT ON COLUMN portfolio.keyword_metric_observation.device IS 'device';
COMMENT ON COLUMN portfolio.keyword_metric_observation.observed_date IS 'observed date';
COMMENT ON COLUMN portfolio.keyword_metric_observation.confidence IS 'confidence';
COMMENT ON COLUMN portfolio.keyword_metric_observation.raw_artifact_id IS 'raw artifact id';
COMMENT ON COLUMN portfolio.keyword_metric_observation.ingested_at IS 'ingested at';
COMMENT ON COLUMN portfolio.keyword_metric_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE portfolio.opportunity_assessment (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    category_id uuid NOT NULL,
    intent_cluster_id uuid,
    keyword_id uuid,
    assessment_type text NOT NULL,
    formula_version text NOT NULL,
    editorial_feasibility_score numeric(5,2) NOT NULL,
    business_opportunity_score numeric(5,2) NOT NULL,
    compliance_risk_score numeric(5,2) NOT NULL,
    overall_priority_score numeric(5,2) NOT NULL,
    decision text NOT NULL,
    editorial_components jsonb DEFAULT '{}'::jsonb NOT NULL,
    business_components jsonb DEFAULT '{}'::jsonb NOT NULL,
    compliance_components jsonb DEFAULT '{}'::jsonb NOT NULL,
    assessed_at timestamptz NOT NULL,
    assessed_by_actor_type text NOT NULL,
    assessed_by_actor_id uuid,
    expires_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_portfolio_opportunity_assessment PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_opp_display UNIQUE (display_id),
    CONSTRAINT ck_portfolio_opp_type CHECK (assessment_type IN ('CATEGORY', 'CLUSTER', 'KEYWORD', 'ARTICLE_PLAN')),
    CONSTRAINT ck_portfolio_opp_editorial CHECK (editorial_feasibility_score >= 0 AND editorial_feasibility_score <= 100),
    CONSTRAINT ck_portfolio_opp_business CHECK (business_opportunity_score >= 0 AND business_opportunity_score <= 100),
    CONSTRAINT ck_portfolio_opp_compliance CHECK (compliance_risk_score >= 0 AND compliance_risk_score <= 100),
    CONSTRAINT ck_portfolio_opp_priority CHECK (overall_priority_score >= 0 AND overall_priority_score <= 100),
    CONSTRAINT ck_portfolio_opp_decision CHECK (decision IN ('PURSUE', 'RESEARCH', 'HOLD', 'REJECT', 'EXIT')),
    CONSTRAINT ck_portfolio_opp_editorial_json CHECK (jsonb_typeof(editorial_components) = 'object'),
    CONSTRAINT ck_portfolio_opp_business_json CHECK (jsonb_typeof(business_components) = 'object'),
    CONSTRAINT ck_portfolio_opp_compliance_json CHECK (jsonb_typeof(compliance_components) = 'object'),
    CONSTRAINT ck_portfolio_opp_expiry CHECK (expires_at IS NULL OR expires_at > assessed_at)
);
COMMENT ON TABLE portfolio.opportunity_assessment IS 'Editorial feasibility、Business opportunity、Compliance riskを混合せず別Column・別根拠で評価する版付き判断。';
COMMENT ON COLUMN portfolio.opportunity_assessment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.opportunity_assessment.display_id IS 'OPA-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.opportunity_assessment.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN portfolio.opportunity_assessment.intent_cluster_id IS 'intent cluster id';
COMMENT ON COLUMN portfolio.opportunity_assessment.keyword_id IS 'keyword id';
COMMENT ON COLUMN portfolio.opportunity_assessment.assessment_type IS 'assessment type';
COMMENT ON COLUMN portfolio.opportunity_assessment.formula_version IS 'formula version';
COMMENT ON COLUMN portfolio.opportunity_assessment.editorial_feasibility_score IS 'editorial feasibility score';
COMMENT ON COLUMN portfolio.opportunity_assessment.business_opportunity_score IS 'business opportunity score';
COMMENT ON COLUMN portfolio.opportunity_assessment.compliance_risk_score IS 'compliance risk score';
COMMENT ON COLUMN portfolio.opportunity_assessment.overall_priority_score IS 'overall priority score';
COMMENT ON COLUMN portfolio.opportunity_assessment.decision IS 'decision';
COMMENT ON COLUMN portfolio.opportunity_assessment.editorial_components IS 'Editorialに必要な一次情報、独自価値、比較可能性等。';
COMMENT ON COLUMN portfolio.opportunity_assessment.business_components IS '需要、競争、商品数、想定EPC等。推薦順位には渡さない。';
COMMENT ON COLUMN portfolio.opportunity_assessment.compliance_components IS 'Category、表示、著作権、規約、YMYL等のRisk。';
COMMENT ON COLUMN portfolio.opportunity_assessment.assessed_at IS 'assessed at';
COMMENT ON COLUMN portfolio.opportunity_assessment.assessed_by_actor_type IS 'assessed by actor type';
COMMENT ON COLUMN portfolio.opportunity_assessment.assessed_by_actor_id IS 'assessed by actor id';
COMMENT ON COLUMN portfolio.opportunity_assessment.expires_at IS 'expires at';
COMMENT ON COLUMN portfolio.opportunity_assessment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE portfolio.action_candidate (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    category_id uuid,
    action_type text NOT NULL,
    target_entity_type text NOT NULL,
    target_entity_id uuid,
    secondary_entity_id uuid,
    source_signal text NOT NULL,
    expected_incremental_profit_jpy bigint,
    urgency_score numeric(5,2) NOT NULL,
    confidence numeric(5,4) NOT NULL,
    priority_score numeric(8,3) NOT NULL,
    status text DEFAULT 'PROPOSED' NOT NULL,
    rationale jsonb DEFAULT '{}'::jsonb NOT NULL,
    generated_at timestamptz NOT NULL,
    expires_at timestamptz,
    decided_by_principal_id uuid,
    decided_at timestamptz,
    decision_note text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_portfolio_action_candidate PRIMARY KEY (id),
    CONSTRAINT uq_portfolio_action_display UNIQUE (display_id),
    CONSTRAINT ck_portfolio_action_type CHECK (action_type IN ('CREATE', 'UPDATE', 'MERGE', 'DELETE', 'ARCHIVE', 'PAUSE', 'HOLD', 'INVESTIGATE')),
    CONSTRAINT ck_portfolio_action_target CHECK (target_entity_type IN ('CATEGORY', 'CLUSTER', 'KEYWORD', 'ARTICLE_PLAN', 'ARTICLE', 'PRODUCT', 'OFFER')),
    CONSTRAINT ck_portfolio_action_urgency CHECK (urgency_score >= 0 AND urgency_score <= 100),
    CONSTRAINT ck_portfolio_action_conf CHECK (confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_portfolio_action_status CHECK (status IN ('PROPOSED', 'ACCEPTED', 'REJECTED', 'IN_PROGRESS', 'COMPLETED', 'EXPIRED')),
    CONSTRAINT ck_portfolio_action_rationale CHECK (jsonb_typeof(rationale) = 'object'),
    CONSTRAINT ck_portfolio_action_expiry CHECK (expires_at IS NULL OR expires_at > generated_at),
    CONSTRAINT ck_portfolio_action_decision_pair CHECK ((decided_by_principal_id IS NULL) = (decided_at IS NULL)),
    CONSTRAINT ck_portfolio_action_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE portfolio.action_candidate IS '新規作成・更新・統合・削除・保留の候補を、期待増分利益・緊急度・信頼度とともに管理する。';
COMMENT ON COLUMN portfolio.action_candidate.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN portfolio.action_candidate.display_id IS 'ACT-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN portfolio.action_candidate.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN portfolio.action_candidate.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN portfolio.action_candidate.action_type IS 'action type';
COMMENT ON COLUMN portfolio.action_candidate.target_entity_type IS 'target entity type';
COMMENT ON COLUMN portfolio.action_candidate.target_entity_id IS 'target entity id';
COMMENT ON COLUMN portfolio.action_candidate.secondary_entity_id IS 'secondary entity id';
COMMENT ON COLUMN portfolio.action_candidate.source_signal IS 'source signal';
COMMENT ON COLUMN portfolio.action_candidate.expected_incremental_profit_jpy IS 'expected incremental profit jpy';
COMMENT ON COLUMN portfolio.action_candidate.urgency_score IS 'urgency score';
COMMENT ON COLUMN portfolio.action_candidate.confidence IS 'confidence';
COMMENT ON COLUMN portfolio.action_candidate.priority_score IS 'priority score';
COMMENT ON COLUMN portfolio.action_candidate.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN portfolio.action_candidate.rationale IS 'rationale';
COMMENT ON COLUMN portfolio.action_candidate.generated_at IS 'generated at';
COMMENT ON COLUMN portfolio.action_candidate.expires_at IS 'expires at';
COMMENT ON COLUMN portfolio.action_candidate.decided_by_principal_id IS 'decided by principal id';
COMMENT ON COLUMN portfolio.action_candidate.decided_at IS 'decided at';
COMMENT ON COLUMN portfolio.action_candidate.decision_note IS 'decision note';
COMMENT ON COLUMN portfolio.action_candidate.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.action_candidate.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN portfolio.action_candidate.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.provider_endpoint (
    id uuid DEFAULT uuidv7() NOT NULL,
    provider_code text NOT NULL,
    provider_name text NOT NULL,
    api_name text NOT NULL,
    api_version text NOT NULL,
    base_host text NOT NULL,
    status text NOT NULL,
    contract_sha256 text NOT NULL,
    documentation_url text,
    non_secret_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    effective_from timestamptz NOT NULL,
    effective_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_provider_endpoint PRIMARY KEY (id),
    CONSTRAINT uq_catalog_provider_api_version UNIQUE (provider_code, api_name, api_version),
    CONSTRAINT ck_catalog_provider_host CHECK (base_host ~ '^[a-z0-9.-]+$'),
    CONSTRAINT ck_catalog_provider_status CHECK (status IN ('DRAFT', 'ACTIVE', 'DEPRECATED', 'RETIRED', 'BLOCKED')),
    CONSTRAINT ck_catalog_provider_contract_hash CHECK (contract_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_catalog_provider_config CHECK (jsonb_typeof(non_secret_config) = 'object'),
    CONSTRAINT ck_catalog_provider_window CHECK (effective_to IS NULL OR effective_to > effective_from)
);
COMMENT ON TABLE catalog.provider_endpoint IS '楽天等のCommerce ProviderとAPI Contract versionを一つのVersion行として管理する。Secretは含めない。';
COMMENT ON COLUMN catalog.provider_endpoint.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.provider_endpoint.provider_code IS 'provider code';
COMMENT ON COLUMN catalog.provider_endpoint.provider_name IS 'provider name';
COMMENT ON COLUMN catalog.provider_endpoint.api_name IS 'api name';
COMMENT ON COLUMN catalog.provider_endpoint.api_version IS 'api version';
COMMENT ON COLUMN catalog.provider_endpoint.base_host IS 'base host';
COMMENT ON COLUMN catalog.provider_endpoint.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN catalog.provider_endpoint.contract_sha256 IS 'contract sha256';
COMMENT ON COLUMN catalog.provider_endpoint.documentation_url IS 'documentation url';
COMMENT ON COLUMN catalog.provider_endpoint.non_secret_config IS 'Timeout、page size、field mapping等。Application ID、Access Key、Affiliate IDは含めない。';
COMMENT ON COLUMN catalog.provider_endpoint.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN catalog.provider_endpoint.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN catalog.provider_endpoint.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.ingestion_request (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    provider_endpoint_id uuid NOT NULL,
    job_id uuid NOT NULL,
    request_fingerprint text NOT NULL,
    request_parameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    requested_at timestamptz NOT NULL,
    responded_at timestamptz,
    http_status integer,
    status text NOT NULL,
    raw_response_artifact_id uuid,
    item_count integer,
    rate_limit_observation jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_class text,
    error_code text,
    error_message text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_ingestion_request PRIMARY KEY (id),
    CONSTRAINT uq_catalog_ingestion_display UNIQUE (display_id),
    CONSTRAINT uq_catalog_ingestion_job UNIQUE (job_id),
    CONSTRAINT ck_catalog_ingestion_fingerprint CHECK (request_fingerprint ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_catalog_ingestion_status CHECK (status IN ('REQUESTED', 'SUCCEEDED', 'FAILED', 'QUARANTINED')),
    CONSTRAINT ck_catalog_ingestion_http CHECK (http_status IS NULL OR http_status BETWEEN 100 AND 599),
    CONSTRAINT ck_catalog_ingestion_count CHECK (item_count IS NULL OR item_count >= 0),
    CONSTRAINT ck_catalog_ingestion_params CHECK (jsonb_typeof(request_parameters) = 'object'),
    CONSTRAINT ck_catalog_ingestion_rate CHECK (jsonb_typeof(rate_limit_observation) = 'object'),
    CONSTRAINT ck_catalog_ingestion_response CHECK (status <> 'SUCCEEDED' OR (responded_at IS NOT NULL AND raw_response_artifact_id IS NOT NULL))
);
COMMENT ON TABLE catalog.ingestion_request IS '外部API Request/Responseの契約、raw Artifact、件数、Rate Limit、失敗分類を記録する。';
COMMENT ON COLUMN catalog.ingestion_request.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.ingestion_request.display_id IS 'ING-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN catalog.ingestion_request.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN catalog.ingestion_request.job_id IS '非同期Job。';
COMMENT ON COLUMN catalog.ingestion_request.request_fingerprint IS 'request fingerprint';
COMMENT ON COLUMN catalog.ingestion_request.request_parameters IS 'Secretを除外したCanonical request parameters。';
COMMENT ON COLUMN catalog.ingestion_request.requested_at IS 'requested at';
COMMENT ON COLUMN catalog.ingestion_request.responded_at IS 'responded at';
COMMENT ON COLUMN catalog.ingestion_request.http_status IS 'http status';
COMMENT ON COLUMN catalog.ingestion_request.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN catalog.ingestion_request.raw_response_artifact_id IS 'raw response artifact id';
COMMENT ON COLUMN catalog.ingestion_request.item_count IS 'item count';
COMMENT ON COLUMN catalog.ingestion_request.rate_limit_observation IS 'Remaining、reset時刻等。';
COMMENT ON COLUMN catalog.ingestion_request.error_class IS 'error class';
COMMENT ON COLUMN catalog.ingestion_request.error_code IS 'error code';
COMMENT ON COLUMN catalog.ingestion_request.error_message IS 'error message';
COMMENT ON COLUMN catalog.ingestion_request.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.rakuten_genre (
    id uuid DEFAULT uuidv7() NOT NULL,
    provider_endpoint_id uuid NOT NULL,
    external_genre_id bigint NOT NULL,
    parent_external_genre_id bigint,
    genre_name text NOT NULL,
    genre_level smallint NOT NULL,
    is_leaf boolean NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    source_snapshot_id uuid NOT NULL,
    observed_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_rakuten_genre PRIMARY KEY (id),
    CONSTRAINT uq_catalog_rakuten_genre UNIQUE (provider_endpoint_id, external_genre_id),
    CONSTRAINT ck_catalog_rakuten_genre_id CHECK (external_genre_id > 0),
    CONSTRAINT ck_catalog_rakuten_genre_level CHECK (genre_level >= 0),
    CONSTRAINT ck_catalog_rakuten_genre_parent CHECK (parent_external_genre_id IS NULL OR parent_external_genre_id <> external_genre_id),
    CONSTRAINT ck_catalog_rakuten_genre_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.rakuten_genre IS '楽天ジャンルID階層のVersioned current registry。';
COMMENT ON COLUMN catalog.rakuten_genre.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.rakuten_genre.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN catalog.rakuten_genre.external_genre_id IS 'external genre id';
COMMENT ON COLUMN catalog.rakuten_genre.parent_external_genre_id IS 'parent external genre id';
COMMENT ON COLUMN catalog.rakuten_genre.genre_name IS 'genre name';
COMMENT ON COLUMN catalog.rakuten_genre.genre_level IS 'genre level';
COMMENT ON COLUMN catalog.rakuten_genre.is_leaf IS 'is leaf';
COMMENT ON COLUMN catalog.rakuten_genre.is_active IS 'is active';
COMMENT ON COLUMN catalog.rakuten_genre.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.rakuten_genre.observed_at IS 'observed at';
COMMENT ON COLUMN catalog.rakuten_genre.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.rakuten_genre.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.rakuten_genre.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.shop (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    provider_endpoint_id uuid NOT NULL,
    external_shop_code text NOT NULL,
    shop_name text NOT NULL,
    shop_url text,
    affiliate_capable boolean DEFAULT true NOT NULL,
    status text NOT NULL,
    first_observed_at timestamptz NOT NULL,
    last_observed_at timestamptz NOT NULL,
    source_snapshot_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_shop PRIMARY KEY (id),
    CONSTRAINT uq_catalog_shop_display UNIQUE (display_id),
    CONSTRAINT uq_catalog_shop_external UNIQUE (provider_endpoint_id, external_shop_code),
    CONSTRAINT ck_catalog_shop_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'BLOCKED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_shop_url CHECK (shop_url IS NULL OR shop_url ~ '^https://'),
    CONSTRAINT ck_catalog_shop_observed CHECK (last_observed_at >= first_observed_at),
    CONSTRAINT ck_catalog_shop_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.shop IS 'Provider内ShopをStable IDへ正規化する。';
COMMENT ON COLUMN catalog.shop.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.shop.display_id IS 'SHP-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN catalog.shop.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN catalog.shop.external_shop_code IS 'external shop code';
COMMENT ON COLUMN catalog.shop.shop_name IS 'shop name';
COMMENT ON COLUMN catalog.shop.shop_url IS 'shop url';
COMMENT ON COLUMN catalog.shop.affiliate_capable IS 'affiliate capable';
COMMENT ON COLUMN catalog.shop.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN catalog.shop.first_observed_at IS 'first observed at';
COMMENT ON COLUMN catalog.shop.last_observed_at IS 'last observed at';
COMMENT ON COLUMN catalog.shop.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.shop.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.shop.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.shop.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.canonical_product (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    category_id uuid NOT NULL,
    canonical_name text NOT NULL,
    brand_name text,
    manufacturer_name text,
    model_number text,
    jan_code text,
    product_type text NOT NULL,
    lifecycle_status text DEFAULT 'ACTIVE' NOT NULL,
    identity_confidence numeric(5,4) NOT NULL,
    identity_attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    merged_into_product_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_canonical_product PRIMARY KEY (id),
    CONSTRAINT uq_catalog_product_display UNIQUE (display_id),
    CONSTRAINT ck_catalog_product_conf CHECK (identity_confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_catalog_product_lifecycle CHECK (lifecycle_status IN ('ACTIVE', 'DISCONTINUED', 'MERGED', 'SPLIT', 'UNKNOWN')),
    CONSTRAINT ck_catalog_product_jan CHECK (jan_code IS NULL OR jan_code ~ '^[0-9]{8,14}$'),
    CONSTRAINT ck_catalog_product_identity CHECK (jsonb_typeof(identity_attributes) = 'object'),
    CONSTRAINT ck_catalog_product_merge CHECK (merged_into_product_id IS NULL OR merged_into_product_id <> id),
    CONSTRAINT ck_catalog_product_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.canonical_product IS '複数Shop Listingを束ねる商品概念。JAN、型番、Brand等は確信度付きIdentityとして扱う。';
COMMENT ON COLUMN catalog.canonical_product.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.canonical_product.display_id IS 'PRD-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN catalog.canonical_product.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN catalog.canonical_product.canonical_name IS 'canonical name';
COMMENT ON COLUMN catalog.canonical_product.brand_name IS 'brand name';
COMMENT ON COLUMN catalog.canonical_product.manufacturer_name IS 'manufacturer name';
COMMENT ON COLUMN catalog.canonical_product.model_number IS 'model number';
COMMENT ON COLUMN catalog.canonical_product.jan_code IS 'jan code';
COMMENT ON COLUMN catalog.canonical_product.product_type IS 'product type';
COMMENT ON COLUMN catalog.canonical_product.lifecycle_status IS 'lifecycle status';
COMMENT ON COLUMN catalog.canonical_product.identity_confidence IS 'identity confidence';
COMMENT ON COLUMN catalog.canonical_product.identity_attributes IS '同定に使用した正規化Attribute。';
COMMENT ON COLUMN catalog.canonical_product.merged_into_product_id IS 'merged into product id';
COMMENT ON COLUMN catalog.canonical_product.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.canonical_product.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.canonical_product.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.product_candidate (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    provider_endpoint_id uuid NOT NULL,
    external_item_code text NOT NULL,
    shop_id uuid NOT NULL,
    rakuten_genre_id uuid,
    item_name text NOT NULL,
    normalized_item_name text NOT NULL,
    model_number_candidate text,
    jan_code_candidate text,
    image_set jsonb DEFAULT '{}'::jsonb NOT NULL,
    listing_status text NOT NULL,
    first_observed_at timestamptz NOT NULL,
    last_observed_at timestamptz NOT NULL,
    source_snapshot_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_product_candidate PRIMARY KEY (id),
    CONSTRAINT uq_catalog_candidate_display UNIQUE (display_id),
    CONSTRAINT uq_catalog_candidate_external UNIQUE (provider_endpoint_id, external_item_code),
    CONSTRAINT ck_catalog_candidate_status CHECK (listing_status IN ('ACTIVE', 'MISSING', 'ENDED', 'BLOCKED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_candidate_jan CHECK (jan_code_candidate IS NULL OR jan_code_candidate ~ '^[0-9]{8,14}$'),
    CONSTRAINT ck_catalog_candidate_images CHECK (jsonb_typeof(image_set) = 'object'),
    CONSTRAINT ck_catalog_candidate_observed CHECK (last_observed_at >= first_observed_at),
    CONSTRAINT ck_catalog_candidate_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.product_candidate IS 'Provider Listingから抽出した商品候補。raw本文はArtifactへ置き、比較に必要な正規化項目と許可画像URLのみ保持する。';
COMMENT ON COLUMN catalog.product_candidate.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.product_candidate.display_id IS 'PCD-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN catalog.product_candidate.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN catalog.product_candidate.external_item_code IS 'external item code';
COMMENT ON COLUMN catalog.product_candidate.shop_id IS 'shop id';
COMMENT ON COLUMN catalog.product_candidate.rakuten_genre_id IS 'rakuten genre id';
COMMENT ON COLUMN catalog.product_candidate.item_name IS 'item name';
COMMENT ON COLUMN catalog.product_candidate.normalized_item_name IS 'normalized item name';
COMMENT ON COLUMN catalog.product_candidate.model_number_candidate IS 'model number candidate';
COMMENT ON COLUMN catalog.product_candidate.jan_code_candidate IS 'jan code candidate';
COMMENT ON COLUMN catalog.product_candidate.image_set IS 'APIが返した許可画像URL、order、size。Overlay/Crop後画像は登録しない。';
COMMENT ON COLUMN catalog.product_candidate.listing_status IS 'listing status';
COMMENT ON COLUMN catalog.product_candidate.first_observed_at IS 'first observed at';
COMMENT ON COLUMN catalog.product_candidate.last_observed_at IS 'last observed at';
COMMENT ON COLUMN catalog.product_candidate.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.product_candidate.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.product_candidate.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.product_candidate.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.grouping_decision (
    id uuid DEFAULT uuidv7() NOT NULL,
    product_candidate_id uuid NOT NULL,
    proposed_product_id uuid,
    decision_type text NOT NULL,
    decision_score numeric(5,4),
    rule_version text NOT NULL,
    reasons jsonb DEFAULT '{}'::jsonb NOT NULL,
    decided_by_actor_type text NOT NULL,
    decided_by_actor_id uuid,
    decided_at timestamptz NOT NULL,
    supersedes_decision_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_grouping_decision PRIMARY KEY (id),
    CONSTRAINT ck_catalog_group_decision_type CHECK (decision_type IN ('AUTO_ACCEPT', 'HUMAN_ACCEPT', 'REJECT', 'SPLIT', 'UNDECIDED')),
    CONSTRAINT ck_catalog_group_score CHECK (decision_score IS NULL OR decision_score BETWEEN 0 AND 1),
    CONSTRAINT ck_catalog_group_reasons CHECK (jsonb_typeof(reasons) = 'object'),
    CONSTRAINT ck_catalog_group_target CHECK (decision_type IN ('REJECT','UNDECIDED') OR proposed_product_id IS NOT NULL)
);
COMMENT ON TABLE catalog.grouping_decision IS 'Product CandidateをCanonical Productへ統合・分離・却下した判断とRule版・Score・理由を追記保存する。';
COMMENT ON COLUMN catalog.grouping_decision.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.grouping_decision.product_candidate_id IS 'product candidate id';
COMMENT ON COLUMN catalog.grouping_decision.proposed_product_id IS 'proposed product id';
COMMENT ON COLUMN catalog.grouping_decision.decision_type IS 'decision type';
COMMENT ON COLUMN catalog.grouping_decision.decision_score IS 'decision score';
COMMENT ON COLUMN catalog.grouping_decision.rule_version IS 'rule version';
COMMENT ON COLUMN catalog.grouping_decision.reasons IS '一致・不一致Attribute、閾値、Manual note。';
COMMENT ON COLUMN catalog.grouping_decision.decided_by_actor_type IS 'decided by actor type';
COMMENT ON COLUMN catalog.grouping_decision.decided_by_actor_id IS 'decided by actor id';
COMMENT ON COLUMN catalog.grouping_decision.decided_at IS 'decided at';
COMMENT ON COLUMN catalog.grouping_decision.supersedes_decision_id IS 'supersedes decision id';
COMMENT ON COLUMN catalog.grouping_decision.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.product_group_membership (
    id uuid DEFAULT uuidv7() NOT NULL,
    product_id uuid NOT NULL,
    product_candidate_id uuid NOT NULL,
    grouping_decision_id uuid NOT NULL,
    valid_from timestamptz NOT NULL,
    valid_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_product_group_membership PRIMARY KEY (id),
    CONSTRAINT ck_catalog_membership_window CHECK (valid_to IS NULL OR valid_to > valid_from)
);
COMMENT ON TABLE catalog.product_group_membership IS 'Product CandidateがどのCanonical Productへ属したかを有効期間付きで記録する。';
COMMENT ON COLUMN catalog.product_group_membership.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.product_group_membership.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN catalog.product_group_membership.product_candidate_id IS 'product candidate id';
COMMENT ON COLUMN catalog.product_group_membership.grouping_decision_id IS 'grouping decision id';
COMMENT ON COLUMN catalog.product_group_membership.valid_from IS 'valid from';
COMMENT ON COLUMN catalog.product_group_membership.valid_to IS 'valid to';
COMMENT ON COLUMN catalog.product_group_membership.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.attribute_definition (
    id uuid DEFAULT uuidv7() NOT NULL,
    category_id uuid,
    attribute_code text NOT NULL,
    name text NOT NULL,
    data_type text NOT NULL,
    unit_family text,
    is_comparable boolean DEFAULT true NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    normalization_rule_version text NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_attribute_definition PRIMARY KEY (id),
    CONSTRAINT ck_catalog_attribute_type CHECK (data_type IN ('TEXT', 'NUMERIC', 'BOOLEAN', 'DATE', 'CODE')),
    CONSTRAINT ck_catalog_attribute_status CHECK (status IN ('ACTIVE', 'RETIRED')),
    CONSTRAINT ck_catalog_attribute_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.attribute_definition IS 'カテゴリ別の比較可能Attribute定義、型、単位、正規化Ruleを管理する。';
COMMENT ON COLUMN catalog.attribute_definition.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.attribute_definition.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN catalog.attribute_definition.attribute_code IS 'attribute code';
COMMENT ON COLUMN catalog.attribute_definition.name IS 'name';
COMMENT ON COLUMN catalog.attribute_definition.data_type IS 'data type';
COMMENT ON COLUMN catalog.attribute_definition.unit_family IS 'unit family';
COMMENT ON COLUMN catalog.attribute_definition.is_comparable IS 'is comparable';
COMMENT ON COLUMN catalog.attribute_definition.is_required IS 'is required';
COMMENT ON COLUMN catalog.attribute_definition.normalization_rule_version IS 'normalization rule version';
COMMENT ON COLUMN catalog.attribute_definition.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN catalog.attribute_definition.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.attribute_definition.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.attribute_definition.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.product_attribute_value (
    id uuid DEFAULT uuidv7() NOT NULL,
    product_id uuid NOT NULL,
    attribute_definition_id uuid NOT NULL,
    value_text text,
    value_numeric numeric(30,10),
    value_boolean boolean,
    value_date date,
    value_code text,
    unit_code text,
    source_fact_id uuid,
    confidence numeric(5,4) NOT NULL,
    valid_from timestamptz NOT NULL,
    valid_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_product_attribute_value PRIMARY KEY (id),
    CONSTRAINT ck_catalog_product_attr_one_value CHECK (num_nonnulls(value_text, value_numeric, value_boolean, value_date, value_code) = 1),
    CONSTRAINT ck_catalog_product_attr_conf CHECK (confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_catalog_product_attr_window CHECK (valid_to IS NULL OR valid_to > valid_from)
);
COMMENT ON TABLE catalog.product_attribute_value IS 'Canonical Productの型付きAttribute値と根拠Fact、有効期間、信頼度を保持する。';
COMMENT ON COLUMN catalog.product_attribute_value.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.product_attribute_value.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN catalog.product_attribute_value.attribute_definition_id IS 'attribute definition id';
COMMENT ON COLUMN catalog.product_attribute_value.value_text IS 'value text';
COMMENT ON COLUMN catalog.product_attribute_value.value_numeric IS 'value numeric';
COMMENT ON COLUMN catalog.product_attribute_value.value_boolean IS 'value boolean';
COMMENT ON COLUMN catalog.product_attribute_value.value_date IS 'value date';
COMMENT ON COLUMN catalog.product_attribute_value.value_code IS 'value code';
COMMENT ON COLUMN catalog.product_attribute_value.unit_code IS 'unit code';
COMMENT ON COLUMN catalog.product_attribute_value.source_fact_id IS 'source fact id';
COMMENT ON COLUMN catalog.product_attribute_value.confidence IS 'confidence';
COMMENT ON COLUMN catalog.product_attribute_value.valid_from IS 'valid from';
COMMENT ON COLUMN catalog.product_attribute_value.valid_to IS 'valid to';
COMMENT ON COLUMN catalog.product_attribute_value.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.product_relation (
    id uuid DEFAULT uuidv7() NOT NULL,
    from_product_id uuid NOT NULL,
    to_product_id uuid NOT NULL,
    relation_type text NOT NULL,
    confidence numeric(5,4) NOT NULL,
    source_fact_id uuid,
    valid_from timestamptz NOT NULL,
    valid_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_product_relation PRIMARY KEY (id),
    CONSTRAINT ck_catalog_product_relation_type CHECK (relation_type IN ('VARIANT', 'SUCCESSOR', 'PREDECESSOR', 'BUNDLE', 'COMPATIBLE', 'EQUIVALENT', 'ACCESSORY')),
    CONSTRAINT ck_catalog_product_relation_self CHECK (from_product_id <> to_product_id),
    CONSTRAINT ck_catalog_product_relation_conf CHECK (confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_catalog_product_relation_window CHECK (valid_to IS NULL OR valid_to > valid_from)
);
COMMENT ON TABLE catalog.product_relation IS '後継、前世代、Variant、Bundle、Equivalent等の商品関係を根拠付きで管理する。';
COMMENT ON COLUMN catalog.product_relation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.product_relation.from_product_id IS 'from product id';
COMMENT ON COLUMN catalog.product_relation.to_product_id IS 'to product id';
COMMENT ON COLUMN catalog.product_relation.relation_type IS 'relation type';
COMMENT ON COLUMN catalog.product_relation.confidence IS 'confidence';
COMMENT ON COLUMN catalog.product_relation.source_fact_id IS 'source fact id';
COMMENT ON COLUMN catalog.product_relation.valid_from IS 'valid from';
COMMENT ON COLUMN catalog.product_relation.valid_to IS 'valid to';
COMMENT ON COLUMN catalog.product_relation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.offer (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    provider_endpoint_id uuid NOT NULL,
    external_offer_id text NOT NULL,
    product_candidate_id uuid NOT NULL,
    product_id uuid,
    shop_id uuid NOT NULL,
    item_url text NOT NULL,
    status text NOT NULL,
    first_observed_at timestamptz NOT NULL,
    last_observed_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_catalog_offer PRIMARY KEY (id),
    CONSTRAINT uq_catalog_offer_display UNIQUE (display_id),
    CONSTRAINT uq_catalog_offer_external UNIQUE (provider_endpoint_id, external_offer_id),
    CONSTRAINT ck_catalog_offer_url CHECK (item_url ~ '^https://'),
    CONSTRAINT ck_catalog_offer_status CHECK (status IN ('ACTIVE', 'OUT_OF_STOCK', 'ENDED', 'SUSPENDED', 'BLOCKED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_offer_observed CHECK (last_observed_at >= first_observed_at),
    CONSTRAINT ck_catalog_offer_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE catalog.offer IS 'Shop単位の販売OfferをStable ID化し、Product Candidate・Shop・Canonical Productへ結び付ける。';
COMMENT ON COLUMN catalog.offer.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.offer.display_id IS 'OFF-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN catalog.offer.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN catalog.offer.external_offer_id IS 'external offer id';
COMMENT ON COLUMN catalog.offer.product_candidate_id IS 'product candidate id';
COMMENT ON COLUMN catalog.offer.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN catalog.offer.shop_id IS 'shop id';
COMMENT ON COLUMN catalog.offer.item_url IS 'item url';
COMMENT ON COLUMN catalog.offer.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN catalog.offer.first_observed_at IS 'first observed at';
COMMENT ON COLUMN catalog.offer.last_observed_at IS 'last observed at';
COMMENT ON COLUMN catalog.offer.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.offer.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN catalog.offer.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE catalog.price_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    offer_id uuid NOT NULL,
    price_jpy bigint NOT NULL,
    tax_included boolean DEFAULT true NOT NULL,
    shipping_fee_jpy bigint,
    shipping_condition text NOT NULL,
    points_rate numeric(9,6),
    observed_at timestamptz NOT NULL,
    ingested_at timestamptz NOT NULL,
    valid_until timestamptz,
    source_snapshot_id uuid NOT NULL,
    validation_status text NOT NULL,
    confidence numeric(5,4) NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_price_observation PRIMARY KEY (id),
    CONSTRAINT ck_catalog_price_nonnegative CHECK (price_jpy >= 0 AND (shipping_fee_jpy IS NULL OR shipping_fee_jpy >= 0)),
    CONSTRAINT ck_catalog_price_shipping CHECK (shipping_condition IN ('FREE', 'PAID', 'CONDITIONAL', 'INCLUDED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_price_points CHECK (points_rate IS NULL OR points_rate BETWEEN 0 AND 100),
    CONSTRAINT ck_catalog_price_valid CHECK (valid_until IS NULL OR valid_until > observed_at),
    CONSTRAINT ck_catalog_price_validation CHECK (validation_status IN ('VALID', 'SUSPECT', 'INVALID', 'CONFLICT')),
    CONSTRAINT ck_catalog_price_conf CHECK (confidence BETWEEN 0 AND 1)
);
COMMENT ON TABLE catalog.price_observation IS '価格・送料・Point等の時点事実を上書きせず追記する。';
COMMENT ON COLUMN catalog.price_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.price_observation.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN catalog.price_observation.price_jpy IS 'price jpy';
COMMENT ON COLUMN catalog.price_observation.tax_included IS 'tax included';
COMMENT ON COLUMN catalog.price_observation.shipping_fee_jpy IS 'shipping fee jpy';
COMMENT ON COLUMN catalog.price_observation.shipping_condition IS 'shipping condition';
COMMENT ON COLUMN catalog.price_observation.points_rate IS 'points rate';
COMMENT ON COLUMN catalog.price_observation.observed_at IS 'observed at';
COMMENT ON COLUMN catalog.price_observation.ingested_at IS 'ingested at';
COMMENT ON COLUMN catalog.price_observation.valid_until IS 'valid until';
COMMENT ON COLUMN catalog.price_observation.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.price_observation.validation_status IS 'validation status';
COMMENT ON COLUMN catalog.price_observation.confidence IS 'confidence';
COMMENT ON COLUMN catalog.price_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.availability_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    offer_id uuid NOT NULL,
    availability text NOT NULL,
    quantity integer,
    lead_time_text text,
    observed_at timestamptz NOT NULL,
    ingested_at timestamptz NOT NULL,
    valid_until timestamptz,
    source_snapshot_id uuid NOT NULL,
    validation_status text NOT NULL,
    confidence numeric(5,4) NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_availability_observation PRIMARY KEY (id),
    CONSTRAINT ck_catalog_avail_type CHECK (availability IN ('IN_STOCK', 'OUT_OF_STOCK', 'BACKORDER', 'PREORDER', 'DISCONTINUED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_avail_qty CHECK (quantity IS NULL OR quantity >= 0),
    CONSTRAINT ck_catalog_avail_valid CHECK (valid_until IS NULL OR valid_until > observed_at),
    CONSTRAINT ck_catalog_avail_validation CHECK (validation_status IN ('VALID', 'SUSPECT', 'INVALID', 'CONFLICT')),
    CONSTRAINT ck_catalog_avail_conf CHECK (confidence BETWEEN 0 AND 1)
);
COMMENT ON TABLE catalog.availability_observation IS '在庫・販売終了・Backorder等の時点事実を追記する。';
COMMENT ON COLUMN catalog.availability_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.availability_observation.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN catalog.availability_observation.availability IS 'availability';
COMMENT ON COLUMN catalog.availability_observation.quantity IS 'quantity';
COMMENT ON COLUMN catalog.availability_observation.lead_time_text IS 'lead time text';
COMMENT ON COLUMN catalog.availability_observation.observed_at IS 'observed at';
COMMENT ON COLUMN catalog.availability_observation.ingested_at IS 'ingested at';
COMMENT ON COLUMN catalog.availability_observation.valid_until IS 'valid until';
COMMENT ON COLUMN catalog.availability_observation.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.availability_observation.validation_status IS 'validation status';
COMMENT ON COLUMN catalog.availability_observation.confidence IS 'confidence';
COMMENT ON COLUMN catalog.availability_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.review_aggregate_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    offer_id uuid NOT NULL,
    review_count integer NOT NULL,
    review_average numeric(3,2),
    observed_at timestamptz NOT NULL,
    ingested_at timestamptz NOT NULL,
    source_snapshot_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_review_aggregate_observation PRIMARY KEY (id),
    CONSTRAINT ck_catalog_review_count CHECK (review_count >= 0),
    CONSTRAINT ck_catalog_review_average CHECK (review_average IS NULL OR review_average BETWEEN 0 AND 5)
);
COMMENT ON TABLE catalog.review_aggregate_observation IS '楽天APIが返すReview件数・平均評価のみを保存する。Review本文を保存するColumnは設けない。';
COMMENT ON COLUMN catalog.review_aggregate_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.review_aggregate_observation.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN catalog.review_aggregate_observation.review_count IS 'review count';
COMMENT ON COLUMN catalog.review_aggregate_observation.review_average IS 'review average';
COMMENT ON COLUMN catalog.review_aggregate_observation.observed_at IS 'observed at';
COMMENT ON COLUMN catalog.review_aggregate_observation.ingested_at IS 'ingested at';
COMMENT ON COLUMN catalog.review_aggregate_observation.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.review_aggregate_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.affiliate_link_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    offer_id uuid NOT NULL,
    affiliate_url text NOT NULL,
    url_sha256 text NOT NULL,
    destination_host text NOT NULL,
    is_api_returned boolean NOT NULL,
    affiliate_rate numeric(9,6),
    observed_at timestamptz NOT NULL,
    valid_until timestamptz,
    source_snapshot_id uuid NOT NULL,
    validation_status text NOT NULL,
    link_contract_version text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_affiliate_link_observation PRIMARY KEY (id),
    CONSTRAINT ck_catalog_affiliate_url CHECK (affiliate_url ~ '^https://'),
    CONSTRAINT ck_catalog_affiliate_hash CHECK (url_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_catalog_affiliate_host CHECK (destination_host ~ '^[a-z0-9.-]+$'),
    CONSTRAINT ck_catalog_affiliate_api CHECK (is_api_returned = true),
    CONSTRAINT ck_catalog_affiliate_rate CHECK (affiliate_rate IS NULL OR affiliate_rate BETWEEN 0 AND 100),
    CONSTRAINT ck_catalog_affiliate_valid CHECK (valid_until IS NULL OR valid_until > observed_at),
    CONSTRAINT ck_catalog_affiliate_validation CHECK (validation_status IN ('VALID', 'UNVERIFIED', 'INVALID', 'EXPIRED', 'BLOCKED'))
);
COMMENT ON TABLE catalog.affiliate_link_observation IS '公式/API返却Affiliate URL、Destination host、URL hash、料率Observationを追記し、URLを改変しない。';
COMMENT ON COLUMN catalog.affiliate_link_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.affiliate_link_observation.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN catalog.affiliate_link_observation.affiliate_url IS 'affiliate url';
COMMENT ON COLUMN catalog.affiliate_link_observation.url_sha256 IS 'url sha256';
COMMENT ON COLUMN catalog.affiliate_link_observation.destination_host IS 'destination host';
COMMENT ON COLUMN catalog.affiliate_link_observation.is_api_returned IS 'is api returned';
COMMENT ON COLUMN catalog.affiliate_link_observation.affiliate_rate IS 'affiliate rate';
COMMENT ON COLUMN catalog.affiliate_link_observation.observed_at IS 'observed at';
COMMENT ON COLUMN catalog.affiliate_link_observation.valid_until IS 'valid until';
COMMENT ON COLUMN catalog.affiliate_link_observation.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN catalog.affiliate_link_observation.validation_status IS 'validation status';
COMMENT ON COLUMN catalog.affiliate_link_observation.link_contract_version IS 'link contract version';
COMMENT ON COLUMN catalog.affiliate_link_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE catalog.offer_current_projection (
    offer_id uuid NOT NULL,
    product_id uuid,
    price_observation_id uuid,
    availability_observation_id uuid,
    review_observation_id uuid,
    affiliate_link_observation_id uuid,
    current_price_jpy bigint,
    current_shipping_fee_jpy bigint,
    current_availability text DEFAULT 'UNKNOWN' NOT NULL,
    review_count integer,
    review_average numeric(3,2),
    affiliate_url text,
    destination_host text,
    price_observed_at timestamptz,
    availability_observed_at timestamptz,
    link_observed_at timestamptz,
    freshness_status text NOT NULL,
    projection_version bigint NOT NULL,
    updated_at timestamptz NOT NULL,
    CONSTRAINT pk_catalog_offer_current_projection PRIMARY KEY (offer_id),
    CONSTRAINT ck_catalog_offer_current_price CHECK (current_price_jpy IS NULL OR current_price_jpy >= 0),
    CONSTRAINT ck_catalog_offer_current_ship CHECK (current_shipping_fee_jpy IS NULL OR current_shipping_fee_jpy >= 0),
    CONSTRAINT ck_catalog_offer_current_avail CHECK (current_availability IN ('IN_STOCK', 'OUT_OF_STOCK', 'BACKORDER', 'PREORDER', 'DISCONTINUED', 'UNKNOWN')),
    CONSTRAINT ck_catalog_offer_current_review CHECK ((review_count IS NULL OR review_count >= 0) AND (review_average IS NULL OR review_average BETWEEN 0 AND 5)),
    CONSTRAINT ck_catalog_offer_current_url CHECK (affiliate_url IS NULL OR affiliate_url ~ '^https://'),
    CONSTRAINT ck_catalog_offer_current_fresh CHECK (freshness_status IN ('FRESH', 'WARNING', 'STALE', 'UNKNOWN', 'CONFLICT')),
    CONSTRAINT ck_catalog_offer_current_version CHECK (projection_version >= 1)
);
COMMENT ON TABLE catalog.offer_current_projection IS '最新かつValidなObservationを選択した再生成可能Projection。公開候補はさらにFreshness/Policyを通す。';
COMMENT ON COLUMN catalog.offer_current_projection.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN catalog.offer_current_projection.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN catalog.offer_current_projection.price_observation_id IS 'price observation id';
COMMENT ON COLUMN catalog.offer_current_projection.availability_observation_id IS 'availability observation id';
COMMENT ON COLUMN catalog.offer_current_projection.review_observation_id IS 'review observation id';
COMMENT ON COLUMN catalog.offer_current_projection.affiliate_link_observation_id IS 'affiliate link observation id';
COMMENT ON COLUMN catalog.offer_current_projection.current_price_jpy IS 'current price jpy';
COMMENT ON COLUMN catalog.offer_current_projection.current_shipping_fee_jpy IS 'current shipping fee jpy';
COMMENT ON COLUMN catalog.offer_current_projection.current_availability IS 'current availability';
COMMENT ON COLUMN catalog.offer_current_projection.review_count IS 'review count';
COMMENT ON COLUMN catalog.offer_current_projection.review_average IS 'review average';
COMMENT ON COLUMN catalog.offer_current_projection.affiliate_url IS 'affiliate url';
COMMENT ON COLUMN catalog.offer_current_projection.destination_host IS 'destination host';
COMMENT ON COLUMN catalog.offer_current_projection.price_observed_at IS 'price observed at';
COMMENT ON COLUMN catalog.offer_current_projection.availability_observed_at IS 'availability observed at';
COMMENT ON COLUMN catalog.offer_current_projection.link_observed_at IS 'link observed at';
COMMENT ON COLUMN catalog.offer_current_projection.freshness_status IS 'freshness status';
COMMENT ON COLUMN catalog.offer_current_projection.projection_version IS 'projection version';
COMMENT ON COLUMN catalog.offer_current_projection.updated_at IS '最終更新時刻。UTCのtimestamptz。';

CREATE TABLE catalog.category_genre_mapping (
    id uuid DEFAULT uuidv7() NOT NULL,
    category_id uuid NOT NULL,
    rakuten_genre_id uuid NOT NULL,
    mapping_role text NOT NULL,
    valid_from timestamptz NOT NULL,
    valid_to timestamptz,
    decision_reason text NOT NULL,
    decided_by_principal_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_catalog_category_genre_mapping PRIMARY KEY (id),
    CONSTRAINT ck_catalog_category_genre_role CHECK (mapping_role IN ('PRIMARY', 'INCLUDE', 'EXCLUDE')),
    CONSTRAINT ck_catalog_category_genre_window CHECK (valid_to IS NULL OR valid_to > valid_from)
);
COMMENT ON TABLE catalog.category_genre_mapping IS 'RAOS Categoryと楽天Genreのinclude/exclude/primary関係を有効期間付きで管理する。';
COMMENT ON COLUMN catalog.category_genre_mapping.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN catalog.category_genre_mapping.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN catalog.category_genre_mapping.rakuten_genre_id IS 'rakuten genre id';
COMMENT ON COLUMN catalog.category_genre_mapping.mapping_role IS 'mapping role';
COMMENT ON COLUMN catalog.category_genre_mapping.valid_from IS 'valid from';
COMMENT ON COLUMN catalog.category_genre_mapping.valid_to IS 'valid to';
COMMENT ON COLUMN catalog.category_genre_mapping.decision_reason IS 'decision reason';
COMMENT ON COLUMN catalog.category_genre_mapping.decided_by_principal_id IS 'decided by principal id';
COMMENT ON COLUMN catalog.category_genre_mapping.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.source (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    source_type text NOT NULL,
    provider_endpoint_id uuid,
    name text NOT NULL,
    base_url text,
    authority_level text NOT NULL,
    permitted_use text NOT NULL,
    terms_checked_at timestamptz,
    terms_checked_by_principal_id uuid,
    status text DEFAULT 'ACTIVE' NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_evidence_source PRIMARY KEY (id),
    CONSTRAINT uq_evidence_source_display UNIQUE (display_id),
    CONSTRAINT ck_evidence_source_type CHECK (source_type IN ('PROVIDER_API', 'MANUFACTURER', 'OFFICIAL_DOCUMENT', 'MANUAL_VERIFIED', 'INTERNAL_CALCULATION', 'ANALYTICS', 'OTHER')),
    CONSTRAINT ck_evidence_source_authority CHECK (authority_level IN ('PRIMARY', 'OFFICIAL', 'SECONDARY', 'INTERNAL_DERIVED', 'UNVERIFIED')),
    CONSTRAINT ck_evidence_source_status CHECK (status IN ('ACTIVE', 'PAUSED', 'BLOCKED', 'RETIRED')),
    CONSTRAINT ck_evidence_source_url CHECK (base_url IS NULL OR base_url ~ '^https://'),
    CONSTRAINT ck_evidence_source_meta CHECK (jsonb_typeof(metadata) = 'object'),
    CONSTRAINT ck_evidence_source_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE evidence.source IS 'Provider API、Manufacturer、Manual entry等の根拠Sourceと利用条件・Authorityを管理する。';
COMMENT ON COLUMN evidence.source.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.source.display_id IS 'SRC-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.source.source_type IS 'source type';
COMMENT ON COLUMN evidence.source.provider_endpoint_id IS 'provider endpoint id';
COMMENT ON COLUMN evidence.source.name IS 'name';
COMMENT ON COLUMN evidence.source.base_url IS 'base url';
COMMENT ON COLUMN evidence.source.authority_level IS 'authority level';
COMMENT ON COLUMN evidence.source.permitted_use IS 'permitted use';
COMMENT ON COLUMN evidence.source.terms_checked_at IS 'terms checked at';
COMMENT ON COLUMN evidence.source.terms_checked_by_principal_id IS 'terms checked by principal id';
COMMENT ON COLUMN evidence.source.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN evidence.source.metadata IS 'Contact、acquisition method、robots/terms note等。';
COMMENT ON COLUMN evidence.source.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN evidence.source.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN evidence.source.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE evidence.source_snapshot (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    source_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    external_reference text,
    acquired_at timestamptz NOT NULL,
    effective_at timestamptz,
    expires_at timestamptz,
    content_sha256 text NOT NULL,
    parser_version text NOT NULL,
    validation_status text NOT NULL,
    validation_message text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_source_snapshot PRIMARY KEY (id),
    CONSTRAINT uq_evidence_snapshot_display UNIQUE (display_id),
    CONSTRAINT uq_evidence_snapshot_artifact UNIQUE (artifact_id),
    CONSTRAINT ck_evidence_snapshot_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_evidence_snapshot_status CHECK (validation_status IN ('VALID', 'SUSPECT', 'INVALID', 'QUARANTINED')),
    CONSTRAINT ck_evidence_snapshot_expiry CHECK (expires_at IS NULL OR expires_at > COALESCE(effective_at, acquired_at))
);
COMMENT ON TABLE evidence.source_snapshot IS 'Sourceの特定時点原本をObject Artifactと結び、取得・有効・失効・Parser・Validationを不変保存する。';
COMMENT ON COLUMN evidence.source_snapshot.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.source_snapshot.display_id IS 'SSN-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.source_snapshot.source_id IS 'source id';
COMMENT ON COLUMN evidence.source_snapshot.artifact_id IS 'S3互換Object Storage上の不変Artifactレジストリ。';
COMMENT ON COLUMN evidence.source_snapshot.external_reference IS 'external reference';
COMMENT ON COLUMN evidence.source_snapshot.acquired_at IS 'acquired at';
COMMENT ON COLUMN evidence.source_snapshot.effective_at IS 'effective at';
COMMENT ON COLUMN evidence.source_snapshot.expires_at IS 'expires at';
COMMENT ON COLUMN evidence.source_snapshot.content_sha256 IS 'content sha256';
COMMENT ON COLUMN evidence.source_snapshot.parser_version IS 'parser version';
COMMENT ON COLUMN evidence.source_snapshot.validation_status IS 'validation status';
COMMENT ON COLUMN evidence.source_snapshot.validation_message IS 'validation message';
COMMENT ON COLUMN evidence.source_snapshot.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.fact (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    source_snapshot_id uuid NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    predicate text NOT NULL,
    value_text text,
    value_numeric numeric(30,10),
    value_boolean boolean,
    value_date date,
    value_timestamp timestamptz,
    value_json jsonb,
    unit_code text,
    locale text,
    fact_kind text DEFAULT 'ASSERTED' NOT NULL,
    confidence numeric(5,4) NOT NULL,
    valid_from timestamptz,
    valid_to timestamptz,
    locator jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_fact PRIMARY KEY (id),
    CONSTRAINT uq_evidence_fact_display UNIQUE (display_id),
    CONSTRAINT ck_evidence_fact_subject CHECK (subject_type IN ('SITE', 'CATEGORY', 'PRODUCT', 'OFFER', 'SHOP', 'ARTICLE', 'KEYWORD', 'OTHER')),
    CONSTRAINT ck_evidence_fact_one_value CHECK (num_nonnulls(value_text, value_numeric, value_boolean, value_date, value_timestamp, value_json) = 1),
    CONSTRAINT ck_evidence_fact_kind CHECK (fact_kind IN ('ASSERTED', 'DERIVED', 'MANUAL_VERIFIED')),
    CONSTRAINT ck_evidence_fact_conf CHECK (confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_evidence_fact_window CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from),
    CONSTRAINT ck_evidence_fact_locator CHECK (jsonb_typeof(locator) = 'object'),
    CONSTRAINT ck_evidence_fact_value_json CHECK (value_json IS NULL OR jsonb_typeof(value_json) IN ('object','array','string','number','boolean','null'))
);
COMMENT ON TABLE evidence.fact IS 'Source Snapshotから抽出・正規化した型付き事実。subject_type/id、predicate、locator、信頼度、有効期間を持つ。';
COMMENT ON COLUMN evidence.fact.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.fact.display_id IS 'FCT-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.fact.source_snapshot_id IS 'source snapshot id';
COMMENT ON COLUMN evidence.fact.subject_type IS 'subject type';
COMMENT ON COLUMN evidence.fact.subject_id IS 'subject id';
COMMENT ON COLUMN evidence.fact.predicate IS 'predicate';
COMMENT ON COLUMN evidence.fact.value_text IS 'value text';
COMMENT ON COLUMN evidence.fact.value_numeric IS 'value numeric';
COMMENT ON COLUMN evidence.fact.value_boolean IS 'value boolean';
COMMENT ON COLUMN evidence.fact.value_date IS 'value date';
COMMENT ON COLUMN evidence.fact.value_timestamp IS 'value timestamp';
COMMENT ON COLUMN evidence.fact.value_json IS 'value json';
COMMENT ON COLUMN evidence.fact.unit_code IS 'unit code';
COMMENT ON COLUMN evidence.fact.locale IS 'locale';
COMMENT ON COLUMN evidence.fact.fact_kind IS 'fact kind';
COMMENT ON COLUMN evidence.fact.confidence IS 'confidence';
COMMENT ON COLUMN evidence.fact.valid_from IS 'valid from';
COMMENT ON COLUMN evidence.fact.valid_to IS 'valid to';
COMMENT ON COLUMN evidence.fact.locator IS 'JSON Pointer、page、section、table cell等の出典内位置。';
COMMENT ON COLUMN evidence.fact.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.fact_derivation (
    derived_fact_id uuid NOT NULL,
    input_fact_id uuid NOT NULL,
    derivation_role text NOT NULL,
    algorithm_version text NOT NULL,
    formula_description text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_fact_derivation PRIMARY KEY (derived_fact_id, input_fact_id, derivation_role),
    CONSTRAINT ck_evidence_derivation_role CHECK (derivation_role IN ('INPUT', 'BASELINE', 'QUALIFIER', 'EXCLUSION')),
    CONSTRAINT ck_evidence_derivation_self CHECK (derived_fact_id <> input_fact_id)
);
COMMENT ON TABLE evidence.fact_derivation IS 'Derived Factと入力Factを多対多で結び、Algorithm/Formula versionを追跡する。';
COMMENT ON COLUMN evidence.fact_derivation.derived_fact_id IS 'derived fact id';
COMMENT ON COLUMN evidence.fact_derivation.input_fact_id IS 'input fact id';
COMMENT ON COLUMN evidence.fact_derivation.derivation_role IS 'derivation role';
COMMENT ON COLUMN evidence.fact_derivation.algorithm_version IS 'algorithm version';
COMMENT ON COLUMN evidence.fact_derivation.formula_description IS 'formula description';
COMMENT ON COLUMN evidence.fact_derivation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.source_packet (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_plan_id uuid NOT NULL,
    packet_type text NOT NULL,
    status text DEFAULT 'BUILDING' NOT NULL,
    current_version_no integer DEFAULT 0 NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_evidence_source_packet PRIMARY KEY (id),
    CONSTRAINT uq_evidence_packet_display UNIQUE (display_id),
    CONSTRAINT uq_evidence_packet_plan_type UNIQUE (article_plan_id, packet_type),
    CONSTRAINT ck_evidence_packet_type CHECK (packet_type IN ('ARTICLE_DRAFT', 'ARTICLE_UPDATE', 'COMPARISON', 'QUALITY_REVIEW')),
    CONSTRAINT ck_evidence_packet_status CHECK (status IN ('BUILDING', 'READY', 'IN_REVIEW', 'APPROVED', 'INVALID', 'SUPERSEDED')),
    CONSTRAINT ck_evidence_packet_version_no CHECK (current_version_no >= 0),
    CONSTRAINT ck_evidence_packet_lock CHECK (lock_version >= 0)
);
COMMENT ON TABLE evidence.source_packet IS 'Article Plan向けSource PacketのStable Aggregate。Version本文はsource_packet_versionへ置く。';
COMMENT ON COLUMN evidence.source_packet.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.source_packet.display_id IS 'SP-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.source_packet.article_plan_id IS 'article plan id';
COMMENT ON COLUMN evidence.source_packet.packet_type IS 'packet type';
COMMENT ON COLUMN evidence.source_packet.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN evidence.source_packet.current_version_no IS 'current version no';
COMMENT ON COLUMN evidence.source_packet.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN evidence.source_packet.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN evidence.source_packet.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE evidence.source_packet_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    source_packet_id uuid NOT NULL,
    version_no integer NOT NULL,
    artifact_id uuid NOT NULL,
    content_sha256 text NOT NULL,
    schema_version integer NOT NULL,
    status text NOT NULL,
    built_by_job_id uuid,
    reviewed_by_principal_id uuid,
    reviewed_at timestamptz,
    review_note text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_source_packet_version PRIMARY KEY (id),
    CONSTRAINT uq_evidence_packet_version_display UNIQUE (display_id),
    CONSTRAINT uq_evidence_packet_version_no UNIQUE (source_packet_id, version_no),
    CONSTRAINT uq_evidence_packet_version_artifact UNIQUE (artifact_id),
    CONSTRAINT ck_evidence_packet_version_num CHECK (version_no >= 1 AND schema_version >= 1),
    CONSTRAINT ck_evidence_packet_version_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_evidence_packet_version_status CHECK (status IN ('BUILDING', 'READY', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'SUPERSEDED', 'INVALID')),
    CONSTRAINT ck_evidence_packet_version_review CHECK (status NOT IN ('APPROVED','REJECTED') OR (reviewed_by_principal_id IS NOT NULL AND reviewed_at IS NOT NULL))
);
COMMENT ON TABLE evidence.source_packet_version IS 'AI/Editorへ渡す許可済み根拠集合の不変Version。Artifact hash、Schema、Review決定を保持する。';
COMMENT ON COLUMN evidence.source_packet_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.source_packet_version.display_id IS 'SPV-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.source_packet_version.source_packet_id IS 'source packet id';
COMMENT ON COLUMN evidence.source_packet_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN evidence.source_packet_version.artifact_id IS 'S3互換Object Storage上の不変Artifactレジストリ。';
COMMENT ON COLUMN evidence.source_packet_version.content_sha256 IS 'content sha256';
COMMENT ON COLUMN evidence.source_packet_version.schema_version IS 'schema version';
COMMENT ON COLUMN evidence.source_packet_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN evidence.source_packet_version.built_by_job_id IS 'built by job id';
COMMENT ON COLUMN evidence.source_packet_version.reviewed_by_principal_id IS 'reviewed by principal id';
COMMENT ON COLUMN evidence.source_packet_version.reviewed_at IS 'reviewed at';
COMMENT ON COLUMN evidence.source_packet_version.review_note IS 'review note';
COMMENT ON COLUMN evidence.source_packet_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.source_packet_fact (
    source_packet_version_id uuid NOT NULL,
    fact_id uuid NOT NULL,
    usage_role text NOT NULL,
    display_order integer NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_source_packet_fact PRIMARY KEY (source_packet_version_id, fact_id),
    CONSTRAINT ck_evidence_packet_fact_role CHECK (usage_role IN ('REQUIRED', 'SUPPORTING', 'QUALIFIER', 'EXCLUSION', 'CONTRADICTING')),
    CONSTRAINT ck_evidence_packet_fact_order CHECK (display_order >= 0)
);
COMMENT ON TABLE evidence.source_packet_fact IS 'Source Packet VersionへFactをrequired/supporting/exclusionとして収録する。';
COMMENT ON COLUMN evidence.source_packet_fact.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN evidence.source_packet_fact.fact_id IS 'fact id';
COMMENT ON COLUMN evidence.source_packet_fact.usage_role IS 'usage role';
COMMENT ON COLUMN evidence.source_packet_fact.display_order IS 'display order';
COMMENT ON COLUMN evidence.source_packet_fact.is_required IS 'is required';
COMMENT ON COLUMN evidence.source_packet_fact.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.source_packet_product (
    source_packet_version_id uuid NOT NULL,
    product_id uuid NOT NULL,
    offer_id uuid,
    product_role text NOT NULL,
    display_order integer NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_source_packet_product PRIMARY KEY (source_packet_version_id, product_id, product_role),
    CONSTRAINT ck_evidence_packet_product_role CHECK (product_role IN ('CANDIDATE', 'RECOMMENDED', 'COMPARED', 'EXCLUDED', 'REFERENCE')),
    CONSTRAINT ck_evidence_packet_product_order CHECK (display_order >= 0)
);
COMMENT ON TABLE evidence.source_packet_product IS 'Source Packet Versionに含めるProduct/Offerとcandidate/recommended/compared/excluded roleを固定する。';
COMMENT ON COLUMN evidence.source_packet_product.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN evidence.source_packet_product.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN evidence.source_packet_product.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN evidence.source_packet_product.product_role IS 'product role';
COMMENT ON COLUMN evidence.source_packet_product.display_order IS 'display order';
COMMENT ON COLUMN evidence.source_packet_product.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.claim (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_version_id uuid NOT NULL,
    block_id uuid,
    claim_key text NOT NULL,
    claim_type text NOT NULL,
    claim_text text NOT NULL,
    criticality text NOT NULL,
    support_status text DEFAULT 'PENDING' NOT NULL,
    generated_by_ai_attempt_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_claim PRIMARY KEY (id),
    CONSTRAINT uq_evidence_claim_display UNIQUE (display_id),
    CONSTRAINT uq_evidence_claim_key UNIQUE (article_version_id, claim_key),
    CONSTRAINT ck_evidence_claim_type CHECK (claim_type IN ('FACTUAL', 'COMPARATIVE', 'RECOMMENDATION', 'DISCLOSURE', 'EXPERIENCE', 'OPINION')),
    CONSTRAINT ck_evidence_claim_criticality CHECK (criticality IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_evidence_claim_support CHECK (support_status IN ('PENDING', 'SUPPORTED', 'PARTIAL', 'UNSUPPORTED', 'CONFLICT', 'NOT_REQUIRED'))
);
COMMENT ON TABLE evidence.claim IS '公開文中の主張単位。Article Version/Block、生成Attempt、Criticality、Support statusを追跡する。';
COMMENT ON COLUMN evidence.claim.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN evidence.claim.display_id IS 'CLM-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN evidence.claim.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN evidence.claim.block_id IS 'block id';
COMMENT ON COLUMN evidence.claim.claim_key IS 'claim key';
COMMENT ON COLUMN evidence.claim.claim_type IS 'claim type';
COMMENT ON COLUMN evidence.claim.claim_text IS 'claim text';
COMMENT ON COLUMN evidence.claim.criticality IS 'criticality';
COMMENT ON COLUMN evidence.claim.support_status IS 'support status';
COMMENT ON COLUMN evidence.claim.generated_by_ai_attempt_id IS 'generated by ai attempt id';
COMMENT ON COLUMN evidence.claim.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE evidence.claim_evidence_link (
    claim_id uuid NOT NULL,
    fact_id uuid NOT NULL,
    support_type text NOT NULL,
    support_strength numeric(5,4) NOT NULL,
    note text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_evidence_claim_evidence_link PRIMARY KEY (claim_id, fact_id, support_type),
    CONSTRAINT ck_evidence_claim_link_type CHECK (support_type IN ('SUPPORTS', 'QUALIFIES', 'CONTRADICTS')),
    CONSTRAINT ck_evidence_claim_link_strength CHECK (support_strength BETWEEN 0 AND 1)
);
COMMENT ON TABLE evidence.claim_evidence_link IS 'ClaimとFactをsupports/qualifies/contradictsとして結び、Support strengthと注記を保持する。';
COMMENT ON COLUMN evidence.claim_evidence_link.claim_id IS 'claim id';
COMMENT ON COLUMN evidence.claim_evidence_link.fact_id IS 'fact id';
COMMENT ON COLUMN evidence.claim_evidence_link.support_type IS 'support type';
COMMENT ON COLUMN evidence.claim_evidence_link.support_strength IS 'support strength';
COMMENT ON COLUMN evidence.claim_evidence_link.note IS 'note';
COMMENT ON COLUMN evidence.claim_evidence_link.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.article_plan (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    category_id uuid NOT NULL,
    intent_cluster_id uuid NOT NULL,
    primary_keyword_id uuid NOT NULL,
    article_type text NOT NULL,
    working_title text NOT NULL,
    objective text NOT NULL,
    status text DEFAULT 'IDEA' NOT NULL,
    priority smallint DEFAULT 50 NOT NULL,
    opportunity_assessment_id uuid,
    created_by_principal_id uuid NOT NULL,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    brief jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_editorial_article_plan PRIMARY KEY (id),
    CONSTRAINT uq_editorial_plan_display UNIQUE (display_id),
    CONSTRAINT ck_editorial_plan_type CHECK (article_type IN ('SELECTION_GUIDE', 'USE_CASE_RECOMMENDATION', 'PRODUCT_COMPARISON', 'MODEL_DIFFERENCE', 'CONDITION_FILTER')),
    CONSTRAINT ck_editorial_plan_status CHECK (status IN ('IDEA', 'PLANNED', 'SOURCES_PENDING', 'PACKET_READY', 'GENERATING', 'DRAFT', 'IN_REVIEW', 'APPROVED', 'CANCELLED', 'ARCHIVED')),
    CONSTRAINT ck_editorial_plan_priority CHECK (priority BETWEEN 0 AND 100),
    CONSTRAINT ck_editorial_plan_approval CHECK (status <> 'APPROVED' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL)),
    CONSTRAINT ck_editorial_plan_brief CHECK (jsonb_typeof(brief) = 'object'),
    CONSTRAINT ck_editorial_plan_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE editorial.article_plan IS 'Category・Intent・Primary Keyword・Opportunityを結ぶ記事企画。公開記事より前の意思決定正本。';
COMMENT ON COLUMN editorial.article_plan.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article_plan.display_id IS 'PLAN-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN editorial.article_plan.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN editorial.article_plan.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN editorial.article_plan.intent_cluster_id IS 'intent cluster id';
COMMENT ON COLUMN editorial.article_plan.primary_keyword_id IS 'primary keyword id';
COMMENT ON COLUMN editorial.article_plan.article_type IS 'article type';
COMMENT ON COLUMN editorial.article_plan.working_title IS 'working title';
COMMENT ON COLUMN editorial.article_plan.objective IS 'objective';
COMMENT ON COLUMN editorial.article_plan.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.article_plan.priority IS 'priority';
COMMENT ON COLUMN editorial.article_plan.opportunity_assessment_id IS 'opportunity assessment id';
COMMENT ON COLUMN editorial.article_plan.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN editorial.article_plan.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN editorial.article_plan.approved_at IS 'approved at';
COMMENT ON COLUMN editorial.article_plan.brief IS 'Target user、decision questions、required sections、unique value hypothesis。';
COMMENT ON COLUMN editorial.article_plan.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_plan.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_plan.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE editorial.article (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    article_plan_id uuid NOT NULL,
    article_type text NOT NULL,
    status text DEFAULT 'IDEA' NOT NULL,
    current_version_id uuid,
    published_version_id uuid,
    archived_at timestamptz,
    archive_reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_editorial_article PRIMARY KEY (id),
    CONSTRAINT uq_editorial_article_display UNIQUE (display_id),
    CONSTRAINT uq_editorial_article_plan UNIQUE (article_plan_id),
    CONSTRAINT ck_editorial_article_type CHECK (article_type IN ('SELECTION_GUIDE', 'USE_CASE_RECOMMENDATION', 'PRODUCT_COMPARISON', 'MODEL_DIFFERENCE', 'CONDITION_FILTER')),
    CONSTRAINT ck_editorial_article_status CHECK (status IN ('IDEA', 'PLANNED', 'SOURCES_PENDING', 'PACKET_READY', 'GENERATING', 'DRAFT', 'AUTO_REVIEW', 'HUMAN_REVIEW', 'APPROVED', 'SCHEDULED', 'PUBLISHED', 'UPDATE_PENDING', 'PAUSED', 'ARCHIVED')),
    CONSTRAINT ck_editorial_article_archive CHECK (status <> 'ARCHIVED' OR archived_at IS NOT NULL),
    CONSTRAINT ck_editorial_article_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE editorial.article IS '論理記事Aggregate。SlugやVersionを分離し、current/published Versionはdeferrable FKで指す。';
COMMENT ON COLUMN editorial.article.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article.display_id IS 'ART-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN editorial.article.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN editorial.article.article_plan_id IS 'article plan id';
COMMENT ON COLUMN editorial.article.article_type IS 'article type';
COMMENT ON COLUMN editorial.article.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.article.current_version_id IS 'current version id';
COMMENT ON COLUMN editorial.article.published_version_id IS 'published version id';
COMMENT ON COLUMN editorial.article.archived_at IS 'archived at';
COMMENT ON COLUMN editorial.article.archive_reason IS 'archive reason';
COMMENT ON COLUMN editorial.article.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE editorial.article_slug (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    article_id uuid NOT NULL,
    slug text NOT NULL,
    normalized_path text NOT NULL,
    status text NOT NULL,
    valid_from timestamptz NOT NULL,
    valid_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_article_slug PRIMARY KEY (id),
    CONSTRAINT ck_editorial_slug_path CHECK (normalized_path ~ '^/[a-z0-9/_-]*$'),
    CONSTRAINT ck_editorial_slug_status CHECK (status IN ('ACTIVE', 'REDIRECTED', 'RETIRED')),
    CONSTRAINT ck_editorial_slug_window CHECK (valid_to IS NULL OR valid_to > valid_from)
);
COMMENT ON TABLE editorial.article_slug IS 'Site内Pathの履歴。Slug変更時は既存行を上書きせずvalid_toを閉じ、新行を作る。';
COMMENT ON COLUMN editorial.article_slug.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article_slug.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN editorial.article_slug.article_id IS '論理記事ID。';
COMMENT ON COLUMN editorial.article_slug.slug IS 'slug';
COMMENT ON COLUMN editorial.article_slug.normalized_path IS 'normalized path';
COMMENT ON COLUMN editorial.article_slug.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.article_slug.valid_from IS 'valid from';
COMMENT ON COLUMN editorial.article_slug.valid_to IS 'valid to';
COMMENT ON COLUMN editorial.article_slug.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.article_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_id uuid NOT NULL,
    version_no integer NOT NULL,
    content_schema_version integer NOT NULL,
    title text NOT NULL,
    meta_title text,
    meta_description text,
    excerpt text,
    body_sha256 text NOT NULL,
    status text DEFAULT 'DRAFT' NOT NULL,
    source_packet_version_id uuid NOT NULL,
    based_on_version_id uuid,
    ai_job_id uuid,
    created_by_actor_type text NOT NULL,
    created_by_actor_id uuid,
    submitted_at timestamptz,
    reviewed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_editorial_article_version PRIMARY KEY (id),
    CONSTRAINT uq_editorial_article_version_display UNIQUE (display_id),
    CONSTRAINT uq_editorial_article_version_no UNIQUE (article_id, version_no),
    CONSTRAINT ck_editorial_article_version_num CHECK (version_no >= 1 AND content_schema_version >= 1),
    CONSTRAINT ck_editorial_article_version_hash CHECK (body_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_editorial_article_version_status CHECK (status IN ('DRAFT', 'AUTO_REVIEW', 'HUMAN_REVIEW', 'APPROVED', 'REJECTED', 'SUPERSEDED')),
    CONSTRAINT ck_editorial_article_version_actor CHECK (created_by_actor_type IN ('USER', 'SERVICE', 'SYSTEM')),
    CONSTRAINT ck_editorial_article_version_review CHECK (status NOT IN ('HUMAN_REVIEW','APPROVED','REJECTED') OR submitted_at IS NOT NULL),
    CONSTRAINT ck_editorial_article_version_lock CHECK (lock_version >= 0)
);
COMMENT ON TABLE editorial.article_version IS '構造化記事のVersion。AI Draft、人間Edit、Review、Approvalを上書きせずVersionで管理する。';
COMMENT ON COLUMN editorial.article_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article_version.display_id IS 'ARV-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN editorial.article_version.article_id IS '論理記事ID。';
COMMENT ON COLUMN editorial.article_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN editorial.article_version.content_schema_version IS 'content schema version';
COMMENT ON COLUMN editorial.article_version.title IS 'title';
COMMENT ON COLUMN editorial.article_version.meta_title IS 'meta title';
COMMENT ON COLUMN editorial.article_version.meta_description IS 'meta description';
COMMENT ON COLUMN editorial.article_version.excerpt IS 'excerpt';
COMMENT ON COLUMN editorial.article_version.body_sha256 IS 'body sha256';
COMMENT ON COLUMN editorial.article_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.article_version.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN editorial.article_version.based_on_version_id IS 'based on version id';
COMMENT ON COLUMN editorial.article_version.ai_job_id IS 'ai job id';
COMMENT ON COLUMN editorial.article_version.created_by_actor_type IS 'created by actor type';
COMMENT ON COLUMN editorial.article_version.created_by_actor_id IS 'created by actor id';
COMMENT ON COLUMN editorial.article_version.submitted_at IS 'submitted at';
COMMENT ON COLUMN editorial.article_version.reviewed_at IS 'reviewed at';
COMMENT ON COLUMN editorial.article_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_version.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_version.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE editorial.article_block (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_version_id uuid NOT NULL,
    block_key text NOT NULL,
    block_type text NOT NULL,
    position integer NOT NULL,
    heading_level smallint,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    plain_text text NOT NULL,
    content_sha256 text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_article_block PRIMARY KEY (id),
    CONSTRAINT uq_editorial_block_key UNIQUE (article_version_id, block_key),
    CONSTRAINT uq_editorial_block_position UNIQUE (article_version_id, position),
    CONSTRAINT uq_editorial_block_id_version UNIQUE (id, article_version_id),
    CONSTRAINT ck_editorial_block_type CHECK (block_type IN ('INTRO', 'HEADING', 'PARAGRAPH', 'SELECTION_CRITERIA', 'COMPARISON_TABLE', 'PRODUCT_CARD', 'RECOMMENDATION', 'FIT_NONFIT', 'FAQ', 'DISCLOSURE', 'SUMMARY', 'CALLOUT', 'INTERNAL_LINKS')),
    CONSTRAINT ck_editorial_block_position CHECK (position >= 0),
    CONSTRAINT ck_editorial_block_heading CHECK (heading_level IS NULL OR heading_level BETWEEN 2 AND 4),
    CONSTRAINT ck_editorial_block_content CHECK (jsonb_typeof(content) = 'object'),
    CONSTRAINT ck_editorial_block_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$')
);
COMMENT ON TABLE editorial.article_block IS 'Article Version内の順序付き構造化Block。任意HTMLではなくBlock type＋Schema-valid JSONを保存する。';
COMMENT ON COLUMN editorial.article_block.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article_block.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN editorial.article_block.block_key IS 'block key';
COMMENT ON COLUMN editorial.article_block.block_type IS 'block type';
COMMENT ON COLUMN editorial.article_block.position IS 'position';
COMMENT ON COLUMN editorial.article_block.heading_level IS 'heading level';
COMMENT ON COLUMN editorial.article_block.content IS 'Block type別JSON Schemaに適合した構造化本文。';
COMMENT ON COLUMN editorial.article_block.plain_text IS 'plain text';
COMMENT ON COLUMN editorial.article_block.content_sha256 IS 'content sha256';
COMMENT ON COLUMN editorial.article_block.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.article_block_product (
    article_block_id uuid NOT NULL,
    product_id uuid NOT NULL,
    offer_id uuid,
    placement_role text NOT NULL,
    position integer NOT NULL,
    placement_id text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_article_block_product PRIMARY KEY (article_block_id, product_id, placement_role),
    CONSTRAINT uq_editorial_block_placement UNIQUE (placement_id),
    CONSTRAINT ck_editorial_block_product_role CHECK (placement_role IN ('PRIMARY', 'ALTERNATIVE', 'COMPARED', 'MENTIONED', 'EXCLUDED')),
    CONSTRAINT ck_editorial_block_product_position CHECK (position >= 0)
);
COMMENT ON TABLE editorial.article_block_product IS 'BlockへProduct/Offerをroleとposition付きで結ぶ。';
COMMENT ON COLUMN editorial.article_block_product.article_block_id IS 'article block id';
COMMENT ON COLUMN editorial.article_block_product.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN editorial.article_block_product.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN editorial.article_block_product.placement_role IS 'placement role';
COMMENT ON COLUMN editorial.article_block_product.position IS 'position';
COMMENT ON COLUMN editorial.article_block_product.placement_id IS 'placement id';
COMMENT ON COLUMN editorial.article_block_product.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.comparison_axis (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_version_id uuid NOT NULL,
    axis_code text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    data_type text NOT NULL,
    unit_code text,
    position integer NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_comparison_axis PRIMARY KEY (id),
    CONSTRAINT uq_editorial_axis_code UNIQUE (article_version_id, axis_code),
    CONSTRAINT uq_editorial_axis_position UNIQUE (article_version_id, position),
    CONSTRAINT ck_editorial_axis_type CHECK (data_type IN ('TEXT', 'NUMERIC', 'BOOLEAN', 'DATE', 'CODE')),
    CONSTRAINT ck_editorial_axis_position CHECK (position >= 0)
);
COMMENT ON TABLE editorial.comparison_axis IS 'Article Versionごとの比較軸定義。Product比較表の意味と型・単位・根拠要件を固定する。';
COMMENT ON COLUMN editorial.comparison_axis.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.comparison_axis.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN editorial.comparison_axis.axis_code IS 'axis code';
COMMENT ON COLUMN editorial.comparison_axis.name IS 'name';
COMMENT ON COLUMN editorial.comparison_axis.description IS 'description';
COMMENT ON COLUMN editorial.comparison_axis.data_type IS 'data type';
COMMENT ON COLUMN editorial.comparison_axis.unit_code IS 'unit code';
COMMENT ON COLUMN editorial.comparison_axis.position IS 'position';
COMMENT ON COLUMN editorial.comparison_axis.is_required IS 'is required';
COMMENT ON COLUMN editorial.comparison_axis.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.comparison_value (
    id uuid DEFAULT uuidv7() NOT NULL,
    comparison_axis_id uuid NOT NULL,
    product_id uuid NOT NULL,
    value_text text,
    value_numeric numeric(30,10),
    value_boolean boolean,
    value_date date,
    value_code text,
    display_value text NOT NULL,
    source_fact_id uuid,
    validation_status text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_comparison_value PRIMARY KEY (id),
    CONSTRAINT uq_editorial_comparison_value UNIQUE (comparison_axis_id, product_id),
    CONSTRAINT ck_editorial_comparison_one_value CHECK (num_nonnulls(value_text, value_numeric, value_boolean, value_date, value_code) = 1),
    CONSTRAINT ck_editorial_comparison_status CHECK (validation_status IN ('VALID', 'MISSING', 'CONFLICT', 'UNSUPPORTED')),
    CONSTRAINT ck_editorial_comparison_evidence CHECK (validation_status <> 'VALID' OR source_fact_id IS NOT NULL)
);
COMMENT ON TABLE editorial.comparison_value IS '比較軸×Productの型付き値、表示値、根拠Fact、Validation状態。';
COMMENT ON COLUMN editorial.comparison_value.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.comparison_value.comparison_axis_id IS 'comparison axis id';
COMMENT ON COLUMN editorial.comparison_value.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN editorial.comparison_value.value_text IS 'value text';
COMMENT ON COLUMN editorial.comparison_value.value_numeric IS 'value numeric';
COMMENT ON COLUMN editorial.comparison_value.value_boolean IS 'value boolean';
COMMENT ON COLUMN editorial.comparison_value.value_date IS 'value date';
COMMENT ON COLUMN editorial.comparison_value.value_code IS 'value code';
COMMENT ON COLUMN editorial.comparison_value.display_value IS 'display value';
COMMENT ON COLUMN editorial.comparison_value.source_fact_id IS 'source fact id';
COMMENT ON COLUMN editorial.comparison_value.validation_status IS 'validation status';
COMMENT ON COLUMN editorial.comparison_value.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.recommendation_set (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_version_id uuid NOT NULL,
    set_code text NOT NULL,
    name text NOT NULL,
    target_segment text NOT NULL,
    methodology text NOT NULL,
    editorial_policy_version text NOT NULL,
    position integer NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_recommendation_set PRIMARY KEY (id),
    CONSTRAINT uq_editorial_rec_set_code UNIQUE (article_version_id, set_code),
    CONSTRAINT uq_editorial_rec_set_position UNIQUE (article_version_id, position),
    CONSTRAINT ck_editorial_rec_set_position CHECK (position >= 0)
);
COMMENT ON TABLE editorial.recommendation_set IS '用途・条件別Recommendation groupとMethodologyをArticle Versionへ固定する。';
COMMENT ON COLUMN editorial.recommendation_set.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.recommendation_set.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN editorial.recommendation_set.set_code IS 'set code';
COMMENT ON COLUMN editorial.recommendation_set.name IS 'name';
COMMENT ON COLUMN editorial.recommendation_set.target_segment IS 'target segment';
COMMENT ON COLUMN editorial.recommendation_set.methodology IS 'methodology';
COMMENT ON COLUMN editorial.recommendation_set.editorial_policy_version IS 'editorial policy version';
COMMENT ON COLUMN editorial.recommendation_set.position IS 'position';
COMMENT ON COLUMN editorial.recommendation_set.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.recommendation (
    id uuid DEFAULT uuidv7() NOT NULL,
    recommendation_set_id uuid NOT NULL,
    product_id uuid NOT NULL,
    rank_position integer NOT NULL,
    suitability_score numeric(5,2) NOT NULL,
    status text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_recommendation PRIMARY KEY (id),
    CONSTRAINT uq_editorial_rec_product UNIQUE (recommendation_set_id, product_id),
    CONSTRAINT uq_editorial_rec_rank UNIQUE (recommendation_set_id, rank_position),
    CONSTRAINT ck_editorial_rec_rank CHECK (rank_position >= 1),
    CONSTRAINT ck_editorial_rec_score CHECK (suitability_score >= 0 AND suitability_score <= 100),
    CONSTRAINT ck_editorial_rec_status CHECK (status IN ('RECOMMENDED', 'ALTERNATIVE', 'NOT_RECOMMENDED', 'EXCLUDED'))
);
COMMENT ON TABLE editorial.recommendation IS 'Recommendation Set内の商品順位とEditorial Suitability Score。収益・Affiliate rate Columnを持たない。';
COMMENT ON COLUMN editorial.recommendation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.recommendation.recommendation_set_id IS 'recommendation set id';
COMMENT ON COLUMN editorial.recommendation.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN editorial.recommendation.rank_position IS 'rank position';
COMMENT ON COLUMN editorial.recommendation.suitability_score IS 'suitability score';
COMMENT ON COLUMN editorial.recommendation.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.recommendation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.recommendation_rationale (
    id uuid DEFAULT uuidv7() NOT NULL,
    recommendation_id uuid NOT NULL,
    rationale_type text NOT NULL,
    rationale_text text NOT NULL,
    claim_id uuid,
    source_fact_id uuid,
    position integer NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_recommendation_rationale PRIMARY KEY (id),
    CONSTRAINT ck_editorial_rationale_type CHECK (rationale_type IN ('FIT', 'NON_FIT', 'TRADE_OFF', 'QUALIFIER', 'EVIDENCE')),
    CONSTRAINT ck_editorial_rationale_source CHECK (claim_id IS NOT NULL OR source_fact_id IS NOT NULL),
    CONSTRAINT ck_editorial_rationale_position CHECK (position >= 0)
);
COMMENT ON TABLE editorial.recommendation_rationale IS '推薦のfit/non-fit/trade-off/qualifierをClaimまたはFactへ結び、説明可能性を担保する。';
COMMENT ON COLUMN editorial.recommendation_rationale.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.recommendation_rationale.recommendation_id IS 'recommendation id';
COMMENT ON COLUMN editorial.recommendation_rationale.rationale_type IS 'rationale type';
COMMENT ON COLUMN editorial.recommendation_rationale.rationale_text IS 'rationale text';
COMMENT ON COLUMN editorial.recommendation_rationale.claim_id IS 'claim id';
COMMENT ON COLUMN editorial.recommendation_rationale.source_fact_id IS 'source fact id';
COMMENT ON COLUMN editorial.recommendation_rationale.position IS 'position';
COMMENT ON COLUMN editorial.recommendation_rationale.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.review_comment (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_version_id uuid NOT NULL,
    article_block_id uuid,
    claim_id uuid,
    thread_id uuid NOT NULL,
    parent_comment_id uuid,
    author_principal_id uuid NOT NULL,
    comment_text text NOT NULL,
    status text DEFAULT 'OPEN' NOT NULL,
    resolved_by_principal_id uuid,
    resolved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_editorial_review_comment PRIMARY KEY (id),
    CONSTRAINT ck_editorial_review_comment_status CHECK (status IN ('OPEN', 'RESOLVED', 'WONT_FIX')),
    CONSTRAINT ck_editorial_review_comment_target CHECK (article_block_id IS NOT NULL OR claim_id IS NOT NULL),
    CONSTRAINT ck_editorial_review_comment_resolve_pair CHECK ((resolved_by_principal_id IS NULL) = (resolved_at IS NULL))
);
COMMENT ON TABLE editorial.review_comment IS 'Article Version、Block、Claimに対するReview thread。修正・解決履歴を上書きせずCommentとして残す。';
COMMENT ON COLUMN editorial.review_comment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.review_comment.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN editorial.review_comment.article_block_id IS 'article block id';
COMMENT ON COLUMN editorial.review_comment.claim_id IS 'claim id';
COMMENT ON COLUMN editorial.review_comment.thread_id IS 'thread id';
COMMENT ON COLUMN editorial.review_comment.parent_comment_id IS 'parent comment id';
COMMENT ON COLUMN editorial.review_comment.author_principal_id IS 'author principal id';
COMMENT ON COLUMN editorial.review_comment.comment_text IS 'comment text';
COMMENT ON COLUMN editorial.review_comment.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.review_comment.resolved_by_principal_id IS 'resolved by principal id';
COMMENT ON COLUMN editorial.review_comment.resolved_at IS 'resolved at';
COMMENT ON COLUMN editorial.review_comment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE editorial.article_link (
    id uuid DEFAULT uuidv7() NOT NULL,
    from_article_id uuid NOT NULL,
    to_article_id uuid NOT NULL,
    link_type text NOT NULL,
    anchor_text text,
    source_block_key text,
    status text DEFAULT 'ACTIVE' NOT NULL,
    reason text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_editorial_article_link PRIMARY KEY (id),
    CONSTRAINT uq_editorial_article_link UNIQUE (from_article_id, to_article_id, link_type),
    CONSTRAINT ck_editorial_article_link_self CHECK (from_article_id <> to_article_id),
    CONSTRAINT ck_editorial_article_link_type CHECK (link_type IN ('INTERNAL', 'RELATED', 'CANONICAL_REFERENCE')),
    CONSTRAINT ck_editorial_article_link_status CHECK (status IN ('ACTIVE', 'PAUSED', 'REMOVED')),
    CONSTRAINT ck_editorial_article_link_version CHECK (lock_version >= 0)
);
COMMENT ON TABLE editorial.article_link IS '記事間のInternal/Related/Canonical link intentを管理し、公開時に安全なRouteへ解決する。';
COMMENT ON COLUMN editorial.article_link.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN editorial.article_link.from_article_id IS 'from article id';
COMMENT ON COLUMN editorial.article_link.to_article_id IS 'to article id';
COMMENT ON COLUMN editorial.article_link.link_type IS 'link type';
COMMENT ON COLUMN editorial.article_link.anchor_text IS 'anchor text';
COMMENT ON COLUMN editorial.article_link.source_block_key IS 'source block key';
COMMENT ON COLUMN editorial.article_link.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN editorial.article_link.reason IS 'reason';
COMMENT ON COLUMN editorial.article_link.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_link.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN editorial.article_link.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE ai.task_definition (
    id uuid DEFAULT uuidv7() NOT NULL,
    task_code text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    risk_level text NOT NULL,
    output_schema_code text NOT NULL,
    default_max_tokens integer NOT NULL,
    default_max_cost_jpy bigint NOT NULL,
    human_review_required boolean DEFAULT true NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_task_definition PRIMARY KEY (id),
    CONSTRAINT uq_ai_task_code UNIQUE (task_code),
    CONSTRAINT ck_ai_task_risk CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_ai_task_tokens CHECK (default_max_tokens BETWEEN 1 AND 1000000),
    CONSTRAINT ck_ai_task_cost CHECK (default_max_cost_jpy >= 0),
    CONSTRAINT ck_ai_task_status CHECK (status IN ('ACTIVE', 'PAUSED', 'RETIRED'))
);
COMMENT ON TABLE ai.task_definition IS 'AI処理のTask type、Risk、Output Schema、予算、人間Review要否を定義する。';
COMMENT ON COLUMN ai.task_definition.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.task_definition.task_code IS 'task code';
COMMENT ON COLUMN ai.task_definition.name IS 'name';
COMMENT ON COLUMN ai.task_definition.description IS 'description';
COMMENT ON COLUMN ai.task_definition.risk_level IS 'risk level';
COMMENT ON COLUMN ai.task_definition.output_schema_code IS 'output schema code';
COMMENT ON COLUMN ai.task_definition.default_max_tokens IS 'default max tokens';
COMMENT ON COLUMN ai.task_definition.default_max_cost_jpy IS 'default max cost jpy';
COMMENT ON COLUMN ai.task_definition.human_review_required IS 'human review required';
COMMENT ON COLUMN ai.task_definition.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.task_definition.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.prompt_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    task_definition_id uuid NOT NULL,
    prompt_code text NOT NULL,
    version_no integer NOT NULL,
    git_path text NOT NULL,
    git_commit_sha text NOT NULL,
    template_sha256 text NOT NULL,
    status text NOT NULL,
    effective_from timestamptz,
    effective_to timestamptz,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_prompt_version PRIMARY KEY (id),
    CONSTRAINT uq_ai_prompt_display UNIQUE (display_id),
    CONSTRAINT uq_ai_prompt_version UNIQUE (prompt_code, version_no),
    CONSTRAINT ck_ai_prompt_version CHECK (version_no >= 1),
    CONSTRAINT ck_ai_prompt_git CHECK (git_commit_sha ~ '^[0-9a-f]{40,64}$'),
    CONSTRAINT ck_ai_prompt_hash CHECK (template_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ai_prompt_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED', 'REJECTED')),
    CONSTRAINT ck_ai_prompt_window CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from),
    CONSTRAINT ck_ai_prompt_approval CHECK (status <> 'ACTIVE' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL))
);
COMMENT ON TABLE ai.prompt_version IS 'Git管理Prompt templateの稼働Version、hash、承認、適用期間を登録する。Prompt本文はDBへ重複保存しない。';
COMMENT ON COLUMN ai.prompt_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.prompt_version.display_id IS 'PRM-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ai.prompt_version.task_definition_id IS 'task definition id';
COMMENT ON COLUMN ai.prompt_version.prompt_code IS 'prompt code';
COMMENT ON COLUMN ai.prompt_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN ai.prompt_version.git_path IS 'git path';
COMMENT ON COLUMN ai.prompt_version.git_commit_sha IS 'git commit sha';
COMMENT ON COLUMN ai.prompt_version.template_sha256 IS 'template sha256';
COMMENT ON COLUMN ai.prompt_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.prompt_version.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN ai.prompt_version.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN ai.prompt_version.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN ai.prompt_version.approved_at IS 'approved at';
COMMENT ON COLUMN ai.prompt_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.output_schema_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    schema_code text NOT NULL,
    version_no integer NOT NULL,
    git_path text NOT NULL,
    git_commit_sha text NOT NULL,
    schema_sha256 text NOT NULL,
    status text NOT NULL,
    effective_from timestamptz,
    effective_to timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_output_schema_version PRIMARY KEY (id),
    CONSTRAINT uq_ai_output_schema_version UNIQUE (schema_code, version_no),
    CONSTRAINT ck_ai_output_schema_version CHECK (version_no >= 1),
    CONSTRAINT ck_ai_output_schema_git CHECK (git_commit_sha ~ '^[0-9a-f]{40,64}$'),
    CONSTRAINT ck_ai_output_schema_hash CHECK (schema_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ai_output_schema_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED')),
    CONSTRAINT ck_ai_output_schema_window CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from)
);
COMMENT ON TABLE ai.output_schema_version IS 'Structured OutputのJSON Schema version、Git commit、hash、稼働状態を登録する。';
COMMENT ON COLUMN ai.output_schema_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.output_schema_version.schema_code IS 'schema code';
COMMENT ON COLUMN ai.output_schema_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN ai.output_schema_version.git_path IS 'git path';
COMMENT ON COLUMN ai.output_schema_version.git_commit_sha IS 'git commit sha';
COMMENT ON COLUMN ai.output_schema_version.schema_sha256 IS 'schema sha256';
COMMENT ON COLUMN ai.output_schema_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.output_schema_version.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN ai.output_schema_version.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN ai.output_schema_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.model_definition (
    id uuid DEFAULT uuidv7() NOT NULL,
    provider_code text NOT NULL,
    provider_model_id text NOT NULL,
    display_name text NOT NULL,
    capabilities jsonb DEFAULT '{}'::jsonb NOT NULL,
    input_price_per_million numeric(20,8),
    cached_input_price_per_million numeric(20,8),
    output_price_per_million numeric(20,8),
    pricing_currency text,
    pricing_observed_at timestamptz,
    status text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_model_definition PRIMARY KEY (id),
    CONSTRAINT uq_ai_model_provider_id UNIQUE (provider_code, provider_model_id),
    CONSTRAINT ck_ai_model_capabilities CHECK (jsonb_typeof(capabilities) = 'object'),
    CONSTRAINT ck_ai_model_prices CHECK ((input_price_per_million IS NULL OR input_price_per_million >= 0) AND (cached_input_price_per_million IS NULL OR cached_input_price_per_million >= 0) AND (output_price_per_million IS NULL OR output_price_per_million >= 0)),
    CONSTRAINT ck_ai_model_currency CHECK (pricing_currency IS NULL OR pricing_currency ~ '^[A-Z]{3}$'),
    CONSTRAINT ck_ai_model_status CHECK (status IN ('ACTIVE', 'EVALUATION', 'PAUSED', 'RETIRED', 'BLOCKED'))
);
COMMENT ON TABLE ai.model_definition IS 'Provider model ID、Capability、Pricing observation、稼働状態を管理する。API Keyは保持しない。';
COMMENT ON COLUMN ai.model_definition.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.model_definition.provider_code IS 'provider code';
COMMENT ON COLUMN ai.model_definition.provider_model_id IS 'provider model id';
COMMENT ON COLUMN ai.model_definition.display_name IS 'display name';
COMMENT ON COLUMN ai.model_definition.capabilities IS 'Structured output、context、batch等のCapability snapshot。';
COMMENT ON COLUMN ai.model_definition.input_price_per_million IS 'input price per million';
COMMENT ON COLUMN ai.model_definition.cached_input_price_per_million IS 'cached input price per million';
COMMENT ON COLUMN ai.model_definition.output_price_per_million IS 'output price per million';
COMMENT ON COLUMN ai.model_definition.pricing_currency IS 'pricing currency';
COMMENT ON COLUMN ai.model_definition.pricing_observed_at IS 'pricing observed at';
COMMENT ON COLUMN ai.model_definition.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.model_definition.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.model_route_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    route_code text NOT NULL,
    version_no integer NOT NULL,
    task_definition_id uuid NOT NULL,
    primary_model_id uuid NOT NULL,
    fallback_model_id uuid,
    route_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    monthly_budget_jpy bigint,
    per_job_budget_jpy bigint NOT NULL,
    status text NOT NULL,
    effective_from timestamptz,
    effective_to timestamptz,
    approved_by_principal_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_model_route_version PRIMARY KEY (id),
    CONSTRAINT uq_ai_route_version UNIQUE (route_code, version_no),
    CONSTRAINT ck_ai_route_version CHECK (version_no >= 1),
    CONSTRAINT ck_ai_route_config CHECK (jsonb_typeof(route_config) = 'object'),
    CONSTRAINT ck_ai_route_budget CHECK ((monthly_budget_jpy IS NULL OR monthly_budget_jpy >= 0) AND per_job_budget_jpy >= 0),
    CONSTRAINT ck_ai_route_status CHECK (status IN ('DRAFT', 'ACTIVE', 'PAUSED', 'RETIRED')),
    CONSTRAINT ck_ai_route_window CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from),
    CONSTRAINT ck_ai_route_models CHECK (fallback_model_id IS NULL OR fallback_model_id <> primary_model_id)
);
COMMENT ON TABLE ai.model_route_version IS 'TaskごとのPrimary/Fallback model、Timeout、Budget、Retry等の稼働Route version。';
COMMENT ON COLUMN ai.model_route_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.model_route_version.route_code IS 'route code';
COMMENT ON COLUMN ai.model_route_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN ai.model_route_version.task_definition_id IS 'task definition id';
COMMENT ON COLUMN ai.model_route_version.primary_model_id IS 'primary model id';
COMMENT ON COLUMN ai.model_route_version.fallback_model_id IS 'fallback model id';
COMMENT ON COLUMN ai.model_route_version.route_config IS 'Timeout、retry、temperature、max tokens等。';
COMMENT ON COLUMN ai.model_route_version.monthly_budget_jpy IS 'monthly budget jpy';
COMMENT ON COLUMN ai.model_route_version.per_job_budget_jpy IS 'per job budget jpy';
COMMENT ON COLUMN ai.model_route_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.model_route_version.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN ai.model_route_version.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN ai.model_route_version.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN ai.model_route_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.ai_job (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    ops_job_id uuid NOT NULL,
    task_definition_id uuid NOT NULL,
    article_plan_id uuid,
    article_version_id uuid,
    source_packet_version_id uuid NOT NULL,
    prompt_version_id uuid NOT NULL,
    output_schema_version_id uuid NOT NULL,
    model_route_version_id uuid NOT NULL,
    status text DEFAULT 'PENDING' NOT NULL,
    max_cost_jpy bigint NOT NULL,
    completed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_ai_job PRIMARY KEY (id),
    CONSTRAINT uq_ai_job_display UNIQUE (display_id),
    CONSTRAINT uq_ai_job_ops UNIQUE (ops_job_id),
    CONSTRAINT ck_ai_job_status CHECK (status IN ('PENDING', 'RUNNING', 'SUCCEEDED', 'FAILED', 'BLOCKED', 'CANCELLED')),
    CONSTRAINT ck_ai_job_cost CHECK (max_cost_jpy >= 0),
    CONSTRAINT ck_ai_job_target CHECK (article_plan_id IS NOT NULL OR article_version_id IS NOT NULL),
    CONSTRAINT ck_ai_job_complete CHECK (status NOT IN ('SUCCEEDED','FAILED','BLOCKED','CANCELLED') OR completed_at IS NOT NULL)
);
COMMENT ON TABLE ai.ai_job IS 'AI TaskのCanonical requestと各Version参照を固定し、Ops Jobと1対1で実行状態を管理する。';
COMMENT ON COLUMN ai.ai_job.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.ai_job.display_id IS 'AIJ-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN ai.ai_job.ops_job_id IS 'ops job id';
COMMENT ON COLUMN ai.ai_job.task_definition_id IS 'task definition id';
COMMENT ON COLUMN ai.ai_job.article_plan_id IS 'article plan id';
COMMENT ON COLUMN ai.ai_job.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN ai.ai_job.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN ai.ai_job.prompt_version_id IS 'prompt version id';
COMMENT ON COLUMN ai.ai_job.output_schema_version_id IS 'output schema version id';
COMMENT ON COLUMN ai.ai_job.model_route_version_id IS 'model route version id';
COMMENT ON COLUMN ai.ai_job.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.ai_job.max_cost_jpy IS 'max cost jpy';
COMMENT ON COLUMN ai.ai_job.completed_at IS 'completed at';
COMMENT ON COLUMN ai.ai_job.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.ai_attempt (
    id uuid DEFAULT uuidv7() NOT NULL,
    ai_job_id uuid NOT NULL,
    attempt_no smallint NOT NULL,
    model_id uuid NOT NULL,
    provider_request_id text,
    status text NOT NULL,
    input_artifact_id uuid NOT NULL,
    output_artifact_id uuid,
    input_sha256 text NOT NULL,
    output_sha256 text,
    refusal_code text,
    finish_reason text,
    latency_ms integer,
    error_class text,
    error_code text,
    error_message text,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_ai_attempt PRIMARY KEY (id),
    CONSTRAINT uq_ai_attempt_no UNIQUE (ai_job_id, attempt_no),
    CONSTRAINT ck_ai_attempt_no CHECK (attempt_no >= 1),
    CONSTRAINT ck_ai_attempt_status CHECK (status IN ('RUNNING', 'SUCCEEDED', 'FAILED', 'REFUSED', 'TIMED_OUT', 'CANCELLED')),
    CONSTRAINT ck_ai_attempt_input_hash CHECK (input_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ai_attempt_output_hash CHECK (output_sha256 IS NULL OR output_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_ai_attempt_latency CHECK (latency_ms IS NULL OR latency_ms >= 0),
    CONSTRAINT ck_ai_attempt_complete CHECK (status = 'RUNNING' OR completed_at IS NOT NULL),
    CONSTRAINT ck_ai_attempt_output CHECK (status <> 'SUCCEEDED' OR (output_artifact_id IS NOT NULL AND output_sha256 IS NOT NULL))
);
COMMENT ON TABLE ai.ai_attempt IS 'Provider callごとの入力/出力Artifact、model、request ID、hash、Refusal、Latency、Errorを不変保存する。';
COMMENT ON COLUMN ai.ai_attempt.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.ai_attempt.ai_job_id IS 'ai job id';
COMMENT ON COLUMN ai.ai_attempt.attempt_no IS 'attempt no';
COMMENT ON COLUMN ai.ai_attempt.model_id IS 'model id';
COMMENT ON COLUMN ai.ai_attempt.provider_request_id IS 'provider request id';
COMMENT ON COLUMN ai.ai_attempt.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN ai.ai_attempt.input_artifact_id IS 'input artifact id';
COMMENT ON COLUMN ai.ai_attempt.output_artifact_id IS 'output artifact id';
COMMENT ON COLUMN ai.ai_attempt.input_sha256 IS 'input sha256';
COMMENT ON COLUMN ai.ai_attempt.output_sha256 IS 'output sha256';
COMMENT ON COLUMN ai.ai_attempt.refusal_code IS 'refusal code';
COMMENT ON COLUMN ai.ai_attempt.finish_reason IS 'finish reason';
COMMENT ON COLUMN ai.ai_attempt.latency_ms IS 'latency ms';
COMMENT ON COLUMN ai.ai_attempt.error_class IS 'error class';
COMMENT ON COLUMN ai.ai_attempt.error_code IS 'error code';
COMMENT ON COLUMN ai.ai_attempt.error_message IS 'error message';
COMMENT ON COLUMN ai.ai_attempt.started_at IS 'started at';
COMMENT ON COLUMN ai.ai_attempt.completed_at IS 'completed at';
COMMENT ON COLUMN ai.ai_attempt.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.usage_cost (
    id uuid DEFAULT uuidv7() NOT NULL,
    ai_attempt_id uuid NOT NULL,
    input_tokens bigint NOT NULL,
    cached_input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint NOT NULL,
    total_tokens bigint NOT NULL,
    provider_cost_amount numeric(20,8) NOT NULL,
    provider_currency text NOT NULL,
    fx_rate_to_jpy numeric(20,8) NOT NULL,
    cost_jpy bigint NOT NULL,
    pricing_version text NOT NULL,
    observed_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_usage_cost PRIMARY KEY (id),
    CONSTRAINT uq_ai_usage_attempt UNIQUE (ai_attempt_id),
    CONSTRAINT ck_ai_usage_tokens CHECK (input_tokens >= 0 AND cached_input_tokens >= 0 AND output_tokens >= 0 AND total_tokens = input_tokens + output_tokens),
    CONSTRAINT ck_ai_usage_cost CHECK (provider_cost_amount >= 0 AND fx_rate_to_jpy > 0 AND cost_jpy >= 0),
    CONSTRAINT ck_ai_usage_currency CHECK (provider_currency ~ '^[A-Z]{3}$')
);
COMMENT ON TABLE ai.usage_cost IS 'AI AttemptのToken usage、Provider原通貨費用、換算Rate、JPY費用を不変記録する。';
COMMENT ON COLUMN ai.usage_cost.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.usage_cost.ai_attempt_id IS 'ai attempt id';
COMMENT ON COLUMN ai.usage_cost.input_tokens IS 'input tokens';
COMMENT ON COLUMN ai.usage_cost.cached_input_tokens IS 'cached input tokens';
COMMENT ON COLUMN ai.usage_cost.output_tokens IS 'output tokens';
COMMENT ON COLUMN ai.usage_cost.total_tokens IS 'total tokens';
COMMENT ON COLUMN ai.usage_cost.provider_cost_amount IS 'provider cost amount';
COMMENT ON COLUMN ai.usage_cost.provider_currency IS 'provider currency';
COMMENT ON COLUMN ai.usage_cost.fx_rate_to_jpy IS 'fx rate to jpy';
COMMENT ON COLUMN ai.usage_cost.cost_jpy IS 'cost jpy';
COMMENT ON COLUMN ai.usage_cost.pricing_version IS 'pricing version';
COMMENT ON COLUMN ai.usage_cost.observed_at IS 'observed at';
COMMENT ON COLUMN ai.usage_cost.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE ai.evaluation_result (
    id uuid DEFAULT uuidv7() NOT NULL,
    suite_code text NOT NULL,
    suite_version integer NOT NULL,
    run_id uuid NOT NULL,
    task_definition_id uuid NOT NULL,
    model_route_version_id uuid NOT NULL,
    prompt_version_id uuid NOT NULL,
    case_key text NOT NULL,
    metric_code text NOT NULL,
    metric_value numeric(20,8) NOT NULL,
    passed boolean NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_artifact_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_ai_evaluation_result PRIMARY KEY (id),
    CONSTRAINT uq_ai_eval_case_metric UNIQUE (run_id, case_key, metric_code),
    CONSTRAINT ck_ai_eval_suite_version CHECK (suite_version >= 1),
    CONSTRAINT ck_ai_eval_details CHECK (jsonb_typeof(details) = 'object')
);
COMMENT ON TABLE ai.evaluation_result IS 'Model RouteまたはPrompt候補を固定Evaluation suiteで比較したCase/Metric結果。詳細DatasetはArtifactへ置く。';
COMMENT ON COLUMN ai.evaluation_result.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN ai.evaluation_result.suite_code IS 'suite code';
COMMENT ON COLUMN ai.evaluation_result.suite_version IS 'suite version';
COMMENT ON COLUMN ai.evaluation_result.run_id IS 'run id';
COMMENT ON COLUMN ai.evaluation_result.task_definition_id IS 'task definition id';
COMMENT ON COLUMN ai.evaluation_result.model_route_version_id IS 'model route version id';
COMMENT ON COLUMN ai.evaluation_result.prompt_version_id IS 'prompt version id';
COMMENT ON COLUMN ai.evaluation_result.case_key IS 'case key';
COMMENT ON COLUMN ai.evaluation_result.metric_code IS 'metric code';
COMMENT ON COLUMN ai.evaluation_result.metric_value IS 'metric value';
COMMENT ON COLUMN ai.evaluation_result.passed IS 'passed';
COMMENT ON COLUMN ai.evaluation_result.details IS 'details';
COMMENT ON COLUMN ai.evaluation_result.result_artifact_id IS 'result artifact id';
COMMENT ON COLUMN ai.evaluation_result.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.policy_bundle (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    bundle_code text NOT NULL,
    version_no integer NOT NULL,
    status text NOT NULL,
    git_commit_sha text NOT NULL,
    bundle_sha256 text NOT NULL,
    effective_from timestamptz,
    effective_to timestamptz,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_policy_bundle PRIMARY KEY (id),
    CONSTRAINT uq_policy_bundle_display UNIQUE (display_id),
    CONSTRAINT uq_policy_bundle_version UNIQUE (bundle_code, version_no),
    CONSTRAINT ck_policy_bundle_version CHECK (version_no >= 1),
    CONSTRAINT ck_policy_bundle_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED', 'REJECTED')),
    CONSTRAINT ck_policy_bundle_git CHECK (git_commit_sha ~ '^[0-9a-f]{40,64}$'),
    CONSTRAINT ck_policy_bundle_hash CHECK (bundle_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_policy_bundle_window CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from),
    CONSTRAINT ck_policy_bundle_approval CHECK (status <> 'ACTIVE' OR (approved_by_principal_id IS NOT NULL AND approved_at IS NOT NULL))
);
COMMENT ON TABLE policy.policy_bundle IS '規約・品質・鮮度・Security Rule集合をVersion、Git commit、hash、承認、有効期間で固定する。';
COMMENT ON COLUMN policy.policy_bundle.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.policy_bundle.display_id IS 'POL-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN policy.policy_bundle.bundle_code IS 'bundle code';
COMMENT ON COLUMN policy.policy_bundle.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN policy.policy_bundle.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN policy.policy_bundle.git_commit_sha IS 'git commit sha';
COMMENT ON COLUMN policy.policy_bundle.bundle_sha256 IS 'bundle sha256';
COMMENT ON COLUMN policy.policy_bundle.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN policy.policy_bundle.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN policy.policy_bundle.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN policy.policy_bundle.approved_at IS 'approved at';
COMMENT ON COLUMN policy.policy_bundle.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.rule_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    rule_code text NOT NULL,
    version_no integer NOT NULL,
    rule_category text NOT NULL,
    severity text NOT NULL,
    is_blocking boolean NOT NULL,
    implementation_type text NOT NULL,
    definition jsonb DEFAULT '{}'::jsonb NOT NULL,
    definition_sha256 text NOT NULL,
    status text NOT NULL,
    created_by_principal_id uuid NOT NULL,
    approved_by_principal_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_rule_version PRIMARY KEY (id),
    CONSTRAINT uq_policy_rule_version UNIQUE (rule_code, version_no),
    CONSTRAINT ck_policy_rule_version CHECK (version_no >= 1),
    CONSTRAINT ck_policy_rule_category CHECK (rule_category IN ('COMPLIANCE', 'FACTUAL', 'QUALITY', 'FRESHNESS', 'LINK', 'SECURITY', 'ACCESSIBILITY', 'SEO')),
    CONSTRAINT ck_policy_rule_severity CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_policy_rule_impl CHECK (implementation_type IN ('PYTHON', 'SQL', 'REGEX', 'JSON_SCHEMA', 'MANUAL')),
    CONSTRAINT ck_policy_rule_definition CHECK (jsonb_typeof(definition) = 'object'),
    CONSTRAINT ck_policy_rule_hash CHECK (definition_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_policy_rule_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED', 'REJECTED'))
);
COMMENT ON TABLE policy.rule_version IS '個別RuleのCategory、Severity、Blocking、Implementation、定義、hashをVersion管理する。';
COMMENT ON COLUMN policy.rule_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.rule_version.rule_code IS 'rule code';
COMMENT ON COLUMN policy.rule_version.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN policy.rule_version.rule_category IS 'rule category';
COMMENT ON COLUMN policy.rule_version.severity IS 'severity';
COMMENT ON COLUMN policy.rule_version.is_blocking IS 'is blocking';
COMMENT ON COLUMN policy.rule_version.implementation_type IS 'implementation type';
COMMENT ON COLUMN policy.rule_version.definition IS 'Regex、threshold、field、manual checklist等のRule定義。';
COMMENT ON COLUMN policy.rule_version.definition_sha256 IS 'definition sha256';
COMMENT ON COLUMN policy.rule_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN policy.rule_version.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN policy.rule_version.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN policy.rule_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.bundle_rule (
    policy_bundle_id uuid NOT NULL,
    rule_version_id uuid NOT NULL,
    execution_order integer NOT NULL,
    mode text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_bundle_rule PRIMARY KEY (policy_bundle_id, rule_version_id),
    CONSTRAINT uq_policy_bundle_rule_order UNIQUE (policy_bundle_id, execution_order),
    CONSTRAINT ck_policy_bundle_rule_order CHECK (execution_order >= 0),
    CONSTRAINT ck_policy_bundle_rule_mode CHECK (mode IN ('ENFORCE', 'SHADOW', 'DISABLED'))
);
COMMENT ON TABLE policy.bundle_rule IS 'Policy Bundle内のRule version、実行順、enforce/shadow/disabled modeを固定する。';
COMMENT ON COLUMN policy.bundle_rule.policy_bundle_id IS 'policy bundle id';
COMMENT ON COLUMN policy.bundle_rule.rule_version_id IS 'rule version id';
COMMENT ON COLUMN policy.bundle_rule.execution_order IS 'execution order';
COMMENT ON COLUMN policy.bundle_rule.mode IS 'mode';
COMMENT ON COLUMN policy.bundle_rule.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.quality_check_run (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_version_id uuid NOT NULL,
    source_packet_version_id uuid NOT NULL,
    policy_bundle_id uuid NOT NULL,
    status text NOT NULL,
    triggered_by_actor_type text NOT NULL,
    triggered_by_actor_id uuid,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    total_score numeric(5,2),
    blocking_finding_count integer DEFAULT 0 NOT NULL,
    report_artifact_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_quality_check_run PRIMARY KEY (id),
    CONSTRAINT uq_policy_check_display UNIQUE (display_id),
    CONSTRAINT ck_policy_check_status CHECK (status IN ('RUNNING', 'PASSED', 'FAILED', 'ERROR', 'CANCELLED')),
    CONSTRAINT ck_policy_check_actor CHECK (triggered_by_actor_type IN ('USER', 'SERVICE', 'SYSTEM')),
    CONSTRAINT ck_policy_check_score CHECK (total_score IS NULL OR total_score >= 0 AND total_score <= 100),
    CONSTRAINT ck_policy_check_blocking CHECK (blocking_finding_count >= 0),
    CONSTRAINT ck_policy_check_complete CHECK (status = 'RUNNING' OR completed_at IS NOT NULL)
);
COMMENT ON TABLE policy.quality_check_run IS 'Article Versionを特定Source Packet/Policy Bundleで検査したRunとReport Artifact。';
COMMENT ON COLUMN policy.quality_check_run.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.quality_check_run.display_id IS 'QCR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN policy.quality_check_run.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN policy.quality_check_run.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN policy.quality_check_run.policy_bundle_id IS 'policy bundle id';
COMMENT ON COLUMN policy.quality_check_run.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN policy.quality_check_run.triggered_by_actor_type IS 'triggered by actor type';
COMMENT ON COLUMN policy.quality_check_run.triggered_by_actor_id IS 'triggered by actor id';
COMMENT ON COLUMN policy.quality_check_run.started_at IS 'started at';
COMMENT ON COLUMN policy.quality_check_run.completed_at IS 'completed at';
COMMENT ON COLUMN policy.quality_check_run.total_score IS 'total score';
COMMENT ON COLUMN policy.quality_check_run.blocking_finding_count IS 'blocking finding count';
COMMENT ON COLUMN policy.quality_check_run.report_artifact_id IS 'report artifact id';
COMMENT ON COLUMN policy.quality_check_run.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.finding (
    id uuid DEFAULT uuidv7() NOT NULL,
    quality_check_run_id uuid NOT NULL,
    rule_version_id uuid NOT NULL,
    finding_code text NOT NULL,
    severity text NOT NULL,
    is_blocking boolean NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    article_block_id uuid,
    claim_id uuid,
    message text NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'OPEN' NOT NULL,
    resolved_at timestamptz,
    resolved_by_principal_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_finding PRIMARY KEY (id),
    CONSTRAINT ck_policy_finding_severity CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_policy_finding_entity CHECK (entity_type IN ('ARTICLE_VERSION', 'BLOCK', 'CLAIM', 'PRODUCT', 'OFFER', 'LINK', 'SOURCE_PACKET')),
    CONSTRAINT ck_policy_finding_status CHECK (status IN ('OPEN', 'FIXED', 'WAIVED', 'FALSE_POSITIVE', 'ACCEPTED_RISK')),
    CONSTRAINT ck_policy_finding_evidence CHECK (jsonb_typeof(evidence) = 'object'),
    CONSTRAINT ck_policy_finding_resolve_pair CHECK ((resolved_at IS NULL) = (resolved_by_principal_id IS NULL))
);
COMMENT ON TABLE policy.finding IS 'Quality Checkで検出したRule違反・不足・Conflictを対象Entityへ紐付け、解決・Waiver状態を管理する。';
COMMENT ON COLUMN policy.finding.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.finding.quality_check_run_id IS 'quality check run id';
COMMENT ON COLUMN policy.finding.rule_version_id IS 'rule version id';
COMMENT ON COLUMN policy.finding.finding_code IS 'finding code';
COMMENT ON COLUMN policy.finding.severity IS 'severity';
COMMENT ON COLUMN policy.finding.is_blocking IS 'is blocking';
COMMENT ON COLUMN policy.finding.entity_type IS 'entity type';
COMMENT ON COLUMN policy.finding.entity_id IS 'entity id';
COMMENT ON COLUMN policy.finding.article_block_id IS 'article block id';
COMMENT ON COLUMN policy.finding.claim_id IS 'claim id';
COMMENT ON COLUMN policy.finding.message IS 'message';
COMMENT ON COLUMN policy.finding.evidence IS '検出値、expected、locator、comparison等。';
COMMENT ON COLUMN policy.finding.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN policy.finding.resolved_at IS 'resolved at';
COMMENT ON COLUMN policy.finding.resolved_by_principal_id IS 'resolved by principal id';
COMMENT ON COLUMN policy.finding.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.quality_score (
    id uuid DEFAULT uuidv7() NOT NULL,
    quality_check_run_id uuid NOT NULL,
    score_version text NOT NULL,
    total_score numeric(5,2) NOT NULL,
    pass_score numeric(5,2) NOT NULL,
    factual_accuracy_score numeric(5,2) NOT NULL,
    disclosure_policy_score numeric(5,2) NOT NULL,
    passed boolean NOT NULL,
    components jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_quality_score PRIMARY KEY (id),
    CONSTRAINT uq_policy_quality_score_run UNIQUE (quality_check_run_id),
    CONSTRAINT ck_policy_score_total CHECK (total_score >= 0 AND total_score <= 100),
    CONSTRAINT ck_policy_score_pass CHECK (pass_score >= 0 AND pass_score <= 100),
    CONSTRAINT ck_policy_score_factual CHECK (factual_accuracy_score BETWEEN 0 AND 20),
    CONSTRAINT ck_policy_score_disclosure CHECK (disclosure_policy_score BETWEEN 0 AND 5),
    CONSTRAINT ck_policy_score_components CHECK (jsonb_typeof(components) = 'object'),
    CONSTRAINT ck_policy_score_pass_logic CHECK (passed = (total_score >= pass_score AND factual_accuracy_score >= 18 AND disclosure_policy_score = 5))
);
COMMENT ON TABLE policy.quality_score IS 'Quality Runの100点評価、必須Subscore、Pass threshold、判定、内訳JSON。';
COMMENT ON COLUMN policy.quality_score.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.quality_score.quality_check_run_id IS 'quality check run id';
COMMENT ON COLUMN policy.quality_score.score_version IS 'score version';
COMMENT ON COLUMN policy.quality_score.total_score IS 'total score';
COMMENT ON COLUMN policy.quality_score.pass_score IS 'pass score';
COMMENT ON COLUMN policy.quality_score.factual_accuracy_score IS 'factual accuracy score';
COMMENT ON COLUMN policy.quality_score.disclosure_policy_score IS 'disclosure policy score';
COMMENT ON COLUMN policy.quality_score.passed IS 'passed';
COMMENT ON COLUMN policy.quality_score.components IS '8評価軸のearned/max/reason。';
COMMENT ON COLUMN policy.quality_score.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.waiver (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    finding_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    justification text NOT NULL,
    status text DEFAULT 'REQUESTED' NOT NULL,
    requested_by_principal_id uuid NOT NULL,
    requested_at timestamptz NOT NULL,
    decided_by_principal_id uuid,
    decided_at timestamptz,
    decision_reason text,
    expires_at timestamptz,
    revoked_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_waiver PRIMARY KEY (id),
    CONSTRAINT uq_policy_waiver_display UNIQUE (display_id),
    CONSTRAINT ck_policy_waiver_scope CHECK (scope_type IN ('FINDING', 'ARTICLE_VERSION', 'ARTICLE', 'CATEGORY')),
    CONSTRAINT ck_policy_waiver_status CHECK (status IN ('REQUESTED', 'APPROVED', 'REJECTED', 'EXPIRED', 'REVOKED')),
    CONSTRAINT ck_policy_waiver_decision_pair CHECK (status = 'REQUESTED' OR (decided_by_principal_id IS NOT NULL AND decided_at IS NOT NULL)),
    CONSTRAINT ck_policy_waiver_expiry CHECK (expires_at IS NULL OR expires_at > requested_at)
);
COMMENT ON TABLE policy.waiver IS 'Findingの例外申請・承認・期限・Scopeを管理する。Critical zero-tolerance RuleはDB/Serviceで申請不可にする。';
COMMENT ON COLUMN policy.waiver.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.waiver.display_id IS 'WVR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN policy.waiver.finding_id IS 'finding id';
COMMENT ON COLUMN policy.waiver.scope_type IS 'scope type';
COMMENT ON COLUMN policy.waiver.scope_id IS 'scope id';
COMMENT ON COLUMN policy.waiver.justification IS 'justification';
COMMENT ON COLUMN policy.waiver.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN policy.waiver.requested_by_principal_id IS 'requested by principal id';
COMMENT ON COLUMN policy.waiver.requested_at IS 'requested at';
COMMENT ON COLUMN policy.waiver.decided_by_principal_id IS 'decided by principal id';
COMMENT ON COLUMN policy.waiver.decided_at IS 'decided at';
COMMENT ON COLUMN policy.waiver.decision_reason IS 'decision reason';
COMMENT ON COLUMN policy.waiver.expires_at IS 'expires at';
COMMENT ON COLUMN policy.waiver.revoked_at IS 'revoked at';
COMMENT ON COLUMN policy.waiver.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE policy.gate_decision (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    gate_code text NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    policy_bundle_id uuid NOT NULL,
    result text NOT NULL,
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    evidence_artifact_id uuid NOT NULL,
    decided_by_principal_id uuid NOT NULL,
    decided_at timestamptz NOT NULL,
    expires_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_policy_gate_decision PRIMARY KEY (id),
    CONSTRAINT uq_policy_gate_display UNIQUE (display_id),
    CONSTRAINT ck_policy_gate_code CHECK (gate_code IN ('GATE-0', 'GATE-1', 'GATE-2', 'GATE-3', 'GATE-4')),
    CONSTRAINT ck_policy_gate_scope CHECK (scope_type IN ('SITE', 'CATEGORY', 'ARTICLE_TYPE', 'RELEASE')),
    CONSTRAINT ck_policy_gate_result CHECK (result IN ('PASS', 'FAIL', 'CONDITIONAL')),
    CONSTRAINT ck_policy_gate_conditions CHECK (jsonb_typeof(conditions) = 'object'),
    CONSTRAINT ck_policy_gate_expiry CHECK (expires_at IS NULL OR expires_at > decided_at)
);
COMMENT ON TABLE policy.gate_decision IS 'GATE-0～4のscope別Pass/Fail/Conditional判定、根拠Artifact、条件、有効期限を追記する。';
COMMENT ON COLUMN policy.gate_decision.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN policy.gate_decision.display_id IS 'GTD-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN policy.gate_decision.gate_code IS 'gate code';
COMMENT ON COLUMN policy.gate_decision.scope_type IS 'scope type';
COMMENT ON COLUMN policy.gate_decision.scope_id IS 'scope id';
COMMENT ON COLUMN policy.gate_decision.policy_bundle_id IS 'policy bundle id';
COMMENT ON COLUMN policy.gate_decision.result IS 'result';
COMMENT ON COLUMN policy.gate_decision.conditions IS 'Conditional passの未達・期限・scale limit。';
COMMENT ON COLUMN policy.gate_decision.evidence_artifact_id IS 'evidence artifact id';
COMMENT ON COLUMN policy.gate_decision.decided_by_principal_id IS 'decided by principal id';
COMMENT ON COLUMN policy.gate_decision.decided_at IS 'decided at';
COMMENT ON COLUMN policy.gate_decision.expires_at IS 'expires at';
COMMENT ON COLUMN policy.gate_decision.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE publishing.review_assignment (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_version_id uuid NOT NULL,
    review_type text NOT NULL,
    assigned_to_principal_id uuid NOT NULL,
    assigned_by_principal_id uuid NOT NULL,
    status text DEFAULT 'ASSIGNED' NOT NULL,
    priority smallint DEFAULT 50 NOT NULL,
    due_at timestamptz,
    started_at timestamptz,
    completed_at timestamptz,
    cancelled_at timestamptz,
    instructions text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_publishing_review_assignment PRIMARY KEY (id),
    CONSTRAINT uq_publishing_review_assignment_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_review_assignment_type CHECK (review_type IN ('EDITORIAL', 'FACT', 'COMPLIANCE', 'UX', 'FINAL')),
    CONSTRAINT ck_publishing_review_assignment_status CHECK (status IN ('ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    CONSTRAINT ck_publishing_review_assignment_priority CHECK (priority BETWEEN 0 AND 100),
    CONSTRAINT ck_publishing_review_assignment_time CHECK (completed_at IS NULL OR started_at IS NULL OR completed_at >= started_at)
);
COMMENT ON TABLE publishing.review_assignment IS '記事Versionに対する編集・Fact・Compliance等のHuman Review担当、期限、進行状態を管理する。';
COMMENT ON COLUMN publishing.review_assignment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.review_assignment.display_id IS 'RVA-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.review_assignment.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN publishing.review_assignment.review_type IS 'review type';
COMMENT ON COLUMN publishing.review_assignment.assigned_to_principal_id IS 'assigned to principal id';
COMMENT ON COLUMN publishing.review_assignment.assigned_by_principal_id IS 'assigned by principal id';
COMMENT ON COLUMN publishing.review_assignment.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN publishing.review_assignment.priority IS 'priority';
COMMENT ON COLUMN publishing.review_assignment.due_at IS 'due at';
COMMENT ON COLUMN publishing.review_assignment.started_at IS 'started at';
COMMENT ON COLUMN publishing.review_assignment.completed_at IS 'completed at';
COMMENT ON COLUMN publishing.review_assignment.cancelled_at IS 'cancelled at';
COMMENT ON COLUMN publishing.review_assignment.instructions IS 'instructions';
COMMENT ON COLUMN publishing.review_assignment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.review_assignment.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.review_assignment.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE publishing.review_decision (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    review_assignment_id uuid NOT NULL,
    article_version_id uuid NOT NULL,
    decision text NOT NULL,
    summary text NOT NULL,
    checklist_results jsonb DEFAULT '{}'::jsonb NOT NULL,
    decision_artifact_id uuid,
    decided_by_principal_id uuid NOT NULL,
    decided_at timestamptz NOT NULL,
    supersedes_decision_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_publishing_review_decision PRIMARY KEY (id),
    CONSTRAINT uq_publishing_review_decision_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_review_decision_value CHECK (decision IN ('APPROVE', 'CHANGES_REQUESTED', 'REJECT')),
    CONSTRAINT ck_publishing_review_decision_checklist CHECK (jsonb_typeof(checklist_results) = 'object')
);
COMMENT ON TABLE publishing.review_decision IS 'Human Reviewerが特定Assignment・記事Versionへ下したDecisionを追記し、後から上書きしない。';
COMMENT ON COLUMN publishing.review_decision.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.review_decision.display_id IS 'RVD-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.review_decision.review_assignment_id IS 'review assignment id';
COMMENT ON COLUMN publishing.review_decision.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN publishing.review_decision.decision IS 'decision';
COMMENT ON COLUMN publishing.review_decision.summary IS 'summary';
COMMENT ON COLUMN publishing.review_decision.checklist_results IS 'Review checklist項目・結果・Evidence locator。';
COMMENT ON COLUMN publishing.review_decision.decision_artifact_id IS 'decision artifact id';
COMMENT ON COLUMN publishing.review_decision.decided_by_principal_id IS 'decided by principal id';
COMMENT ON COLUMN publishing.review_decision.decided_at IS 'decided at';
COMMENT ON COLUMN publishing.review_decision.supersedes_decision_id IS 'supersedes decision id';
COMMENT ON COLUMN publishing.review_decision.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE publishing.approval (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    article_version_id uuid NOT NULL,
    approval_type text NOT NULL,
    decision text NOT NULL,
    quality_check_run_id uuid,
    policy_bundle_id uuid,
    decision_reason text NOT NULL,
    approved_by_principal_id uuid NOT NULL,
    approved_at timestamptz NOT NULL,
    valid_until timestamptz,
    revoked_at timestamptz,
    revoked_by_principal_id uuid,
    revocation_reason text,
    supersedes_approval_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_publishing_approval PRIMARY KEY (id),
    CONSTRAINT uq_publishing_approval_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_approval_type CHECK (approval_type IN ('EDITORIAL', 'FACT', 'COMPLIANCE', 'FINAL')),
    CONSTRAINT ck_publishing_approval_decision CHECK (decision IN ('APPROVED', 'REJECTED', 'REVOKED')),
    CONSTRAINT ck_publishing_approval_valid CHECK (valid_until IS NULL OR valid_until > approved_at),
    CONSTRAINT ck_publishing_approval_revoke_pair CHECK ((revoked_at IS NULL) = (revoked_by_principal_id IS NULL)),
    CONSTRAINT ck_publishing_approval_revoke_event CHECK (decision <> 'REVOKED' OR (supersedes_approval_id IS NOT NULL AND revoked_at IS NOT NULL AND revoked_by_principal_id IS NOT NULL))
);
COMMENT ON TABLE publishing.approval IS '記事Versionに対するEditorial・Compliance・Final approval/revocationを独立した監査事実として追記する。';
COMMENT ON COLUMN publishing.approval.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.approval.display_id IS 'APR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.approval.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN publishing.approval.approval_type IS 'approval type';
COMMENT ON COLUMN publishing.approval.decision IS 'decision';
COMMENT ON COLUMN publishing.approval.quality_check_run_id IS 'quality check run id';
COMMENT ON COLUMN publishing.approval.policy_bundle_id IS 'policy bundle id';
COMMENT ON COLUMN publishing.approval.decision_reason IS 'decision reason';
COMMENT ON COLUMN publishing.approval.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN publishing.approval.approved_at IS 'approved at';
COMMENT ON COLUMN publishing.approval.valid_until IS 'valid until';
COMMENT ON COLUMN publishing.approval.revoked_at IS 'revoked at';
COMMENT ON COLUMN publishing.approval.revoked_by_principal_id IS 'revoked by principal id';
COMMENT ON COLUMN publishing.approval.revocation_reason IS 'revocation reason';
COMMENT ON COLUMN publishing.approval.supersedes_approval_id IS 'supersedes approval id';
COMMENT ON COLUMN publishing.approval.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE publishing.publication_candidate (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    article_version_id uuid NOT NULL,
    final_approval_id uuid NOT NULL,
    quality_check_run_id uuid NOT NULL,
    requested_by_principal_id uuid NOT NULL,
    request_idempotency_key text NOT NULL,
    status text DEFAULT 'REQUESTED' NOT NULL,
    snapshot_build_job_id uuid,
    publication_snapshot_id uuid,
    blocked_reason_code text,
    blocked_detail text,
    requested_at timestamptz NOT NULL,
    completed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_publishing_publication_candidate PRIMARY KEY (id),
    CONSTRAINT uq_publishing_candidate_display UNIQUE (display_id),
    CONSTRAINT uq_publishing_candidate_idempotency UNIQUE (site_id, request_idempotency_key),
    CONSTRAINT ck_publishing_candidate_status CHECK (status IN ('REQUESTED', 'VALIDATING', 'BLOCKED', 'SNAPSHOT_READY', 'PUBLISHED', 'FAILED', 'CANCELLED')),
    CONSTRAINT ck_publishing_candidate_block CHECK (status <> 'BLOCKED' OR blocked_reason_code IS NOT NULL)
);
COMMENT ON TABLE publishing.publication_candidate IS '公開要求の冪等受付、最終Approval、Quality Run、Snapshot build状態、Block理由を管理する。';
COMMENT ON COLUMN publishing.publication_candidate.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.publication_candidate.display_id IS 'PBC-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.publication_candidate.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN publishing.publication_candidate.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN publishing.publication_candidate.final_approval_id IS 'final approval id';
COMMENT ON COLUMN publishing.publication_candidate.quality_check_run_id IS 'quality check run id';
COMMENT ON COLUMN publishing.publication_candidate.requested_by_principal_id IS 'requested by principal id';
COMMENT ON COLUMN publishing.publication_candidate.request_idempotency_key IS 'request idempotency key';
COMMENT ON COLUMN publishing.publication_candidate.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN publishing.publication_candidate.snapshot_build_job_id IS 'snapshot build job id';
COMMENT ON COLUMN publishing.publication_candidate.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN publishing.publication_candidate.blocked_reason_code IS 'blocked reason code';
COMMENT ON COLUMN publishing.publication_candidate.blocked_detail IS 'blocked detail';
COMMENT ON COLUMN publishing.publication_candidate.requested_at IS 'requested at';
COMMENT ON COLUMN publishing.publication_candidate.completed_at IS 'completed at';
COMMENT ON COLUMN publishing.publication_candidate.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.publication_candidate.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.publication_candidate.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE publishing.publication_snapshot (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    article_id uuid NOT NULL,
    article_version_id uuid NOT NULL,
    publication_candidate_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    schema_version integer NOT NULL,
    content_sha256 text NOT NULL,
    source_packet_version_id uuid NOT NULL,
    policy_bundle_id uuid NOT NULL,
    quality_check_run_id uuid NOT NULL,
    final_approval_id uuid NOT NULL,
    canonical_path text NOT NULL,
    title text NOT NULL,
    meta_title text,
    meta_description text,
    disclosure_text text NOT NULL,
    manifest jsonb DEFAULT '{}'::jsonb NOT NULL,
    built_by_job_id uuid NOT NULL,
    built_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_publishing_publication_snapshot PRIMARY KEY (id),
    CONSTRAINT uq_publishing_snapshot_display UNIQUE (display_id),
    CONSTRAINT uq_publishing_snapshot_artifact UNIQUE (artifact_id),
    CONSTRAINT uq_publishing_snapshot_hash UNIQUE (site_id, content_sha256),
    CONSTRAINT ck_publishing_snapshot_schema CHECK (schema_version > 0),
    CONSTRAINT ck_publishing_snapshot_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_publishing_snapshot_manifest CHECK (jsonb_typeof(manifest) = 'object'),
    CONSTRAINT ck_publishing_snapshot_path CHECK (canonical_path ~ '^/' AND canonical_path !~ '[?#[:cntrl:]]')
);
COMMENT ON TABLE publishing.publication_snapshot IS '承認済みArticle Versionから生成した公開内容・Product Card・Structured Dataの不変Snapshot manifest。';
COMMENT ON COLUMN publishing.publication_snapshot.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.publication_snapshot.display_id IS 'PBS-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.publication_snapshot.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN publishing.publication_snapshot.article_id IS '論理記事ID。';
COMMENT ON COLUMN publishing.publication_snapshot.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN publishing.publication_snapshot.publication_candidate_id IS 'publication candidate id';
COMMENT ON COLUMN publishing.publication_snapshot.artifact_id IS 'S3互換Object Storage上の不変Artifactレジストリ。';
COMMENT ON COLUMN publishing.publication_snapshot.schema_version IS 'schema version';
COMMENT ON COLUMN publishing.publication_snapshot.content_sha256 IS 'content sha256';
COMMENT ON COLUMN publishing.publication_snapshot.source_packet_version_id IS 'source packet version id';
COMMENT ON COLUMN publishing.publication_snapshot.policy_bundle_id IS 'policy bundle id';
COMMENT ON COLUMN publishing.publication_snapshot.quality_check_run_id IS 'quality check run id';
COMMENT ON COLUMN publishing.publication_snapshot.final_approval_id IS 'final approval id';
COMMENT ON COLUMN publishing.publication_snapshot.canonical_path IS 'canonical path';
COMMENT ON COLUMN publishing.publication_snapshot.title IS 'title';
COMMENT ON COLUMN publishing.publication_snapshot.meta_title IS 'meta title';
COMMENT ON COLUMN publishing.publication_snapshot.meta_description IS 'meta description';
COMMENT ON COLUMN publishing.publication_snapshot.disclosure_text IS 'disclosure text';
COMMENT ON COLUMN publishing.publication_snapshot.manifest IS '公開Block、Product/Card refs、Structured Data、Asset hash、Freshness metadata。';
COMMENT ON COLUMN publishing.publication_snapshot.built_by_job_id IS 'built by job id';
COMMENT ON COLUMN publishing.publication_snapshot.built_at IS 'built at';
COMMENT ON COLUMN publishing.publication_snapshot.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE publishing.publication (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    article_id uuid NOT NULL,
    channel text DEFAULT 'WEB' NOT NULL,
    state text DEFAULT 'UNPUBLISHED' NOT NULL,
    current_snapshot_id uuid,
    current_route_id uuid,
    first_published_at timestamptz,
    last_published_at timestamptz,
    unpublished_at timestamptz,
    etag text,
    projection_generation bigint DEFAULT 0 NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_publishing_publication PRIMARY KEY (id),
    CONSTRAINT uq_publishing_publication_display UNIQUE (display_id),
    CONSTRAINT uq_publishing_publication_article_channel UNIQUE (site_id, article_id, channel),
    CONSTRAINT ck_publishing_publication_channel CHECK (channel IN ('WEB', 'FEED', 'API')),
    CONSTRAINT ck_publishing_publication_state CHECK (state IN ('UNPUBLISHED', 'PUBLISHED', 'SUSPENDED', 'ARCHIVED')),
    CONSTRAINT ck_publishing_publication_snapshot CHECK (state <> 'PUBLISHED' OR current_snapshot_id IS NOT NULL),
    CONSTRAINT ck_publishing_publication_generation CHECK (projection_generation >= 0)
);
COMMENT ON TABLE publishing.publication IS 'サイト・記事・Channel単位の現在公開状態とCurrent Snapshotを保持する制御Record。公開内容自体はSnapshotを正本とする。';
COMMENT ON COLUMN publishing.publication.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.publication.display_id IS 'PUB-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.publication.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN publishing.publication.article_id IS '論理記事ID。';
COMMENT ON COLUMN publishing.publication.channel IS 'channel';
COMMENT ON COLUMN publishing.publication.state IS 'state';
COMMENT ON COLUMN publishing.publication.current_snapshot_id IS 'current snapshot id';
COMMENT ON COLUMN publishing.publication.current_route_id IS 'current route id';
COMMENT ON COLUMN publishing.publication.first_published_at IS 'first published at';
COMMENT ON COLUMN publishing.publication.last_published_at IS 'last published at';
COMMENT ON COLUMN publishing.publication.unpublished_at IS 'unpublished at';
COMMENT ON COLUMN publishing.publication.etag IS 'etag';
COMMENT ON COLUMN publishing.publication.projection_generation IS 'projection generation';
COMMENT ON COLUMN publishing.publication.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.publication.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.publication.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE publishing.publication_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    publication_id uuid NOT NULL,
    event_type text NOT NULL,
    from_snapshot_id uuid,
    to_snapshot_id uuid,
    publication_candidate_id uuid,
    release_id uuid,
    actor_type text NOT NULL,
    actor_id uuid,
    reason_code text NOT NULL,
    reason_detail text,
    correlation_id uuid NOT NULL,
    occurred_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_publishing_publication_event PRIMARY KEY (id),
    CONSTRAINT uq_publishing_event_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_event_type CHECK (event_type IN ('PUBLISHED', 'UNPUBLISHED', 'SUSPENDED', 'RESUMED', 'ROLLED_BACK', 'PROJECTION_REBUILT', 'FAILED')),
    CONSTRAINT ck_publishing_event_actor CHECK (actor_type IN ('HUMAN', 'SERVICE', 'SYSTEM'))
);
COMMENT ON TABLE publishing.publication_event IS 'Publish・Unpublish・Suspend・Resume・Rollback・Projection完了を時系列で追記する監査Event。';
COMMENT ON COLUMN publishing.publication_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.publication_event.display_id IS 'PUE-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.publication_event.publication_id IS 'publication id';
COMMENT ON COLUMN publishing.publication_event.event_type IS 'event type';
COMMENT ON COLUMN publishing.publication_event.from_snapshot_id IS 'from snapshot id';
COMMENT ON COLUMN publishing.publication_event.to_snapshot_id IS 'to snapshot id';
COMMENT ON COLUMN publishing.publication_event.publication_candidate_id IS 'publication candidate id';
COMMENT ON COLUMN publishing.publication_event.release_id IS 'release id';
COMMENT ON COLUMN publishing.publication_event.actor_type IS 'actor type';
COMMENT ON COLUMN publishing.publication_event.actor_id IS 'actor id';
COMMENT ON COLUMN publishing.publication_event.reason_code IS 'reason code';
COMMENT ON COLUMN publishing.publication_event.reason_detail IS 'reason detail';
COMMENT ON COLUMN publishing.publication_event.correlation_id IS '要求・Job・Eventを横断して追跡するCorrelation ID。';
COMMENT ON COLUMN publishing.publication_event.occurred_at IS 'occurred at';
COMMENT ON COLUMN publishing.publication_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE publishing.public_route (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    path text NOT NULL,
    route_type text NOT NULL,
    article_id uuid,
    publication_id uuid,
    redirect_target_route_id uuid,
    http_status smallint DEFAULT 200 NOT NULL,
    is_indexable boolean DEFAULT true NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    activated_at timestamptz,
    deactivated_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_publishing_public_route PRIMARY KEY (id),
    CONSTRAINT uq_publishing_route_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_route_type CHECK (route_type IN ('ARTICLE', 'REDIRECT', 'GONE', 'STATIC')),
    CONSTRAINT ck_publishing_route_status CHECK (status IN ('DRAFT', 'ACTIVE', 'INACTIVE')),
    CONSTRAINT ck_publishing_route_path CHECK (path ~ '^/' AND path !~ '[?#[:cntrl:]]'),
    CONSTRAINT ck_publishing_route_http CHECK (http_status BETWEEN 200 AND 599),
    CONSTRAINT ck_publishing_route_target CHECK (route_type <> 'REDIRECT' OR redirect_target_route_id IS NOT NULL),
    CONSTRAINT ck_publishing_route_article CHECK (route_type <> 'ARTICLE' OR article_id IS NOT NULL)
);
COMMENT ON TABLE publishing.public_route IS 'Canonical path、Redirect、Noindex、Route ownerを管理し、同一Siteで同時に同じPathを所有させない。';
COMMENT ON COLUMN publishing.public_route.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.public_route.display_id IS 'RTE-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.public_route.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN publishing.public_route.path IS 'path';
COMMENT ON COLUMN publishing.public_route.route_type IS 'route type';
COMMENT ON COLUMN publishing.public_route.article_id IS '論理記事ID。';
COMMENT ON COLUMN publishing.public_route.publication_id IS 'publication id';
COMMENT ON COLUMN publishing.public_route.redirect_target_route_id IS 'redirect target route id';
COMMENT ON COLUMN publishing.public_route.http_status IS 'http status';
COMMENT ON COLUMN publishing.public_route.is_indexable IS 'is indexable';
COMMENT ON COLUMN publishing.public_route.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN publishing.public_route.activated_at IS 'activated at';
COMMENT ON COLUMN publishing.public_route.deactivated_at IS 'deactivated at';
COMMENT ON COLUMN publishing.public_route.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.public_route.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN publishing.public_route.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE publishing.rollback_record (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    publication_id uuid NOT NULL,
    from_snapshot_id uuid NOT NULL,
    to_snapshot_id uuid NOT NULL,
    incident_id uuid,
    requested_by_principal_id uuid NOT NULL,
    approved_by_principal_id uuid,
    executed_by_principal_id uuid,
    status text DEFAULT 'REQUESTED' NOT NULL,
    reason text NOT NULL,
    verification_result text,
    requested_at timestamptz NOT NULL,
    executed_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_publishing_rollback_record PRIMARY KEY (id),
    CONSTRAINT uq_publishing_rollback_display UNIQUE (display_id),
    CONSTRAINT ck_publishing_rollback_status CHECK (status IN ('REQUESTED', 'APPROVED', 'EXECUTED', 'FAILED', 'CANCELLED')),
    CONSTRAINT ck_publishing_rollback_diff CHECK (from_snapshot_id <> to_snapshot_id)
);
COMMENT ON TABLE publishing.rollback_record IS '誤公開・不具合時に、対象Publicationを以前の不変Snapshotへ戻した事実、検証、承認を保存する。';
COMMENT ON COLUMN publishing.rollback_record.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN publishing.rollback_record.display_id IS 'RBK-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN publishing.rollback_record.publication_id IS 'publication id';
COMMENT ON COLUMN publishing.rollback_record.from_snapshot_id IS 'from snapshot id';
COMMENT ON COLUMN publishing.rollback_record.to_snapshot_id IS 'to snapshot id';
COMMENT ON COLUMN publishing.rollback_record.incident_id IS 'incident id';
COMMENT ON COLUMN publishing.rollback_record.requested_by_principal_id IS 'requested by principal id';
COMMENT ON COLUMN publishing.rollback_record.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN publishing.rollback_record.executed_by_principal_id IS 'executed by principal id';
COMMENT ON COLUMN publishing.rollback_record.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN publishing.rollback_record.reason IS 'reason';
COMMENT ON COLUMN publishing.rollback_record.verification_result IS 'verification result';
COMMENT ON COLUMN publishing.rollback_record.requested_at IS 'requested at';
COMMENT ON COLUMN publishing.rollback_record.executed_at IS 'executed at';
COMMENT ON COLUMN publishing.rollback_record.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE freshness.freshness_policy (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    category_id uuid,
    article_type text,
    fact_type text NOT NULL,
    version_no integer NOT NULL,
    warning_after interval NOT NULL,
    critical_after interval NOT NULL,
    refresh_interval interval NOT NULL,
    on_critical_action text NOT NULL,
    effective_from timestamptz NOT NULL,
    effective_to timestamptz,
    created_by_principal_id uuid NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_freshness_freshness_policy PRIMARY KEY (id),
    CONSTRAINT uq_freshness_policy_display UNIQUE (display_id),
    CONSTRAINT uq_freshness_policy_version UNIQUE (site_id, category_id, article_type, fact_type, version_no),
    CONSTRAINT ck_freshness_policy_version CHECK (version_no > 0),
    CONSTRAINT ck_freshness_policy_order CHECK (critical_after > warning_after),
    CONSTRAINT ck_freshness_policy_refresh CHECK (refresh_interval > interval '0 seconds'),
    CONSTRAINT ck_freshness_policy_action CHECK (on_critical_action IN ('WARN', 'BLOCK_NEW_PUBLICATION', 'DISABLE_AFFILIATE_LINK', 'SUSPEND_ARTICLE')),
    CONSTRAINT ck_freshness_policy_effective CHECK (effective_to IS NULL OR effective_to > effective_from)
);
COMMENT ON TABLE freshness.freshness_policy IS 'カテゴリ・記事種別・Fact種別ごとの最大Age、Warning、Critical、再取得CadenceをVersion管理する。';
COMMENT ON COLUMN freshness.freshness_policy.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.freshness_policy.display_id IS 'FPL-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN freshness.freshness_policy.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN freshness.freshness_policy.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN freshness.freshness_policy.article_type IS 'article type';
COMMENT ON COLUMN freshness.freshness_policy.fact_type IS 'fact type';
COMMENT ON COLUMN freshness.freshness_policy.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN freshness.freshness_policy.warning_after IS 'warning after';
COMMENT ON COLUMN freshness.freshness_policy.critical_after IS 'critical after';
COMMENT ON COLUMN freshness.freshness_policy.refresh_interval IS 'refresh interval';
COMMENT ON COLUMN freshness.freshness_policy.on_critical_action IS 'on critical action';
COMMENT ON COLUMN freshness.freshness_policy.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN freshness.freshness_policy.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN freshness.freshness_policy.created_by_principal_id IS '作成操作を行ったIAM Principal。';
COMMENT ON COLUMN freshness.freshness_policy.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE freshness.refresh_schedule (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    freshness_policy_id uuid NOT NULL,
    status text DEFAULT 'ACTIVE' NOT NULL,
    priority smallint DEFAULT 50 NOT NULL,
    next_due_at timestamptz NOT NULL,
    last_started_at timestamptz,
    last_succeeded_at timestamptz,
    consecutive_failure_count integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_until timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_freshness_refresh_schedule PRIMARY KEY (id),
    CONSTRAINT uq_freshness_schedule_target UNIQUE (site_id, target_type, target_id),
    CONSTRAINT ck_freshness_schedule_target CHECK (target_type IN ('PRODUCT', 'OFFER', 'ARTICLE', 'AFFILIATE_LINK', 'SOURCE_PACKET')),
    CONSTRAINT ck_freshness_schedule_status CHECK (status IN ('ACTIVE', 'PAUSED', 'DISABLED')),
    CONSTRAINT ck_freshness_schedule_priority CHECK (priority BETWEEN 0 AND 100),
    CONSTRAINT ck_freshness_schedule_fail CHECK (consecutive_failure_count >= 0),
    CONSTRAINT ck_freshness_schedule_lease CHECK ((lease_owner IS NULL) = (lease_until IS NULL))
);
COMMENT ON TABLE freshness.refresh_schedule IS 'Product・Offer・Article・Link等の次回Refresh due、Lease、連続失敗、優先度を一元管理する。';
COMMENT ON COLUMN freshness.refresh_schedule.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.refresh_schedule.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN freshness.refresh_schedule.target_type IS 'target type';
COMMENT ON COLUMN freshness.refresh_schedule.target_id IS 'target id';
COMMENT ON COLUMN freshness.refresh_schedule.freshness_policy_id IS 'freshness policy id';
COMMENT ON COLUMN freshness.refresh_schedule.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN freshness.refresh_schedule.priority IS 'priority';
COMMENT ON COLUMN freshness.refresh_schedule.next_due_at IS 'next due at';
COMMENT ON COLUMN freshness.refresh_schedule.last_started_at IS 'last started at';
COMMENT ON COLUMN freshness.refresh_schedule.last_succeeded_at IS 'last succeeded at';
COMMENT ON COLUMN freshness.refresh_schedule.consecutive_failure_count IS 'consecutive failure count';
COMMENT ON COLUMN freshness.refresh_schedule.lease_owner IS 'lease owner';
COMMENT ON COLUMN freshness.refresh_schedule.lease_until IS 'lease until';
COMMENT ON COLUMN freshness.refresh_schedule.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN freshness.refresh_schedule.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN freshness.refresh_schedule.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE freshness.refresh_run (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    ops_job_id uuid NOT NULL,
    run_type text NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid,
    status text NOT NULL,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    target_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    continuation jsonb DEFAULT '{}'::jsonb NOT NULL,
    report_artifact_id uuid,
    error_summary text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_freshness_refresh_run PRIMARY KEY (id),
    CONSTRAINT uq_freshness_run_display UNIQUE (display_id),
    CONSTRAINT uq_freshness_run_job UNIQUE (ops_job_id),
    CONSTRAINT ck_freshness_run_type CHECK (run_type IN ('SCHEDULED', 'MANUAL', 'EVENT_DRIVEN', 'REPAIR')),
    CONSTRAINT ck_freshness_run_scope CHECK (scope_type IN ('SITE', 'CATEGORY', 'PRODUCT', 'OFFER', 'ARTICLE', 'LINK')),
    CONSTRAINT ck_freshness_run_status CHECK (status IN ('RUNNING', 'SUCCEEDED', 'PARTIAL', 'FAILED', 'CANCELLED')),
    CONSTRAINT ck_freshness_run_counts CHECK (target_count >= 0 AND success_count >= 0 AND failure_count >= 0),
    CONSTRAINT ck_freshness_run_continuation CHECK (jsonb_typeof(continuation) = 'object')
);
COMMENT ON TABLE freshness.refresh_run IS 'Scheduleまたは手動要求に基づくRefresh batchの範囲、Job、結果件数、Cursor、Errorを管理する。';
COMMENT ON COLUMN freshness.refresh_run.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.refresh_run.display_id IS 'RFR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN freshness.refresh_run.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN freshness.refresh_run.ops_job_id IS 'ops job id';
COMMENT ON COLUMN freshness.refresh_run.run_type IS 'run type';
COMMENT ON COLUMN freshness.refresh_run.scope_type IS 'scope type';
COMMENT ON COLUMN freshness.refresh_run.scope_id IS 'scope id';
COMMENT ON COLUMN freshness.refresh_run.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN freshness.refresh_run.started_at IS 'started at';
COMMENT ON COLUMN freshness.refresh_run.completed_at IS 'completed at';
COMMENT ON COLUMN freshness.refresh_run.target_count IS 'target count';
COMMENT ON COLUMN freshness.refresh_run.success_count IS 'success count';
COMMENT ON COLUMN freshness.refresh_run.failure_count IS 'failure count';
COMMENT ON COLUMN freshness.refresh_run.continuation IS 'Provider cursor・page・resume token。';
COMMENT ON COLUMN freshness.refresh_run.report_artifact_id IS 'report artifact id';
COMMENT ON COLUMN freshness.refresh_run.error_summary IS 'error summary';
COMMENT ON COLUMN freshness.refresh_run.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE freshness.staleness_assessment (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    freshness_policy_id uuid NOT NULL,
    observation_id uuid,
    observation_at timestamptz,
    assessed_at timestamptz NOT NULL,
    age_seconds bigint,
    freshness_status text NOT NULL,
    recommended_action text NOT NULL,
    reason_code text NOT NULL,
    refresh_run_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_freshness_staleness_assessment PRIMARY KEY (id),
    CONSTRAINT ck_freshness_assessment_target CHECK (target_type IN ('PRODUCT', 'OFFER', 'ARTICLE', 'AFFILIATE_LINK', 'SOURCE_PACKET')),
    CONSTRAINT ck_freshness_assessment_status CHECK (freshness_status IN ('FRESH', 'WARNING', 'CRITICAL', 'UNKNOWN')),
    CONSTRAINT ck_freshness_assessment_action CHECK (recommended_action IN ('NONE', 'REFRESH', 'BLOCK_PUBLICATION', 'DISABLE_LINK', 'SUSPEND_ARTICLE', 'MANUAL_REVIEW')),
    CONSTRAINT ck_freshness_assessment_age CHECK (age_seconds IS NULL OR age_seconds >= 0)
);
COMMENT ON TABLE freshness.staleness_assessment IS '特定対象のObservation age・Policy・Fresh/Warning/Critical判定と推奨Actionを追記する。';
COMMENT ON COLUMN freshness.staleness_assessment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.staleness_assessment.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN freshness.staleness_assessment.target_type IS 'target type';
COMMENT ON COLUMN freshness.staleness_assessment.target_id IS 'target id';
COMMENT ON COLUMN freshness.staleness_assessment.freshness_policy_id IS 'freshness policy id';
COMMENT ON COLUMN freshness.staleness_assessment.observation_id IS 'observation id';
COMMENT ON COLUMN freshness.staleness_assessment.observation_at IS 'observation at';
COMMENT ON COLUMN freshness.staleness_assessment.assessed_at IS 'assessed at';
COMMENT ON COLUMN freshness.staleness_assessment.age_seconds IS 'age seconds';
COMMENT ON COLUMN freshness.staleness_assessment.freshness_status IS 'freshness status';
COMMENT ON COLUMN freshness.staleness_assessment.recommended_action IS 'recommended action';
COMMENT ON COLUMN freshness.staleness_assessment.reason_code IS 'reason code';
COMMENT ON COLUMN freshness.staleness_assessment.refresh_run_id IS 'refresh run id';
COMMENT ON COLUMN freshness.staleness_assessment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE freshness.link_check (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    affiliate_link_observation_id uuid,
    refresh_run_id uuid,
    checked_at timestamptz NOT NULL,
    check_method text NOT NULL,
    result text NOT NULL,
    http_status smallint,
    destination_host text,
    destination_url_sha256 text,
    latency_ms integer,
    risk_code text,
    response_artifact_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_freshness_link_check PRIMARY KEY (id),
    CONSTRAINT ck_freshness_link_method CHECK (check_method IN ('API_REISSUE', 'HEAD', 'GET_NO_REDIRECT', 'MANUAL')),
    CONSTRAINT ck_freshness_link_result CHECK (result IN ('VALID', 'REDIRECT_CHANGED', 'NOT_FOUND', 'SERVER_ERROR', 'TIMEOUT', 'MALFORMED', 'UNSAFE_HOST', 'UNKNOWN')),
    CONSTRAINT ck_freshness_link_http CHECK (http_status IS NULL OR http_status BETWEEN 100 AND 599),
    CONSTRAINT ck_freshness_link_hash CHECK (destination_url_sha256 IS NULL OR destination_url_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_freshness_link_latency CHECK (latency_ms IS NULL OR latency_ms >= 0)
);
COMMENT ON TABLE freshness.link_check IS '楽天Affiliate URLを経由せず検査し、HTTP・Destination host・API再取得一致・Riskを履歴化する。';
COMMENT ON COLUMN freshness.link_check.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.link_check.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN freshness.link_check.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN freshness.link_check.affiliate_link_observation_id IS 'affiliate link observation id';
COMMENT ON COLUMN freshness.link_check.refresh_run_id IS 'refresh run id';
COMMENT ON COLUMN freshness.link_check.checked_at IS 'checked at';
COMMENT ON COLUMN freshness.link_check.check_method IS 'check method';
COMMENT ON COLUMN freshness.link_check.result IS 'result';
COMMENT ON COLUMN freshness.link_check.http_status IS 'http status';
COMMENT ON COLUMN freshness.link_check.destination_host IS 'destination host';
COMMENT ON COLUMN freshness.link_check.destination_url_sha256 IS 'destination url sha256';
COMMENT ON COLUMN freshness.link_check.latency_ms IS 'latency ms';
COMMENT ON COLUMN freshness.link_check.risk_code IS 'risk code';
COMMENT ON COLUMN freshness.link_check.response_artifact_id IS 'response artifact id';
COMMENT ON COLUMN freshness.link_check.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE freshness.impact_assessment (
    id uuid DEFAULT uuidv7() NOT NULL,
    change_type text NOT NULL,
    changed_entity_type text NOT NULL,
    changed_entity_id uuid NOT NULL,
    article_id uuid,
    article_version_id uuid,
    claim_id uuid,
    publication_id uuid,
    impact_level text NOT NULL,
    required_action text NOT NULL,
    reason text NOT NULL,
    detected_at timestamptz NOT NULL,
    resolved_at timestamptz,
    resolved_by_job_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_freshness_impact_assessment PRIMARY KEY (id),
    CONSTRAINT ck_freshness_impact_change CHECK (change_type IN ('PRICE', 'AVAILABILITY', 'PRODUCT_ATTRIBUTE', 'AFFILIATE_LINK', 'SOURCE_CORRECTION', 'POLICY_CHANGE', 'PRODUCT_GROUPING')),
    CONSTRAINT ck_freshness_impact_entity CHECK (changed_entity_type IN ('SOURCE_SNAPSHOT', 'FACT', 'PRODUCT', 'OFFER', 'LINK', 'POLICY_BUNDLE')),
    CONSTRAINT ck_freshness_impact_level CHECK (impact_level IN ('NONE', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_freshness_impact_action CHECK (required_action IN ('NONE', 'REFRESH_DRAFT', 'REVIEW', 'REPUBLISH', 'DISABLE_LINK', 'SUSPEND_PUBLICATION'))
);
COMMENT ON TABLE freshness.impact_assessment IS 'Source/Product/Offer変更がClaim・記事・公開Snapshotへ与える影響と必要Actionを追記する。';
COMMENT ON COLUMN freshness.impact_assessment.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN freshness.impact_assessment.change_type IS 'change type';
COMMENT ON COLUMN freshness.impact_assessment.changed_entity_type IS 'changed entity type';
COMMENT ON COLUMN freshness.impact_assessment.changed_entity_id IS 'changed entity id';
COMMENT ON COLUMN freshness.impact_assessment.article_id IS '論理記事ID。';
COMMENT ON COLUMN freshness.impact_assessment.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN freshness.impact_assessment.claim_id IS 'claim id';
COMMENT ON COLUMN freshness.impact_assessment.publication_id IS 'publication id';
COMMENT ON COLUMN freshness.impact_assessment.impact_level IS 'impact level';
COMMENT ON COLUMN freshness.impact_assessment.required_action IS 'required action';
COMMENT ON COLUMN freshness.impact_assessment.reason IS 'reason';
COMMENT ON COLUMN freshness.impact_assessment.detected_at IS 'detected at';
COMMENT ON COLUMN freshness.impact_assessment.resolved_at IS 'resolved at';
COMMENT ON COLUMN freshness.impact_assessment.resolved_by_job_id IS 'resolved by job id';
COMMENT ON COLUMN freshness.impact_assessment.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.anonymous_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    event_id uuid NOT NULL,
    site_id uuid NOT NULL,
    event_type text NOT NULL,
    occurred_at timestamptz NOT NULL,
    received_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    business_date date NOT NULL,
    session_pseudonym_sha256 text,
    visitor_pseudonym_sha256 text,
    consent_state text NOT NULL,
    privacy_mode text NOT NULL,
    article_id uuid,
    article_version_id uuid,
    publication_snapshot_id uuid,
    product_id uuid,
    offer_id uuid,
    page_path text,
    referrer_host text,
    device_class text,
    country_code char(2),
    event_properties jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_anonymous_event PRIMARY KEY (id),
    CONSTRAINT uq_analytics_event_id UNIQUE (event_id),
    CONSTRAINT ck_analytics_event_type CHECK (event_type IN ('PAGE_VIEW', 'ARTICLE_ENGAGED', 'CTA_IMPRESSION', 'AFFILIATE_CLICK', 'INTERNAL_LINK_CLICK', 'SEARCH', 'ERROR')),
    CONSTRAINT ck_analytics_event_consent CHECK (consent_state IN ('GRANTED', 'DENIED', 'NOT_REQUIRED', 'UNKNOWN')),
    CONSTRAINT ck_analytics_event_privacy CHECK (privacy_mode IN ('FULL_CONSENT', 'COOKILESS', 'ESSENTIAL_ONLY')),
    CONSTRAINT ck_analytics_event_session_hash CHECK (session_pseudonym_sha256 IS NULL OR session_pseudonym_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_analytics_event_visitor_hash CHECK (visitor_pseudonym_sha256 IS NULL OR visitor_pseudonym_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_analytics_event_props CHECK (jsonb_typeof(event_properties) = 'object')
);
COMMENT ON TABLE analytics.anonymous_event IS '個人識別情報を保存せず、Consent状態付きでPage view・CTA表示・Click等を受け付ける短期Event。';
COMMENT ON COLUMN analytics.anonymous_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.anonymous_event.event_id IS 'event id';
COMMENT ON COLUMN analytics.anonymous_event.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.anonymous_event.event_type IS 'event type';
COMMENT ON COLUMN analytics.anonymous_event.occurred_at IS 'occurred at';
COMMENT ON COLUMN analytics.anonymous_event.received_at IS 'received at';
COMMENT ON COLUMN analytics.anonymous_event.business_date IS 'business date';
COMMENT ON COLUMN analytics.anonymous_event.session_pseudonym_sha256 IS 'session pseudonym sha256';
COMMENT ON COLUMN analytics.anonymous_event.visitor_pseudonym_sha256 IS 'visitor pseudonym sha256';
COMMENT ON COLUMN analytics.anonymous_event.consent_state IS 'consent state';
COMMENT ON COLUMN analytics.anonymous_event.privacy_mode IS 'privacy mode';
COMMENT ON COLUMN analytics.anonymous_event.article_id IS '論理記事ID。';
COMMENT ON COLUMN analytics.anonymous_event.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN analytics.anonymous_event.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN analytics.anonymous_event.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN analytics.anonymous_event.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN analytics.anonymous_event.page_path IS 'page path';
COMMENT ON COLUMN analytics.anonymous_event.referrer_host IS 'referrer host';
COMMENT ON COLUMN analytics.anonymous_event.device_class IS 'device class';
COMMENT ON COLUMN analytics.anonymous_event.country_code IS 'country code';
COMMENT ON COLUMN analytics.anonymous_event.event_properties IS 'Allowlist済み低Cardinality属性のみ。URL query、IP、raw UA、email等は禁止。';
COMMENT ON COLUMN analytics.anonymous_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.affiliate_click_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    anonymous_event_id uuid,
    site_id uuid NOT NULL,
    article_id uuid NOT NULL,
    article_version_id uuid NOT NULL,
    publication_snapshot_id uuid NOT NULL,
    product_id uuid,
    offer_id uuid NOT NULL,
    affiliate_link_observation_id uuid NOT NULL,
    destination_host text NOT NULL,
    destination_url_sha256 text NOT NULL,
    cta_key text NOT NULL,
    block_key text,
    position_index integer,
    occurred_at timestamptz NOT NULL,
    business_date date NOT NULL,
    delivery_state text DEFAULT 'RECEIVED' NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_affiliate_click_event PRIMARY KEY (id),
    CONSTRAINT uq_analytics_click_event UNIQUE (anonymous_event_id),
    CONSTRAINT ck_analytics_click_url_hash CHECK (destination_url_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_analytics_click_position CHECK (position_index IS NULL OR position_index >= 0),
    CONSTRAINT ck_analytics_click_delivery CHECK (delivery_state IN ('RECEIVED', 'LATE', 'DUPLICATE_REJECTED'))
);
COMMENT ON TABLE analytics.affiliate_click_event IS '楽天URLへ直接遷移させつつsendBeacon等で取得したクリック文脈を追記する。Redirect gatewayには使用しない。';
COMMENT ON COLUMN analytics.affiliate_click_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.affiliate_click_event.anonymous_event_id IS 'anonymous event id';
COMMENT ON COLUMN analytics.affiliate_click_event.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.affiliate_click_event.article_id IS '論理記事ID。';
COMMENT ON COLUMN analytics.affiliate_click_event.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN analytics.affiliate_click_event.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN analytics.affiliate_click_event.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN analytics.affiliate_click_event.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN analytics.affiliate_click_event.affiliate_link_observation_id IS 'affiliate link observation id';
COMMENT ON COLUMN analytics.affiliate_click_event.destination_host IS 'destination host';
COMMENT ON COLUMN analytics.affiliate_click_event.destination_url_sha256 IS 'destination url sha256';
COMMENT ON COLUMN analytics.affiliate_click_event.cta_key IS 'cta key';
COMMENT ON COLUMN analytics.affiliate_click_event.block_key IS 'block key';
COMMENT ON COLUMN analytics.affiliate_click_event.position_index IS 'position index';
COMMENT ON COLUMN analytics.affiliate_click_event.occurred_at IS 'occurred at';
COMMENT ON COLUMN analytics.affiliate_click_event.business_date IS 'business date';
COMMENT ON COLUMN analytics.affiliate_click_event.delivery_state IS 'delivery state';
COMMENT ON COLUMN analytics.affiliate_click_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.import_run (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    source_type text NOT NULL,
    ops_job_id uuid NOT NULL,
    source_artifact_id uuid,
    status text NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    dimensions jsonb DEFAULT '{}'::jsonb NOT NULL,
    watermark text,
    row_count bigint DEFAULT 0 NOT NULL,
    inserted_count bigint DEFAULT 0 NOT NULL,
    rejected_count bigint DEFAULT 0 NOT NULL,
    started_at timestamptz NOT NULL,
    completed_at timestamptz,
    error_summary text,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_import_run PRIMARY KEY (id),
    CONSTRAINT uq_analytics_import_display UNIQUE (display_id),
    CONSTRAINT uq_analytics_import_job UNIQUE (ops_job_id),
    CONSTRAINT ck_analytics_import_source CHECK (source_type IN ('GSC', 'GA4', 'RANK_PROVIDER', 'MANUAL')),
    CONSTRAINT ck_analytics_import_status CHECK (status IN ('RUNNING', 'SUCCEEDED', 'PARTIAL', 'FAILED', 'CANCELLED')),
    CONSTRAINT ck_analytics_import_dates CHECK (date_to >= date_from),
    CONSTRAINT ck_analytics_import_counts CHECK (row_count >= 0 AND inserted_count >= 0 AND rejected_count >= 0),
    CONSTRAINT ck_analytics_import_dimensions CHECK (jsonb_typeof(dimensions) = 'object')
);
COMMENT ON TABLE analytics.import_run IS 'Search Console・GA4等の集計取込範囲、Watermark、原本Artifact、件数、再実行状態を管理する。';
COMMENT ON COLUMN analytics.import_run.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.import_run.display_id IS 'AIR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN analytics.import_run.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.import_run.source_type IS 'source type';
COMMENT ON COLUMN analytics.import_run.ops_job_id IS 'ops job id';
COMMENT ON COLUMN analytics.import_run.source_artifact_id IS 'source artifact id';
COMMENT ON COLUMN analytics.import_run.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN analytics.import_run.date_from IS 'date from';
COMMENT ON COLUMN analytics.import_run.date_to IS 'date to';
COMMENT ON COLUMN analytics.import_run.dimensions IS '要求したdimension・filter・property等。';
COMMENT ON COLUMN analytics.import_run.watermark IS 'watermark';
COMMENT ON COLUMN analytics.import_run.row_count IS 'row count';
COMMENT ON COLUMN analytics.import_run.inserted_count IS 'inserted count';
COMMENT ON COLUMN analytics.import_run.rejected_count IS 'rejected count';
COMMENT ON COLUMN analytics.import_run.started_at IS 'started at';
COMMENT ON COLUMN analytics.import_run.completed_at IS 'completed at';
COMMENT ON COLUMN analytics.import_run.error_summary IS 'error summary';
COMMENT ON COLUMN analytics.import_run.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.gsc_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    import_run_id uuid NOT NULL,
    site_id uuid NOT NULL,
    metric_date date NOT NULL,
    query_text text,
    query_sha256 text,
    page_path text,
    country_code char(2),
    device text,
    search_appearance text,
    clicks bigint NOT NULL,
    impressions bigint NOT NULL,
    ctr numeric(10,8) NOT NULL,
    average_position numeric(10,4) NOT NULL,
    is_privacy_suppressed boolean DEFAULT false NOT NULL,
    dimension_key_sha256 text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_gsc_observation PRIMARY KEY (id),
    CONSTRAINT ck_analytics_gsc_query_hash CHECK (query_sha256 IS NULL OR query_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_analytics_gsc_dim_hash CHECK (dimension_key_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_analytics_gsc_counts CHECK (clicks >= 0 AND impressions >= 0 AND clicks <= impressions),
    CONSTRAINT ck_analytics_gsc_ctr CHECK (ctr >= 0 AND ctr <= 1),
    CONSTRAINT ck_analytics_gsc_position CHECK (average_position >= 0)
);
COMMENT ON TABLE analytics.gsc_observation IS 'Search Console APIから取得した日・query・page等の集計値。Queryはsanitizeし、低Volume抑制を維持する。';
COMMENT ON COLUMN analytics.gsc_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.gsc_observation.import_run_id IS 'import run id';
COMMENT ON COLUMN analytics.gsc_observation.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.gsc_observation.metric_date IS 'metric date';
COMMENT ON COLUMN analytics.gsc_observation.query_text IS 'query text';
COMMENT ON COLUMN analytics.gsc_observation.query_sha256 IS 'query sha256';
COMMENT ON COLUMN analytics.gsc_observation.page_path IS 'page path';
COMMENT ON COLUMN analytics.gsc_observation.country_code IS 'country code';
COMMENT ON COLUMN analytics.gsc_observation.device IS 'device';
COMMENT ON COLUMN analytics.gsc_observation.search_appearance IS 'search appearance';
COMMENT ON COLUMN analytics.gsc_observation.clicks IS 'clicks';
COMMENT ON COLUMN analytics.gsc_observation.impressions IS 'impressions';
COMMENT ON COLUMN analytics.gsc_observation.ctr IS 'ctr';
COMMENT ON COLUMN analytics.gsc_observation.average_position IS 'average position';
COMMENT ON COLUMN analytics.gsc_observation.is_privacy_suppressed IS 'is privacy suppressed';
COMMENT ON COLUMN analytics.gsc_observation.dimension_key_sha256 IS 'dimension key sha256';
COMMENT ON COLUMN analytics.gsc_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.ga4_observation (
    id uuid DEFAULT uuidv7() NOT NULL,
    import_run_id uuid NOT NULL,
    site_id uuid NOT NULL,
    metric_date date NOT NULL,
    dimension_schema_version integer NOT NULL,
    dimensions jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    grain_key_sha256 text NOT NULL,
    is_thresholded boolean DEFAULT false NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_ga4_observation PRIMARY KEY (id),
    CONSTRAINT ck_analytics_ga4_schema CHECK (dimension_schema_version > 0),
    CONSTRAINT ck_analytics_ga4_dimensions CHECK (jsonb_typeof(dimensions) = 'object'),
    CONSTRAINT ck_analytics_ga4_metrics CHECK (jsonb_typeof(metrics) = 'object'),
    CONSTRAINT ck_analytics_ga4_grain_hash CHECK (grain_key_sha256 ~ '^[0-9a-f]{64}$')
);
COMMENT ON TABLE analytics.ga4_observation IS 'GA4 Data APIの集計Grainをdimension/metric schema versionとhashで保存する。Event raw exportはMVP対象外。';
COMMENT ON COLUMN analytics.ga4_observation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.ga4_observation.import_run_id IS 'import run id';
COMMENT ON COLUMN analytics.ga4_observation.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.ga4_observation.metric_date IS 'metric date';
COMMENT ON COLUMN analytics.ga4_observation.dimension_schema_version IS 'dimension schema version';
COMMENT ON COLUMN analytics.ga4_observation.dimensions IS 'pagePath、deviceCategory等のAllowlist dimension。';
COMMENT ON COLUMN analytics.ga4_observation.metrics IS 'sessions、views、engagedSessions等の非負集計値。';
COMMENT ON COLUMN analytics.ga4_observation.grain_key_sha256 IS 'grain key sha256';
COMMENT ON COLUMN analytics.ga4_observation.is_thresholded IS 'is thresholded';
COMMENT ON COLUMN analytics.ga4_observation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.attribution_estimate (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    commission_id uuid NOT NULL,
    article_id uuid,
    publication_snapshot_id uuid,
    attribution_type text NOT NULL,
    method_version text NOT NULL,
    allocation_ratio numeric(12,10) NOT NULL,
    confidence_score numeric(5,2) NOT NULL,
    signals jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'PROPOSED' NOT NULL,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    calculated_by_job_id uuid NOT NULL,
    calculated_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_attribution_estimate PRIMARY KEY (id),
    CONSTRAINT uq_analytics_attribution_display UNIQUE (display_id),
    CONSTRAINT ck_analytics_attribution_type CHECK (attribution_type IN ('DIRECT', 'ESTIMATED', 'UNATTRIBUTED')),
    CONSTRAINT ck_analytics_attribution_ratio CHECK (allocation_ratio >= 0 AND allocation_ratio <= 1),
    CONSTRAINT ck_analytics_attribution_confidence CHECK (confidence_score >= 0 AND confidence_score <= 100),
    CONSTRAINT ck_analytics_attribution_status CHECK (status IN ('PROPOSED', 'APPROVED', 'REJECTED', 'SUPERSEDED')),
    CONSTRAINT ck_analytics_attribution_signals CHECK (jsonb_typeof(signals) = 'object'),
    CONSTRAINT ck_analytics_attribution_article CHECK (attribution_type = 'UNATTRIBUTED' OR article_id IS NOT NULL),
    CONSTRAINT ck_analytics_attribution_approval CHECK ((approved_by_principal_id IS NULL) = (approved_at IS NULL))
);
COMMENT ON TABLE analytics.attribution_estimate IS 'Provider Factと自サイト観測を混同せず、Direct・Estimated・Unattributedの配賦候補とConfidenceをVersion化する。';
COMMENT ON COLUMN analytics.attribution_estimate.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.attribution_estimate.display_id IS 'ATE-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN analytics.attribution_estimate.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.attribution_estimate.commission_id IS 'commission id';
COMMENT ON COLUMN analytics.attribution_estimate.article_id IS '論理記事ID。';
COMMENT ON COLUMN analytics.attribution_estimate.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN analytics.attribution_estimate.attribution_type IS 'attribution type';
COMMENT ON COLUMN analytics.attribution_estimate.method_version IS 'method version';
COMMENT ON COLUMN analytics.attribution_estimate.allocation_ratio IS 'allocation ratio';
COMMENT ON COLUMN analytics.attribution_estimate.confidence_score IS 'confidence score';
COMMENT ON COLUMN analytics.attribution_estimate.signals IS 'Time window、click count、direct provider fields等。Raw identifierは不可。';
COMMENT ON COLUMN analytics.attribution_estimate.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN analytics.attribution_estimate.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN analytics.attribution_estimate.approved_at IS 'approved at';
COMMENT ON COLUMN analytics.attribution_estimate.calculated_by_job_id IS 'calculated by job id';
COMMENT ON COLUMN analytics.attribution_estimate.calculated_at IS 'calculated at';
COMMENT ON COLUMN analytics.attribution_estimate.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.data_quality_finding (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    import_run_id uuid,
    finding_code text NOT NULL,
    severity text NOT NULL,
    status text DEFAULT 'OPEN' NOT NULL,
    metric_date date,
    message text NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    detected_at timestamptz NOT NULL,
    resolved_at timestamptz,
    resolved_by_principal_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_analytics_data_quality_finding PRIMARY KEY (id),
    CONSTRAINT ck_analytics_dq_severity CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_analytics_dq_status CHECK (status IN ('OPEN', 'FIXED', 'ACCEPTED', 'FALSE_POSITIVE')),
    CONSTRAINT ck_analytics_dq_evidence CHECK (jsonb_typeof(evidence) = 'object'),
    CONSTRAINT ck_analytics_dq_resolve CHECK ((resolved_at IS NULL) = (resolved_by_principal_id IS NULL))
);
COMMENT ON TABLE analytics.data_quality_finding IS 'Analytics取込の欠損、重複、集計不一致、Privacy violation、遅延をSource/Run/Dateへ紐付ける。';
COMMENT ON COLUMN analytics.data_quality_finding.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN analytics.data_quality_finding.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.data_quality_finding.import_run_id IS 'import run id';
COMMENT ON COLUMN analytics.data_quality_finding.finding_code IS 'finding code';
COMMENT ON COLUMN analytics.data_quality_finding.severity IS 'severity';
COMMENT ON COLUMN analytics.data_quality_finding.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN analytics.data_quality_finding.metric_date IS 'metric date';
COMMENT ON COLUMN analytics.data_quality_finding.message IS 'message';
COMMENT ON COLUMN analytics.data_quality_finding.evidence IS 'Expected/actual/count/hashのみ。PIIは格納しない。';
COMMENT ON COLUMN analytics.data_quality_finding.detected_at IS 'detected at';
COMMENT ON COLUMN analytics.data_quality_finding.resolved_at IS 'resolved at';
COMMENT ON COLUMN analytics.data_quality_finding.resolved_by_principal_id IS 'resolved by principal id';
COMMENT ON COLUMN analytics.data_quality_finding.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE analytics.daily_article_metric (
    site_id uuid NOT NULL,
    article_id uuid NOT NULL,
    metric_date date NOT NULL,
    publication_snapshot_id uuid,
    page_views bigint DEFAULT 0 NOT NULL,
    sessions bigint DEFAULT 0 NOT NULL,
    engaged_sessions bigint DEFAULT 0 NOT NULL,
    affiliate_clicks bigint DEFAULT 0 NOT NULL,
    gsc_clicks bigint DEFAULT 0 NOT NULL,
    gsc_impressions bigint DEFAULT 0 NOT NULL,
    average_position numeric(10,4),
    affiliate_click_rate numeric(12,10),
    source_watermark text NOT NULL,
    projection_version bigint NOT NULL,
    updated_at timestamptz NOT NULL,
    CONSTRAINT pk_analytics_daily_article_metric PRIMARY KEY (site_id, article_id, metric_date),
    CONSTRAINT ck_analytics_daily_counts CHECK (page_views >= 0 AND sessions >= 0 AND engaged_sessions >= 0 AND affiliate_clicks >= 0 AND gsc_clicks >= 0 AND gsc_impressions >= 0),
    CONSTRAINT ck_analytics_daily_rate CHECK (affiliate_click_rate IS NULL OR (affiliate_click_rate >= 0 AND affiliate_click_rate <= 1)),
    CONSTRAINT ck_analytics_daily_position CHECK (average_position IS NULL OR average_position >= 0),
    CONSTRAINT ck_analytics_daily_version CHECK (projection_version > 0)
);
COMMENT ON TABLE analytics.daily_article_metric IS '日次・記事単位のPV、Session、検索表示、楽天Click等を再生成可能なProjectionとして保持する。';
COMMENT ON COLUMN analytics.daily_article_metric.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN analytics.daily_article_metric.article_id IS '論理記事ID。';
COMMENT ON COLUMN analytics.daily_article_metric.metric_date IS 'metric date';
COMMENT ON COLUMN analytics.daily_article_metric.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN analytics.daily_article_metric.page_views IS 'page views';
COMMENT ON COLUMN analytics.daily_article_metric.sessions IS 'sessions';
COMMENT ON COLUMN analytics.daily_article_metric.engaged_sessions IS 'engaged sessions';
COMMENT ON COLUMN analytics.daily_article_metric.affiliate_clicks IS 'affiliate clicks';
COMMENT ON COLUMN analytics.daily_article_metric.gsc_clicks IS 'gsc clicks';
COMMENT ON COLUMN analytics.daily_article_metric.gsc_impressions IS 'gsc impressions';
COMMENT ON COLUMN analytics.daily_article_metric.average_position IS 'average position';
COMMENT ON COLUMN analytics.daily_article_metric.affiliate_click_rate IS 'affiliate click rate';
COMMENT ON COLUMN analytics.daily_article_metric.source_watermark IS 'source watermark';
COMMENT ON COLUMN analytics.daily_article_metric.projection_version IS 'projection version';
COMMENT ON COLUMN analytics.daily_article_metric.updated_at IS '最終更新時刻。UTCのtimestamptz。';

CREATE TABLE finance.parser_version (
    id uuid DEFAULT uuidv7() NOT NULL,
    provider_code text NOT NULL,
    format_code text NOT NULL,
    version text NOT NULL,
    code_sha256 text NOT NULL,
    schema_artifact_id uuid NOT NULL,
    fixture_artifact_id uuid,
    status text DEFAULT 'ACTIVE' NOT NULL,
    released_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_parser_version PRIMARY KEY (id),
    CONSTRAINT uq_finance_parser_version UNIQUE (provider_code, format_code, version),
    CONSTRAINT ck_finance_parser_hash CHECK (code_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_parser_status CHECK (status IN ('ACTIVE', 'DEPRECATED', 'DISABLED'))
);
COMMENT ON TABLE finance.parser_version IS '楽天成果CSV等のProvider・FormatごとのParser code/schema/test fixture versionを不変登録する。';
COMMENT ON COLUMN finance.parser_version.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.parser_version.provider_code IS 'provider code';
COMMENT ON COLUMN finance.parser_version.format_code IS 'format code';
COMMENT ON COLUMN finance.parser_version.version IS 'version';
COMMENT ON COLUMN finance.parser_version.code_sha256 IS 'code sha256';
COMMENT ON COLUMN finance.parser_version.schema_artifact_id IS 'schema artifact id';
COMMENT ON COLUMN finance.parser_version.fixture_artifact_id IS 'fixture artifact id';
COMMENT ON COLUMN finance.parser_version.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN finance.parser_version.released_at IS 'released at';
COMMENT ON COLUMN finance.parser_version.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.revenue_import (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    provider_code text NOT NULL,
    source_artifact_id uuid NOT NULL,
    source_sha256 text NOT NULL,
    parser_version_id uuid NOT NULL,
    ops_job_id uuid,
    status text DEFAULT 'UPLOADED' NOT NULL,
    is_dry_run boolean DEFAULT true NOT NULL,
    period_from date NOT NULL,
    period_to date NOT NULL,
    row_count integer DEFAULT 0 NOT NULL,
    accepted_count integer DEFAULT 0 NOT NULL,
    rejected_count integer DEFAULT 0 NOT NULL,
    gross_order_amount_jpy bigint,
    commission_amount_jpy bigint,
    confirmed_by_principal_id uuid,
    confirmed_at timestamptz,
    reconciliation_status text DEFAULT 'PENDING' NOT NULL,
    report_artifact_id uuid,
    error_summary text,
    uploaded_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_finance_revenue_import PRIMARY KEY (id),
    CONSTRAINT uq_finance_revenue_import_display UNIQUE (display_id),
    CONSTRAINT uq_finance_revenue_import_hash UNIQUE (site_id, provider_code, source_sha256),
    CONSTRAINT ck_finance_revenue_import_hash CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_revenue_import_dates CHECK (period_to >= period_from),
    CONSTRAINT ck_finance_revenue_import_status CHECK (status IN ('UPLOADED', 'SCANNED', 'PARSED', 'DRY_RUN_READY', 'CONFIRMED', 'IMPORTED', 'REJECTED', 'FAILED')),
    CONSTRAINT ck_finance_revenue_import_recon CHECK (reconciliation_status IN ('PENDING', 'MATCHED', 'MISMATCH', 'WAIVED')),
    CONSTRAINT ck_finance_revenue_import_counts CHECK (row_count >= 0 AND accepted_count >= 0 AND rejected_count >= 0),
    CONSTRAINT ck_finance_revenue_import_confirm CHECK ((confirmed_by_principal_id IS NULL) = (confirmed_at IS NULL))
);
COMMENT ON TABLE finance.revenue_import IS '成果原本UploadからMalware/形式検査、Dry Run、人間確認、Canonical import、突合までの状態を管理する。';
COMMENT ON COLUMN finance.revenue_import.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.revenue_import.display_id IS 'RVI-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.revenue_import.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.revenue_import.provider_code IS 'provider code';
COMMENT ON COLUMN finance.revenue_import.source_artifact_id IS 'source artifact id';
COMMENT ON COLUMN finance.revenue_import.source_sha256 IS 'source sha256';
COMMENT ON COLUMN finance.revenue_import.parser_version_id IS 'parser version id';
COMMENT ON COLUMN finance.revenue_import.ops_job_id IS 'ops job id';
COMMENT ON COLUMN finance.revenue_import.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN finance.revenue_import.is_dry_run IS 'is dry run';
COMMENT ON COLUMN finance.revenue_import.period_from IS 'period from';
COMMENT ON COLUMN finance.revenue_import.period_to IS 'period to';
COMMENT ON COLUMN finance.revenue_import.row_count IS 'row count';
COMMENT ON COLUMN finance.revenue_import.accepted_count IS 'accepted count';
COMMENT ON COLUMN finance.revenue_import.rejected_count IS 'rejected count';
COMMENT ON COLUMN finance.revenue_import.gross_order_amount_jpy IS 'gross order amount jpy';
COMMENT ON COLUMN finance.revenue_import.commission_amount_jpy IS 'commission amount jpy';
COMMENT ON COLUMN finance.revenue_import.confirmed_by_principal_id IS 'confirmed by principal id';
COMMENT ON COLUMN finance.revenue_import.confirmed_at IS 'confirmed at';
COMMENT ON COLUMN finance.revenue_import.reconciliation_status IS 'reconciliation status';
COMMENT ON COLUMN finance.revenue_import.report_artifact_id IS 'report artifact id';
COMMENT ON COLUMN finance.revenue_import.error_summary IS 'error summary';
COMMENT ON COLUMN finance.revenue_import.uploaded_at IS 'uploaded at';
COMMENT ON COLUMN finance.revenue_import.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN finance.revenue_import.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN finance.revenue_import.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE finance.revenue_import_row (
    id uuid DEFAULT uuidv7() NOT NULL,
    revenue_import_id uuid NOT NULL,
    row_no integer NOT NULL,
    row_sha256 text NOT NULL,
    parse_status text NOT NULL,
    provider_event_id text,
    provider_order_id_sha256 text,
    event_type text,
    occurred_at timestamptz,
    business_date date,
    gross_order_amount_jpy bigint,
    commission_amount_jpy bigint,
    currency char(3),
    error_code text,
    error_detail text,
    normalized_extra jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_revenue_import_row PRIMARY KEY (id),
    CONSTRAINT uq_finance_revenue_row_no UNIQUE (revenue_import_id, row_no),
    CONSTRAINT uq_finance_revenue_row_hash UNIQUE (revenue_import_id, row_sha256),
    CONSTRAINT ck_finance_revenue_row_no CHECK (row_no > 0),
    CONSTRAINT ck_finance_revenue_row_hash CHECK (row_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_revenue_order_hash CHECK (provider_order_id_sha256 IS NULL OR provider_order_id_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_revenue_parse CHECK (parse_status IN ('ACCEPTED', 'REJECTED', 'DUPLICATE', 'IGNORED')),
    CONSTRAINT ck_finance_revenue_extra CHECK (jsonb_typeof(normalized_extra) = 'object')
);
COMMENT ON TABLE finance.revenue_import_row IS '成果原本の各行をLine hashとParser resultで追跡するStaging。原文全体はArtifact、DBは必要最小限の正規化値のみ。';
COMMENT ON COLUMN finance.revenue_import_row.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.revenue_import_row.revenue_import_id IS 'revenue import id';
COMMENT ON COLUMN finance.revenue_import_row.row_no IS 'row no';
COMMENT ON COLUMN finance.revenue_import_row.row_sha256 IS 'row sha256';
COMMENT ON COLUMN finance.revenue_import_row.parse_status IS 'parse status';
COMMENT ON COLUMN finance.revenue_import_row.provider_event_id IS 'provider event id';
COMMENT ON COLUMN finance.revenue_import_row.provider_order_id_sha256 IS 'provider order id sha256';
COMMENT ON COLUMN finance.revenue_import_row.event_type IS 'event type';
COMMENT ON COLUMN finance.revenue_import_row.occurred_at IS 'occurred at';
COMMENT ON COLUMN finance.revenue_import_row.business_date IS 'business date';
COMMENT ON COLUMN finance.revenue_import_row.gross_order_amount_jpy IS 'gross order amount jpy';
COMMENT ON COLUMN finance.revenue_import_row.commission_amount_jpy IS 'commission amount jpy';
COMMENT ON COLUMN finance.revenue_import_row.currency IS 'currency';
COMMENT ON COLUMN finance.revenue_import_row.error_code IS 'error code';
COMMENT ON COLUMN finance.revenue_import_row.error_detail IS 'error detail';
COMMENT ON COLUMN finance.revenue_import_row.normalized_extra IS 'Allowlist済みProvider固有field。';
COMMENT ON COLUMN finance.revenue_import_row.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.commission (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    provider_code text NOT NULL,
    provider_event_id text NOT NULL,
    provider_order_id_sha256 text,
    source_import_row_id uuid NOT NULL,
    status text NOT NULL,
    ordered_at timestamptz,
    confirmed_at timestamptz,
    cancelled_at timestamptz,
    business_month date NOT NULL,
    gross_order_amount_jpy bigint,
    confirmed_order_amount_jpy bigint,
    generated_commission_jpy bigint,
    confirmed_commission_jpy bigint,
    currency char(3) DEFAULT 'JPY' NOT NULL,
    provider_category_code text,
    provider_shop_code text,
    provider_item_code text,
    last_event_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version bigint DEFAULT 0 NOT NULL,
    CONSTRAINT pk_finance_commission PRIMARY KEY (id),
    CONSTRAINT uq_finance_commission_display UNIQUE (display_id),
    CONSTRAINT uq_finance_commission_provider_event UNIQUE (site_id, provider_code, provider_event_id),
    CONSTRAINT ck_finance_commission_status CHECK (status IN ('GENERATED', 'CONFIRMED', 'CANCELLED', 'ADJUSTED', 'UNKNOWN')),
    CONSTRAINT ck_finance_commission_order_hash CHECK (provider_order_id_sha256 IS NULL OR provider_order_id_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_commission_month CHECK (date_trunc('month', business_month)::date = business_month)
);
COMMENT ON TABLE finance.commission IS '楽天側の発生・確定・取消をCanonical provider factとして保持する。記事帰属や推定値をこのRecordへ上書きしない。';
COMMENT ON COLUMN finance.commission.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.commission.display_id IS 'COM-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.commission.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.commission.provider_code IS 'provider code';
COMMENT ON COLUMN finance.commission.provider_event_id IS 'provider event id';
COMMENT ON COLUMN finance.commission.provider_order_id_sha256 IS 'provider order id sha256';
COMMENT ON COLUMN finance.commission.source_import_row_id IS 'source import row id';
COMMENT ON COLUMN finance.commission.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN finance.commission.ordered_at IS 'ordered at';
COMMENT ON COLUMN finance.commission.confirmed_at IS 'confirmed at';
COMMENT ON COLUMN finance.commission.cancelled_at IS 'cancelled at';
COMMENT ON COLUMN finance.commission.business_month IS 'business month';
COMMENT ON COLUMN finance.commission.gross_order_amount_jpy IS 'gross order amount jpy';
COMMENT ON COLUMN finance.commission.confirmed_order_amount_jpy IS 'confirmed order amount jpy';
COMMENT ON COLUMN finance.commission.generated_commission_jpy IS 'generated commission jpy';
COMMENT ON COLUMN finance.commission.confirmed_commission_jpy IS 'confirmed commission jpy';
COMMENT ON COLUMN finance.commission.currency IS 'currency';
COMMENT ON COLUMN finance.commission.provider_category_code IS 'provider category code';
COMMENT ON COLUMN finance.commission.provider_shop_code IS 'provider shop code';
COMMENT ON COLUMN finance.commission.provider_item_code IS 'provider item code';
COMMENT ON COLUMN finance.commission.last_event_at IS 'last event at';
COMMENT ON COLUMN finance.commission.created_at IS 'レコード作成時刻。UTCのtimestamptz。';
COMMENT ON COLUMN finance.commission.updated_at IS '最終更新時刻。UTCのtimestamptz。';
COMMENT ON COLUMN finance.commission.lock_version IS '楽観的排他制御用の単調増加Version。';

CREATE TABLE finance.commission_event (
    id uuid DEFAULT uuidv7() NOT NULL,
    commission_id uuid NOT NULL,
    source_import_row_id uuid NOT NULL,
    event_sequence integer NOT NULL,
    event_type text NOT NULL,
    from_status text,
    to_status text NOT NULL,
    gross_order_amount_jpy bigint,
    commission_amount_jpy bigint,
    provider_occurred_at timestamptz,
    recorded_at timestamptz NOT NULL,
    event_sha256 text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_commission_event PRIMARY KEY (id),
    CONSTRAINT uq_finance_commission_event_seq UNIQUE (commission_id, event_sequence),
    CONSTRAINT uq_finance_commission_event_hash UNIQUE (commission_id, event_sha256),
    CONSTRAINT ck_finance_commission_event_seq CHECK (event_sequence > 0),
    CONSTRAINT ck_finance_commission_event_hash CHECK (event_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_finance_commission_event_type CHECK (event_type IN ('GENERATED', 'CONFIRMED', 'CANCELLED', 'AMOUNT_CHANGED', 'CORRECTED'))
);
COMMENT ON TABLE finance.commission_event IS 'Commissionの発生・確定・取消・金額変更をProvider event順に追記し、現在状態の根拠にする。';
COMMENT ON COLUMN finance.commission_event.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.commission_event.commission_id IS 'commission id';
COMMENT ON COLUMN finance.commission_event.source_import_row_id IS 'source import row id';
COMMENT ON COLUMN finance.commission_event.event_sequence IS 'event sequence';
COMMENT ON COLUMN finance.commission_event.event_type IS 'event type';
COMMENT ON COLUMN finance.commission_event.from_status IS 'from status';
COMMENT ON COLUMN finance.commission_event.to_status IS 'to status';
COMMENT ON COLUMN finance.commission_event.gross_order_amount_jpy IS 'gross order amount jpy';
COMMENT ON COLUMN finance.commission_event.commission_amount_jpy IS 'commission amount jpy';
COMMENT ON COLUMN finance.commission_event.provider_occurred_at IS 'provider occurred at';
COMMENT ON COLUMN finance.commission_event.recorded_at IS 'recorded at';
COMMENT ON COLUMN finance.commission_event.event_sha256 IS 'event sha256';
COMMENT ON COLUMN finance.commission_event.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.external_cost (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    cost_type text NOT NULL,
    vendor_code text NOT NULL,
    service_code text,
    occurred_on date NOT NULL,
    amount_original numeric(20,6) NOT NULL,
    currency_original char(3) NOT NULL,
    fx_rate_to_jpy numeric(20,10) DEFAULT 1 NOT NULL,
    amount_jpy bigint NOT NULL,
    article_id uuid,
    category_id uuid,
    ai_job_id uuid,
    source_artifact_id uuid,
    source_record_key text NOT NULL,
    recorded_by_actor_type text NOT NULL,
    recorded_by_actor_id uuid,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_external_cost PRIMARY KEY (id),
    CONSTRAINT uq_finance_external_cost_display UNIQUE (display_id),
    CONSTRAINT uq_finance_external_cost_source UNIQUE (vendor_code, source_record_key),
    CONSTRAINT ck_finance_external_cost_type CHECK (cost_type IN ('LLM', 'API', 'HOSTING', 'OBSERVABILITY', 'ANALYTICS', 'CONTENT_TOOL', 'OTHER')),
    CONSTRAINT ck_finance_external_cost_values CHECK (amount_original >= 0 AND fx_rate_to_jpy > 0 AND amount_jpy >= 0),
    CONSTRAINT ck_finance_external_cost_actor CHECK (recorded_by_actor_type IN ('HUMAN', 'SERVICE', 'IMPORT'))
);
COMMENT ON TABLE finance.external_cost IS 'LLM・API・Hosting・Tool等の外部費用をInvoice/Usage根拠付きでJPYへ正規化して追記する。';
COMMENT ON COLUMN finance.external_cost.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.external_cost.display_id IS 'CST-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.external_cost.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.external_cost.cost_type IS 'cost type';
COMMENT ON COLUMN finance.external_cost.vendor_code IS 'vendor code';
COMMENT ON COLUMN finance.external_cost.service_code IS 'service code';
COMMENT ON COLUMN finance.external_cost.occurred_on IS 'occurred on';
COMMENT ON COLUMN finance.external_cost.amount_original IS 'amount original';
COMMENT ON COLUMN finance.external_cost.currency_original IS 'currency original';
COMMENT ON COLUMN finance.external_cost.fx_rate_to_jpy IS 'fx rate to jpy';
COMMENT ON COLUMN finance.external_cost.amount_jpy IS 'amount jpy';
COMMENT ON COLUMN finance.external_cost.article_id IS '論理記事ID。';
COMMENT ON COLUMN finance.external_cost.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN finance.external_cost.ai_job_id IS 'ai job id';
COMMENT ON COLUMN finance.external_cost.source_artifact_id IS 'source artifact id';
COMMENT ON COLUMN finance.external_cost.source_record_key IS 'source record key';
COMMENT ON COLUMN finance.external_cost.recorded_by_actor_type IS 'recorded by actor type';
COMMENT ON COLUMN finance.external_cost.recorded_by_actor_id IS 'recorded by actor id';
COMMENT ON COLUMN finance.external_cost.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.human_work_log (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    work_date date NOT NULL,
    work_type text NOT NULL,
    minutes integer NOT NULL,
    hourly_cost_jpy bigint NOT NULL,
    computed_cost_jpy bigint NOT NULL,
    article_id uuid,
    category_id uuid,
    article_version_id uuid,
    note text,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_human_work_log PRIMARY KEY (id),
    CONSTRAINT uq_finance_worklog_display UNIQUE (display_id),
    CONSTRAINT ck_finance_worklog_type CHECK (work_type IN ('RESEARCH', 'WRITING', 'EDITING', 'FACT_CHECK', 'COMPLIANCE', 'PUBLISHING', 'REFRESH', 'INCIDENT', 'ENGINEERING', 'OTHER')),
    CONSTRAINT ck_finance_worklog_minutes CHECK (minutes > 0 AND minutes <= 1440),
    CONSTRAINT ck_finance_worklog_cost CHECK (hourly_cost_jpy >= 0 AND computed_cost_jpy >= 0),
    CONSTRAINT ck_finance_worklog_approval CHECK ((approved_by_principal_id IS NULL) = (approved_at IS NULL))
);
COMMENT ON TABLE finance.human_work_log IS '制作・編集・Review・更新等の人間作業時間と原価を記事・カテゴリへ配賦可能な形で記録する。';
COMMENT ON COLUMN finance.human_work_log.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.human_work_log.display_id IS 'HWL-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.human_work_log.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.human_work_log.principal_id IS 'principal id';
COMMENT ON COLUMN finance.human_work_log.work_date IS 'work date';
COMMENT ON COLUMN finance.human_work_log.work_type IS 'work type';
COMMENT ON COLUMN finance.human_work_log.minutes IS 'minutes';
COMMENT ON COLUMN finance.human_work_log.hourly_cost_jpy IS 'hourly cost jpy';
COMMENT ON COLUMN finance.human_work_log.computed_cost_jpy IS 'computed cost jpy';
COMMENT ON COLUMN finance.human_work_log.article_id IS '論理記事ID。';
COMMENT ON COLUMN finance.human_work_log.category_id IS '対象カテゴリ。';
COMMENT ON COLUMN finance.human_work_log.article_version_id IS '記事の特定Version。';
COMMENT ON COLUMN finance.human_work_log.note IS 'note';
COMMENT ON COLUMN finance.human_work_log.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN finance.human_work_log.approved_at IS 'approved at';
COMMENT ON COLUMN finance.human_work_log.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.allocation_rule (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    rule_code text NOT NULL,
    version_no integer NOT NULL,
    cost_source_type text NOT NULL,
    method text NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    status text DEFAULT 'ACTIVE' NOT NULL,
    approved_by_principal_id uuid NOT NULL,
    approved_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_allocation_rule PRIMARY KEY (id),
    CONSTRAINT uq_finance_allocation_rule_display UNIQUE (display_id),
    CONSTRAINT uq_finance_allocation_rule_version UNIQUE (site_id, rule_code, version_no),
    CONSTRAINT ck_finance_allocation_rule_version CHECK (version_no > 0),
    CONSTRAINT ck_finance_allocation_rule_source CHECK (cost_source_type IN ('EXTERNAL_COST', 'HUMAN_WORK', 'SHARED_OVERHEAD')),
    CONSTRAINT ck_finance_allocation_rule_method CHECK (method IN ('DIRECT', 'EQUAL', 'SESSION_WEIGHTED', 'CLICK_WEIGHTED', 'AI_USAGE_WEIGHTED', 'MANUAL')),
    CONSTRAINT ck_finance_allocation_rule_status CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED')),
    CONSTRAINT ck_finance_allocation_rule_dates CHECK (effective_to IS NULL OR effective_to >= effective_from),
    CONSTRAINT ck_finance_allocation_rule_params CHECK (jsonb_typeof(parameters) = 'object')
);
COMMENT ON TABLE finance.allocation_rule IS '外部費用・人件費をSite/Category/Articleへ配賦するMethod、Weight、Scope、Versionを不変管理する。';
COMMENT ON COLUMN finance.allocation_rule.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.allocation_rule.display_id IS 'ALR-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.allocation_rule.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.allocation_rule.rule_code IS 'rule code';
COMMENT ON COLUMN finance.allocation_rule.version_no IS 'Aggregate内で1から増加する不変Version番号。';
COMMENT ON COLUMN finance.allocation_rule.cost_source_type IS 'cost source type';
COMMENT ON COLUMN finance.allocation_rule.method IS 'method';
COMMENT ON COLUMN finance.allocation_rule.parameters IS 'equal、session weight、token usage、manual weights等。';
COMMENT ON COLUMN finance.allocation_rule.effective_from IS '設定・関係が有効になる時刻。';
COMMENT ON COLUMN finance.allocation_rule.effective_to IS '設定・関係の有効終了時刻。NULLは終了未定。';
COMMENT ON COLUMN finance.allocation_rule.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN finance.allocation_rule.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN finance.allocation_rule.approved_at IS 'approved at';
COMMENT ON COLUMN finance.allocation_rule.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.cost_allocation (
    id uuid DEFAULT uuidv7() NOT NULL,
    allocation_rule_id uuid NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    period_month date NOT NULL,
    allocation_ratio numeric(12,10) NOT NULL,
    allocated_amount_jpy bigint NOT NULL,
    calculated_by_job_id uuid NOT NULL,
    calculated_at timestamptz NOT NULL,
    calculation_sha256 text NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_cost_allocation PRIMARY KEY (id),
    CONSTRAINT uq_finance_cost_allocation UNIQUE (source_type, source_id, target_type, target_id, period_month, allocation_rule_id),
    CONSTRAINT ck_finance_cost_alloc_source CHECK (source_type IN ('EXTERNAL_COST', 'HUMAN_WORK', 'SHARED_OVERHEAD')),
    CONSTRAINT ck_finance_cost_alloc_target CHECK (target_type IN ('SITE', 'CATEGORY', 'ARTICLE')),
    CONSTRAINT ck_finance_cost_alloc_month CHECK (date_trunc('month', period_month)::date = period_month),
    CONSTRAINT ck_finance_cost_alloc_ratio CHECK (allocation_ratio >= 0 AND allocation_ratio <= 1),
    CONSTRAINT ck_finance_cost_alloc_amount CHECK (allocated_amount_jpy >= 0),
    CONSTRAINT ck_finance_cost_alloc_hash CHECK (calculation_sha256 ~ '^[0-9a-f]{64}$')
);
COMMENT ON TABLE finance.cost_allocation IS '特定原価をArticle/Category/SiteへRuleに従って配賦した不変結果。Source総額との合計一致をDQで検証する。';
COMMENT ON COLUMN finance.cost_allocation.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.cost_allocation.allocation_rule_id IS 'allocation rule id';
COMMENT ON COLUMN finance.cost_allocation.source_type IS 'source type';
COMMENT ON COLUMN finance.cost_allocation.source_id IS 'source id';
COMMENT ON COLUMN finance.cost_allocation.target_type IS 'target type';
COMMENT ON COLUMN finance.cost_allocation.target_id IS 'target id';
COMMENT ON COLUMN finance.cost_allocation.period_month IS 'period month';
COMMENT ON COLUMN finance.cost_allocation.allocation_ratio IS 'allocation ratio';
COMMENT ON COLUMN finance.cost_allocation.allocated_amount_jpy IS 'allocated amount jpy';
COMMENT ON COLUMN finance.cost_allocation.calculated_by_job_id IS 'calculated by job id';
COMMENT ON COLUMN finance.cost_allocation.calculated_at IS 'calculated at';
COMMENT ON COLUMN finance.cost_allocation.calculation_sha256 IS 'calculation sha256';
COMMENT ON COLUMN finance.cost_allocation.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE finance.unit_economics_snapshot (
    id uuid DEFAULT uuidv7() NOT NULL,
    display_id text NOT NULL,
    site_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    period_month date NOT NULL,
    calculation_version text NOT NULL,
    status text NOT NULL,
    confirmed_commission_jpy bigint NOT NULL,
    generated_commission_jpy bigint NOT NULL,
    external_cost_jpy bigint NOT NULL,
    human_cost_jpy bigint NOT NULL,
    contribution_profit_jpy bigint NOT NULL,
    eligible_sessions bigint NOT NULL,
    affiliate_clicks bigint NOT NULL,
    confirmed_orders bigint NOT NULL,
    confirmed_epc_jpy numeric(20,6),
    confirmed_rpm_jpy numeric(20,6),
    confirmation_rate numeric(12,10),
    cost_recovery_months numeric(12,4),
    source_watermark text NOT NULL,
    report_artifact_id uuid NOT NULL,
    calculated_by_job_id uuid NOT NULL,
    calculated_at timestamptz NOT NULL,
    approved_by_principal_id uuid,
    approved_at timestamptz,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_finance_unit_economics_snapshot PRIMARY KEY (id),
    CONSTRAINT uq_finance_unit_econ_display UNIQUE (display_id),
    CONSTRAINT uq_finance_unit_econ_version UNIQUE (site_id, scope_type, scope_id, period_month, calculation_version),
    CONSTRAINT ck_finance_unit_econ_scope CHECK (scope_type IN ('SITE', 'CATEGORY', 'ARTICLE')),
    CONSTRAINT ck_finance_unit_econ_month CHECK (date_trunc('month', period_month)::date = period_month),
    CONSTRAINT ck_finance_unit_econ_status CHECK (status IN ('DRAFT', 'APPROVED', 'SUPERSEDED')),
    CONSTRAINT ck_finance_unit_econ_nonnegative CHECK (confirmed_commission_jpy >= 0 AND generated_commission_jpy >= 0 AND external_cost_jpy >= 0 AND human_cost_jpy >= 0 AND eligible_sessions >= 0 AND affiliate_clicks >= 0 AND confirmed_orders >= 0),
    CONSTRAINT ck_finance_unit_econ_rate CHECK (confirmation_rate IS NULL OR (confirmation_rate >= 0 AND confirmation_rate <= 1)),
    CONSTRAINT ck_finance_unit_econ_approval CHECK ((approved_by_principal_id IS NULL) = (approved_at IS NULL)),
    CONSTRAINT ck_finance_unit_econ_formula CHECK (contribution_profit_jpy = confirmed_commission_jpy - external_cost_jpy - human_cost_jpy)
);
COMMENT ON TABLE finance.unit_economics_snapshot IS 'Site/Category/Article単位の確定報酬、変動費、人件費、確定EPC/RPM、貢献利益を月次Versionとして凍結する。';
COMMENT ON COLUMN finance.unit_economics_snapshot.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN finance.unit_economics_snapshot.display_id IS 'UES-接頭辞を持つアプリケーション生成の不変表示ID。';
COMMENT ON COLUMN finance.unit_economics_snapshot.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN finance.unit_economics_snapshot.scope_type IS 'scope type';
COMMENT ON COLUMN finance.unit_economics_snapshot.scope_id IS 'scope id';
COMMENT ON COLUMN finance.unit_economics_snapshot.period_month IS 'period month';
COMMENT ON COLUMN finance.unit_economics_snapshot.calculation_version IS 'calculation version';
COMMENT ON COLUMN finance.unit_economics_snapshot.status IS '業務状態を示す安定Enum文字列。';
COMMENT ON COLUMN finance.unit_economics_snapshot.confirmed_commission_jpy IS 'confirmed commission jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.generated_commission_jpy IS 'generated commission jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.external_cost_jpy IS 'external cost jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.human_cost_jpy IS 'human cost jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.contribution_profit_jpy IS 'contribution profit jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.eligible_sessions IS 'eligible sessions';
COMMENT ON COLUMN finance.unit_economics_snapshot.affiliate_clicks IS 'affiliate clicks';
COMMENT ON COLUMN finance.unit_economics_snapshot.confirmed_orders IS 'confirmed orders';
COMMENT ON COLUMN finance.unit_economics_snapshot.confirmed_epc_jpy IS 'confirmed epc jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.confirmed_rpm_jpy IS 'confirmed rpm jpy';
COMMENT ON COLUMN finance.unit_economics_snapshot.confirmation_rate IS 'confirmation rate';
COMMENT ON COLUMN finance.unit_economics_snapshot.cost_recovery_months IS 'cost recovery months';
COMMENT ON COLUMN finance.unit_economics_snapshot.source_watermark IS 'source watermark';
COMMENT ON COLUMN finance.unit_economics_snapshot.report_artifact_id IS 'report artifact id';
COMMENT ON COLUMN finance.unit_economics_snapshot.calculated_by_job_id IS 'calculated by job id';
COMMENT ON COLUMN finance.unit_economics_snapshot.calculated_at IS 'calculated at';
COMMENT ON COLUMN finance.unit_economics_snapshot.approved_by_principal_id IS 'approved by principal id';
COMMENT ON COLUMN finance.unit_economics_snapshot.approved_at IS 'approved at';
COMMENT ON COLUMN finance.unit_economics_snapshot.created_at IS 'レコード作成時刻。UTCのtimestamptz。';

CREATE TABLE readmodel.public_article (
    article_id uuid NOT NULL,
    site_id uuid NOT NULL,
    publication_id uuid NOT NULL,
    publication_snapshot_id uuid NOT NULL,
    canonical_path text NOT NULL,
    title text NOT NULL,
    meta_title text,
    meta_description text,
    excerpt text,
    disclosure_text text NOT NULL,
    article_type text NOT NULL,
    language_tag text DEFAULT 'ja-JP' NOT NULL,
    content_sha256 text NOT NULL,
    structured_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    freshness_status text NOT NULL,
    published_at timestamptz NOT NULL,
    updated_public_at timestamptz NOT NULL,
    projection_generation bigint NOT NULL,
    is_indexable boolean NOT NULL,
    CONSTRAINT pk_readmodel_public_article PRIMARY KEY (article_id),
    CONSTRAINT uq_readmodel_public_article_snapshot UNIQUE (publication_snapshot_id),
    CONSTRAINT uq_readmodel_public_article_path UNIQUE (site_id, canonical_path),
    CONSTRAINT ck_readmodel_public_article_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ck_readmodel_public_article_json CHECK (jsonb_typeof(structured_data) = 'object'),
    CONSTRAINT ck_readmodel_public_article_freshness CHECK (freshness_status IN ('FRESH', 'WARNING', 'CRITICAL', 'UNKNOWN')),
    CONSTRAINT ck_readmodel_public_article_generation CHECK (projection_generation > 0),
    CONSTRAINT ck_readmodel_public_article_path CHECK (canonical_path ~ '^/' AND canonical_path !~ '[?#[:cntrl:]]')
);
COMMENT ON TABLE readmodel.public_article IS '公開Rendererが読む現在記事Projection。承認済みPublication Snapshotからのみ再生成し、編集DBを直接参照させない。';
COMMENT ON COLUMN readmodel.public_article.article_id IS '論理記事ID。';
COMMENT ON COLUMN readmodel.public_article.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN readmodel.public_article.publication_id IS 'publication id';
COMMENT ON COLUMN readmodel.public_article.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN readmodel.public_article.canonical_path IS 'canonical path';
COMMENT ON COLUMN readmodel.public_article.title IS 'title';
COMMENT ON COLUMN readmodel.public_article.meta_title IS 'meta title';
COMMENT ON COLUMN readmodel.public_article.meta_description IS 'meta description';
COMMENT ON COLUMN readmodel.public_article.excerpt IS 'excerpt';
COMMENT ON COLUMN readmodel.public_article.disclosure_text IS 'disclosure text';
COMMENT ON COLUMN readmodel.public_article.article_type IS 'article type';
COMMENT ON COLUMN readmodel.public_article.language_tag IS 'language tag';
COMMENT ON COLUMN readmodel.public_article.content_sha256 IS 'content sha256';
COMMENT ON COLUMN readmodel.public_article.structured_data IS 'Sanitize済みJSON-LD payload。';
COMMENT ON COLUMN readmodel.public_article.freshness_status IS 'freshness status';
COMMENT ON COLUMN readmodel.public_article.published_at IS 'published at';
COMMENT ON COLUMN readmodel.public_article.updated_public_at IS 'updated public at';
COMMENT ON COLUMN readmodel.public_article.projection_generation IS 'projection generation';
COMMENT ON COLUMN readmodel.public_article.is_indexable IS 'is indexable';

CREATE TABLE readmodel.public_article_block (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_id uuid NOT NULL,
    publication_snapshot_id uuid NOT NULL,
    block_key text NOT NULL,
    block_type text NOT NULL,
    position integer NOT NULL,
    heading_level smallint,
    heading_text text,
    rendered_html text,
    render_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    block_sha256 text NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    CONSTRAINT pk_readmodel_public_article_block PRIMARY KEY (id),
    CONSTRAINT uq_readmodel_public_block_key UNIQUE (publication_snapshot_id, block_key),
    CONSTRAINT uq_readmodel_public_block_pos UNIQUE (publication_snapshot_id, position),
    CONSTRAINT ck_readmodel_public_block_position CHECK (position >= 0),
    CONSTRAINT ck_readmodel_public_block_heading CHECK (heading_level IS NULL OR heading_level BETWEEN 2 AND 6),
    CONSTRAINT ck_readmodel_public_block_payload CHECK (jsonb_typeof(render_payload) = 'object'),
    CONSTRAINT ck_readmodel_public_block_hash CHECK (block_sha256 ~ '^[0-9a-f]{64}$')
);
COMMENT ON TABLE readmodel.public_article_block IS '公開Snapshotの表示順Block、Sanitize済みHTML/JSON、Block hashを保持するProjection。';
COMMENT ON COLUMN readmodel.public_article_block.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN readmodel.public_article_block.article_id IS '論理記事ID。';
COMMENT ON COLUMN readmodel.public_article_block.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN readmodel.public_article_block.block_key IS 'block key';
COMMENT ON COLUMN readmodel.public_article_block.block_type IS 'block type';
COMMENT ON COLUMN readmodel.public_article_block.position IS 'position';
COMMENT ON COLUMN readmodel.public_article_block.heading_level IS 'heading level';
COMMENT ON COLUMN readmodel.public_article_block.heading_text IS 'heading text';
COMMENT ON COLUMN readmodel.public_article_block.rendered_html IS 'rendered html';
COMMENT ON COLUMN readmodel.public_article_block.render_payload IS 'Component renderer用Allowlist payload。';
COMMENT ON COLUMN readmodel.public_article_block.block_sha256 IS 'block sha256';
COMMENT ON COLUMN readmodel.public_article_block.is_visible IS 'is visible';

CREATE TABLE readmodel.public_product_card (
    id uuid DEFAULT uuidv7() NOT NULL,
    article_id uuid NOT NULL,
    publication_snapshot_id uuid NOT NULL,
    product_id uuid NOT NULL,
    card_key text NOT NULL,
    display_name text NOT NULL,
    short_description text,
    image_url text,
    image_alt text,
    badges jsonb DEFAULT '{}'::jsonb NOT NULL,
    comparison_attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    position integer NOT NULL,
    product_freshness_status text NOT NULL,
    content_sha256 text NOT NULL,
    CONSTRAINT pk_readmodel_public_product_card PRIMARY KEY (id),
    CONSTRAINT uq_readmodel_public_card_key UNIQUE (publication_snapshot_id, card_key),
    CONSTRAINT uq_readmodel_public_card_product UNIQUE (publication_snapshot_id, product_id),
    CONSTRAINT ck_readmodel_public_card_badges CHECK (jsonb_typeof(badges) = 'object'),
    CONSTRAINT ck_readmodel_public_card_attrs CHECK (jsonb_typeof(comparison_attributes) = 'object'),
    CONSTRAINT ck_readmodel_public_card_position CHECK (position >= 0),
    CONSTRAINT ck_readmodel_public_card_freshness CHECK (product_freshness_status IN ('FRESH', 'WARNING', 'CRITICAL', 'UNKNOWN')),
    CONSTRAINT ck_readmodel_public_card_hash CHECK (content_sha256 ~ '^[0-9a-f]{64}$')
);
COMMENT ON TABLE readmodel.public_product_card IS '公開記事内のProduct表示名、比較属性、Badge、画像参照をSnapshot単位で保持する。報酬率は含めない。';
COMMENT ON COLUMN readmodel.public_product_card.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN readmodel.public_product_card.article_id IS '論理記事ID。';
COMMENT ON COLUMN readmodel.public_product_card.publication_snapshot_id IS 'publication snapshot id';
COMMENT ON COLUMN readmodel.public_product_card.product_id IS '正規化されたCanonical Product。';
COMMENT ON COLUMN readmodel.public_product_card.card_key IS 'card key';
COMMENT ON COLUMN readmodel.public_product_card.display_name IS 'display name';
COMMENT ON COLUMN readmodel.public_product_card.short_description IS 'short description';
COMMENT ON COLUMN readmodel.public_product_card.image_url IS 'image url';
COMMENT ON COLUMN readmodel.public_product_card.image_alt IS 'image alt';
COMMENT ON COLUMN readmodel.public_product_card.badges IS '根拠付き表示Badge。';
COMMENT ON COLUMN readmodel.public_product_card.comparison_attributes IS '公開可能FactのみをSnapshot化。';
COMMENT ON COLUMN readmodel.public_product_card.position IS 'position';
COMMENT ON COLUMN readmodel.public_product_card.product_freshness_status IS 'product freshness status';
COMMENT ON COLUMN readmodel.public_product_card.content_sha256 IS 'content sha256';

CREATE TABLE readmodel.public_offer (
    id uuid DEFAULT uuidv7() NOT NULL,
    public_product_card_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    shop_name text NOT NULL,
    price_jpy bigint,
    shipping_fee_jpy bigint,
    availability text NOT NULL,
    affiliate_url text,
    destination_host text,
    price_observed_at timestamptz,
    availability_observed_at timestamptz,
    link_observed_at timestamptz,
    freshness_status text NOT NULL,
    is_cta_enabled boolean NOT NULL,
    cta_disabled_reason text,
    position integer NOT NULL,
    projection_generation bigint NOT NULL,
    CONSTRAINT pk_readmodel_public_offer PRIMARY KEY (id),
    CONSTRAINT uq_readmodel_public_offer UNIQUE (public_product_card_id, offer_id),
    CONSTRAINT ck_readmodel_public_offer_price CHECK (price_jpy IS NULL OR price_jpy >= 0),
    CONSTRAINT ck_readmodel_public_offer_shipping CHECK (shipping_fee_jpy IS NULL OR shipping_fee_jpy >= 0),
    CONSTRAINT ck_readmodel_public_offer_avail CHECK (availability IN ('IN_STOCK', 'OUT_OF_STOCK', 'BACKORDER', 'DISCONTINUED', 'UNKNOWN')),
    CONSTRAINT ck_readmodel_public_offer_freshness CHECK (freshness_status IN ('FRESH', 'WARNING', 'CRITICAL', 'UNKNOWN')),
    CONSTRAINT ck_readmodel_public_offer_cta CHECK (is_cta_enabled OR cta_disabled_reason IS NOT NULL),
    CONSTRAINT ck_readmodel_public_offer_position CHECK (position >= 0),
    CONSTRAINT ck_readmodel_public_offer_generation CHECK (projection_generation > 0)
);
COMMENT ON TABLE readmodel.public_offer IS '公開Product Cardに紐づく価格・在庫・楽天Affiliate URL・観測時刻を保持する安全Projection。料率・収益情報は禁止。';
COMMENT ON COLUMN readmodel.public_offer.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN readmodel.public_offer.public_product_card_id IS 'public product card id';
COMMENT ON COLUMN readmodel.public_offer.offer_id IS 'ショップ単位の販売Offer。';
COMMENT ON COLUMN readmodel.public_offer.shop_id IS 'shop id';
COMMENT ON COLUMN readmodel.public_offer.shop_name IS 'shop name';
COMMENT ON COLUMN readmodel.public_offer.price_jpy IS 'price jpy';
COMMENT ON COLUMN readmodel.public_offer.shipping_fee_jpy IS 'shipping fee jpy';
COMMENT ON COLUMN readmodel.public_offer.availability IS 'availability';
COMMENT ON COLUMN readmodel.public_offer.affiliate_url IS 'affiliate url';
COMMENT ON COLUMN readmodel.public_offer.destination_host IS 'destination host';
COMMENT ON COLUMN readmodel.public_offer.price_observed_at IS 'price observed at';
COMMENT ON COLUMN readmodel.public_offer.availability_observed_at IS 'availability observed at';
COMMENT ON COLUMN readmodel.public_offer.link_observed_at IS 'link observed at';
COMMENT ON COLUMN readmodel.public_offer.freshness_status IS 'freshness status';
COMMENT ON COLUMN readmodel.public_offer.is_cta_enabled IS 'is cta enabled';
COMMENT ON COLUMN readmodel.public_offer.cta_disabled_reason IS 'cta disabled reason';
COMMENT ON COLUMN readmodel.public_offer.position IS 'position';
COMMENT ON COLUMN readmodel.public_offer.projection_generation IS 'projection generation';

CREATE TABLE readmodel.public_route (
    site_id uuid NOT NULL,
    path text NOT NULL,
    route_type text NOT NULL,
    article_id uuid,
    redirect_path text,
    http_status smallint NOT NULL,
    is_indexable boolean NOT NULL,
    projection_generation bigint NOT NULL,
    updated_at timestamptz NOT NULL,
    CONSTRAINT pk_readmodel_public_route PRIMARY KEY (site_id, path),
    CONSTRAINT ck_readmodel_route_type CHECK (route_type IN ('ARTICLE', 'REDIRECT', 'GONE', 'STATIC')),
    CONSTRAINT ck_readmodel_route_path CHECK (path ~ '^/' AND path !~ '[?#[:cntrl:]]'),
    CONSTRAINT ck_readmodel_route_http CHECK (http_status BETWEEN 200 AND 599),
    CONSTRAINT ck_readmodel_route_redirect CHECK (route_type <> 'REDIRECT' OR redirect_path IS NOT NULL),
    CONSTRAINT ck_readmodel_route_article CHECK (route_type <> 'ARTICLE' OR article_id IS NOT NULL),
    CONSTRAINT ck_readmodel_route_generation CHECK (projection_generation > 0)
);
COMMENT ON TABLE readmodel.public_route IS 'Public WebのPath解決に必要なArticle/Redirect/Gone Projection。公開RoleはこのSchema以外を読まない。';
COMMENT ON COLUMN readmodel.public_route.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN readmodel.public_route.path IS 'path';
COMMENT ON COLUMN readmodel.public_route.route_type IS 'route type';
COMMENT ON COLUMN readmodel.public_route.article_id IS '論理記事ID。';
COMMENT ON COLUMN readmodel.public_route.redirect_path IS 'redirect path';
COMMENT ON COLUMN readmodel.public_route.http_status IS 'http status';
COMMENT ON COLUMN readmodel.public_route.is_indexable IS 'is indexable';
COMMENT ON COLUMN readmodel.public_route.projection_generation IS 'projection generation';
COMMENT ON COLUMN readmodel.public_route.updated_at IS '最終更新時刻。UTCのtimestamptz。';

CREATE TABLE readmodel.runtime_control (
    id uuid DEFAULT uuidv7() NOT NULL,
    site_id uuid NOT NULL,
    scope_type text NOT NULL,
    scope_id uuid,
    publication_enabled boolean NOT NULL,
    affiliate_links_enabled boolean NOT NULL,
    generation bigint NOT NULL,
    reason_code text,
    expires_at timestamptz,
    projected_at timestamptz NOT NULL,
    CONSTRAINT pk_readmodel_runtime_control PRIMARY KEY (id),
    CONSTRAINT ck_readmodel_runtime_scope CHECK (scope_type IN ('GLOBAL', 'SITE', 'CATEGORY', 'ARTICLE')),
    CONSTRAINT ck_readmodel_runtime_scope_id CHECK ((scope_type IN ('GLOBAL','SITE') AND scope_id IS NULL) OR (scope_type IN ('CATEGORY','ARTICLE') AND scope_id IS NOT NULL)),
    CONSTRAINT ck_readmodel_runtime_generation CHECK (generation >= 0)
);
COMMENT ON TABLE readmodel.runtime_control IS 'Public Rendererが低Latencyで参照するPublication/Affiliate Link Kill Switchの安全Projection。障害時は停止側へ倒す。';
COMMENT ON COLUMN readmodel.runtime_control.id IS '内部主キー。PostgreSQL 18のuuidv7()で生成する時系列順UUID。';
COMMENT ON COLUMN readmodel.runtime_control.site_id IS '対象サイト。MVPは1サイトだが将来の複数サイトを識別可能にする。';
COMMENT ON COLUMN readmodel.runtime_control.scope_type IS 'scope type';
COMMENT ON COLUMN readmodel.runtime_control.scope_id IS 'scope id';
COMMENT ON COLUMN readmodel.runtime_control.publication_enabled IS 'publication enabled';
COMMENT ON COLUMN readmodel.runtime_control.affiliate_links_enabled IS 'affiliate links enabled';
COMMENT ON COLUMN readmodel.runtime_control.generation IS 'generation';
COMMENT ON COLUMN readmodel.runtime_control.reason_code IS 'reason code';
COMMENT ON COLUMN readmodel.runtime_control.expires_at IS 'expires at';
COMMENT ON COLUMN readmodel.runtime_control.projected_at IS 'projected at';

-- Foreign keys are added after all tables exist to allow explicit circular aggregate links.
ALTER TABLE ops.job ADD CONSTRAINT fk_ops_job_payload_artifact_id FOREIGN KEY (payload_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ops.job ADD CONSTRAINT fk_ops_job_parent_job_id FOREIGN KEY (parent_job_id) REFERENCES ops.job (id) ON DELETE SET NULL;
ALTER TABLE ops.job ADD CONSTRAINT fk_ops_job_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE ops.job_attempt ADD CONSTRAINT fk_ops_job_attempt_job_id FOREIGN KEY (job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE ops.job_attempt ADD CONSTRAINT fk_ops_job_attempt_input_artifact_id FOREIGN KEY (input_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ops.job_attempt ADD CONSTRAINT fk_ops_job_attempt_output_artifact_id FOREIGN KEY (output_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ops.idempotency_record ADD CONSTRAINT fk_ops_idempotency_record_response_artifact_id FOREIGN KEY (response_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ops.audit_export ADD CONSTRAINT fk_ops_audit_export_artifact_id FOREIGN KEY (artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ops.alert ADD CONSTRAINT fk_ops_alert_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE SET NULL;
ALTER TABLE ops.alert ADD CONSTRAINT fk_ops_alert_acknowledged_by_principal_id FOREIGN KEY (acknowledged_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.incident ADD CONSTRAINT fk_ops_incident_declared_by_principal_id FOREIGN KEY (declared_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.incident ADD CONSTRAINT fk_ops_incident_commander_principal_id FOREIGN KEY (commander_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.incident_event ADD CONSTRAINT fk_ops_incident_event_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE RESTRICT;
ALTER TABLE ops.incident_event ADD CONSTRAINT fk_ops_incident_event_actor_principal_id FOREIGN KEY (actor_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.kill_switch ADD CONSTRAINT fk_ops_kill_switch_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE SET NULL;
ALTER TABLE ops.kill_switch ADD CONSTRAINT fk_ops_kill_switch_changed_by_principal_id FOREIGN KEY (changed_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.kill_switch_change ADD CONSTRAINT fk_ops_kill_switch_change_kill_switch_id FOREIGN KEY (kill_switch_id) REFERENCES ops.kill_switch (id) ON DELETE RESTRICT;
ALTER TABLE ops.kill_switch_change ADD CONSTRAINT fk_ops_kill_switch_change_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE SET NULL;
ALTER TABLE ops.kill_switch_change ADD CONSTRAINT fk_ops_kill_switch_change_actor_principal_id FOREIGN KEY (actor_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.runtime_setting_version ADD CONSTRAINT fk_ops_runtime_setting_version_created_by_principal_id FOREIGN KEY (created_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.runtime_setting_version ADD CONSTRAINT fk_ops_runtime_setting_version_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.retention_policy ADD CONSTRAINT fk_ops_retention_policy_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.release ADD CONSTRAINT fk_ops_release_deployed_by_principal_id FOREIGN KEY (deployed_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ops.release ADD CONSTRAINT fk_ops_release_rollback_of_release_id FOREIGN KEY (rollback_of_release_id) REFERENCES ops.release (id) ON DELETE SET NULL;
ALTER TABLE ops.release ADD CONSTRAINT fk_ops_release_manifest_artifact_id FOREIGN KEY (manifest_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE iam.user_account ADD CONSTRAINT fk_iam_user_account_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.service_principal ADD CONSTRAINT fk_iam_service_principal_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.role_permission ADD CONSTRAINT fk_iam_role_permission_role_id FOREIGN KEY (role_id) REFERENCES iam.role (id) ON DELETE RESTRICT;
ALTER TABLE iam.role_permission ADD CONSTRAINT fk_iam_role_permission_permission_id FOREIGN KEY (permission_id) REFERENCES iam.permission (id) ON DELETE RESTRICT;
ALTER TABLE iam.principal_role_assignment ADD CONSTRAINT fk_iam_principal_role_assignment_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.principal_role_assignment ADD CONSTRAINT fk_iam_principal_role_assignment_role_id FOREIGN KEY (role_id) REFERENCES iam.role (id) ON DELETE RESTRICT;
ALTER TABLE iam.principal_role_assignment ADD CONSTRAINT fk_iam_principal_role_assignment_assigned_by_principal_id FOREIGN KEY (assigned_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.principal_role_assignment ADD CONSTRAINT fk_iam_principal_role_assignment_revoked_by_principal_id FOREIGN KEY (revoked_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.session_revocation ADD CONSTRAINT fk_iam_session_revocation_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.session_revocation ADD CONSTRAINT fk_iam_session_revocation_created_by_principal_id FOREIGN KEY (created_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.break_glass_record ADD CONSTRAINT fk_iam_break_glass_record_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE iam.break_glass_record ADD CONSTRAINT fk_iam_break_glass_record_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE RESTRICT;
ALTER TABLE iam.break_glass_record ADD CONSTRAINT fk_iam_break_glass_record_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.category ADD CONSTRAINT fk_portfolio_category_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.category ADD CONSTRAINT fk_portfolio_category_parent_category_id FOREIGN KEY (parent_category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.category ADD CONSTRAINT fk_portfolio_category_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.intent_cluster ADD CONSTRAINT fk_portfolio_intent_cluster_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.keyword ADD CONSTRAINT fk_portfolio_keyword_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.intent_cluster_keyword ADD CONSTRAINT fk_portfolio_intent_cluster_keyword_intent_cluster_id FOREIGN KEY (intent_cluster_id) REFERENCES portfolio.intent_cluster (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.intent_cluster_keyword ADD CONSTRAINT fk_portfolio_intent_cluster_keyword_keyword_id FOREIGN KEY (keyword_id) REFERENCES portfolio.keyword (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.keyword_metric_observation ADD CONSTRAINT fk_portfolio_keyword_metric_observation_keyword_id FOREIGN KEY (keyword_id) REFERENCES portfolio.keyword (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.keyword_metric_observation ADD CONSTRAINT fk_portfolio_keyword_metric_observation_raw_artifact_id FOREIGN KEY (raw_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.opportunity_assessment ADD CONSTRAINT fk_portfolio_opportunity_assessment_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.opportunity_assessment ADD CONSTRAINT fk_portfolio_opportunity_assessment_intent_cluster_id FOREIGN KEY (intent_cluster_id) REFERENCES portfolio.intent_cluster (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.opportunity_assessment ADD CONSTRAINT fk_portfolio_opportunity_assessment_keyword_id FOREIGN KEY (keyword_id) REFERENCES portfolio.keyword (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.action_candidate ADD CONSTRAINT fk_portfolio_action_candidate_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.action_candidate ADD CONSTRAINT fk_portfolio_action_candidate_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE portfolio.action_candidate ADD CONSTRAINT fk_portfolio_action_candidate_decided_by_principal_id FOREIGN KEY (decided_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE catalog.ingestion_request ADD CONSTRAINT fk_catalog_ingestion_request_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE catalog.ingestion_request ADD CONSTRAINT fk_catalog_ingestion_request_job_id FOREIGN KEY (job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE catalog.ingestion_request ADD CONSTRAINT fk_catalog_ingestion_request_raw_response_artifact_id FOREIGN KEY (raw_response_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE catalog.rakuten_genre ADD CONSTRAINT fk_catalog_rakuten_genre_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE catalog.rakuten_genre ADD CONSTRAINT fk_catalog_rakuten_genre_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.shop ADD CONSTRAINT fk_catalog_shop_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE catalog.shop ADD CONSTRAINT fk_catalog_shop_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.canonical_product ADD CONSTRAINT fk_catalog_canonical_product_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE catalog.canonical_product ADD CONSTRAINT fk_catalog_canonical_product_merged_into_product_id FOREIGN KEY (merged_into_product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_candidate ADD CONSTRAINT fk_catalog_product_candidate_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_candidate ADD CONSTRAINT fk_catalog_product_candidate_shop_id FOREIGN KEY (shop_id) REFERENCES catalog.shop (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_candidate ADD CONSTRAINT fk_catalog_product_candidate_rakuten_genre_id FOREIGN KEY (rakuten_genre_id) REFERENCES catalog.rakuten_genre (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_candidate ADD CONSTRAINT fk_catalog_product_candidate_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.grouping_decision ADD CONSTRAINT fk_catalog_grouping_decision_product_candidate_id FOREIGN KEY (product_candidate_id) REFERENCES catalog.product_candidate (id) ON DELETE RESTRICT;
ALTER TABLE catalog.grouping_decision ADD CONSTRAINT fk_catalog_grouping_decision_proposed_product_id FOREIGN KEY (proposed_product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.grouping_decision ADD CONSTRAINT fk_catalog_grouping_decision_supersedes_decision_id FOREIGN KEY (supersedes_decision_id) REFERENCES catalog.grouping_decision (id) ON DELETE SET NULL;
ALTER TABLE catalog.product_group_membership ADD CONSTRAINT fk_catalog_product_group_membership_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_group_membership ADD CONSTRAINT fk_catalog_product_group_membership_product_candidate_id FOREIGN KEY (product_candidate_id) REFERENCES catalog.product_candidate (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_group_membership ADD CONSTRAINT fk_catalog_product_group_membership_grouping_decision_id FOREIGN KEY (grouping_decision_id) REFERENCES catalog.grouping_decision (id) ON DELETE RESTRICT;
ALTER TABLE catalog.attribute_definition ADD CONSTRAINT fk_catalog_attribute_definition_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_attribute_value ADD CONSTRAINT fk_catalog_product_attribute_value_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_attribute_value ADD CONSTRAINT fk_catalog_product_attribute_value_attribute_definition_id FOREIGN KEY (attribute_definition_id) REFERENCES catalog.attribute_definition (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_attribute_value ADD CONSTRAINT fk_catalog_product_attribute_value_source_fact_id FOREIGN KEY (source_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_relation ADD CONSTRAINT fk_catalog_product_relation_from_product_id FOREIGN KEY (from_product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_relation ADD CONSTRAINT fk_catalog_product_relation_to_product_id FOREIGN KEY (to_product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.product_relation ADD CONSTRAINT fk_catalog_product_relation_source_fact_id FOREIGN KEY (source_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer ADD CONSTRAINT fk_catalog_offer_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer ADD CONSTRAINT fk_catalog_offer_product_candidate_id FOREIGN KEY (product_candidate_id) REFERENCES catalog.product_candidate (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer ADD CONSTRAINT fk_catalog_offer_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer ADD CONSTRAINT fk_catalog_offer_shop_id FOREIGN KEY (shop_id) REFERENCES catalog.shop (id) ON DELETE RESTRICT;
ALTER TABLE catalog.price_observation ADD CONSTRAINT fk_catalog_price_observation_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE catalog.price_observation ADD CONSTRAINT fk_catalog_price_observation_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.availability_observation ADD CONSTRAINT fk_catalog_availability_observation_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE catalog.availability_observation ADD CONSTRAINT fk_catalog_availability_observation_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.review_aggregate_observation ADD CONSTRAINT fk_catalog_review_aggregate_observation_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE catalog.review_aggregate_observation ADD CONSTRAINT fk_catalog_review_aggregate_observation_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.affiliate_link_observation ADD CONSTRAINT fk_catalog_affiliate_link_observation_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE catalog.affiliate_link_observation ADD CONSTRAINT fk_catalog_affiliate_link_observation_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_price_observation_id FOREIGN KEY (price_observation_id) REFERENCES catalog.price_observation (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_availability_observation_id FOREIGN KEY (availability_observation_id) REFERENCES catalog.availability_observation (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_review_observation_id FOREIGN KEY (review_observation_id) REFERENCES catalog.review_aggregate_observation (id) ON DELETE RESTRICT;
ALTER TABLE catalog.offer_current_projection ADD CONSTRAINT fk_catalog_offer_current_projection_affiliate_link_o_c2329b301d FOREIGN KEY (affiliate_link_observation_id) REFERENCES catalog.affiliate_link_observation (id) ON DELETE RESTRICT;
ALTER TABLE catalog.category_genre_mapping ADD CONSTRAINT fk_catalog_category_genre_mapping_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE catalog.category_genre_mapping ADD CONSTRAINT fk_catalog_category_genre_mapping_rakuten_genre_id FOREIGN KEY (rakuten_genre_id) REFERENCES catalog.rakuten_genre (id) ON DELETE RESTRICT;
ALTER TABLE catalog.category_genre_mapping ADD CONSTRAINT fk_catalog_category_genre_mapping_decided_by_principal_id FOREIGN KEY (decided_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source ADD CONSTRAINT fk_evidence_source_provider_endpoint_id FOREIGN KEY (provider_endpoint_id) REFERENCES catalog.provider_endpoint (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source ADD CONSTRAINT fk_evidence_source_terms_checked_by_principal_id FOREIGN KEY (terms_checked_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_snapshot ADD CONSTRAINT fk_evidence_source_snapshot_source_id FOREIGN KEY (source_id) REFERENCES evidence.source (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_snapshot ADD CONSTRAINT fk_evidence_source_snapshot_artifact_id FOREIGN KEY (artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE evidence.fact ADD CONSTRAINT fk_evidence_fact_source_snapshot_id FOREIGN KEY (source_snapshot_id) REFERENCES evidence.source_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE evidence.fact_derivation ADD CONSTRAINT fk_evidence_fact_derivation_derived_fact_id FOREIGN KEY (derived_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE evidence.fact_derivation ADD CONSTRAINT fk_evidence_fact_derivation_input_fact_id FOREIGN KEY (input_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet ADD CONSTRAINT fk_evidence_source_packet_article_plan_id FOREIGN KEY (article_plan_id) REFERENCES editorial.article_plan (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_version ADD CONSTRAINT fk_evidence_source_packet_version_source_packet_id FOREIGN KEY (source_packet_id) REFERENCES evidence.source_packet (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_version ADD CONSTRAINT fk_evidence_source_packet_version_artifact_id FOREIGN KEY (artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_version ADD CONSTRAINT fk_evidence_source_packet_version_built_by_job_id FOREIGN KEY (built_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_version ADD CONSTRAINT fk_evidence_source_packet_version_reviewed_by_principal_id FOREIGN KEY (reviewed_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_fact ADD CONSTRAINT fk_evidence_source_packet_fact_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_fact ADD CONSTRAINT fk_evidence_source_packet_fact_fact_id FOREIGN KEY (fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_product ADD CONSTRAINT fk_evidence_source_packet_product_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_product ADD CONSTRAINT fk_evidence_source_packet_product_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE evidence.source_packet_product ADD CONSTRAINT fk_evidence_source_packet_product_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE evidence.claim ADD CONSTRAINT fk_evidence_claim_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE evidence.claim ADD CONSTRAINT fk_evidence_claim_block_id_article_version_id FOREIGN KEY (block_id, article_version_id) REFERENCES editorial.article_block (id, article_version_id) ON DELETE RESTRICT;
ALTER TABLE evidence.claim ADD CONSTRAINT fk_evidence_claim_generated_by_ai_attempt_id FOREIGN KEY (generated_by_ai_attempt_id) REFERENCES ai.ai_attempt (id) ON DELETE RESTRICT;
ALTER TABLE evidence.claim_evidence_link ADD CONSTRAINT fk_evidence_claim_evidence_link_claim_id FOREIGN KEY (claim_id) REFERENCES evidence.claim (id) ON DELETE RESTRICT;
ALTER TABLE evidence.claim_evidence_link ADD CONSTRAINT fk_evidence_claim_evidence_link_fact_id FOREIGN KEY (fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_intent_cluster_id FOREIGN KEY (intent_cluster_id) REFERENCES portfolio.intent_cluster (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_primary_keyword_id FOREIGN KEY (primary_keyword_id) REFERENCES portfolio.keyword (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_opportunity_assessment_id FOREIGN KEY (opportunity_assessment_id) REFERENCES portfolio.opportunity_assessment (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_created_by_principal_id FOREIGN KEY (created_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_plan ADD CONSTRAINT fk_editorial_article_plan_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article ADD CONSTRAINT fk_editorial_article_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article ADD CONSTRAINT fk_editorial_article_article_plan_id FOREIGN KEY (article_plan_id) REFERENCES editorial.article_plan (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article ADD CONSTRAINT fk_editorial_article_current_version_id FOREIGN KEY (current_version_id) REFERENCES editorial.article_version (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE editorial.article ADD CONSTRAINT fk_editorial_article_published_version_id FOREIGN KEY (published_version_id) REFERENCES editorial.article_version (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE editorial.article_slug ADD CONSTRAINT fk_editorial_article_slug_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_slug ADD CONSTRAINT fk_editorial_article_slug_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_version ADD CONSTRAINT fk_editorial_article_version_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE editorial.article_version ADD CONSTRAINT fk_editorial_article_version_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_version ADD CONSTRAINT fk_editorial_article_version_based_on_version_id FOREIGN KEY (based_on_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_version ADD CONSTRAINT fk_editorial_article_version_ai_job_id FOREIGN KEY (ai_job_id) REFERENCES ai.ai_job (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_block ADD CONSTRAINT fk_editorial_article_block_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_block_product ADD CONSTRAINT fk_editorial_article_block_product_article_block_id FOREIGN KEY (article_block_id) REFERENCES editorial.article_block (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_block_product ADD CONSTRAINT fk_editorial_article_block_product_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_block_product ADD CONSTRAINT fk_editorial_article_block_product_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE editorial.comparison_axis ADD CONSTRAINT fk_editorial_comparison_axis_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.comparison_value ADD CONSTRAINT fk_editorial_comparison_value_comparison_axis_id FOREIGN KEY (comparison_axis_id) REFERENCES editorial.comparison_axis (id) ON DELETE RESTRICT;
ALTER TABLE editorial.comparison_value ADD CONSTRAINT fk_editorial_comparison_value_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE editorial.comparison_value ADD CONSTRAINT fk_editorial_comparison_value_source_fact_id FOREIGN KEY (source_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation_set ADD CONSTRAINT fk_editorial_recommendation_set_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation ADD CONSTRAINT fk_editorial_recommendation_recommendation_set_id FOREIGN KEY (recommendation_set_id) REFERENCES editorial.recommendation_set (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation ADD CONSTRAINT fk_editorial_recommendation_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation_rationale ADD CONSTRAINT fk_editorial_recommendation_rationale_recommendation_id FOREIGN KEY (recommendation_id) REFERENCES editorial.recommendation (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation_rationale ADD CONSTRAINT fk_editorial_recommendation_rationale_claim_id FOREIGN KEY (claim_id) REFERENCES evidence.claim (id) ON DELETE RESTRICT;
ALTER TABLE editorial.recommendation_rationale ADD CONSTRAINT fk_editorial_recommendation_rationale_source_fact_id FOREIGN KEY (source_fact_id) REFERENCES evidence.fact (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_article_block_id FOREIGN KEY (article_block_id) REFERENCES editorial.article_block (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_claim_id FOREIGN KEY (claim_id) REFERENCES evidence.claim (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_parent_comment_id FOREIGN KEY (parent_comment_id) REFERENCES editorial.review_comment (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_author_principal_id FOREIGN KEY (author_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE editorial.review_comment ADD CONSTRAINT fk_editorial_review_comment_resolved_by_principal_id FOREIGN KEY (resolved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_link ADD CONSTRAINT fk_editorial_article_link_from_article_id FOREIGN KEY (from_article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE editorial.article_link ADD CONSTRAINT fk_editorial_article_link_to_article_id FOREIGN KEY (to_article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE ai.prompt_version ADD CONSTRAINT fk_ai_prompt_version_task_definition_id FOREIGN KEY (task_definition_id) REFERENCES ai.task_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.prompt_version ADD CONSTRAINT fk_ai_prompt_version_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ai.model_route_version ADD CONSTRAINT fk_ai_model_route_version_task_definition_id FOREIGN KEY (task_definition_id) REFERENCES ai.task_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.model_route_version ADD CONSTRAINT fk_ai_model_route_version_primary_model_id FOREIGN KEY (primary_model_id) REFERENCES ai.model_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.model_route_version ADD CONSTRAINT fk_ai_model_route_version_fallback_model_id FOREIGN KEY (fallback_model_id) REFERENCES ai.model_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.model_route_version ADD CONSTRAINT fk_ai_model_route_version_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_ops_job_id FOREIGN KEY (ops_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_task_definition_id FOREIGN KEY (task_definition_id) REFERENCES ai.task_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_article_plan_id FOREIGN KEY (article_plan_id) REFERENCES editorial.article_plan (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_prompt_version_id FOREIGN KEY (prompt_version_id) REFERENCES ai.prompt_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_output_schema_version_id FOREIGN KEY (output_schema_version_id) REFERENCES ai.output_schema_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_job ADD CONSTRAINT fk_ai_ai_job_model_route_version_id FOREIGN KEY (model_route_version_id) REFERENCES ai.model_route_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_attempt ADD CONSTRAINT fk_ai_ai_attempt_ai_job_id FOREIGN KEY (ai_job_id) REFERENCES ai.ai_job (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_attempt ADD CONSTRAINT fk_ai_ai_attempt_model_id FOREIGN KEY (model_id) REFERENCES ai.model_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_attempt ADD CONSTRAINT fk_ai_ai_attempt_input_artifact_id FOREIGN KEY (input_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ai.ai_attempt ADD CONSTRAINT fk_ai_ai_attempt_output_artifact_id FOREIGN KEY (output_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE ai.usage_cost ADD CONSTRAINT fk_ai_usage_cost_ai_attempt_id FOREIGN KEY (ai_attempt_id) REFERENCES ai.ai_attempt (id) ON DELETE RESTRICT;
ALTER TABLE ai.evaluation_result ADD CONSTRAINT fk_ai_evaluation_result_task_definition_id FOREIGN KEY (task_definition_id) REFERENCES ai.task_definition (id) ON DELETE RESTRICT;
ALTER TABLE ai.evaluation_result ADD CONSTRAINT fk_ai_evaluation_result_model_route_version_id FOREIGN KEY (model_route_version_id) REFERENCES ai.model_route_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.evaluation_result ADD CONSTRAINT fk_ai_evaluation_result_prompt_version_id FOREIGN KEY (prompt_version_id) REFERENCES ai.prompt_version (id) ON DELETE RESTRICT;
ALTER TABLE ai.evaluation_result ADD CONSTRAINT fk_ai_evaluation_result_result_artifact_id FOREIGN KEY (result_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE policy.policy_bundle ADD CONSTRAINT fk_policy_policy_bundle_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.rule_version ADD CONSTRAINT fk_policy_rule_version_created_by_principal_id FOREIGN KEY (created_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.rule_version ADD CONSTRAINT fk_policy_rule_version_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.bundle_rule ADD CONSTRAINT fk_policy_bundle_rule_policy_bundle_id FOREIGN KEY (policy_bundle_id) REFERENCES policy.policy_bundle (id) ON DELETE RESTRICT;
ALTER TABLE policy.bundle_rule ADD CONSTRAINT fk_policy_bundle_rule_rule_version_id FOREIGN KEY (rule_version_id) REFERENCES policy.rule_version (id) ON DELETE RESTRICT;
ALTER TABLE policy.quality_check_run ADD CONSTRAINT fk_policy_quality_check_run_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE policy.quality_check_run ADD CONSTRAINT fk_policy_quality_check_run_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE policy.quality_check_run ADD CONSTRAINT fk_policy_quality_check_run_policy_bundle_id FOREIGN KEY (policy_bundle_id) REFERENCES policy.policy_bundle (id) ON DELETE RESTRICT;
ALTER TABLE policy.quality_check_run ADD CONSTRAINT fk_policy_quality_check_run_report_artifact_id FOREIGN KEY (report_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE policy.finding ADD CONSTRAINT fk_policy_finding_quality_check_run_id FOREIGN KEY (quality_check_run_id) REFERENCES policy.quality_check_run (id) ON DELETE RESTRICT;
ALTER TABLE policy.finding ADD CONSTRAINT fk_policy_finding_rule_version_id FOREIGN KEY (rule_version_id) REFERENCES policy.rule_version (id) ON DELETE RESTRICT;
ALTER TABLE policy.finding ADD CONSTRAINT fk_policy_finding_article_block_id FOREIGN KEY (article_block_id) REFERENCES editorial.article_block (id) ON DELETE RESTRICT;
ALTER TABLE policy.finding ADD CONSTRAINT fk_policy_finding_claim_id FOREIGN KEY (claim_id) REFERENCES evidence.claim (id) ON DELETE RESTRICT;
ALTER TABLE policy.finding ADD CONSTRAINT fk_policy_finding_resolved_by_principal_id FOREIGN KEY (resolved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.quality_score ADD CONSTRAINT fk_policy_quality_score_quality_check_run_id FOREIGN KEY (quality_check_run_id) REFERENCES policy.quality_check_run (id) ON DELETE RESTRICT;
ALTER TABLE policy.waiver ADD CONSTRAINT fk_policy_waiver_finding_id FOREIGN KEY (finding_id) REFERENCES policy.finding (id) ON DELETE RESTRICT;
ALTER TABLE policy.waiver ADD CONSTRAINT fk_policy_waiver_requested_by_principal_id FOREIGN KEY (requested_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.waiver ADD CONSTRAINT fk_policy_waiver_decided_by_principal_id FOREIGN KEY (decided_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE policy.gate_decision ADD CONSTRAINT fk_policy_gate_decision_policy_bundle_id FOREIGN KEY (policy_bundle_id) REFERENCES policy.policy_bundle (id) ON DELETE RESTRICT;
ALTER TABLE policy.gate_decision ADD CONSTRAINT fk_policy_gate_decision_evidence_artifact_id FOREIGN KEY (evidence_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE policy.gate_decision ADD CONSTRAINT fk_policy_gate_decision_decided_by_principal_id FOREIGN KEY (decided_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_assignment ADD CONSTRAINT fk_publishing_review_assignment_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_assignment ADD CONSTRAINT fk_publishing_review_assignment_assigned_to_principal_id FOREIGN KEY (assigned_to_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_assignment ADD CONSTRAINT fk_publishing_review_assignment_assigned_by_principal_id FOREIGN KEY (assigned_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_decision ADD CONSTRAINT fk_publishing_review_decision_review_assignment_id FOREIGN KEY (review_assignment_id) REFERENCES publishing.review_assignment (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_decision ADD CONSTRAINT fk_publishing_review_decision_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_decision ADD CONSTRAINT fk_publishing_review_decision_decision_artifact_id FOREIGN KEY (decision_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_decision ADD CONSTRAINT fk_publishing_review_decision_decided_by_principal_id FOREIGN KEY (decided_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.review_decision ADD CONSTRAINT fk_publishing_review_decision_supersedes_decision_id FOREIGN KEY (supersedes_decision_id) REFERENCES publishing.review_decision (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_quality_check_run_id FOREIGN KEY (quality_check_run_id) REFERENCES policy.quality_check_run (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_policy_bundle_id FOREIGN KEY (policy_bundle_id) REFERENCES policy.policy_bundle (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_revoked_by_principal_id FOREIGN KEY (revoked_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.approval ADD CONSTRAINT fk_publishing_approval_supersedes_approval_id FOREIGN KEY (supersedes_approval_id) REFERENCES publishing.approval (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_final_approval_id FOREIGN KEY (final_approval_id) REFERENCES publishing.approval (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_quality_check_run_id FOREIGN KEY (quality_check_run_id) REFERENCES policy.quality_check_run (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_requested_by_principal_id FOREIGN KEY (requested_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_snapshot_build_job_id FOREIGN KEY (snapshot_build_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_candidate ADD CONSTRAINT fk_publishing_publication_candidate_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_publication_candidate_id FOREIGN KEY (publication_candidate_id) REFERENCES publishing.publication_candidate (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_artifact_id FOREIGN KEY (artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_source_packet_version_id FOREIGN KEY (source_packet_version_id) REFERENCES evidence.source_packet_version (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_policy_bundle_id FOREIGN KEY (policy_bundle_id) REFERENCES policy.policy_bundle (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_quality_check_run_id FOREIGN KEY (quality_check_run_id) REFERENCES policy.quality_check_run (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_final_approval_id FOREIGN KEY (final_approval_id) REFERENCES publishing.approval (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_snapshot ADD CONSTRAINT fk_publishing_publication_snapshot_built_by_job_id FOREIGN KEY (built_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication ADD CONSTRAINT fk_publishing_publication_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication ADD CONSTRAINT fk_publishing_publication_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication ADD CONSTRAINT fk_publishing_publication_current_snapshot_id FOREIGN KEY (current_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication ADD CONSTRAINT fk_publishing_publication_current_route_id FOREIGN KEY (current_route_id) REFERENCES publishing.public_route (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE publishing.publication_event ADD CONSTRAINT fk_publishing_publication_event_publication_id FOREIGN KEY (publication_id) REFERENCES publishing.publication (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_event ADD CONSTRAINT fk_publishing_publication_event_from_snapshot_id FOREIGN KEY (from_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_event ADD CONSTRAINT fk_publishing_publication_event_to_snapshot_id FOREIGN KEY (to_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_event ADD CONSTRAINT fk_publishing_publication_event_publication_candidate_id FOREIGN KEY (publication_candidate_id) REFERENCES publishing.publication_candidate (id) ON DELETE RESTRICT;
ALTER TABLE publishing.publication_event ADD CONSTRAINT fk_publishing_publication_event_release_id FOREIGN KEY (release_id) REFERENCES ops.release (id) ON DELETE RESTRICT;
ALTER TABLE publishing.public_route ADD CONSTRAINT fk_publishing_public_route_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE publishing.public_route ADD CONSTRAINT fk_publishing_public_route_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE publishing.public_route ADD CONSTRAINT fk_publishing_public_route_publication_id FOREIGN KEY (publication_id) REFERENCES publishing.publication (id) ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE publishing.public_route ADD CONSTRAINT fk_publishing_public_route_redirect_target_route_id FOREIGN KEY (redirect_target_route_id) REFERENCES publishing.public_route (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_publication_id FOREIGN KEY (publication_id) REFERENCES publishing.publication (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_from_snapshot_id FOREIGN KEY (from_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_to_snapshot_id FOREIGN KEY (to_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_incident_id FOREIGN KEY (incident_id) REFERENCES ops.incident (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_requested_by_principal_id FOREIGN KEY (requested_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE publishing.rollback_record ADD CONSTRAINT fk_publishing_rollback_record_executed_by_principal_id FOREIGN KEY (executed_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE freshness.freshness_policy ADD CONSTRAINT fk_freshness_freshness_policy_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE freshness.freshness_policy ADD CONSTRAINT fk_freshness_freshness_policy_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE freshness.freshness_policy ADD CONSTRAINT fk_freshness_freshness_policy_created_by_principal_id FOREIGN KEY (created_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE freshness.refresh_schedule ADD CONSTRAINT fk_freshness_refresh_schedule_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE freshness.refresh_schedule ADD CONSTRAINT fk_freshness_refresh_schedule_freshness_policy_id FOREIGN KEY (freshness_policy_id) REFERENCES freshness.freshness_policy (id) ON DELETE RESTRICT;
ALTER TABLE freshness.refresh_run ADD CONSTRAINT fk_freshness_refresh_run_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE freshness.refresh_run ADD CONSTRAINT fk_freshness_refresh_run_ops_job_id FOREIGN KEY (ops_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE freshness.refresh_run ADD CONSTRAINT fk_freshness_refresh_run_report_artifact_id FOREIGN KEY (report_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE freshness.staleness_assessment ADD CONSTRAINT fk_freshness_staleness_assessment_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE freshness.staleness_assessment ADD CONSTRAINT fk_freshness_staleness_assessment_freshness_policy_id FOREIGN KEY (freshness_policy_id) REFERENCES freshness.freshness_policy (id) ON DELETE RESTRICT;
ALTER TABLE freshness.staleness_assessment ADD CONSTRAINT fk_freshness_staleness_assessment_refresh_run_id FOREIGN KEY (refresh_run_id) REFERENCES freshness.refresh_run (id) ON DELETE RESTRICT;
ALTER TABLE freshness.link_check ADD CONSTRAINT fk_freshness_link_check_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE freshness.link_check ADD CONSTRAINT fk_freshness_link_check_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE freshness.link_check ADD CONSTRAINT fk_freshness_link_check_affiliate_link_observation_id FOREIGN KEY (affiliate_link_observation_id) REFERENCES catalog.affiliate_link_observation (id) ON DELETE RESTRICT;
ALTER TABLE freshness.link_check ADD CONSTRAINT fk_freshness_link_check_refresh_run_id FOREIGN KEY (refresh_run_id) REFERENCES freshness.refresh_run (id) ON DELETE RESTRICT;
ALTER TABLE freshness.link_check ADD CONSTRAINT fk_freshness_link_check_response_artifact_id FOREIGN KEY (response_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE freshness.impact_assessment ADD CONSTRAINT fk_freshness_impact_assessment_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE freshness.impact_assessment ADD CONSTRAINT fk_freshness_impact_assessment_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE freshness.impact_assessment ADD CONSTRAINT fk_freshness_impact_assessment_claim_id FOREIGN KEY (claim_id) REFERENCES evidence.claim (id) ON DELETE RESTRICT;
ALTER TABLE freshness.impact_assessment ADD CONSTRAINT fk_freshness_impact_assessment_publication_id FOREIGN KEY (publication_id) REFERENCES publishing.publication (id) ON DELETE RESTRICT;
ALTER TABLE freshness.impact_assessment ADD CONSTRAINT fk_freshness_impact_assessment_resolved_by_job_id FOREIGN KEY (resolved_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE analytics.anonymous_event ADD CONSTRAINT fk_analytics_anonymous_event_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_anonymous_event_id FOREIGN KEY (anonymous_event_id) REFERENCES analytics.anonymous_event (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE analytics.affiliate_click_event ADD CONSTRAINT fk_analytics_affiliate_click_event_affiliate_link_ob_c93c61f52c FOREIGN KEY (affiliate_link_observation_id) REFERENCES catalog.affiliate_link_observation (id) ON DELETE RESTRICT;
ALTER TABLE analytics.import_run ADD CONSTRAINT fk_analytics_import_run_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.import_run ADD CONSTRAINT fk_analytics_import_run_ops_job_id FOREIGN KEY (ops_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE analytics.import_run ADD CONSTRAINT fk_analytics_import_run_source_artifact_id FOREIGN KEY (source_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE analytics.gsc_observation ADD CONSTRAINT fk_analytics_gsc_observation_import_run_id FOREIGN KEY (import_run_id) REFERENCES analytics.import_run (id) ON DELETE RESTRICT;
ALTER TABLE analytics.gsc_observation ADD CONSTRAINT fk_analytics_gsc_observation_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.ga4_observation ADD CONSTRAINT fk_analytics_ga4_observation_import_run_id FOREIGN KEY (import_run_id) REFERENCES analytics.import_run (id) ON DELETE RESTRICT;
ALTER TABLE analytics.ga4_observation ADD CONSTRAINT fk_analytics_ga4_observation_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_commission_id FOREIGN KEY (commission_id) REFERENCES finance.commission (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE analytics.attribution_estimate ADD CONSTRAINT fk_analytics_attribution_estimate_calculated_by_job_id FOREIGN KEY (calculated_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE analytics.data_quality_finding ADD CONSTRAINT fk_analytics_data_quality_finding_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.data_quality_finding ADD CONSTRAINT fk_analytics_data_quality_finding_import_run_id FOREIGN KEY (import_run_id) REFERENCES analytics.import_run (id) ON DELETE RESTRICT;
ALTER TABLE analytics.data_quality_finding ADD CONSTRAINT fk_analytics_data_quality_finding_resolved_by_principal_id FOREIGN KEY (resolved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE analytics.daily_article_metric ADD CONSTRAINT fk_analytics_daily_article_metric_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE analytics.daily_article_metric ADD CONSTRAINT fk_analytics_daily_article_metric_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE analytics.daily_article_metric ADD CONSTRAINT fk_analytics_daily_article_metric_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE finance.parser_version ADD CONSTRAINT fk_finance_parser_version_schema_artifact_id FOREIGN KEY (schema_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.parser_version ADD CONSTRAINT fk_finance_parser_version_fixture_artifact_id FOREIGN KEY (fixture_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_source_artifact_id FOREIGN KEY (source_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_parser_version_id FOREIGN KEY (parser_version_id) REFERENCES finance.parser_version (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_ops_job_id FOREIGN KEY (ops_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_confirmed_by_principal_id FOREIGN KEY (confirmed_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import ADD CONSTRAINT fk_finance_revenue_import_report_artifact_id FOREIGN KEY (report_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.revenue_import_row ADD CONSTRAINT fk_finance_revenue_import_row_revenue_import_id FOREIGN KEY (revenue_import_id) REFERENCES finance.revenue_import (id) ON DELETE CASCADE;
ALTER TABLE finance.commission ADD CONSTRAINT fk_finance_commission_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.commission ADD CONSTRAINT fk_finance_commission_source_import_row_id FOREIGN KEY (source_import_row_id) REFERENCES finance.revenue_import_row (id) ON DELETE RESTRICT;
ALTER TABLE finance.commission_event ADD CONSTRAINT fk_finance_commission_event_commission_id FOREIGN KEY (commission_id) REFERENCES finance.commission (id) ON DELETE RESTRICT;
ALTER TABLE finance.commission_event ADD CONSTRAINT fk_finance_commission_event_source_import_row_id FOREIGN KEY (source_import_row_id) REFERENCES finance.revenue_import_row (id) ON DELETE RESTRICT;
ALTER TABLE finance.external_cost ADD CONSTRAINT fk_finance_external_cost_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.external_cost ADD CONSTRAINT fk_finance_external_cost_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE finance.external_cost ADD CONSTRAINT fk_finance_external_cost_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE finance.external_cost ADD CONSTRAINT fk_finance_external_cost_ai_job_id FOREIGN KEY (ai_job_id) REFERENCES ai.ai_job (id) ON DELETE RESTRICT;
ALTER TABLE finance.external_cost ADD CONSTRAINT fk_finance_external_cost_source_artifact_id FOREIGN KEY (source_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_principal_id FOREIGN KEY (principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_category_id FOREIGN KEY (category_id) REFERENCES portfolio.category (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_article_version_id FOREIGN KEY (article_version_id) REFERENCES editorial.article_version (id) ON DELETE RESTRICT;
ALTER TABLE finance.human_work_log ADD CONSTRAINT fk_finance_human_work_log_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE finance.allocation_rule ADD CONSTRAINT fk_finance_allocation_rule_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.allocation_rule ADD CONSTRAINT fk_finance_allocation_rule_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE finance.cost_allocation ADD CONSTRAINT fk_finance_cost_allocation_allocation_rule_id FOREIGN KEY (allocation_rule_id) REFERENCES finance.allocation_rule (id) ON DELETE RESTRICT;
ALTER TABLE finance.cost_allocation ADD CONSTRAINT fk_finance_cost_allocation_calculated_by_job_id FOREIGN KEY (calculated_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE finance.unit_economics_snapshot ADD CONSTRAINT fk_finance_unit_economics_snapshot_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE finance.unit_economics_snapshot ADD CONSTRAINT fk_finance_unit_economics_snapshot_report_artifact_id FOREIGN KEY (report_artifact_id) REFERENCES ops.object_artifact (id) ON DELETE RESTRICT;
ALTER TABLE finance.unit_economics_snapshot ADD CONSTRAINT fk_finance_unit_economics_snapshot_calculated_by_job_id FOREIGN KEY (calculated_by_job_id) REFERENCES ops.job (id) ON DELETE RESTRICT;
ALTER TABLE finance.unit_economics_snapshot ADD CONSTRAINT fk_finance_unit_economics_snapshot_approved_by_principal_id FOREIGN KEY (approved_by_principal_id) REFERENCES iam.principal (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_article ADD CONSTRAINT fk_readmodel_public_article_article_id FOREIGN KEY (article_id) REFERENCES editorial.article (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_article ADD CONSTRAINT fk_readmodel_public_article_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_article ADD CONSTRAINT fk_readmodel_public_article_publication_id FOREIGN KEY (publication_id) REFERENCES publishing.publication (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_article ADD CONSTRAINT fk_readmodel_public_article_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_article_block ADD CONSTRAINT fk_readmodel_public_article_block_article_id FOREIGN KEY (article_id) REFERENCES readmodel.public_article (article_id) ON DELETE CASCADE;
ALTER TABLE readmodel.public_article_block ADD CONSTRAINT fk_readmodel_public_article_block_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_product_card ADD CONSTRAINT fk_readmodel_public_product_card_article_id FOREIGN KEY (article_id) REFERENCES readmodel.public_article (article_id) ON DELETE CASCADE;
ALTER TABLE readmodel.public_product_card ADD CONSTRAINT fk_readmodel_public_product_card_publication_snapshot_id FOREIGN KEY (publication_snapshot_id) REFERENCES publishing.publication_snapshot (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_product_card ADD CONSTRAINT fk_readmodel_public_product_card_product_id FOREIGN KEY (product_id) REFERENCES catalog.canonical_product (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_offer ADD CONSTRAINT fk_readmodel_public_offer_public_product_card_id FOREIGN KEY (public_product_card_id) REFERENCES readmodel.public_product_card (id) ON DELETE CASCADE;
ALTER TABLE readmodel.public_offer ADD CONSTRAINT fk_readmodel_public_offer_offer_id FOREIGN KEY (offer_id) REFERENCES catalog.offer (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_offer ADD CONSTRAINT fk_readmodel_public_offer_shop_id FOREIGN KEY (shop_id) REFERENCES catalog.shop (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_route ADD CONSTRAINT fk_readmodel_public_route_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;
ALTER TABLE readmodel.public_route ADD CONSTRAINT fk_readmodel_public_route_article_id FOREIGN KEY (article_id) REFERENCES readmodel.public_article (article_id) ON DELETE CASCADE;
ALTER TABLE readmodel.runtime_control ADD CONSTRAINT fk_readmodel_runtime_control_site_id FOREIGN KEY (site_id) REFERENCES portfolio.site (id) ON DELETE RESTRICT;

-- Explicit supporting and query indexes. PostgreSQL does not automatically index referencing FK columns.
CREATE UNIQUE INDEX uq_ops_object_artifact_location ON ops.object_artifact USING btree (bucket_name, object_key, object_version) NULLS NOT DISTINCT;
CREATE INDEX ix_ops_object_artifact_sha ON ops.object_artifact USING btree (sha256);
CREATE INDEX ix_ops_object_artifact_kind_created ON ops.object_artifact USING btree (artifact_kind, created_at);
CREATE UNIQUE INDEX uq_ops_job_idempotency ON ops.job USING btree (job_type, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX ix_ops_job_ready ON ops.job USING btree (queue_name, priority, available_at) WHERE status IN ('PENDING','READY');
CREATE INDEX ix_ops_job_lease ON ops.job USING btree (lease_expires_at) WHERE status = 'RUNNING';
CREATE INDEX ix_ops_job_aggregate ON ops.job USING btree (aggregate_type, aggregate_id);
CREATE INDEX ix_ops_job_correlation ON ops.job USING btree (correlation_id);
CREATE INDEX ix_ops_job_payload_artifact_id ON ops.job USING btree (payload_artifact_id);
CREATE INDEX ix_ops_job_parent_job_id ON ops.job USING btree (parent_job_id);
CREATE INDEX ix_ops_job_site_id ON ops.job USING btree (site_id);
CREATE INDEX ix_ops_job_attempt_started ON ops.job_attempt USING btree (started_at);
CREATE INDEX ix_ops_job_attempt_status ON ops.job_attempt USING btree (status, started_at);
CREATE INDEX ix_ops_job_attempt_input_artifact_id ON ops.job_attempt USING btree (input_artifact_id);
CREATE INDEX ix_ops_job_attempt_output_artifact_id ON ops.job_attempt USING btree (output_artifact_id);
CREATE INDEX ix_ops_outbox_ready ON ops.outbox_event USING btree (status, available_at) WHERE status IN ('PENDING','FAILED');
CREATE INDEX ix_ops_outbox_aggregate ON ops.outbox_event USING btree (aggregate_type, aggregate_id, aggregate_version);
CREATE INDEX ix_ops_outbox_correlation ON ops.outbox_event USING btree (correlation_id);
CREATE INDEX ix_ops_outbox_created_brin ON ops.outbox_event USING brin (created_at);
CREATE INDEX ix_ops_inbox_event ON ops.inbox_receipt USING btree (event_id);
CREATE INDEX ix_ops_inbox_received ON ops.inbox_receipt USING btree (received_at);
CREATE INDEX ix_ops_idempotency_expiry ON ops.idempotency_record USING btree (expires_at);
CREATE INDEX ix_ops_idempotency_record_response_artifact_id ON ops.idempotency_record USING btree (response_artifact_id);
CREATE INDEX ix_ops_audit_occurred ON ops.audit_event USING btree (occurred_at);
CREATE INDEX ix_ops_audit_actor ON ops.audit_event USING btree (actor_type, actor_id, occurred_at);
CREATE INDEX ix_ops_audit_target ON ops.audit_event USING btree (target_type, target_id, occurred_at);
CREATE INDEX ix_ops_audit_corr ON ops.audit_event USING btree (correlation_id);
CREATE INDEX ix_ops_audit_occurred_brin ON ops.audit_event USING brin (occurred_at);
CREATE INDEX ix_ops_audit_export_artifact_id ON ops.audit_export USING btree (artifact_id);
CREATE UNIQUE INDEX uq_ops_alert_open_key ON ops.alert USING btree (alert_key) WHERE status IN ('OPEN','ACKNOWLEDGED');
CREATE INDEX ix_ops_alert_status ON ops.alert USING btree (status, severity, last_seen_at);
CREATE INDEX ix_ops_alert_incident_id ON ops.alert USING btree (incident_id);
CREATE INDEX ix_ops_alert_acknowledged_by_principal_id ON ops.alert USING btree (acknowledged_by_principal_id);
CREATE INDEX ix_ops_incident_status ON ops.incident USING btree (status, severity, declared_at);
CREATE INDEX ix_ops_incident_declared_by_principal_id ON ops.incident USING btree (declared_by_principal_id);
CREATE INDEX ix_ops_incident_commander_principal_id ON ops.incident USING btree (commander_principal_id);
CREATE INDEX ix_ops_incident_event_timeline ON ops.incident_event USING btree (incident_id, occurred_at);
CREATE INDEX ix_ops_incident_event_actor_principal_id ON ops.incident_event USING btree (actor_principal_id);
CREATE UNIQUE INDEX uq_ops_kill_scope ON ops.kill_switch USING btree (scope_type, scope_id, switch_type) NULLS NOT DISTINCT;
CREATE INDEX ix_ops_kill_engaged ON ops.kill_switch USING btree (switch_type, is_engaged) WHERE is_engaged = true;
CREATE INDEX ix_ops_kill_switch_incident_id ON ops.kill_switch USING btree (incident_id);
CREATE INDEX ix_ops_kill_switch_changed_by_principal_id ON ops.kill_switch USING btree (changed_by_principal_id);
CREATE INDEX ix_ops_kill_change_timeline ON ops.kill_switch_change USING btree (kill_switch_id, occurred_at);
CREATE INDEX ix_ops_kill_switch_change_incident_id ON ops.kill_switch_change USING btree (incident_id);
CREATE INDEX ix_ops_kill_switch_change_actor_principal_id ON ops.kill_switch_change USING btree (actor_principal_id);
CREATE UNIQUE INDEX uq_ops_setting_active ON ops.runtime_setting_version USING btree (setting_key, scope_type, scope_id) NULLS NOT DISTINCT WHERE status = 'ACTIVE';
CREATE INDEX ix_ops_setting_lookup ON ops.runtime_setting_version USING btree (setting_key, status, effective_from);
CREATE INDEX ix_ops_runtime_setting_version_created_by_principal_id ON ops.runtime_setting_version USING btree (created_by_principal_id);
CREATE INDEX ix_ops_runtime_setting_version_approved_by_principal_id ON ops.runtime_setting_version USING btree (approved_by_principal_id);
CREATE UNIQUE INDEX uq_ops_retention_active ON ops.retention_policy USING btree (retention_class) WHERE status = 'ACTIVE';
CREATE INDEX ix_ops_retention_policy_approved_by_principal_id ON ops.retention_policy USING btree (approved_by_principal_id);
CREATE INDEX ix_ops_release_env_deployed ON ops.release USING btree (environment, deployed_at);
CREATE INDEX ix_ops_release_deployed_by_principal_id ON ops.release USING btree (deployed_by_principal_id);
CREATE INDEX ix_ops_release_rollback_of_release_id ON ops.release USING btree (rollback_of_release_id);
CREATE INDEX ix_ops_release_manifest_artifact_id ON ops.release USING btree (manifest_artifact_id);
CREATE INDEX ix_iam_principal_status ON iam.principal USING btree (status, principal_type);
CREATE INDEX ix_iam_user_email_lower ON iam.user_account USING btree (lower(email)) WHERE email IS NOT NULL;
CREATE INDEX ix_iam_role_permission_permission_id ON iam.role_permission USING btree (permission_id);
CREATE UNIQUE INDEX uq_iam_assignment_active ON iam.principal_role_assignment USING btree (principal_id, role_id, scope_type, scope_id) NULLS NOT DISTINCT WHERE revoked_at IS NULL;
CREATE INDEX ix_iam_assignment_lookup ON iam.principal_role_assignment USING btree (principal_id, scope_type, scope_id, valid_from);
CREATE INDEX ix_iam_principal_role_assignment_role_id ON iam.principal_role_assignment USING btree (role_id);
CREATE INDEX ix_iam_principal_role_assignment_assigned_by_principal_id ON iam.principal_role_assignment USING btree (assigned_by_principal_id);
CREATE INDEX ix_iam_principal_role_assignment_revoked_by_principal_id ON iam.principal_role_assignment USING btree (revoked_by_principal_id);
CREATE INDEX ix_iam_session_revocation_lookup ON iam.session_revocation USING btree (oidc_issuer, oidc_subject, revoke_before);
CREATE INDEX ix_iam_session_revocation_principal_id ON iam.session_revocation USING btree (principal_id);
CREATE INDEX ix_iam_session_revocation_created_by_principal_id ON iam.session_revocation USING btree (created_by_principal_id);
CREATE INDEX ix_iam_break_glass_active ON iam.break_glass_record USING btree (expires_at) WHERE ended_at IS NULL;
CREATE INDEX ix_iam_break_glass_record_principal_id ON iam.break_glass_record USING btree (principal_id);
CREATE INDEX ix_iam_break_glass_record_incident_id ON iam.break_glass_record USING btree (incident_id);
CREATE INDEX ix_iam_break_glass_record_approved_by_principal_id ON iam.break_glass_record USING btree (approved_by_principal_id);
CREATE INDEX ix_portfolio_category_tree ON portfolio.category USING btree (site_id, parent_category_id);
CREATE INDEX ix_portfolio_category_stage ON portfolio.category USING btree (site_id, stage);
CREATE INDEX ix_portfolio_category_parent_category_id ON portfolio.category USING btree (parent_category_id);
CREATE INDEX ix_portfolio_category_approved_by_principal_id ON portfolio.category USING btree (approved_by_principal_id);
CREATE INDEX ix_portfolio_intent_category ON portfolio.intent_cluster USING btree (category_id, status);
CREATE INDEX ix_portfolio_keyword_text ON portfolio.keyword USING btree (lower(display_text));
CREATE INDEX ix_portfolio_cluster_keyword_role ON portfolio.intent_cluster_keyword USING btree (intent_cluster_id, keyword_role, priority);
CREATE INDEX ix_portfolio_intent_cluster_keyword_keyword_id ON portfolio.intent_cluster_keyword USING btree (keyword_id);
CREATE UNIQUE INDEX uq_portfolio_kw_metric_observation ON portfolio.keyword_metric_observation USING btree (keyword_id, provider_code, metric_type, country_code, device, observed_date);
CREATE INDEX ix_portfolio_kw_metric_latest ON portfolio.keyword_metric_observation USING btree (keyword_id, metric_type, observed_date);
CREATE INDEX ix_portfolio_keyword_metric_observation_raw_artifact_id ON portfolio.keyword_metric_observation USING btree (raw_artifact_id);
CREATE INDEX ix_portfolio_opp_scope ON portfolio.opportunity_assessment USING btree (category_id, intent_cluster_id, keyword_id, assessed_at);
CREATE INDEX ix_portfolio_opp_priority ON portfolio.opportunity_assessment USING btree (decision, overall_priority_score);
CREATE INDEX ix_portfolio_opportunity_assessment_intent_cluster_id ON portfolio.opportunity_assessment USING btree (intent_cluster_id);
CREATE INDEX ix_portfolio_opportunity_assessment_keyword_id ON portfolio.opportunity_assessment USING btree (keyword_id);
CREATE INDEX ix_portfolio_action_queue ON portfolio.action_candidate USING btree (site_id, status, priority_score, generated_at);
CREATE INDEX ix_portfolio_action_target ON portfolio.action_candidate USING btree (target_entity_type, target_entity_id);
CREATE INDEX ix_portfolio_action_candidate_category_id ON portfolio.action_candidate USING btree (category_id);
CREATE INDEX ix_portfolio_action_candidate_decided_by_principal_id ON portfolio.action_candidate USING btree (decided_by_principal_id);
CREATE UNIQUE INDEX uq_catalog_provider_active ON catalog.provider_endpoint USING btree (provider_code, api_name) WHERE status = 'ACTIVE';
CREATE INDEX ix_catalog_ingestion_provider_time ON catalog.ingestion_request USING btree (provider_endpoint_id, requested_at);
CREATE INDEX ix_catalog_ingestion_status ON catalog.ingestion_request USING btree (status, requested_at);
CREATE INDEX ix_catalog_ingestion_request_raw_response_artifact_id ON catalog.ingestion_request USING btree (raw_response_artifact_id);
CREATE INDEX ix_catalog_rakuten_genre_parent ON catalog.rakuten_genre USING btree (provider_endpoint_id, parent_external_genre_id);
CREATE INDEX ix_catalog_rakuten_genre_source_snapshot_id ON catalog.rakuten_genre USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_shop_status ON catalog.shop USING btree (provider_endpoint_id, status);
CREATE INDEX ix_catalog_shop_source_snapshot_id ON catalog.shop USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_product_category ON catalog.canonical_product USING btree (category_id, lifecycle_status);
CREATE INDEX ix_catalog_product_model ON catalog.canonical_product USING btree (category_id, model_number) WHERE model_number IS NOT NULL;
CREATE INDEX ix_catalog_product_jan ON catalog.canonical_product USING btree (jan_code) WHERE jan_code IS NOT NULL;
CREATE INDEX ix_catalog_canonical_product_merged_into_product_id ON catalog.canonical_product USING btree (merged_into_product_id);
CREATE INDEX ix_catalog_candidate_shop ON catalog.product_candidate USING btree (shop_id, listing_status);
CREATE INDEX ix_catalog_candidate_genre ON catalog.product_candidate USING btree (rakuten_genre_id, listing_status);
CREATE INDEX ix_catalog_candidate_model ON catalog.product_candidate USING btree (model_number_candidate) WHERE model_number_candidate IS NOT NULL;
CREATE INDEX ix_catalog_candidate_jan ON catalog.product_candidate USING btree (jan_code_candidate) WHERE jan_code_candidate IS NOT NULL;
CREATE INDEX ix_catalog_product_candidate_source_snapshot_id ON catalog.product_candidate USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_group_candidate ON catalog.grouping_decision USING btree (product_candidate_id, decided_at);
CREATE INDEX ix_catalog_group_product ON catalog.grouping_decision USING btree (proposed_product_id, decided_at);
CREATE INDEX ix_catalog_grouping_decision_supersedes_decision_id ON catalog.grouping_decision USING btree (supersedes_decision_id);
CREATE UNIQUE INDEX uq_catalog_membership_current ON catalog.product_group_membership USING btree (product_candidate_id) WHERE valid_to IS NULL;
CREATE INDEX ix_catalog_membership_product ON catalog.product_group_membership USING btree (product_id, valid_from);
CREATE INDEX ix_catalog_product_group_membership_grouping_decision_id ON catalog.product_group_membership USING btree (grouping_decision_id);
CREATE UNIQUE INDEX uq_catalog_attribute_code ON catalog.attribute_definition USING btree (category_id, attribute_code) NULLS NOT DISTINCT;
CREATE UNIQUE INDEX uq_catalog_product_attr_current ON catalog.product_attribute_value USING btree (product_id, attribute_definition_id) WHERE valid_to IS NULL;
CREATE INDEX ix_catalog_product_attr_numeric ON catalog.product_attribute_value USING btree (attribute_definition_id, value_numeric) WHERE value_numeric IS NOT NULL;
CREATE INDEX ix_catalog_product_attr_code ON catalog.product_attribute_value USING btree (attribute_definition_id, value_code) WHERE value_code IS NOT NULL;
CREATE INDEX ix_catalog_product_attribute_value_source_fact_id ON catalog.product_attribute_value USING btree (source_fact_id);
CREATE UNIQUE INDEX uq_catalog_product_relation_current ON catalog.product_relation USING btree (from_product_id, to_product_id, relation_type) WHERE valid_to IS NULL;
CREATE INDEX ix_catalog_product_relation_reverse ON catalog.product_relation USING btree (to_product_id, relation_type);
CREATE INDEX ix_catalog_product_relation_source_fact_id ON catalog.product_relation USING btree (source_fact_id);
CREATE INDEX ix_catalog_offer_product ON catalog.offer USING btree (product_id, status);
CREATE INDEX ix_catalog_offer_shop ON catalog.offer USING btree (shop_id, status);
CREATE INDEX ix_catalog_offer_candidate ON catalog.offer USING btree (product_candidate_id);
CREATE INDEX ix_catalog_price_offer_time ON catalog.price_observation USING btree (offer_id, observed_at);
CREATE INDEX ix_catalog_price_observed_brin ON catalog.price_observation USING brin (observed_at);
CREATE INDEX ix_catalog_price_observation_source_snapshot_id ON catalog.price_observation USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_avail_offer_time ON catalog.availability_observation USING btree (offer_id, observed_at);
CREATE INDEX ix_catalog_avail_observed_brin ON catalog.availability_observation USING brin (observed_at);
CREATE INDEX ix_catalog_availability_observation_source_snapshot_id ON catalog.availability_observation USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_review_offer_time ON catalog.review_aggregate_observation USING btree (offer_id, observed_at);
CREATE INDEX ix_catalog_review_aggregate_observation_source_snapshot_id ON catalog.review_aggregate_observation USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_affiliate_offer_time ON catalog.affiliate_link_observation USING btree (offer_id, observed_at);
CREATE INDEX ix_catalog_affiliate_hash ON catalog.affiliate_link_observation USING btree (url_sha256);
CREATE INDEX ix_catalog_affiliate_link_observation_source_snapshot_id ON catalog.affiliate_link_observation USING btree (source_snapshot_id);
CREATE INDEX ix_catalog_offer_current_product ON catalog.offer_current_projection USING btree (product_id, freshness_status);
CREATE INDEX ix_catalog_offer_current_available ON catalog.offer_current_projection USING btree (current_availability, freshness_status);
CREATE INDEX ix_catalog_offer_current_projection_price_observation_id ON catalog.offer_current_projection USING btree (price_observation_id);
CREATE INDEX ix_catalog_offer_current_projection_availability_observation_id ON catalog.offer_current_projection USING btree (availability_observation_id);
CREATE INDEX ix_catalog_offer_current_projection_review_observation_id ON catalog.offer_current_projection USING btree (review_observation_id);
CREATE INDEX ix_catalog_offer_current_projection_affiliate_link_o_2ca582c972 ON catalog.offer_current_projection USING btree (affiliate_link_observation_id);
CREATE UNIQUE INDEX uq_catalog_category_genre_current ON catalog.category_genre_mapping USING btree (category_id, rakuten_genre_id, mapping_role) WHERE valid_to IS NULL;
CREATE INDEX ix_catalog_genre_categories ON catalog.category_genre_mapping USING btree (rakuten_genre_id, mapping_role);
CREATE INDEX ix_catalog_category_genre_mapping_decided_by_principal_id ON catalog.category_genre_mapping USING btree (decided_by_principal_id);
CREATE INDEX ix_evidence_source_type_status ON evidence.source USING btree (source_type, status);
CREATE INDEX ix_evidence_source_provider_endpoint_id ON evidence.source USING btree (provider_endpoint_id);
CREATE INDEX ix_evidence_source_terms_checked_by_principal_id ON evidence.source USING btree (terms_checked_by_principal_id);
CREATE INDEX ix_evidence_snapshot_source_time ON evidence.source_snapshot USING btree (source_id, acquired_at);
CREATE INDEX ix_evidence_snapshot_external ON evidence.source_snapshot USING btree (source_id, external_reference) WHERE external_reference IS NOT NULL;
CREATE INDEX ix_evidence_fact_subject ON evidence.fact USING btree (subject_type, subject_id, predicate, created_at);
CREATE INDEX ix_evidence_fact_snapshot ON evidence.fact USING btree (source_snapshot_id);
CREATE INDEX ix_evidence_fact_predicate_numeric ON evidence.fact USING btree (predicate, value_numeric) WHERE value_numeric IS NOT NULL;
CREATE INDEX ix_evidence_derivation_input ON evidence.fact_derivation USING btree (input_fact_id);
CREATE INDEX ix_evidence_packet_status ON evidence.source_packet USING btree (status, updated_at);
CREATE INDEX ix_evidence_packet_version_status ON evidence.source_packet_version USING btree (source_packet_id, status, version_no);
CREATE INDEX ix_evidence_source_packet_version_built_by_job_id ON evidence.source_packet_version USING btree (built_by_job_id);
CREATE INDEX ix_evidence_source_packet_version_reviewed_by_principal_id ON evidence.source_packet_version USING btree (reviewed_by_principal_id);
CREATE INDEX ix_evidence_packet_fact_order ON evidence.source_packet_fact USING btree (source_packet_version_id, display_order);
CREATE INDEX ix_evidence_packet_fact_reverse ON evidence.source_packet_fact USING btree (fact_id);
CREATE INDEX ix_evidence_packet_product_order ON evidence.source_packet_product USING btree (source_packet_version_id, display_order);
CREATE INDEX ix_evidence_packet_product_reverse ON evidence.source_packet_product USING btree (product_id);
CREATE INDEX ix_evidence_source_packet_product_offer_id ON evidence.source_packet_product USING btree (offer_id);
CREATE INDEX ix_evidence_claim_version_status ON evidence.claim USING btree (article_version_id, support_status, criticality);
CREATE INDEX ix_evidence_claim_block ON evidence.claim USING btree (block_id);
CREATE INDEX ix_evidence_claim_block_id_article_version_id ON evidence.claim USING btree (block_id, article_version_id);
CREATE INDEX ix_evidence_claim_generated_by_ai_attempt_id ON evidence.claim USING btree (generated_by_ai_attempt_id);
CREATE INDEX ix_evidence_claim_link_fact ON evidence.claim_evidence_link USING btree (fact_id, support_type);
CREATE INDEX ix_editorial_plan_queue ON editorial.article_plan USING btree (site_id, status, priority, updated_at);
CREATE INDEX ix_editorial_plan_keyword ON editorial.article_plan USING btree (primary_keyword_id, status);
CREATE INDEX ix_editorial_plan_cluster ON editorial.article_plan USING btree (intent_cluster_id, status);
CREATE INDEX ix_editorial_article_plan_category_id ON editorial.article_plan USING btree (category_id);
CREATE INDEX ix_editorial_article_plan_opportunity_assessment_id ON editorial.article_plan USING btree (opportunity_assessment_id);
CREATE INDEX ix_editorial_article_plan_created_by_principal_id ON editorial.article_plan USING btree (created_by_principal_id);
CREATE INDEX ix_editorial_article_plan_approved_by_principal_id ON editorial.article_plan USING btree (approved_by_principal_id);
CREATE INDEX ix_editorial_article_status ON editorial.article USING btree (site_id, status, updated_at);
CREATE INDEX ix_editorial_article_current ON editorial.article USING btree (current_version_id);
CREATE INDEX ix_editorial_article_published ON editorial.article USING btree (published_version_id);
CREATE UNIQUE INDEX uq_editorial_slug_active_path ON editorial.article_slug USING btree (site_id, normalized_path) WHERE valid_to IS NULL;
CREATE UNIQUE INDEX uq_editorial_slug_active_article ON editorial.article_slug USING btree (article_id) WHERE valid_to IS NULL AND status = 'ACTIVE';
CREATE INDEX ix_editorial_slug_article_history ON editorial.article_slug USING btree (article_id, valid_from);
CREATE INDEX ix_editorial_article_version_status ON editorial.article_version USING btree (article_id, status, version_no);
CREATE INDEX ix_editorial_article_version_packet ON editorial.article_version USING btree (source_packet_version_id);
CREATE INDEX ix_editorial_article_version_based_on_version_id ON editorial.article_version USING btree (based_on_version_id);
CREATE INDEX ix_editorial_article_version_ai_job_id ON editorial.article_version USING btree (ai_job_id);
CREATE INDEX ix_editorial_block_order ON editorial.article_block USING btree (article_version_id, position);
CREATE INDEX ix_editorial_block_product_order ON editorial.article_block_product USING btree (article_block_id, position);
CREATE INDEX ix_editorial_block_product_reverse ON editorial.article_block_product USING btree (product_id);
CREATE INDEX ix_editorial_article_block_product_offer_id ON editorial.article_block_product USING btree (offer_id);
CREATE INDEX ix_editorial_comparison_product ON editorial.comparison_value USING btree (product_id, comparison_axis_id);
CREATE INDEX ix_editorial_comparison_value_source_fact_id ON editorial.comparison_value USING btree (source_fact_id);
CREATE INDEX ix_editorial_rec_product_reverse ON editorial.recommendation USING btree (product_id);
CREATE INDEX ix_editorial_rationale_order ON editorial.recommendation_rationale USING btree (recommendation_id, position);
CREATE INDEX ix_editorial_recommendation_rationale_claim_id ON editorial.recommendation_rationale USING btree (claim_id);
CREATE INDEX ix_editorial_recommendation_rationale_source_fact_id ON editorial.recommendation_rationale USING btree (source_fact_id);
CREATE INDEX ix_editorial_review_thread ON editorial.review_comment USING btree (thread_id, created_at);
CREATE INDEX ix_editorial_review_open ON editorial.review_comment USING btree (article_version_id, status) WHERE status = 'OPEN';
CREATE INDEX ix_editorial_review_comment_article_block_id ON editorial.review_comment USING btree (article_block_id);
CREATE INDEX ix_editorial_review_comment_claim_id ON editorial.review_comment USING btree (claim_id);
CREATE INDEX ix_editorial_review_comment_parent_comment_id ON editorial.review_comment USING btree (parent_comment_id);
CREATE INDEX ix_editorial_review_comment_author_principal_id ON editorial.review_comment USING btree (author_principal_id);
CREATE INDEX ix_editorial_review_comment_resolved_by_principal_id ON editorial.review_comment USING btree (resolved_by_principal_id);
CREATE INDEX ix_editorial_article_link_to ON editorial.article_link USING btree (to_article_id, status);
CREATE UNIQUE INDEX uq_ai_prompt_active ON ai.prompt_version USING btree (prompt_code) WHERE status = 'ACTIVE';
CREATE INDEX ix_ai_prompt_task ON ai.prompt_version USING btree (task_definition_id, status);
CREATE INDEX ix_ai_prompt_version_approved_by_principal_id ON ai.prompt_version USING btree (approved_by_principal_id);
CREATE UNIQUE INDEX uq_ai_output_schema_active ON ai.output_schema_version USING btree (schema_code) WHERE status = 'ACTIVE';
CREATE INDEX ix_ai_model_status ON ai.model_definition USING btree (provider_code, status);
CREATE UNIQUE INDEX uq_ai_route_active ON ai.model_route_version USING btree (route_code) WHERE status = 'ACTIVE';
CREATE INDEX ix_ai_route_task ON ai.model_route_version USING btree (task_definition_id, status);
CREATE INDEX ix_ai_model_route_version_primary_model_id ON ai.model_route_version USING btree (primary_model_id);
CREATE INDEX ix_ai_model_route_version_fallback_model_id ON ai.model_route_version USING btree (fallback_model_id);
CREATE INDEX ix_ai_model_route_version_approved_by_principal_id ON ai.model_route_version USING btree (approved_by_principal_id);
CREATE INDEX ix_ai_job_status ON ai.ai_job USING btree (status, created_at);
CREATE INDEX ix_ai_job_article ON ai.ai_job USING btree (article_plan_id, article_version_id);
CREATE INDEX ix_ai_ai_job_task_definition_id ON ai.ai_job USING btree (task_definition_id);
CREATE INDEX ix_ai_ai_job_article_version_id ON ai.ai_job USING btree (article_version_id);
CREATE INDEX ix_ai_ai_job_source_packet_version_id ON ai.ai_job USING btree (source_packet_version_id);
CREATE INDEX ix_ai_ai_job_prompt_version_id ON ai.ai_job USING btree (prompt_version_id);
CREATE INDEX ix_ai_ai_job_output_schema_version_id ON ai.ai_job USING btree (output_schema_version_id);
CREATE INDEX ix_ai_ai_job_model_route_version_id ON ai.ai_job USING btree (model_route_version_id);
CREATE INDEX ix_ai_attempt_model_time ON ai.ai_attempt USING btree (model_id, started_at);
CREATE INDEX ix_ai_attempt_status ON ai.ai_attempt USING btree (status, started_at);
CREATE INDEX ix_ai_ai_attempt_input_artifact_id ON ai.ai_attempt USING btree (input_artifact_id);
CREATE INDEX ix_ai_ai_attempt_output_artifact_id ON ai.ai_attempt USING btree (output_artifact_id);
CREATE INDEX ix_ai_usage_observed ON ai.usage_cost USING btree (observed_at);
CREATE INDEX ix_ai_eval_route ON ai.evaluation_result USING btree (model_route_version_id, created_at);
CREATE INDEX ix_ai_eval_run ON ai.evaluation_result USING btree (run_id, case_key);
CREATE INDEX ix_ai_evaluation_result_task_definition_id ON ai.evaluation_result USING btree (task_definition_id);
CREATE INDEX ix_ai_evaluation_result_prompt_version_id ON ai.evaluation_result USING btree (prompt_version_id);
CREATE INDEX ix_ai_evaluation_result_result_artifact_id ON ai.evaluation_result USING btree (result_artifact_id);
CREATE UNIQUE INDEX uq_policy_bundle_active ON policy.policy_bundle USING btree (bundle_code) WHERE status = 'ACTIVE';
CREATE INDEX ix_policy_policy_bundle_approved_by_principal_id ON policy.policy_bundle USING btree (approved_by_principal_id);
CREATE INDEX ix_policy_rule_version_created_by_principal_id ON policy.rule_version USING btree (created_by_principal_id);
CREATE INDEX ix_policy_rule_version_approved_by_principal_id ON policy.rule_version USING btree (approved_by_principal_id);
CREATE INDEX ix_policy_bundle_rule_rule_version_id ON policy.bundle_rule USING btree (rule_version_id);
CREATE INDEX ix_policy_check_article ON policy.quality_check_run USING btree (article_version_id, started_at);
CREATE INDEX ix_policy_check_status ON policy.quality_check_run USING btree (status, started_at);
CREATE INDEX ix_policy_quality_check_run_source_packet_version_id ON policy.quality_check_run USING btree (source_packet_version_id);
CREATE INDEX ix_policy_quality_check_run_policy_bundle_id ON policy.quality_check_run USING btree (policy_bundle_id);
CREATE INDEX ix_policy_quality_check_run_report_artifact_id ON policy.quality_check_run USING btree (report_artifact_id);
CREATE INDEX ix_policy_finding_open ON policy.finding USING btree (quality_check_run_id, is_blocking, severity) WHERE status = 'OPEN';
CREATE INDEX ix_policy_finding_entity ON policy.finding USING btree (entity_type, entity_id);
CREATE INDEX ix_policy_finding_rule_version_id ON policy.finding USING btree (rule_version_id);
CREATE INDEX ix_policy_finding_article_block_id ON policy.finding USING btree (article_block_id);
CREATE INDEX ix_policy_finding_claim_id ON policy.finding USING btree (claim_id);
CREATE INDEX ix_policy_finding_resolved_by_principal_id ON policy.finding USING btree (resolved_by_principal_id);
CREATE INDEX ix_policy_waiver_active ON policy.waiver USING btree (scope_type, scope_id, status, expires_at);
CREATE INDEX ix_policy_waiver_finding_id ON policy.waiver USING btree (finding_id);
CREATE INDEX ix_policy_waiver_requested_by_principal_id ON policy.waiver USING btree (requested_by_principal_id);
CREATE INDEX ix_policy_waiver_decided_by_principal_id ON policy.waiver USING btree (decided_by_principal_id);
CREATE INDEX ix_policy_gate_scope ON policy.gate_decision USING btree (gate_code, scope_type, scope_id, decided_at);
CREATE INDEX ix_policy_gate_decision_policy_bundle_id ON policy.gate_decision USING btree (policy_bundle_id);
CREATE INDEX ix_policy_gate_decision_evidence_artifact_id ON policy.gate_decision USING btree (evidence_artifact_id);
CREATE INDEX ix_policy_gate_decision_decided_by_principal_id ON policy.gate_decision USING btree (decided_by_principal_id);
CREATE INDEX ix_publishing_review_assignment_queue ON publishing.review_assignment USING btree (assigned_to_principal_id, status, priority, due_at);
CREATE INDEX ix_publishing_review_assignment_article_version_id ON publishing.review_assignment USING btree (article_version_id);
CREATE INDEX ix_publishing_review_assignment_assigned_by_principal_id ON publishing.review_assignment USING btree (assigned_by_principal_id);
CREATE INDEX ix_publishing_review_decision_version ON publishing.review_decision USING btree (article_version_id, decided_at);
CREATE INDEX ix_publishing_review_decision_review_assignment_id ON publishing.review_decision USING btree (review_assignment_id);
CREATE INDEX ix_publishing_review_decision_decision_artifact_id ON publishing.review_decision USING btree (decision_artifact_id);
CREATE INDEX ix_publishing_review_decision_decided_by_principal_id ON publishing.review_decision USING btree (decided_by_principal_id);
CREATE INDEX ix_publishing_review_decision_supersedes_decision_id ON publishing.review_decision USING btree (supersedes_decision_id);
CREATE INDEX ix_publishing_approval_active_candidate ON publishing.approval USING btree (article_version_id, approval_type, approved_at) WHERE decision = 'APPROVED';
CREATE INDEX ix_publishing_approval_version ON publishing.approval USING btree (article_version_id, approved_at);
CREATE INDEX ix_publishing_approval_quality_check_run_id ON publishing.approval USING btree (quality_check_run_id);
CREATE INDEX ix_publishing_approval_policy_bundle_id ON publishing.approval USING btree (policy_bundle_id);
CREATE INDEX ix_publishing_approval_approved_by_principal_id ON publishing.approval USING btree (approved_by_principal_id);
CREATE INDEX ix_publishing_approval_revoked_by_principal_id ON publishing.approval USING btree (revoked_by_principal_id);
CREATE INDEX ix_publishing_approval_supersedes_approval_id ON publishing.approval USING btree (supersedes_approval_id);
CREATE INDEX ix_publishing_candidate_queue ON publishing.publication_candidate USING btree (site_id, status, requested_at);
CREATE INDEX ix_publishing_publication_candidate_article_version_id ON publishing.publication_candidate USING btree (article_version_id);
CREATE INDEX ix_publishing_publication_candidate_final_approval_id ON publishing.publication_candidate USING btree (final_approval_id);
CREATE INDEX ix_publishing_publication_candidate_quality_check_run_id ON publishing.publication_candidate USING btree (quality_check_run_id);
CREATE INDEX ix_publishing_publication_candidate_requested_by_principal_id ON publishing.publication_candidate USING btree (requested_by_principal_id);
CREATE INDEX ix_publishing_publication_candidate_snapshot_build_job_id ON publishing.publication_candidate USING btree (snapshot_build_job_id);
CREATE INDEX ix_publishing_publication_candidate_publication_snapshot_id ON publishing.publication_candidate USING btree (publication_snapshot_id);
CREATE INDEX ix_publishing_snapshot_article ON publishing.publication_snapshot USING btree (article_id, built_at);
CREATE INDEX ix_publishing_publication_snapshot_article_version_id ON publishing.publication_snapshot USING btree (article_version_id);
CREATE INDEX ix_publishing_publication_snapshot_publication_candidate_id ON publishing.publication_snapshot USING btree (publication_candidate_id);
CREATE INDEX ix_publishing_publication_snapshot_source_packet_version_id ON publishing.publication_snapshot USING btree (source_packet_version_id);
CREATE INDEX ix_publishing_publication_snapshot_policy_bundle_id ON publishing.publication_snapshot USING btree (policy_bundle_id);
CREATE INDEX ix_publishing_publication_snapshot_quality_check_run_id ON publishing.publication_snapshot USING btree (quality_check_run_id);
CREATE INDEX ix_publishing_publication_snapshot_final_approval_id ON publishing.publication_snapshot USING btree (final_approval_id);
CREATE INDEX ix_publishing_publication_snapshot_built_by_job_id ON publishing.publication_snapshot USING btree (built_by_job_id);
CREATE INDEX ix_publishing_publication_state ON publishing.publication USING btree (site_id, state, last_published_at);
CREATE INDEX ix_publishing_publication_article_id ON publishing.publication USING btree (article_id);
CREATE INDEX ix_publishing_publication_current_snapshot_id ON publishing.publication USING btree (current_snapshot_id);
CREATE INDEX ix_publishing_publication_current_route_id ON publishing.publication USING btree (current_route_id);
CREATE INDEX ix_publishing_event_publication ON publishing.publication_event USING btree (publication_id, occurred_at);
CREATE INDEX ix_publishing_event_corr ON publishing.publication_event USING btree (correlation_id);
CREATE INDEX ix_publishing_publication_event_from_snapshot_id ON publishing.publication_event USING btree (from_snapshot_id);
CREATE INDEX ix_publishing_publication_event_to_snapshot_id ON publishing.publication_event USING btree (to_snapshot_id);
CREATE INDEX ix_publishing_publication_event_publication_candidate_id ON publishing.publication_event USING btree (publication_candidate_id);
CREATE INDEX ix_publishing_publication_event_release_id ON publishing.publication_event USING btree (release_id);
CREATE UNIQUE INDEX ux_publishing_route_active_path ON publishing.public_route USING btree (site_id, path) WHERE status = 'ACTIVE';
CREATE INDEX ix_publishing_route_article ON publishing.public_route USING btree (article_id, status);
CREATE INDEX ix_publishing_public_route_publication_id ON publishing.public_route USING btree (publication_id);
CREATE INDEX ix_publishing_public_route_redirect_target_route_id ON publishing.public_route USING btree (redirect_target_route_id);
CREATE INDEX ix_publishing_rollback_publication ON publishing.rollback_record USING btree (publication_id, requested_at);
CREATE INDEX ix_publishing_rollback_record_from_snapshot_id ON publishing.rollback_record USING btree (from_snapshot_id);
CREATE INDEX ix_publishing_rollback_record_to_snapshot_id ON publishing.rollback_record USING btree (to_snapshot_id);
CREATE INDEX ix_publishing_rollback_record_incident_id ON publishing.rollback_record USING btree (incident_id);
CREATE INDEX ix_publishing_rollback_record_requested_by_principal_id ON publishing.rollback_record USING btree (requested_by_principal_id);
CREATE INDEX ix_publishing_rollback_record_approved_by_principal_id ON publishing.rollback_record USING btree (approved_by_principal_id);
CREATE INDEX ix_publishing_rollback_record_executed_by_principal_id ON publishing.rollback_record USING btree (executed_by_principal_id);
CREATE INDEX ix_freshness_policy_lookup ON freshness.freshness_policy USING btree (site_id, category_id, fact_type, effective_from);
CREATE INDEX ix_freshness_freshness_policy_category_id ON freshness.freshness_policy USING btree (category_id);
CREATE INDEX ix_freshness_freshness_policy_created_by_principal_id ON freshness.freshness_policy USING btree (created_by_principal_id);
CREATE INDEX ix_freshness_schedule_due ON freshness.refresh_schedule USING btree (status, next_due_at, priority) WHERE status = 'ACTIVE';
CREATE INDEX ix_freshness_refresh_schedule_freshness_policy_id ON freshness.refresh_schedule USING btree (freshness_policy_id);
CREATE INDEX ix_freshness_run_site ON freshness.refresh_run USING btree (site_id, started_at);
CREATE INDEX ix_freshness_refresh_run_report_artifact_id ON freshness.refresh_run USING btree (report_artifact_id);
CREATE INDEX ix_freshness_assessment_target ON freshness.staleness_assessment USING btree (target_type, target_id, assessed_at);
CREATE INDEX ix_freshness_assessment_critical ON freshness.staleness_assessment USING btree (site_id, freshness_status, assessed_at) WHERE freshness_status IN ('CRITICAL','UNKNOWN');
CREATE INDEX ix_freshness_staleness_assessment_freshness_policy_id ON freshness.staleness_assessment USING btree (freshness_policy_id);
CREATE INDEX ix_freshness_staleness_assessment_refresh_run_id ON freshness.staleness_assessment USING btree (refresh_run_id);
CREATE INDEX ix_freshness_link_offer ON freshness.link_check USING btree (offer_id, checked_at);
CREATE INDEX ix_freshness_link_invalid ON freshness.link_check USING btree (site_id, result, checked_at) WHERE result <> 'VALID';
CREATE INDEX ix_freshness_link_check_affiliate_link_observation_id ON freshness.link_check USING btree (affiliate_link_observation_id);
CREATE INDEX ix_freshness_link_check_refresh_run_id ON freshness.link_check USING btree (refresh_run_id);
CREATE INDEX ix_freshness_link_check_response_artifact_id ON freshness.link_check USING btree (response_artifact_id);
CREATE INDEX ix_freshness_impact_open ON freshness.impact_assessment USING btree (impact_level, detected_at) WHERE resolved_at IS NULL;
CREATE INDEX ix_freshness_impact_article ON freshness.impact_assessment USING btree (article_id, detected_at);
CREATE INDEX ix_freshness_impact_assessment_article_version_id ON freshness.impact_assessment USING btree (article_version_id);
CREATE INDEX ix_freshness_impact_assessment_claim_id ON freshness.impact_assessment USING btree (claim_id);
CREATE INDEX ix_freshness_impact_assessment_publication_id ON freshness.impact_assessment USING btree (publication_id);
CREATE INDEX ix_freshness_impact_assessment_resolved_by_job_id ON freshness.impact_assessment USING btree (resolved_by_job_id);
CREATE INDEX ix_analytics_event_site_date ON analytics.anonymous_event USING btree (site_id, business_date, event_type);
CREATE INDEX ix_analytics_event_article ON analytics.anonymous_event USING btree (article_id, occurred_at);
CREATE INDEX ix_analytics_event_received ON analytics.anonymous_event USING btree (received_at);
CREATE INDEX ix_analytics_anonymous_event_article_version_id ON analytics.anonymous_event USING btree (article_version_id);
CREATE INDEX ix_analytics_anonymous_event_publication_snapshot_id ON analytics.anonymous_event USING btree (publication_snapshot_id);
CREATE INDEX ix_analytics_anonymous_event_product_id ON analytics.anonymous_event USING btree (product_id);
CREATE INDEX ix_analytics_anonymous_event_offer_id ON analytics.anonymous_event USING btree (offer_id);
CREATE INDEX ix_analytics_click_article_date ON analytics.affiliate_click_event USING btree (article_id, business_date);
CREATE INDEX ix_analytics_click_offer_date ON analytics.affiliate_click_event USING btree (offer_id, business_date);
CREATE INDEX ix_analytics_affiliate_click_event_site_id ON analytics.affiliate_click_event USING btree (site_id);
CREATE INDEX ix_analytics_affiliate_click_event_article_version_id ON analytics.affiliate_click_event USING btree (article_version_id);
CREATE INDEX ix_analytics_affiliate_click_event_publication_snapshot_id ON analytics.affiliate_click_event USING btree (publication_snapshot_id);
CREATE INDEX ix_analytics_affiliate_click_event_product_id ON analytics.affiliate_click_event USING btree (product_id);
CREATE INDEX ix_analytics_affiliate_click_event_affiliate_link_ob_9ab47dc2f0 ON analytics.affiliate_click_event USING btree (affiliate_link_observation_id);
CREATE INDEX ix_analytics_import_source_date ON analytics.import_run USING btree (site_id, source_type, date_to);
CREATE INDEX ix_analytics_import_run_source_artifact_id ON analytics.import_run USING btree (source_artifact_id);
CREATE UNIQUE INDEX ux_analytics_gsc_grain ON analytics.gsc_observation USING btree (site_id, metric_date, dimension_key_sha256);
CREATE INDEX ix_analytics_gsc_page_date ON analytics.gsc_observation USING btree (site_id, page_path, metric_date);
CREATE INDEX ix_analytics_gsc_query_hash ON analytics.gsc_observation USING btree (query_sha256, metric_date);
CREATE INDEX ix_analytics_gsc_observation_import_run_id ON analytics.gsc_observation USING btree (import_run_id);
CREATE UNIQUE INDEX ux_analytics_ga4_grain ON analytics.ga4_observation USING btree (site_id, metric_date, grain_key_sha256);
CREATE INDEX ix_analytics_ga4_date ON analytics.ga4_observation USING btree (site_id, metric_date);
CREATE INDEX ix_analytics_ga4_observation_import_run_id ON analytics.ga4_observation USING btree (import_run_id);
CREATE INDEX ix_analytics_attribution_commission ON analytics.attribution_estimate USING btree (commission_id, status);
CREATE INDEX ix_analytics_attribution_article ON analytics.attribution_estimate USING btree (article_id, calculated_at);
CREATE INDEX ix_analytics_attribution_estimate_site_id ON analytics.attribution_estimate USING btree (site_id);
CREATE INDEX ix_analytics_attribution_estimate_publication_snapshot_id ON analytics.attribution_estimate USING btree (publication_snapshot_id);
CREATE INDEX ix_analytics_attribution_estimate_approved_by_principal_id ON analytics.attribution_estimate USING btree (approved_by_principal_id);
CREATE INDEX ix_analytics_attribution_estimate_calculated_by_job_id ON analytics.attribution_estimate USING btree (calculated_by_job_id);
CREATE INDEX ix_analytics_dq_open ON analytics.data_quality_finding USING btree (site_id, severity, detected_at) WHERE status = 'OPEN';
CREATE INDEX ix_analytics_data_quality_finding_import_run_id ON analytics.data_quality_finding USING btree (import_run_id);
CREATE INDEX ix_analytics_data_quality_finding_resolved_by_principal_id ON analytics.data_quality_finding USING btree (resolved_by_principal_id);
CREATE INDEX ix_analytics_daily_date ON analytics.daily_article_metric USING btree (site_id, metric_date);
CREATE INDEX ix_analytics_daily_article ON analytics.daily_article_metric USING btree (article_id, metric_date);
CREATE INDEX ix_analytics_daily_article_metric_publication_snapshot_id ON analytics.daily_article_metric USING btree (publication_snapshot_id);
CREATE INDEX ix_finance_parser_version_schema_artifact_id ON finance.parser_version USING btree (schema_artifact_id);
CREATE INDEX ix_finance_parser_version_fixture_artifact_id ON finance.parser_version USING btree (fixture_artifact_id);
CREATE INDEX ix_finance_revenue_import_period ON finance.revenue_import USING btree (site_id, period_to, status);
CREATE INDEX ix_finance_revenue_import_source_artifact_id ON finance.revenue_import USING btree (source_artifact_id);
CREATE INDEX ix_finance_revenue_import_parser_version_id ON finance.revenue_import USING btree (parser_version_id);
CREATE INDEX ix_finance_revenue_import_ops_job_id ON finance.revenue_import USING btree (ops_job_id);
CREATE INDEX ix_finance_revenue_import_confirmed_by_principal_id ON finance.revenue_import USING btree (confirmed_by_principal_id);
CREATE INDEX ix_finance_revenue_import_report_artifact_id ON finance.revenue_import USING btree (report_artifact_id);
CREATE INDEX ix_finance_revenue_row_event ON finance.revenue_import_row USING btree (provider_event_id);
CREATE INDEX ix_finance_revenue_row_status ON finance.revenue_import_row USING btree (revenue_import_id, parse_status);
CREATE INDEX ix_finance_commission_month ON finance.commission USING btree (site_id, business_month, status);
CREATE INDEX ix_finance_commission_item ON finance.commission USING btree (provider_item_code, business_month);
CREATE INDEX ix_finance_commission_source_import_row_id ON finance.commission USING btree (source_import_row_id);
CREATE INDEX ix_finance_commission_event_time ON finance.commission_event USING btree (commission_id, recorded_at);
CREATE INDEX ix_finance_commission_event_source_import_row_id ON finance.commission_event USING btree (source_import_row_id);
CREATE INDEX ix_finance_external_cost_date ON finance.external_cost USING btree (site_id, occurred_on, cost_type);
CREATE INDEX ix_finance_external_cost_article ON finance.external_cost USING btree (article_id, occurred_on);
CREATE INDEX ix_finance_external_cost_category_id ON finance.external_cost USING btree (category_id);
CREATE INDEX ix_finance_external_cost_ai_job_id ON finance.external_cost USING btree (ai_job_id);
CREATE INDEX ix_finance_external_cost_source_artifact_id ON finance.external_cost USING btree (source_artifact_id);
CREATE INDEX ix_finance_worklog_date ON finance.human_work_log USING btree (site_id, work_date, work_type);
CREATE INDEX ix_finance_worklog_article ON finance.human_work_log USING btree (article_id, work_date);
CREATE INDEX ix_finance_human_work_log_principal_id ON finance.human_work_log USING btree (principal_id);
CREATE INDEX ix_finance_human_work_log_category_id ON finance.human_work_log USING btree (category_id);
CREATE INDEX ix_finance_human_work_log_article_version_id ON finance.human_work_log USING btree (article_version_id);
CREATE INDEX ix_finance_human_work_log_approved_by_principal_id ON finance.human_work_log USING btree (approved_by_principal_id);
CREATE INDEX ix_finance_allocation_rule_approved_by_principal_id ON finance.allocation_rule USING btree (approved_by_principal_id);
CREATE INDEX ix_finance_cost_alloc_target ON finance.cost_allocation USING btree (target_type, target_id, period_month);
CREATE INDEX ix_finance_cost_allocation_allocation_rule_id ON finance.cost_allocation USING btree (allocation_rule_id);
CREATE INDEX ix_finance_cost_allocation_calculated_by_job_id ON finance.cost_allocation USING btree (calculated_by_job_id);
CREATE INDEX ix_finance_unit_econ_scope ON finance.unit_economics_snapshot USING btree (scope_type, scope_id, period_month);
CREATE INDEX ix_finance_unit_econ_site ON finance.unit_economics_snapshot USING btree (site_id, period_month, status);
CREATE INDEX ix_finance_unit_economics_snapshot_report_artifact_id ON finance.unit_economics_snapshot USING btree (report_artifact_id);
CREATE INDEX ix_finance_unit_economics_snapshot_calculated_by_job_id ON finance.unit_economics_snapshot USING btree (calculated_by_job_id);
CREATE INDEX ix_finance_unit_economics_snapshot_approved_by_principal_id ON finance.unit_economics_snapshot USING btree (approved_by_principal_id);
CREATE INDEX ix_readmodel_public_article_site ON readmodel.public_article USING btree (site_id, published_at);
CREATE INDEX ix_readmodel_public_article_publication_id ON readmodel.public_article USING btree (publication_id);
CREATE INDEX ix_readmodel_public_block_article ON readmodel.public_article_block USING btree (article_id, position);
CREATE INDEX ix_readmodel_public_card_article ON readmodel.public_product_card USING btree (article_id, position);
CREATE INDEX ix_readmodel_public_product_card_product_id ON readmodel.public_product_card USING btree (product_id);
CREATE INDEX ix_readmodel_public_offer_card ON readmodel.public_offer USING btree (public_product_card_id, position);
CREATE INDEX ix_readmodel_public_offer_offer_id ON readmodel.public_offer USING btree (offer_id);
CREATE INDEX ix_readmodel_public_offer_shop_id ON readmodel.public_offer USING btree (shop_id);
CREATE INDEX ix_readmodel_route_article ON readmodel.public_route USING btree (article_id);
CREATE UNIQUE INDEX ux_readmodel_runtime_scope ON readmodel.runtime_control USING btree (site_id, scope_type, scope_id) NULLS NOT DISTINCT;

-- Standard mutable-row timestamp and optimistic version maintenance.
CREATE OR REPLACE FUNCTION ops.touch_mutable_row() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW IS DISTINCT FROM OLD THEN
        NEW.updated_at := statement_timestamp();
        NEW.lock_version := OLD.lock_version + 1;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_ops_job_touch BEFORE UPDATE ON ops.job FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_ops_alert_touch BEFORE UPDATE ON ops.alert FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_ops_incident_touch BEFORE UPDATE ON ops.incident FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_ops_kill_switch_touch BEFORE UPDATE ON ops.kill_switch FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_iam_principal_touch BEFORE UPDATE ON iam.principal FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_portfolio_site_touch BEFORE UPDATE ON portfolio.site FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_portfolio_category_touch BEFORE UPDATE ON portfolio.category FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_portfolio_intent_cluster_touch BEFORE UPDATE ON portfolio.intent_cluster FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_portfolio_keyword_touch BEFORE UPDATE ON portfolio.keyword FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_portfolio_action_candidate_touch BEFORE UPDATE ON portfolio.action_candidate FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_rakuten_genre_touch BEFORE UPDATE ON catalog.rakuten_genre FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_shop_touch BEFORE UPDATE ON catalog.shop FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_canonical_product_touch BEFORE UPDATE ON catalog.canonical_product FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_product_candidate_touch BEFORE UPDATE ON catalog.product_candidate FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_attribute_definition_touch BEFORE UPDATE ON catalog.attribute_definition FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_catalog_offer_touch BEFORE UPDATE ON catalog.offer FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_evidence_source_touch BEFORE UPDATE ON evidence.source FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_evidence_source_packet_touch BEFORE UPDATE ON evidence.source_packet FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_editorial_article_plan_touch BEFORE UPDATE ON editorial.article_plan FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_editorial_article_touch BEFORE UPDATE ON editorial.article FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_editorial_article_version_touch BEFORE UPDATE ON editorial.article_version FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_editorial_article_link_touch BEFORE UPDATE ON editorial.article_link FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_publishing_review_assignment_touch BEFORE UPDATE ON publishing.review_assignment FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_publishing_publication_candidate_touch BEFORE UPDATE ON publishing.publication_candidate FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_publishing_publication_touch BEFORE UPDATE ON publishing.publication FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_publishing_public_route_touch BEFORE UPDATE ON publishing.public_route FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_freshness_refresh_schedule_touch BEFORE UPDATE ON freshness.refresh_schedule FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_finance_revenue_import_touch BEFORE UPDATE ON finance.revenue_import FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();
CREATE TRIGGER trg_finance_commission_touch BEFORE UPDATE ON finance.commission FOR EACH ROW EXECUTE FUNCTION ops.touch_mutable_row();

-- Hard immutable rows can only be changed during an explicit migrator maintenance window.
CREATE OR REPLACE FUNCTION ops.reject_immutable_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF current_setting('raos.allow_immutable_maintenance', true) = 'on'
       AND pg_has_role(current_user, 'raos_migrator', 'MEMBER') THEN
        IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
    END IF;
    RAISE EXCEPTION 'immutable table %.% does not allow %', TG_TABLE_SCHEMA, TG_TABLE_NAME, TG_OP
        USING ERRCODE = '55000';
END;
$$;
CREATE TRIGGER trg_analytics_affiliate_click_event_immutable BEFORE UPDATE OR DELETE ON analytics.affiliate_click_event FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_analytics_anonymous_event_immutable BEFORE UPDATE OR DELETE ON analytics.anonymous_event FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_catalog_affiliate_link_observation_immutable BEFORE UPDATE OR DELETE ON catalog.affiliate_link_observation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_catalog_availability_observation_immutable BEFORE UPDATE OR DELETE ON catalog.availability_observation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_catalog_grouping_decision_immutable BEFORE UPDATE OR DELETE ON catalog.grouping_decision FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_catalog_price_observation_immutable BEFORE UPDATE OR DELETE ON catalog.price_observation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_catalog_review_aggregate_observation_immutable BEFORE UPDATE OR DELETE ON catalog.review_aggregate_observation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_claim_evidence_link_immutable BEFORE UPDATE OR DELETE ON evidence.claim_evidence_link FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_fact_immutable BEFORE UPDATE OR DELETE ON evidence.fact FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_fact_derivation_immutable BEFORE UPDATE OR DELETE ON evidence.fact_derivation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_source_packet_fact_immutable BEFORE UPDATE OR DELETE ON evidence.source_packet_fact FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_source_packet_product_immutable BEFORE UPDATE OR DELETE ON evidence.source_packet_product FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_evidence_source_snapshot_immutable BEFORE UPDATE OR DELETE ON evidence.source_snapshot FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_finance_commission_event_immutable BEFORE UPDATE OR DELETE ON finance.commission_event FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_finance_cost_allocation_immutable BEFORE UPDATE OR DELETE ON finance.cost_allocation FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_ops_audit_event_immutable BEFORE UPDATE OR DELETE ON ops.audit_event FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_ops_kill_switch_change_immutable BEFORE UPDATE OR DELETE ON ops.kill_switch_change FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_ops_object_artifact_immutable BEFORE UPDATE OR DELETE ON ops.object_artifact FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_publishing_publication_event_immutable BEFORE UPDATE OR DELETE ON publishing.publication_event FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_publishing_publication_snapshot_immutable BEFORE UPDATE OR DELETE ON publishing.publication_snapshot FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();
CREATE TRIGGER trg_publishing_review_decision_immutable BEFORE UPDATE OR DELETE ON publishing.review_decision FOR EACH ROW EXECUTE FUNCTION ops.reject_immutable_mutation();

-- AI jobs may consume only reviewed and approved source packets.
CREATE OR REPLACE FUNCTION ai.guard_approved_source_packet() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE packet_status text;
BEGIN
    SELECT status INTO packet_status FROM evidence.source_packet_version WHERE id = NEW.source_packet_version_id;
    IF packet_status IS DISTINCT FROM 'APPROVED' THEN
        RAISE EXCEPTION 'AI job requires APPROVED source packet version; got %', packet_status USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_ai_job_approved_packet BEFORE INSERT OR UPDATE OF source_packet_version_id ON ai.ai_job FOR EACH ROW EXECUTE FUNCTION ai.guard_approved_source_packet();

-- Final approval is a human decision and requires a passed quality run with no open blockers.
CREATE OR REPLACE FUNCTION publishing.guard_final_approval() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE p_type text; q_passed boolean; q_article uuid; packet_status text; blockers bigint;
BEGIN
    IF NEW.approval_type <> 'FINAL' OR NEW.decision <> 'APPROVED' THEN RETURN NEW; END IF;
    SELECT principal_type INTO p_type FROM iam.principal WHERE id = NEW.approved_by_principal_id AND status = 'ACTIVE';
    IF p_type IS DISTINCT FROM 'USER' THEN
        RAISE EXCEPTION 'FINAL approval requires an active USER principal' USING ERRCODE='23514';
    END IF;
    IF NEW.quality_check_run_id IS NULL THEN
        RAISE EXCEPTION 'FINAL approval requires quality_check_run_id' USING ERRCODE='23514';
    END IF;
    SELECT qs.passed, qr.article_version_id INTO q_passed, q_article
      FROM policy.quality_check_run qr JOIN policy.quality_score qs ON qs.quality_check_run_id = qr.id
     WHERE qr.id = NEW.quality_check_run_id AND qr.status = 'PASSED';
    IF q_passed IS DISTINCT FROM true OR q_article IS DISTINCT FROM NEW.article_version_id THEN
        RAISE EXCEPTION 'FINAL approval requires a passed matching quality run' USING ERRCODE='23514';
    END IF;
    SELECT count(*) INTO blockers FROM policy.finding
     WHERE quality_check_run_id = NEW.quality_check_run_id AND is_blocking AND status = 'OPEN';
    IF blockers > 0 THEN RAISE EXCEPTION 'FINAL approval blocked by % open findings', blockers USING ERRCODE='23514'; END IF;
    SELECT spv.status INTO packet_status
      FROM editorial.article_version av JOIN evidence.source_packet_version spv ON spv.id = av.source_packet_version_id
     WHERE av.id = NEW.article_version_id;
    IF packet_status IS DISTINCT FROM 'APPROVED' THEN
        RAISE EXCEPTION 'FINAL approval requires APPROVED source packet' USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_publishing_final_approval BEFORE INSERT ON publishing.approval FOR EACH ROW EXECUTE FUNCTION publishing.guard_final_approval();

-- Publication candidate repeats critical checks at the database boundary.
CREATE OR REPLACE FUNCTION publishing.guard_publication_candidate() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE a publishing.approval%ROWTYPE; q_passed boolean; q_article uuid; blockers bigint; article_id_v uuid; category_id_v uuid; switch_count bigint;
BEGIN
    SELECT * INTO a FROM publishing.approval WHERE id = NEW.final_approval_id;
    IF a.id IS NULL OR a.article_version_id <> NEW.article_version_id OR a.approval_type <> 'FINAL' OR a.decision <> 'APPROVED'
       OR a.revoked_at IS NOT NULL OR (a.valid_until IS NOT NULL AND a.valid_until <= statement_timestamp()) THEN
        RAISE EXCEPTION 'invalid final approval for publication candidate' USING ERRCODE='23514';
    END IF;
    IF EXISTS (SELECT 1 FROM publishing.approval r WHERE r.supersedes_approval_id = a.id AND r.decision = 'REVOKED') THEN
        RAISE EXCEPTION 'final approval has been revoked' USING ERRCODE='23514';
    END IF;
    SELECT qs.passed, qr.article_version_id INTO q_passed, q_article
      FROM policy.quality_check_run qr JOIN policy.quality_score qs ON qs.quality_check_run_id = qr.id
     WHERE qr.id = NEW.quality_check_run_id AND qr.status = 'PASSED';
    IF q_passed IS DISTINCT FROM true OR q_article IS DISTINCT FROM NEW.article_version_id THEN
        RAISE EXCEPTION 'publication candidate quality run is not a passed matching run' USING ERRCODE='23514';
    END IF;
    SELECT count(*) INTO blockers FROM policy.finding WHERE quality_check_run_id=NEW.quality_check_run_id AND is_blocking AND status='OPEN';
    IF blockers > 0 THEN RAISE EXCEPTION 'publication blocked by open findings' USING ERRCODE='23514'; END IF;
    SELECT ar.id, ap.category_id INTO article_id_v, category_id_v
      FROM editorial.article_version av JOIN editorial.article ar ON ar.id=av.article_id JOIN editorial.article_plan ap ON ap.id=ar.article_plan_id
     WHERE av.id=NEW.article_version_id AND ar.site_id=NEW.site_id;
    IF article_id_v IS NULL THEN RAISE EXCEPTION 'article/site mismatch' USING ERRCODE='23514'; END IF;
    SELECT count(*) INTO switch_count FROM ops.kill_switch ks
     WHERE ks.is_engaged AND ks.switch_type='PUBLICATION' AND (ks.expires_at IS NULL OR ks.expires_at>statement_timestamp())
       AND ((ks.scope_type='GLOBAL' AND ks.scope_id IS NULL)
         OR (ks.scope_type='SITE' AND ks.scope_id=NEW.site_id)
         OR (ks.scope_type='CATEGORY' AND ks.scope_id=category_id_v)
         OR (ks.scope_type='ARTICLE' AND ks.scope_id=article_id_v));
    IF switch_count > 0 THEN RAISE EXCEPTION 'publication kill switch is engaged' USING ERRCODE='55000'; END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_publishing_candidate_guard BEFORE INSERT OR UPDATE OF final_approval_id, quality_check_run_id, status ON publishing.publication_candidate FOR EACH ROW EXECUTE FUNCTION publishing.guard_publication_candidate();

-- Current publication cannot transition to PUBLISHED while an applicable kill switch is engaged.
CREATE OR REPLACE FUNCTION publishing.guard_publication_transition() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE category_id_v uuid; switch_count bigint;
BEGIN
    IF NEW.state <> 'PUBLISHED' THEN RETURN NEW; END IF;
    SELECT ap.category_id INTO category_id_v FROM editorial.article ar JOIN editorial.article_plan ap ON ap.id=ar.article_plan_id WHERE ar.id=NEW.article_id;
    SELECT count(*) INTO switch_count FROM ops.kill_switch ks
     WHERE ks.is_engaged AND ks.switch_type='PUBLICATION' AND (ks.expires_at IS NULL OR ks.expires_at>statement_timestamp())
       AND ((ks.scope_type='GLOBAL' AND ks.scope_id IS NULL)
         OR (ks.scope_type='SITE' AND ks.scope_id=NEW.site_id)
         OR (ks.scope_type='CATEGORY' AND ks.scope_id=category_id_v)
         OR (ks.scope_type='ARTICLE' AND ks.scope_id=NEW.article_id));
    IF switch_count > 0 THEN RAISE EXCEPTION 'publication kill switch is engaged' USING ERRCODE='55000'; END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_publishing_transition_guard BEFORE INSERT OR UPDATE OF state, current_snapshot_id ON publishing.publication FOR EACH ROW EXECUTE FUNCTION publishing.guard_publication_transition();

-- Kill switch generation is monotonic and changes are projected through explicit application events.
CREATE OR REPLACE FUNCTION ops.guard_kill_switch_generation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP='UPDATE' AND (NEW.is_engaged IS DISTINCT FROM OLD.is_engaged OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.expires_at IS DISTINCT FROM OLD.expires_at) THEN
        NEW.generation := OLD.generation + 1;
        NEW.changed_at := statement_timestamp();
    ELSIF TG_OP='UPDATE' AND NEW.generation <> OLD.generation THEN
        RAISE EXCEPTION 'kill switch generation may only change with state/reason/expiry' USING ERRCODE='23514';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_ops_kill_switch_generation BEFORE UPDATE ON ops.kill_switch FOR EACH ROW EXECUTE FUNCTION ops.guard_kill_switch_generation();

-- Safe operational/read views.
CREATE OR REPLACE VIEW ops.v_outbox_ready AS
SELECT * FROM ops.outbox_event
 WHERE status IN ('PENDING','FAILED') AND available_at <= statement_timestamp()
 ORDER BY available_at, created_at;
CREATE OR REPLACE VIEW catalog.v_safe_offer_current AS
SELECT p.offer_id, p.product_id, o.shop_id, p.current_price_jpy, p.current_shipping_fee_jpy,
       p.current_availability, p.review_count, p.review_average, p.affiliate_url,
       p.destination_host, p.price_observed_at, p.availability_observed_at,
       p.link_observed_at, p.freshness_status, p.projection_version, p.updated_at
  FROM catalog.offer_current_projection p JOIN catalog.offer o ON o.id=p.offer_id;
CREATE OR REPLACE VIEW publishing.v_publishable_article AS
SELECT av.id AS article_version_id, av.article_id, qr.id AS quality_check_run_id, qs.total_score,
       a.id AS final_approval_id, a.approved_at
  FROM editorial.article_version av
  JOIN policy.quality_check_run qr ON qr.article_version_id=av.id AND qr.status='PASSED'
  JOIN policy.quality_score qs ON qs.quality_check_run_id=qr.id AND qs.passed
  JOIN publishing.approval a ON a.article_version_id=av.id AND a.approval_type='FINAL' AND a.decision='APPROVED'
 WHERE a.revoked_at IS NULL
   AND (a.valid_until IS NULL OR a.valid_until>statement_timestamp())
   AND NOT EXISTS (SELECT 1 FROM policy.finding f WHERE f.quality_check_run_id=qr.id AND f.is_blocking AND f.status='OPEN')
   AND NOT EXISTS (SELECT 1 FROM publishing.approval r WHERE r.supersedes_approval_id=a.id AND r.decision='REVOKED');
CREATE OR REPLACE VIEW finance.v_latest_unit_economics AS
SELECT DISTINCT ON (site_id, scope_type, scope_id, period_month) *
  FROM finance.unit_economics_snapshot
 WHERE status='APPROVED'
 ORDER BY site_id, scope_type, scope_id, period_month, calculated_at DESC;

COMMIT;
