# RAOS-AI-001 Validation Report v0.1

- Generated: `2026-07-30T12:05:28.577660+00:00`
- Scope: static artifact validation plus package integrity
- Result: `PASS`

| Status | Count |
|---|---:|
| PASS | 18 |
| ERROR | 0 |
| WARNING | 4 |

## Checks

| Status | Check | Detail |
| --- | --- | --- |
| PASS | YAML parsing | 30 YAML files parsed |
| PASS | JSON and JSON Schema validation | 36 JSON files parsed; 14 schemas meta-validated |
| PASS | Schema registry integrity | 14 schemas with unique IDs and matching hashes |
| PASS | Task schema smoke fixtures | 12 expected outputs validated |
| PASS | Bootstrap evaluation dataset | 120 structurally valid unique cases |
| PASS | Prompt registry integrity | 12 prompts with valid frontmatter, variables and hashes |
| PASS | Task dependency graph | 12 tasks map to prompt, schema, route, suite and known requirements |
| PASS | Upstream AI Job coverage | 7 upstream AI jobs accounted for; meta-jobs explicitly excluded from one-to-one task mapping |
| PASS | Expected task count | 12 bounded tasks |
| PASS | Expected prompt count | 12 prompt templates |
| PASS | Contract/evaluation test matrix | 537 test rows |
| PASS | Expected bootstrap count | 120 cases |
| PASS | Traceability matrix | 42 requirement/task trace rows |
| PASS | SQL proposal guard | explicit proposal marking and transaction boundary present |
| PASS | Markdown code fences | 24 Markdown files balanced |
| PASS | Secret and review-body content scan | no credential pattern or actual Rakuten review passage detected |
| PASS | Upstream copies | 21 inherited artifacts included |
| WARNING | Live provider integration | No OpenAI Responses API call was made in this artifact environment. |
| WARNING | Database integration | The proposal SQL was not executed against PostgreSQL 18.x. |
| WARNING | OpenAPI/AsyncAPI revision | Proposed API alignment has not been merged into a new RAOS-API version or run through a third-party compatibility CLI. |
| WARNING | Dynamic provider metadata | Model availability, pricing, retention controls and feature support must be refreshed and certified before production release. |
| PASS | ZIP and SHA-256 package integrity | ZIP CRC, member set and 97 SHA-256 entries verified. |

## Package integrity

ZIP CRC, member set and 97 SHA-256 entries verified.

## Runtime validation still required

The static PASS does not certify provider accuracy or production readiness. Codex implementation must add live/recorded provider contract tests, PostgreSQL integration tests, full OpenAPI/AsyncAPI compatibility tests, human-adjudicated evaluation datasets, release decisions, shadow/canary monitoring and rollback drills.
