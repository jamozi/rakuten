# RAOS-AI-001 Codex Kickoff — AI-SLICE-001

## Instruction

Unpack this package and treat `RAOS_05_README_v0.1.md` as the entry point. Read upstream requirements, architecture, data and API contracts before changing code.

Before changing any file, output exactly these five sections:

1. **Loaded contracts** — every RAOS-01 through RAOS-05 artifact actually read.
2. **Detected conflicts or ambiguities** — include the missing/upstream AI task/schema alignment findings.
3. **Planned files** — exact repository paths to add or change.
4. **Test plan** — static, unit, generated-artifact and CI tests.
5. **Out of scope** — explicitly list all business logic, provider calls and database changes not included.

## Implement only AI-SLICE-001

**Name:** AI contract repository bootstrap

### In scope

- Create the canonical repository layout under `contracts/ai/`.
- Copy/import the 12 task contracts, 12 prompts, 12 task schemas and two evaluation schemas without semantic simplification.
- Implement deterministic loaders for YAML, JSON Schema and prompt frontmatter.
- Verify every prompt and schema SHA-256 against its registry.
- Resolve all local `$ref` values and validate JSON Schema Draft 2020-12 documents.
- Validate the 12 schema-smoke expected outputs.
- Validate all 120 bootstrap cases against the evaluation-case schema.
- Add linting for unknown prompt variables, missing frontmatter, unknown task/route/suite references and duplicate IDs.
- Generate typed Python models or validation adapters compatible with Pydantic v2 without reducing schema constraints.
- Generate TypeScript types for task outputs; generation must be deterministic.
- Add CI jobs for contract lint, schema validation, hash verification, generated-file drift and secret/review-body scans.
- Add CODEOWNERS/PR template rules requiring AI platform plus domain-owner review for prompt/schema changes.
- Create a repository decision record describing how proposed upstream patches will be reviewed; do not apply them.

### Out of scope

- Live OpenAI or any provider API calls.
- Prompt execution, model routing, model fallback or cost accounting.
- Database migration or applying `proposals/*.sql`.
- Editing RAOS-04 OpenAPI/AsyncAPI in place.
- Article generation, policy decisions, quality scoring, publication or human-review UI.
- Training/fine-tuning, embedding/vector search, web crawling or review-body ingestion.
- Enabling prompt caching, Batch API, model judge, AIT-011 or AIT-012.

## Mandatory prohibitions

- Do not replace strict JSON Schemas with permissive `dict[str, Any]` models.
- Do not add `additionalProperties: true` to make generation easier.
- Do not change task risk levels, zero-tolerance rules, human-review requirements or route gates.
- Do not hard-code API keys, provider credentials, model prices or exchange rates.
- Do not interpret a proposal file as an approved migration or contract revision.
- Do not allow models/tools to write to approval, publication, policy, Kill Switch or finance state.
- Do not commit generated files unless CI proves deterministic regeneration.

## Definition of Done

1. A clean clone can run one documented command to validate all RAOS-05 AI contracts.
2. YAML/JSON/prompt registries load with no unknown or duplicate IDs.
3. All schema-smoke fixtures validate and at least one intentionally invalid fixture per task fails.
4. All 120 bootstrap cases validate structurally.
5. Prompt and schema hash drift fails CI.
6. Python and TypeScript generation is deterministic across two clean runs.
7. Secret and forbidden-review-body scanning fails on seeded negative fixtures and passes the package.
8. CI reports traceability from task → prompt → schema → route → evaluation suite.
9. No live provider call, database migration or business endpoint is introduced.
10. The PR includes a concise conflict report and leaves proposal artifacts unapplied.

## Required PR evidence

- Command transcript for contract validation.
- Generated artifact diff check.
- Test counts by category.
- List of unresolved upstream revisions.
- Security scan results.
- Exact files copied from this package and their hashes.
