# RAOS-API-001 契約図集

## 1. Trust Surface

```mermaid
flowchart LR
    Browser[Public Browser] -->|Public OpenAPI| CDN[CDN / WAF]
    CDN --> Public[Public Web / Public API]
    Public -->|read only| RM[(readmodel)]
    AdminUser[OIDC User] -->|Admin OpenAPI| Admin[Core API]
    Admin --> Core[(Domain schemas)]
    Scheduler[Scheduler] -->|Internal OpenAPI| Internal[Internal API]
    Internal --> Jobs[(ops.job + outbox)]
    Worker[Workers] -->|Job Message| Queue[Managed Queues]
    Queue --> Worker
    Worker --> Core
    Core -->|Domain Event| Outbox[(outbox)]
    Outbox --> EventBus[Event channels]
```

## 2. Command to Job

```mermaid
sequenceDiagram
    participant C as Admin Client
    participant A as Admin API
    participant I as Idempotency Store
    participant D as Domain DB
    participant O as Outbox
    participant Q as Queue
    participant W as Worker
    C->>A: POST Command + Idempotency-Key
    A->>I: reserve key + payload hash
    alt replay same payload
      I-->>A: stored response
      A-->>C: original 202/201
    else new command
      A->>D: validate authorization/state
      A->>D: write Job REQUESTED
      A->>O: write job_requested event
      A->>I: commit response reference
      A-->>C: 202 JobAccepted + Location
      O->>Q: dispatch Job Message
      Q->>W: at-least-once delivery
      W->>D: lease + idempotent execution
      W->>D: domain result + terminal state
      W->>O: result Domain Event
    end
```

## 3. Optimistic Concurrency

```mermaid
sequenceDiagram
    participant C1 as Editor A
    participant C2 as Editor B
    participant API as Admin API
    participant DB as PostgreSQL
    C1->>API: GET Article
    API-->>C1: ETag "v7"
    C2->>API: GET Article
    API-->>C2: ETag "v7"
    C1->>API: PATCH If-Match "v7"
    API->>DB: UPDATE WHERE lock_version=7
    DB-->>API: lock_version=8
    API-->>C1: 200 ETag "v8"
    C2->>API: PATCH If-Match "v7"
    API->>DB: UPDATE WHERE lock_version=7
    DB-->>API: 0 rows
    API-->>C2: 409 RAOS-CONC-001
```

## 4. Outbox / Inbox / Replay

```mermaid
flowchart TB
    Tx[Domain transaction] --> Domain[(Domain data)]
    Tx --> Outbox[(Outbox event)]
    Outbox --> Dispatcher[Outbox dispatcher]
    Dispatcher --> Bus[Event bus]
    Bus --> Consumer[Consumer]
    Consumer --> Inbox{Inbox key exists?}
    Inbox -- yes --> Ack[Acknowledge duplicate]
    Inbox -- no --> Apply[Apply idempotent projection]
    Apply --> SaveInbox[(Inbox receipt)]
    Apply --> Ack
    Consumer -. terminal contract/security failure .-> DLQ[DLQ / Quarantine]
    DLQ --> Human[Human triage and approved replay]
```

## 5. Evidence to Publication

```mermaid
flowchart LR
    Raw[Raw Artifact] --> Fact[Fact]
    Fact --> Packet[Approved Source Packet]
    Packet --> AI[AI Structured Draft]
    AI --> Claim[Claim extraction]
    Claim --> Evidence[Claim-Evidence links]
    Evidence --> Quality[Quality/Policy run]
    Quality --> Review[Human review]
    Review --> Approval[Final approval]
    Approval --> Candidate[Publication candidate]
    Candidate --> Snapshot[Immutable snapshot]
    Snapshot --> Projection[Public readmodel]
    Projection --> CDN[Public delivery]
```

## 6. Publish and Rollback

```mermaid
sequenceDiagram
    participant U as Publisher
    participant API as Admin API
    participant J as Publication Worker
    participant DB as Core DB
    participant RM as Public Read Model
    U->>API: POST candidate/publish + Idempotency-Key
    API->>DB: verify approval/quality/kill-switch/freshness
    API->>DB: create Job + Outbox
    API-->>U: 202 JobAccepted
    J->>DB: build/verify immutable snapshot
    J->>RM: atomic projection switch
    J->>DB: publication_event(PUBLISHED)
    Note over RM: old snapshot remains immutable
    U->>API: POST publication/rollback(to_snapshot)
    API-->>U: 202 JobAccepted
    J->>RM: atomic switch to prior verified snapshot
    J->>DB: publication_event(ROLLED_BACK)
```

## 7. Affiliate Click Beacon

```mermaid
sequenceDiagram
    participant B as Browser
    participant R as RAOS click endpoint
    participant K as Rakuten destination
    B-)R: sendBeacon(minimized event)
    B->>K: direct provider-issued affiliate URL
    Note over B,K: Navigation does not wait for RAOS
    R->>R: validate rate/schema/consent
    R-->>B: 204 (best effort)
```

## 8. Revenue Import

```mermaid
flowchart LR
    Upload[Presigned upload] --> Scan[Hash / malware / type scan]
    Scan --> Parse[Versioned parser]
    Parse --> Canon[Canonical rows]
    Canon --> Dry[Dry run and reconciliation]
    Dry --> Confirm{Human expected hash/count/amount}
    Confirm -- mismatch --> Reject[Reject / investigate]
    Confirm -- match --> Commit[Immutable provider facts]
    Commit --> Attribute[Direct / Estimated / Unattributed]
    Attribute --> Unit[Confirmed EPC / RPM / contribution profit]
```

## 9. AI Structured Output

```mermaid
flowchart TB
    Packet[Approved Source Packet] --> Orchestrator[AI Orchestrator]
    Prompt[Prompt version] --> Orchestrator
    Model[Model route version] --> Orchestrator
    Policy[Policy bundle version] --> Orchestrator
    Schema[JSON Schema] --> Orchestrator
    Orchestrator --> Provider[LLM Provider]
    Provider --> Validate{Schema + reference guard}
    Validate -- fail within budget --> Retry[Limited repair retry]
    Retry --> Provider
    Validate -- terminal fail --> Quarantine[Quarantine artifact]
    Validate -- pass --> Artifact[Immutable AI output artifact]
    Artifact --> Human[Human review / downstream quality]
```

## 10. Trace Propagation

```mermaid
flowchart LR
    HTTP[HTTP request_id / traceparent] --> Command[Domain Command correlation_id]
    Command --> Job[Job correlation_id / causation_id]
    Job --> Provider[Provider request]
    Job --> Event[Domain Event]
    Event --> Consumer[Projection / downstream Job]
    Consumer --> Audit[Audit event]
```

## 11. Contract Versioning

```mermaid
flowchart LR
    SchemaV1[message.v1] --> ConsumersV1[Consumers v1]
    SchemaV1 --> AddOptional[Add optional field]
    AddOptional --> ConsumersV1
    Breaking[Type/meaning/required change] --> SchemaV2[message.v2]
    SchemaV2 --> Dual[Time-bounded dual publish]
    Dual --> Migrate[Migrate consumers]
    Migrate --> Sunset[Sunset v1]
```
