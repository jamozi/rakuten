# RAOS-API-001 Package README

## Package purpose

RAOSのPublic/Admin/Internal HTTP、Domain Event、Worker Job、AI Structured Output、Import、External Adapterを実装可能な契約へ固定するPackageです。

## Baseline metrics

| Item | Count |
| --- | ---: |
| HTTP operations | 151 |
| Public / Admin / Internal | 6 / 141 / 4 |
| Resource contracts | 55 |
| Error codes | 66 |
| Domain events | 63 |
| Worker jobs | 39 |
| State machines | 10 |
| JSON Schemas | 126 |
| Contract test cases | 2075 |
| Traceability rows | 404 |

## Read order

1. `RAOS_04_CODEX_KICKOFF_v0.1.md`
2. `RAOS_04_api_event_job_contract_design_v0.1.md`
3. `RAOS_04_contract_diagrams_v0.1.md`
4. `RAOS_04_compatibility_policy_v0.1.yaml`
5. `RAOS_04_implementation_slices_v0.1.yaml`
6. `RAOS_04_openapi_public_v0.1.yaml`
7. `RAOS_04_openapi_admin_v0.1.yaml`
8. `RAOS_04_openapi_internal_v0.1.yaml`
9. `RAOS_04_asyncapi_v0.1.yaml`
10. `RAOS_04_*_catalog_v0.1.yaml`
11. `schemas/`
12. `RAOS_04_contract_test_matrix_v0.1.csv`
13. `RAOS_04_traceability_matrix_v0.1.csv`
14. `RAOS_04_001_contract_alignment_patch_v0.1.sql`
15. `upstream/`

## Source of truth order

1. Law / platform terms / registered-media constraints
2. RAOS-REQ-001
3. RAOS-ARCH-001
4. RAOS-DATA-001 plus accepted migrations
5. RAOS-API-001 human design and ADRs
6. OpenAPI / AsyncAPI / JSON Schema machine contracts
7. Generated code

Generated Pydantic/TypeScript files are not source of truth. Never edit them directly.

## Key boundaries

- Public API uses public read model only.
- Admin API uses human OIDC scopes and domain authorization.
- Internal API accepts workload identity only.
- Events are committed facts; Jobs are execution requests.
- AI output is an artifact, never an approval or publish command.
- Affiliate click navigation goes directly to the provider-issued URL; RAOS beacon is best effort.
- Provider facts and estimated attribution remain separate.

## Contract alignment patch

`RAOS_04_001_contract_alignment_patch_v0.1.sql` resolves the Job state mismatch found between architecture and baseline DDL. It is a proposed Expand–Migrate–Contract input. Convert it to the repository migration framework and test it against PostgreSQL 18 before use.

## Intended repository layout

```text
contracts/
  openapi/
    public.yaml
    admin.yaml
    internal.yaml
  asyncapi/
    asyncapi.yaml
  schemas/
    common/
    jobs/
    events/
    ai/
    imports/
    adapters/
  catalogs/
  fixtures/
  compatibility/
src/
  raos_api/
  raos_workers/
generated/
  python/
  typescript/
tests/
  contract/
  integration/
```

## First implementation task

Implement `API-SLICE-001` only. Establish deterministic lint, validation, code generation and drift detection. Do not implement 151 operations in one PR.

## Validation status

The package performs static YAML/JSON/JSON-Schema/reference/catalog/traceability checks. Runtime validation against the repository's actual FastAPI version, generated SDK, PostgreSQL, SQS and external provider fixtures remains an implementation gate and is documented in the validation report.
