# RAOS-API-001 静的検証レポート

- Version: 0.1
- Date: 2026-07-30
- PASS: 40
- ERROR: 0
- WARNING: 2

## 検証結果

| Check | Result | Severity | Details |
| --- | --- | --- | --- |
| YAML parse | PASS | ERROR | 14 files; errors=[] |
| JSON Schema Draft 2020-12 meta-validation | PASS | ERROR | 126 schemas; errors=[] |
| Other JSON parse | PASS | ERROR | 0 files; errors=[] |
| Schema $id uniqueness | PASS | ERROR | 126 IDs, duplicates=[] |
| Schema registry completeness | PASS | ERROR | registry=126, files=126 |
| Schema registry SHA-256 | PASS | ERROR | mismatches=[] |
| JSON Schema relative refs | PASS | ERROR | refs checked; missing=[] |
| OpenAPI public version | PASS | ERROR | 3.1.1 |
| OpenAPI admin version | PASS | ERROR | 3.1.1 |
| OpenAPI internal version | PASS | ERROR | 3.1.1 |
| OpenAPI operation counts | PASS | ERROR | {'public': 6, 'admin': 141, 'internal': 4} |
| OpenAPI operationId uniqueness | PASS | ERROR | found=151, expected=151 |
| OpenAPI refs | PASS | ERROR | errors=[] |
| HTTP idempotency/concurrency/security headers | PASS | ERROR | errors=[] |
| Public OpenAPI schema isolation | PASS | ERROR | components=10, forbidden_names=[], leaked_tokens=[] |
| OpenAPI/catalog operation set | PASS | ERROR | missing=[], extra=[] |
| Operation request/response schema existence | PASS | ERROR | missing=[] |
| AsyncAPI version | PASS | ERROR | 3.0.0 |
| AsyncAPI refs | PASS | ERROR | errors=[] |
| AsyncAPI message count | PASS | ERROR | messages=102, expected=102 |
| AsyncAPI channel count | PASS | ERROR | channels=22, expected=22 |
| Job type uniqueness | PASS | ERROR | 39 |
| Event type uniqueness | PASS | ERROR | 63 |
| Error code uniqueness | PASS | ERROR | 66 |
| Job schema files | PASS | ERROR | missing=[] |
| Event schema files | PASS | ERROR | missing=[] |
| Job emitted event existence | PASS | ERROR | missing=[] |
| Job queue allowlist | PASS | ERROR | invalid=[] |
| Contract test ID uniqueness | PASS | ERROR | 2075 tests |
| Contract test P0 coverage | PASS | ERROR | every HTTP operation has P0 contract test |
| Functional requirement traceability | PASS | ERROR | missing=[] |
| Nonfunctional requirement traceability | PASS | ERROR | missing=[] |
| Hard constraint traceability | PASS | ERROR | missing=[] |
| Job canonical states | PASS | ERROR | ['REQUESTED', 'QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED_RETRYABLE', 'RETRY_SCHEDULED', 'FAILED_TERMINAL', 'QUARANTINED', 'CANCELLED', 'EXPIRED'] |
| Alignment SQL includes all Job states | PASS | ERROR | missing=[] |
| Alignment SQL transaction guard | PASS | ERROR | BEGIN/COMMIT present |
| Markdown code fences | PASS | ERROR | unbalanced=[] |
| Unresolved placeholder scan | PASS | WARNING | hits=[] |
| Upstream files copied | PASS | ERROR | copied=21, missing=[] |
| Secret pattern scan | PASS | ERROR | hits=[] |
| Third-party semantic validator availability | FAIL | WARNING | openapi-spec-validator/prance/AsyncAPI CLI are not installed; structural and reference validation performed instead. Runtime CI must add official/toolchain validators. |
| Runtime integration validation | FAIL | WARNING | FastAPI code generation, PostgreSQL 18 migration, SQS delivery, provider fixtures and deployed authentication were not executed in this artifact environment. |

## 解釈

- `ERROR=0`は、生成した機械可読成果物の静的整合性を示す。実装の正しさや外部Providerとの実接続を保証しない。
- OpenAPI/AsyncAPI専用CLI Validatorはこの環境に未導入のため、CodexのAPI-SLICE-001で追加しCI正本とする。
- JSON SchemaはPython `jsonschema`のDraft 2020-12 meta-validatorで検証した。
- Job alignment SQLは提案Patchであり、PostgreSQL 18の実DBへ適用していない。
- 楽天、Search Console、GA4、LLM ProviderのRecorded Fixture Contract Testは実装工程で必須。
