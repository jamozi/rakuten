# Codex投入指示 — RAOS-API-001

## 依頼する範囲

**API-SLICE-001: Contract repository bootstrap だけを実装すること。**

151 Operationを一括実装しない。DB SchemaをORMから再生成しない。`RAOS_04_001_contract_alignment_patch_v0.1.sql`をProductionへ直接適用しない。

## 読み順

1. `RAOS_04_README_v0.1.md`
2. `upstream/RAOS_01_requirements_purpose_success_v0.1.md`
3. `upstream/RAOS_02_system_architecture_v0.1.md`
4. `upstream/RAOS_03_data_model_database_design_v0.1.md`
5. `RAOS_04_api_event_job_contract_design_v0.1.md`
6. `RAOS_04_compatibility_policy_v0.1.yaml`
7. `RAOS_04_implementation_slices_v0.1.yaml`
8. OpenAPI 3文書、AsyncAPI、`schemas/`、Catalog、Test Matrix

## 実装目的

このPRでは、契約をRepositoryの正本として検証・生成できる状態にする。Business RouterやProvider Callは実装しない。

## 必須成果物

- `contracts/openapi/public.yaml`
- `contracts/openapi/admin.yaml`
- `contracts/openapi/internal.yaml`
- `contracts/asyncapi/asyncapi.yaml`
- `contracts/schemas/**`
- `contracts/catalogs/**`
- Contract lint / reference resolution / compatibility check script
- Pydantic v2 model generationまたは検証用loader
- TypeScript type/client generation（build artifact。手修正禁止）
- `make contracts-lint`
- `make contracts-generate`
- `make contracts-diff`
- CI workflow
- Contract owner / breaking-change PR template

## 実装規則

1. OpenAPI、AsyncAPI、JSON Schemaを先に配置し、生成コードを正本にしない。
2. Generated outputは同一Inputから再現可能にし、再生成後のGit差分をCIで検出する。
3. Public OpenAPIにAdmin/Internal Schemaを再混入させない。
4. Schema `$id`、Operation ID、Event Type、Job Type、Error Codeの一意性を検査する。
5. relative `$ref`をRepository rootとは無関係に、Schema file基準で解決する。
6. JSON Schema Draft 2020-12を使用する。
7. `additionalProperties: false`を生成器が勝手に削除しない。
8. `type: [string, null]`等の3.1/2020-12表現をOpenAPI 3.0用nullableへ劣化変換しない。
9. OpenAPIからRouterを自動実装しない。Model/SDK/fixture生成までに限定する。
10. 現時点の静的検証結果と異なる場合、仕様を黙って修正せずIssue化する。

## Job model整合事項

`RAOS-ARCH-001`のJob状態は10状態、`RAOS-DATA-001`のBaselineは旧7状態である。`RAOS_04_001_contract_alignment_patch_v0.1.sql`を設計入力として読み、RepositoryのMigration方式に適合する新Migration案とIntegration Testだけを作る。実適用はDB担当Review後とする。

## Definition of Done

- 全OpenAPI/AsyncAPI/YAML/JSONがparse可能。
- 全SchemaがDraft 2020-12 meta-validationを通過。
- 全`$ref`が解決。
- Public/Admin/InternalのOperation数がそれぞれ6/141/4。
- Public OpenAPIのSchema componentが必要最小限で、禁止Domainを含まない。
- Event 63種、Job 39種、Error 66種がCatalogと一致。
- Contract generationを2回実行して差分なし。
- Breaking fixtureを投入するとCompatibility CIが失敗。
- `RAOS_04_contract_test_matrix_v0.1.csv`のうちAPI-SLICE-001に関係するP0が自動化。
- PR本文に要求ID、設計ID、実行Command、Test結果、未解決Issueを記載。

## 最初の応答形式

コード変更前に、以下だけを提示すること。

1. 読み込んだ契約ファイル一覧
2. 検出した不整合・曖昧点
3. 変更予定ファイル
4. Test計画
5. API-SLICE-001の対象外
